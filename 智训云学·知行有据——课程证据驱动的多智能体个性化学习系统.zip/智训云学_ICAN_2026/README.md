# 智训云学 · 2026 iCAN 智能体应用项目

基于《Python 程序设计》课程的个性化学习系统：学生提出目标，学习智能体分析画像、检索课程证据、生成资源和练习，并根据答题反馈调整学习路径。项目用 Django、MySQL、独立 Worker、科大讯飞星火及可选的 DeepSeek API 实现。

## 先运行完整界面（Windows）

1. 安装并启动 **Docker Desktop**，等引擎显示正在运行；将整个项目解压到本地目录。
2. 双击项目根目录的 **`一键启动本地演示.bat`**。首次会下载 MySQL 镜像、构建 Web/Worker 并初始化演示数据；脚本自动生成私有数据库密码、角色密码和 Django 密钥。无需单独安装 Python 或 MySQL。
3. 等浏览器打开 `http://127.0.0.1:8000/login/`；若 8000 被占用，按窗口显示的端口访问。用窗口显示的账号 `s001` 和本次学生密码登录。
4. 在学生端选择课程知识点并提交一次**新**生成任务，查看运行步骤、知识引用、资源、练习反馈和新学习路径。生成“个性化微课”后可在线播放并下载六幕分镜 MP4；语音服务不可用时会明确显示“静音分镜视频”。

**三种角色都包含在同一套程序中**：学生 `s001` 登录后进入 `/student/dashboard/`；教师 `t001` 进入 `/teacher/dashboard/`，可查看知识库、AI 资源审核和学情；管理员 `admin` 进入 `/admin/dashboard/`，可查看智能体运行、模型和任务状态。三种账号由启动器初始化，密码分别在本机私有 `deploy/local-demo.env` 的 `DEMO_STUDENT_PASSWORD`、`DEMO_TEACHER_PASSWORD`、`DEMO_ADMIN_PASSWORD` 中。切换角色时从右上角账号菜单**安全退出**，再在同一个 `/login/` 登录。启动窗口只显示学生密码；教师和管理员密码不要放进公开 ZIP、截图、录屏或 GitHub。建议按 [三端演示路线](docs/ICAN_三端演示路线.md) 录制真实的学生—教师—管理员闭环。

诊断双击 `查看本地运行状态.bat`，停止双击 `停止本地演示.bat`。停止不会删除 Docker 数据卷。本机地址只供录屏与测试，外地评委不能用此链接操作。

**从旧版更新且已运行过 Docker 时**：先在旧目录双击 `停止本地演示.bat`（不要重置数据）；把本次交付包解压到新目录，将旧目录中仅保存在电脑上的 `deploy/local-demo.env` 复制到新目录同名位置，再双击新版 `一键启动本地演示.bat`。它会重新构建 Web/Worker，沿用旧数据库卷和已配置的密钥。若不复制旧配置，程序会为保护原数据而停止启动；不要把这个私有文件上传比赛平台、GitHub 或聊天。旧微课不会自动补生成视频，须发起一次新任务。

**旧目录已删除、旧演示数据也不需要时**：在新版项目目录双击 `重置本地演示数据.bat`，确认只清理 `zhixun-ican-local` 项目后输入 `RESET`；脚本会清除该项目旧容器、MySQL 与媒体数据卷。随后双击 `一键启动本地演示.bat` 自动生成全新私有配置，再用 `配置并验证模型.bat` 重新填写星火、DeepSeek 和可选 TTS 凭据。不要在 Docker Desktop 点击“清理所有数据”，那会影响其他项目。

**首次构建遇到 `Failed to fetch` 或 `502 Bad Gateway`**：这是镜像下载 FFmpeg 依赖时的软件源错误，不是数据库或模型密钥错误。新版构建会自动重试并缓存下载文件；若网络持续故障导致失败，保持 Docker Desktop 运行，稍后再次双击 `一键启动本地演示.bat`，不需要重置数据或重填私有配置。不要运行 Docker 的全局清理命令，否则缓存也会被删除。

## 接通真正的大模型

先双击 `配置并验证模型.bat`，在打开的**本机私有文件** `deploy/local-demo.env` 中填入已经开通的星火 `SPARK_API_PASSWORD`，并把 `SPARK_MODEL` 设为有权使用的型号。DeepSeek 备用服务按需填 `AI_API_KEY`；语音按需填讯飞 `SPARK_TTS_APP_ID`、`SPARK_TTS_API_KEY`、`SPARK_TTS_API_SECRET`。保存并关闭记事本后脚本重启 Web/Worker，向已配置的服务发送最短真实请求，打印连接状态。

这些是供应商**在线 API**，不用下载模型权重，也不用在本机部署星火或 DeepSeek。没有 API 权限时仍可运行界面，但任务只能按页面标识规则降级；已有演示资源不能证明本次在线模型成功。不要把私有文件、密钥或密码放到 GitHub、录屏或聊天中。获取入口和调用细节见 [部署与模型调用说明](docs/ICAN_部署与模型调用说明.md)。

微课页面显示的是**该资源生成当时**的语音与视频结果，不是当前配置检测。填好私有文件后，务必运行 `配置并验证模型.bat`，看到 `spark-tts: SUCCESS` 再提交一次新任务生成微课；已生成的静音 MP4 不会自动补入语音。若显示 `NOT_CONFIGURED`，先核对当前运行项目的 `deploy/local-demo.env` 和 Web/Worker 重启；若显示 `FAILED`，按窗口错误检查授权、额度或网络。

## 提交给评委

[公开界面导览](https://zhixun-yunxue-ican-preview.tiffany-ball1992.chatgpt.site)展示真实历史截图，但**不是**交互式智能体站。要供评委远程登录、生成新任务，团队需按部署文档在自己的 Linux 主机与域名部署 MySQL、Web、Worker、HTTPS，外网复验后提供地址和受控学生账号。

从用户提供的 ICAN 复赛提交页看，需提交 **PDF（≤20 页、≤200 MB）**、**MP4（≤5 分钟、≤200 MB）**、以及**可运行链接或源码**；GitHub 不是必选。源码 ZIP 可直接作为源码项上传，但不能替代 MP4。现成 [18 页方案](docs/ICAN_复赛应用方案.pdf)和[五分钟视频脚本](docs/ICAN_五分钟演示脚本.md)在 `docs/`；MP4 需要在实际运行系统时录制。完整状态见[本轮验收](docs/ICAN_本轮修复与最终验收.md)。

## 文件结构

```text
一键启动本地演示.bat           Windows 主入口
配置并验证模型.bat             私有密钥编辑与真实 API 连通性验证
查看本地运行状态.bat / 停止本地演示.bat
README.md / 参赛交付导航.md
app/                         登录、学生/教师业务、评委界面
agent_learning/              智能体、知识检索、资源、路径、Worker
myproject/                   Django 配置与 URL
demo_assets/                 建立演示数据必需的样例文件
deploy/                      Dockerfile、本地/公网 Compose、HTTPS 配置模板
scripts/                     上述批处理对应的 PowerShell 实现
tools/                       初始化、方案 PDF 生成和去敏交付打包
assets/fonts/                Noto Sans SC 字体及 OFL 许可（中文视频/PDF）
docs/                        ICAN 提交材料与核心技术说明
employment_ai_platform_optimized.sql   首次空库初始化所需结构
init_db.py / upgrade_db.py / seed_demo_data.py / manage.py
requirements.txt
```

项目的历史 B1 能力保留在 `app/`；赛项展示主线是 `agent_learning/`。公网部署模板为 `deploy/public-demo.env.example`，不含真实密钥。本地私有 `deploy/local-demo.env` 自动生成并被打包规则排除。

## 源码验证与打包

在装有项目依赖、可访问测试数据库的环境运行 `python manage.py check` 与 `python manage.py test`。无需 MySQL 的打包检查可运行 `python -m unittest discover -s tools -p "test_*.py"`。生成去敏源码：`python tools/create_ican_release.py`；生成分组评委交付包：`python tools/build_ican_submission.py`。发布前检查压缩包内容，轮换任何曾包含在原始项目 ZIP 中的凭据。

PDF 成品已附在 `docs/`；如需重生，可在本机额外运行 `pip install -r tools/requirements-docs.txt` 后执行 `python tools/create_ican_proposal.py`。中文字体及许可已随源码附带，不需要手动到网上寻找。

核心技术文档：[系统设计](docs/SYSTEM_DESIGN_A3.md)、[多智能体](docs/MULTI_AGENT_ARCHITECTURE.md)、[课程知识库](docs/COURSE_KNOWLEDGE_BASE.md)、[RAG](docs/RAG_DESIGN.md)、[内容安全](docs/CONTENT_SAFETY.md)、[依赖与版权](docs/OPEN_SOURCE_NOTICE.md)、[AI 工具披露](docs/AI_CODING_DISCLOSURE.md)。[改造与交付清单](docs/ICAN_2026_改造与交付清单.md)列出待团队补齐的真实测试、用户评估和公网运行证据。
