from django.apps import AppConfig


class AgentLearningConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "agent_learning"
    verbose_name = "智训云学 A3 学习智能体"

