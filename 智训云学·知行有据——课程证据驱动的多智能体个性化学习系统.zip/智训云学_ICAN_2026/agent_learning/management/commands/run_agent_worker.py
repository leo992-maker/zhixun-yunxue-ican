"""Database-backed A3 worker with a durable heartbeat and single-worker guard."""

from __future__ import annotations

import os
import socket
import threading
import time
import uuid
from datetime import timedelta

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from django.db import close_old_connections, connection, transaction
from django.utils import timezone

from agent_learning.models import GenerationJob, WorkerHeartbeat
from agent_learning.services.redaction import sanitize_error
from app.agents.orchestrator import LearningOrchestrator


ACTIVE_WINDOW_SECONDS = 15
HEARTBEAT_INTERVAL_SECONDS = 5


def active_worker():
    cutoff = timezone.now() - timedelta(seconds=ACTIVE_WINDOW_SECONDS)
    return WorkerHeartbeat.objects.filter(status="运行中", last_seen_at__gte=cutoff).order_by("-last_seen_at").first()


def claim_job(worker=None):
    with transaction.atomic():
        job = (
            GenerationJob.objects.select_for_update(skip_locked=True)
            .filter(status="排队中")
            .order_by("created_at")
            .first()
        )
        if job:
            job.status = "已领取"
            job.current_step = "Agent Worker已领取"
            job.save(update_fields=["status", "current_step"])
            if worker:
                worker.current_job = job
                worker.last_seen_at = timezone.now()
                worker.save(update_fields=["current_job", "last_seen_at"])
        return job


def process_one_job(worker=None):
    if not connection.in_atomic_block:
        close_old_connections()
    job = claim_job(worker)
    if not job:
        return False
    try:
        LearningOrchestrator(job).process()
    except Exception as exc:
        print(f"A3任务{job.pk}失败：{sanitize_error(exc, limit=260)}")
    finally:
        if worker:
            WorkerHeartbeat.objects.filter(pk=worker.pk).update(
                current_job=None,
                last_seen_at=timezone.now(),
            )
        if not connection.in_atomic_block:
            close_old_connections()
    return True


def maintain_heartbeat(worker_id, stop_event):
    """Keep the durable heartbeat fresh while a long model call is running."""
    while not stop_event.wait(HEARTBEAT_INTERVAL_SECONDS):
        close_old_connections()
        try:
            WorkerHeartbeat.objects.filter(pk=worker_id, status="运行中").update(
                last_seen_at=timezone.now()
            )
        finally:
            close_old_connections()


class Command(BaseCommand):
    help = "运行A3数据库生成任务Worker（独立进程）"

    def add_arguments(self, parser):
        parser.add_argument("--once", action="store_true", help="最多处理一个任务后退出")
        parser.add_argument("--max-jobs", type=int, default=0, help="处理N个任务后退出；0表示持续运行")
        parser.add_argument("--allow-parallel", action="store_true", help="仅用于明确的并行Worker部署")

    def handle(self, *args, **options):
        if not options["allow_parallel"]:
            existing = active_worker()
            if existing and existing.process_id != os.getpid():
                raise CommandError("已有Agent Worker正在运行；为避免重复领取，本进程未启动。")
        now = timezone.now()
        worker_name = f"{socket.gethostname()}-{os.getpid()}-{uuid.uuid4().hex[:8]}"
        heartbeat = WorkerHeartbeat.objects.create(
            worker_name=worker_name,
            process_id=os.getpid(),
            host_name=socket.gethostname()[:120],
            status="运行中",
            started_at=now,
            last_seen_at=now,
        )
        heartbeat_stop = threading.Event()
        heartbeat_thread = threading.Thread(
            target=maintain_heartbeat,
            args=(heartbeat.pk, heartbeat_stop),
            name="a3-worker-heartbeat",
            daemon=True,
        )
        heartbeat_thread.start()
        processed = 0
        self.stdout.write(self.style.SUCCESS("智训云学 Agent Worker 已启动，心跳正常"))
        try:
            while True:
                WorkerHeartbeat.objects.filter(pk=heartbeat.pk).update(last_seen_at=timezone.now())
                found = process_one_job(heartbeat)
                if found:
                    processed += 1
                if options["once"] or (options["max_jobs"] and processed >= options["max_jobs"]):
                    break
                if not found:
                    time.sleep(max(0.2, float(getattr(settings, "A3_WORKER_POLL_SECONDS", 1.0))))
        finally:
            heartbeat_stop.set()
            heartbeat_thread.join(timeout=HEARTBEAT_INTERVAL_SECONDS + 1)
            WorkerHeartbeat.objects.filter(pk=heartbeat.pk).update(
                status="已停止",
                current_job=None,
                last_seen_at=timezone.now(),
                stopped_at=timezone.now(),
            )
        self.stdout.write(self.style.SUCCESS(f"Agent Worker 已退出，处理任务 {processed} 个"))
