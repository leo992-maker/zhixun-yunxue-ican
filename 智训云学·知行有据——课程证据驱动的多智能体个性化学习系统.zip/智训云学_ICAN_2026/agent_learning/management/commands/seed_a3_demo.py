from django.core.management.base import BaseCommand

from agent_learning.seed import seed_a3_demo_data


class Command(BaseCommand):
    help = "Seed the complete Python course and idempotent s001 A3 demo loop"

    def add_arguments(self, parser):
        parser.add_argument("--skip-worker-demo", action="store_true")

    def handle(self, *args, **options):
        summary = seed_a3_demo_data(process_demo_job=not options["skip_worker_demo"])
        self.stdout.write(self.style.SUCCESS("A3演示数据已就绪"))
        self.stdout.write(" / ".join(f"{key}={value}" for key, value in summary.items()))
