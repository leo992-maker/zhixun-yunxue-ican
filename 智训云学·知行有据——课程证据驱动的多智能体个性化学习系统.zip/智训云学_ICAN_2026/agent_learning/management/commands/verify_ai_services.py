"""Perform real minimal provider requests without printing credentials or model output."""

import tempfile
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError

from agent_learning.services.providers import DeepSeekProvider, GLMProvider, SparkProvider, SparkTTSProvider
from agent_learning.services.redaction import sanitize_error


class Command(BaseCommand):
    help = "Check configured model endpoints with real minimal requests; never print secrets"

    def add_arguments(self, parser):
        parser.add_argument("--include-tts", action="store_true", help="also generate and delete a short test MP3")
        parser.add_argument("--strict", action="store_true", help="fail unless at least one text model works and every configured service passes")

    def handle(self, *args, **options):
        text_success = 0
        failures = 0
        for label, provider in (("spark", SparkProvider()), ("glm", GLMProvider()), ("deepseek", DeepSeekProvider())):
            if not provider.configured:
                self.stdout.write(f"{label}: NOT_CONFIGURED")
                continue
            result = provider.generate(
                [{"role": "user", "content": "仅回复：连接正常"}],
                temperature=0, max_tokens=20, json_mode=False,
                prompt_version="ican-connection-check-v1", use_case="ican_connection_check",
            )
            status = "SUCCESS" if result.is_ai_generated else f"FAILED ({result.error_code})"
            self.stdout.write(f"{label}: {status}; latency_ms={result.latency_ms}; model={result.model}")
            text_success += int(result.is_ai_generated)
            failures += int(not result.is_ai_generated)
        if options["include_tts"]:
            tts = SparkTTSProvider()
            if not tts.configured:
                self.stdout.write("spark-tts: NOT_CONFIGURED")
            else:
                with tempfile.TemporaryDirectory() as folder:
                    target = Path(folder) / "connection-check.mp3"
                    try:
                        tts.synthesize("连接测试", target)
                        if target.is_file() and target.stat().st_size:
                            self.stdout.write("spark-tts: SUCCESS")
                        else:
                            self.stdout.write("spark-tts: EMPTY_OUTPUT")
                            failures += 1
                    except Exception as exc:
                        self.stdout.write(f"spark-tts: FAILED ({sanitize_error(exc, limit=80)})")
                        failures += 1
        if options["strict"] and (text_success == 0 or failures):
            raise CommandError("至少一个文本模型须成功，且所有已配置服务均须成功。")
