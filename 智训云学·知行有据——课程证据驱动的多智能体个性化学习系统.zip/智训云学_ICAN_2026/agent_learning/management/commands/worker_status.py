from django.core.management.base import BaseCommand

from agent_learning.management.commands.run_agent_worker import active_worker


class Command(BaseCommand):
    help = "检查A3 Agent Worker心跳；运行中返回0，否则返回3"

    def add_arguments(self, parser):
        parser.add_argument("--quiet", action="store_true")
        parser.add_argument("--pid", action="store_true", help="仅输出当前Worker进程号")

    def handle(self, *args, **options):
        worker = active_worker()
        if worker:
            if options["pid"]:
                self.stdout.write(str(worker.process_id))
            elif not options["quiet"]:
                self.stdout.write("Agent Worker运行中")
            return
        if not options["quiet"]:
            self.stderr.write("Agent Worker未运行")
        raise SystemExit(3)
