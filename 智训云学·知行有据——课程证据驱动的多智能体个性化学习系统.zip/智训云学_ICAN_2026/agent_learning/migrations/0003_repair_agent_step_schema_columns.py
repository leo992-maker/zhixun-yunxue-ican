from django.db import migrations


SCHEMA_COLUMNS = ("input_schema", "output_schema")


def repair_agent_step_schema_columns(apps, schema_editor):
    """Repair legacy varchar columns without touching already-correct databases.

    An early bundled upgrade script created the two AgentStep schema columns as
    varchar(80).  Migration 0002 deliberately skipped existing columns, so those
    databases retained the undersized type even though Django's migration state
    correctly described JSONField.  Validate every existing value before changing
    only the physical column type; never coerce or discard historical data.
    """

    connection = schema_editor.connection
    if connection.vendor != "mysql":
        return

    table = "a3_agent_step"
    quote = connection.ops.quote_name
    with connection.cursor() as cursor:
        tables = set(connection.introspection.table_names(cursor))
        if table not in tables:
            return

        cursor.execute(
            """
            SELECT COLUMN_NAME, DATA_TYPE
              FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = %s
               AND COLUMN_NAME IN (%s, %s)
            """,
            [table, *SCHEMA_COLUMNS],
        )
        column_types = {name: data_type.lower() for name, data_type in cursor.fetchall()}

        for column in SCHEMA_COLUMNS:
            if column_types.get(column) in {None, "json"}:
                continue
            cursor.execute(
                f"SELECT COUNT(*) FROM {quote(table)} WHERE {quote(column)} IS NULL"
            )
            null_count = cursor.fetchone()[0]
            if null_count:
                raise RuntimeError(
                    f"Cannot safely convert {table}.{column}: "
                    f"{null_count} unexpected NULL value(s) require manual review."
                )

            # Legacy rows contain a short schema name (or an empty string). Keep
            # every character exactly, representing it as a JSON string. Full
            # JSON schema objects written by the current application are already
            # valid and are left untouched.
            cursor.execute(
                f"UPDATE {quote(table)} SET {quote(column)} = JSON_QUOTE({quote(column)}) "
                f"WHERE JSON_VALID({quote(column)}) = 0"
            )
            cursor.execute(
                f"ALTER TABLE {quote(table)} "
                f"MODIFY {quote(column)} JSON NOT NULL"
            )


class Migration(migrations.Migration):
    dependencies = [
        ("agent_learning", "0002_a3_competition_rectification"),
    ]

    operations = [
        migrations.RunPython(repair_agent_step_schema_columns, migrations.RunPython.noop),
    ]
