from django.db import migrations, models


class AddFieldIfMissing(migrations.AddField):
    """Advance migration state while preserving legacy pre-created columns."""

    def database_forwards(self, app_label, schema_editor, from_state, to_state):
        model = to_state.apps.get_model(app_label, self.model_name)
        field = model._meta.get_field(self.name)
        table = model._meta.db_table
        if table in schema_editor.connection.introspection.table_names():
            with schema_editor.connection.cursor() as cursor:
                columns = {
                    item.name
                    for item in schema_editor.connection.introspection.get_table_description(cursor, table)
                }
            if field.column in columns:
                return
        return super().database_forwards(app_label, schema_editor, from_state, to_state)


def widen_legacy_resource_columns(apps, schema_editor):
    if schema_editor.connection.vendor != "mysql":
        return
    quote = schema_editor.connection.ops.quote_name
    table = "a3_personalized_resource"
    with schema_editor.connection.cursor() as cursor:
        if table not in schema_editor.connection.introspection.table_names(cursor):
            return
        # Both operations only widen storage and retain every existing value.
        cursor.execute(
            f"ALTER TABLE {quote(table)} "
            f"MODIFY {quote('generation_mode')} VARCHAR(30) NOT NULL"
        )
        cursor.execute(
            f"ALTER TABLE {quote(table)} "
            f"MODIFY {quote('revision_reason')} LONGTEXT NOT NULL"
        )


class Migration(migrations.Migration):
    dependencies = [
        ("agent_learning", "0003_repair_agent_step_schema_columns"),
    ]

    operations = [
        AddFieldIfMissing(
            model_name="personalizedresource",
            name="failure_code",
            field=models.CharField(blank=True, default="", max_length=60),
        ),
        AddFieldIfMissing(
            model_name="personalizedresource",
            name="input_tokens",
            field=models.PositiveIntegerField(default=0),
        ),
        AddFieldIfMissing(
            model_name="personalizedresource",
            name="is_ai_generated",
            field=models.BooleanField(default=False),
        ),
        AddFieldIfMissing(
            model_name="personalizedresource",
            name="is_degraded",
            field=models.BooleanField(default=False),
        ),
        AddFieldIfMissing(
            model_name="personalizedresource",
            name="latency_ms",
            field=models.PositiveIntegerField(default=0),
        ),
        AddFieldIfMissing(
            model_name="personalizedresource",
            name="output_tokens",
            field=models.PositiveIntegerField(default=0),
        ),
        AddFieldIfMissing(
            model_name="personalizedresource",
            name="prompt_version",
            field=models.CharField(blank=True, default="", max_length=40),
        ),
        migrations.RunPython(widen_legacy_resource_columns, migrations.RunPython.noop),
    ]
