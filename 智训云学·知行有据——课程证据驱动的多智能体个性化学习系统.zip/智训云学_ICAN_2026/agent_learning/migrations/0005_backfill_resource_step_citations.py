from django.db import migrations


RESOURCE_AGENTS = (
    "document_agent",
    "ppt_agent",
    "mindmap_agent",
    "question_agent",
    "reading_agent",
    "practice_agent",
    "multimodal_agent",
)


def backfill_resource_step_citations(apps, schema_editor):
    AgentSharedContext = apps.get_model("agent_learning", "AgentSharedContext")
    AgentStep = apps.get_model("agent_learning", "AgentStep")
    for shared in AgentSharedContext.objects.exclude(rag_evidence=[]).iterator():
        AgentStep.objects.filter(
            run_id=shared.run_id,
            agent__code__in=RESOURCE_AGENTS,
            citations=[],
        ).update(citations=shared.rag_evidence)


class Migration(migrations.Migration):
    dependencies = [
        ("agent_learning", "0004_resource_generation_audit_compatibility"),
    ]

    operations = [
        migrations.RunPython(backfill_resource_step_citations, migrations.RunPython.noop),
    ]
