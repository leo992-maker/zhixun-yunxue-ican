from django.db import migrations, models


def ensure_compatibility_columns(apps, schema_editor):
    """Map the legacy provider-audit columns without dropping any data."""
    table = "a3_model_provider_state"
    with schema_editor.connection.cursor() as cursor:
        columns = {
            column.name
            for column in schema_editor.connection.introspection.get_table_description(cursor, table)
        }
    model = apps.get_model("agent_learning", "ModelProviderState")
    if "last_success_at" not in columns:
        field = models.DateTimeField(blank=True, null=True)
        field.set_attributes_from_name("last_success_at")
        field.model = model
        schema_editor.add_field(model, field)
    if "last_test_result" not in columns:
        field = models.CharField(blank=True, default="", max_length=120)
        field.set_attributes_from_name("last_test_result")
        field.model = model
        schema_editor.add_field(model, field)
    elif schema_editor.connection.vendor == "mysql":
        # The delivered column had no database default, so first inserts failed.
        schema_editor.execute(
            "ALTER TABLE `a3_model_provider_state` "
            "MODIFY `last_test_result` varchar(120) NOT NULL DEFAULT ''"
        )


class Migration(migrations.Migration):
    dependencies = [("agent_learning", "0005_backfill_resource_step_citations")]

    operations = [
        migrations.SeparateDatabaseAndState(
            database_operations=[migrations.RunPython(ensure_compatibility_columns, migrations.RunPython.noop)],
            state_operations=[
                migrations.AddField(
                    model_name="modelproviderstate",
                    name="last_success_at",
                    field=models.DateTimeField(blank=True, null=True),
                ),
                migrations.AddField(
                    model_name="modelproviderstate",
                    name="last_test_result",
                    field=models.CharField(blank=True, default="", max_length=120),
                ),
            ],
        )
    ]
