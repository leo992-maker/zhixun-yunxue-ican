"""Persistent A3 domain models.

The legacy ``app`` models map an established MySQL schema with
``managed=False``.  This application owns only new ``a3_*`` tables and points
to legacy identities with ``db_constraint=False`` so migrations never mutate
or require recreation of B1 tables.
"""

from django.db import models


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class CourseKnowledgeBase(TimeStampedModel):
    course_code = models.CharField(max_length=40, unique=True)
    name = models.CharField(max_length=120)
    description = models.TextField(blank=True, default="")
    owner = models.ForeignKey(
        "app.Teacher", models.DO_NOTHING, null=True, blank=True,
        db_constraint=False, related_name="a3_knowledge_bases",
    )
    total_hours = models.PositiveIntegerField(default=48)
    status = models.CharField(max_length=20, default="已启用")
    current_version = models.PositiveIntegerField(default=1)

    class Meta:
        db_table = "a3_course_knowledge_base"
        verbose_name = "课程知识库"


class KnowledgeVersion(models.Model):
    knowledge_base = models.ForeignKey(
        CourseKnowledgeBase, models.CASCADE, related_name="versions"
    )
    version_no = models.PositiveIntegerField()
    version_label = models.CharField(max_length=60)
    change_note = models.TextField(blank=True, default="")
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_knowledge_version"
        constraints = [
            models.UniqueConstraint(
                fields=["knowledge_base", "version_no"], name="a3_unique_kb_version"
            )
        ]


class CourseChapter(TimeStampedModel):
    knowledge_base = models.ForeignKey(
        CourseKnowledgeBase, models.CASCADE, related_name="chapters"
    )
    chapter_no = models.PositiveIntegerField()
    title = models.CharField(max_length=120)
    objectives = models.JSONField(default=list)
    prerequisite_summary = models.TextField(blank=True, default="")
    lecture = models.TextField()
    example_code = models.TextField(blank=True, default="")
    common_mistakes = models.JSONField(default=list)
    exercises = models.JSONField(default=list)
    reference_answers = models.JSONField(default=list)
    practical_case = models.TextField(blank=True, default="")
    further_reading = models.JSONField(default=list)
    source_notes = models.JSONField(default=list)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "a3_course_chapter"
        ordering = ["chapter_no"]
        constraints = [
            models.UniqueConstraint(
                fields=["knowledge_base", "chapter_no"], name="a3_unique_chapter_no"
            )
        ]

    @property
    def objectives_display(self):
        return "；".join(map(str, self.objectives or []))


class KnowledgePoint(TimeStampedModel):
    chapter = models.ForeignKey(CourseChapter, models.CASCADE, related_name="points")
    point_code = models.CharField(max_length=60, unique=True)
    point_no = models.PositiveIntegerField()
    title = models.CharField(max_length=120)
    summary = models.TextField()
    difficulty = models.CharField(max_length=20, default="中等")
    estimated_minutes = models.PositiveIntegerField(default=20)
    tags = models.JSONField(default=list)
    is_active = models.BooleanField(default=True)

    class Meta:
        db_table = "a3_knowledge_point"
        ordering = ["chapter__chapter_no", "point_no"]
        constraints = [
            models.UniqueConstraint(
                fields=["chapter", "point_no"], name="a3_unique_point_no"
            )
        ]


class KnowledgePrerequisite(models.Model):
    knowledge_point = models.ForeignKey(
        KnowledgePoint, models.CASCADE, related_name="prerequisite_links"
    )
    prerequisite = models.ForeignKey(
        KnowledgePoint, models.CASCADE, related_name="dependent_links"
    )
    required_mastery = models.DecimalField(max_digits=5, decimal_places=2, default=60)
    reason = models.CharField(max_length=255, blank=True, default="")

    class Meta:
        db_table = "a3_knowledge_prerequisite"
        constraints = [
            models.UniqueConstraint(
                fields=["knowledge_point", "prerequisite"], name="a3_unique_prerequisite"
            )
        ]


class KnowledgeDocument(TimeStampedModel):
    knowledge_base = models.ForeignKey(
        CourseKnowledgeBase, models.CASCADE, related_name="documents"
    )
    version = models.ForeignKey(
        KnowledgeVersion, models.PROTECT, related_name="documents"
    )
    chapter = models.ForeignKey(
        CourseChapter, models.SET_NULL, null=True, blank=True, related_name="documents"
    )
    knowledge_point = models.ForeignKey(
        KnowledgePoint, models.SET_NULL, null=True, blank=True, related_name="documents"
    )
    title = models.CharField(max_length=180)
    file = models.FileField(upload_to="a3/knowledge/%Y/%m/", blank=True)
    extension = models.CharField(max_length=16, default="md")
    sha256 = models.CharField(max_length=64)
    source_type = models.CharField(max_length=30, default="课程自建")
    source_reference = models.CharField(max_length=500, blank=True, default="")
    status = models.CharField(max_length=30, default="已解析")
    parse_message = models.CharField(max_length=255, blank=True, default="")
    is_active = models.BooleanField(default=True)
    citation_count = models.PositiveIntegerField(default=0)
    created_by = models.ForeignKey(
        "app.Teacher", models.DO_NOTHING, null=True, blank=True,
        db_constraint=False, related_name="a3_documents",
    )

    class Meta:
        db_table = "a3_knowledge_document"
        indexes = [models.Index(fields=["knowledge_base", "is_active", "status"])]
        constraints = [
            models.UniqueConstraint(
                fields=["knowledge_base", "sha256", "version"], name="a3_unique_document_version"
            )
        ]


class KnowledgeSource(models.Model):
    document = models.ForeignKey(KnowledgeDocument, models.CASCADE, related_name="sources")
    label = models.CharField(max_length=180)
    publisher = models.CharField(max_length=120, blank=True, default="")
    original_reference = models.CharField(max_length=500, blank=True, default="")
    copyright_note = models.CharField(max_length=255, blank=True, default="")
    verified = models.BooleanField(default=False)

    class Meta:
        db_table = "a3_knowledge_source"


class KnowledgeChunk(models.Model):
    document = models.ForeignKey(KnowledgeDocument, models.CASCADE, related_name="chunks")
    chapter = models.ForeignKey(
        CourseChapter, models.SET_NULL, null=True, blank=True, related_name="chunks"
    )
    knowledge_point = models.ForeignKey(
        KnowledgePoint, models.SET_NULL, null=True, blank=True, related_name="chunks"
    )
    chunk_no = models.PositiveIntegerField()
    content = models.TextField()
    token_count = models.PositiveIntegerField(default=0)
    keywords = models.JSONField(default=list)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_knowledge_chunk"
        ordering = ["document_id", "chunk_no"]
        constraints = [
            models.UniqueConstraint(
                fields=["document", "chunk_no"], name="a3_unique_chunk_no"
            )
        ]
        indexes = [models.Index(fields=["knowledge_point", "is_active"])]


class ProfileConversation(models.Model):
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_profile_conversations",
    )
    status = models.CharField(max_length=20, default="进行中")
    extraction_mode = models.CharField(max_length=20, default="规则降级")
    started_at = models.DateTimeField(auto_now_add=True)
    ended_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "a3_profile_conversation"


class ProfileMessage(models.Model):
    conversation = models.ForeignKey(
        ProfileConversation, models.CASCADE, related_name="messages"
    )
    role = models.CharField(max_length=20)
    content = models.TextField()
    sequence = models.PositiveIntegerField()
    is_ai_generated = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_profile_message"
        ordering = ["sequence"]
        constraints = [
            models.UniqueConstraint(
                fields=["conversation", "sequence"], name="a3_unique_profile_message_seq"
            )
        ]


class ProfileDimension(TimeStampedModel):
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_profile_dimensions",
    )
    dimension_code = models.CharField(max_length=60)
    label = models.CharField(max_length=80)
    value = models.JSONField(default=dict)
    source = models.CharField(max_length=30, default="对话规则抽取")
    confidence = models.DecimalField(max_digits=4, decimal_places=3, default=0)
    evidence_message = models.ForeignKey(
        ProfileMessage, models.SET_NULL, null=True, blank=True, related_name="dimension_updates"
    )
    is_confirmed = models.BooleanField(default=False)
    is_rejected = models.BooleanField(default=False)

    class Meta:
        db_table = "a3_profile_dimension"
        constraints = [
            models.UniqueConstraint(
                fields=["student", "dimension_code"], name="a3_unique_student_dimension"
            )
        ]

    @property
    def display_value(self):
        if not isinstance(self.value, dict):
            return str(self.value or "")
        parts = []
        for label, value in self.value.items():
            readable = "、".join(map(str, value)) if isinstance(value, list) else str(value)
            parts.append(f"{label}：{readable}")
        return "；".join(parts)


class ProfileEvidence(models.Model):
    dimension = models.ForeignKey(ProfileDimension, models.CASCADE, related_name="evidence")
    message = models.ForeignKey(ProfileMessage, models.SET_NULL, null=True, blank=True)
    source_type = models.CharField(max_length=30)
    excerpt = models.TextField()
    confidence = models.DecimalField(max_digits=4, decimal_places=3, default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_profile_evidence"


class ProfileSnapshot(models.Model):
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_profile_snapshots",
    )
    dimensions = models.JSONField(default=dict)
    trigger = models.CharField(max_length=60)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_profile_snapshot"
        ordering = ["-created_at"]


class ProfileUpdateEvent(models.Model):
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_profile_update_events",
    )
    dimension_code = models.CharField(max_length=60)
    old_value = models.JSONField(default=dict)
    new_value = models.JSONField(default=dict)
    source = models.CharField(max_length=40)
    reason = models.CharField(max_length=255)
    status = models.CharField(max_length=20, default="已应用")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_profile_update_event"
        ordering = ["-created_at"]


class AgentDefinition(TimeStampedModel):
    code = models.CharField(max_length=60, unique=True)
    name = models.CharField(max_length=80)
    role_description = models.TextField()
    system_prompt_version = models.CharField(max_length=40, default="a3-v1")
    system_prompt = models.TextField(blank=True, default="")
    input_schema = models.JSONField(default=dict)
    output_schema = models.JSONField(default=dict)
    tool_list = models.JSONField(default=list)
    enabled = models.BooleanField(default=True)

    class Meta:
        db_table = "a3_agent_definition"


class AgentWorkflow(TimeStampedModel):
    code = models.CharField(max_length=60)
    name = models.CharField(max_length=120)
    version = models.CharField(max_length=30, default="1.0")
    description = models.TextField()
    step_blueprint = models.JSONField(default=list)
    enabled = models.BooleanField(default=True)

    class Meta:
        db_table = "a3_agent_workflow"
        constraints = [
            models.UniqueConstraint(fields=["code", "version"], name="a3_unique_workflow_version")
        ]


class AgentRun(models.Model):
    workflow = models.ForeignKey(AgentWorkflow, models.PROTECT, related_name="runs")
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, null=True, blank=True,
        db_constraint=False, related_name="a3_agent_runs",
    )
    learning_goal = models.CharField(max_length=255)
    input_summary = models.TextField(blank=True, default="")
    output_summary = models.TextField(blank=True, default="")
    status = models.CharField(max_length=30, default="排队中")
    provider = models.CharField(max_length=40, blank=True, default="")
    model = models.CharField(max_length=80, blank=True, default="")
    started_at = models.DateTimeField(null=True, blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)
    duration_ms = models.PositiveIntegerField(default=0)
    is_retry = models.BooleanField(default=False)
    is_degraded = models.BooleanField(default=False)
    failure_reason = models.CharField(max_length=500, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_agent_run"
        ordering = ["-created_at"]

    @property
    def duration_display(self):
        return f"{self.duration_ms / 1000:.1f}秒"


class AgentSharedContext(models.Model):
    """Versioned, auditable hand-off state shared by one agent workflow."""

    run = models.OneToOneField(AgentRun, models.CASCADE, related_name="shared_context")
    student_profile = models.JSONField(default=dict)
    learning_goal = models.JSONField(default=dict)
    course = models.JSONField(default=dict)
    chapter = models.JSONField(default=dict)
    knowledge_point = models.JSONField(default=dict)
    rag_evidence = models.JSONField(default=list)
    resource_strategy = models.JSONField(default=dict)
    selected_resource_types = models.JSONField(default=list)
    generated_artifacts = models.JSONField(default=list)
    safety_results = models.JSONField(default=list)
    review_results = models.JSONField(default=list)
    learning_path_update = models.JSONField(default=dict)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "a3_agent_shared_context"


class AgentStep(models.Model):
    run = models.ForeignKey(AgentRun, models.CASCADE, related_name="steps")
    agent = models.ForeignKey(AgentDefinition, models.PROTECT, related_name="steps")
    sequence = models.PositiveIntegerField()
    step_name = models.CharField(max_length=120)
    status = models.CharField(max_length=30, default="等待中")
    input_summary = models.TextField(blank=True, default="")
    output_summary = models.TextField(blank=True, default="")
    tools = models.JSONField(default=list)
    citations = models.JSONField(default=list)
    started_at = models.DateTimeField(null=True, blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)
    duration_ms = models.PositiveIntegerField(default=0)
    retry_count = models.PositiveSmallIntegerField(default=0)
    is_degraded = models.BooleanField(default=False)
    provider = models.CharField(max_length=40, blank=True, default="")
    model = models.CharField(max_length=80, blank=True, default="")
    prompt_version = models.CharField(max_length=40, blank=True, default="")
    input_schema = models.JSONField(default=dict)
    output_schema = models.JSONField(default=dict)
    safety_results = models.JSONField(default=dict)
    rework_info = models.JSONField(default=dict)

    class Meta:
        db_table = "a3_agent_step"
        ordering = ["sequence"]
        constraints = [
            models.UniqueConstraint(fields=["run", "sequence"], name="a3_unique_run_step")
        ]

    @property
    def duration_display(self):
        return f"{self.duration_ms / 1000:.1f}秒"

    @property
    def tools_display(self):
        values = self.tools if isinstance(self.tools, list) else []
        return "、".join(str(item) for item in values) or "无外部工具"


class AgentMessage(models.Model):
    step = models.ForeignKey(AgentStep, models.CASCADE, related_name="messages")
    sender = models.CharField(max_length=60)
    receiver = models.CharField(max_length=60)
    message_type = models.CharField(max_length=30, default="handoff")
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_agent_message"


class AgentToolCall(models.Model):
    step = models.ForeignKey(AgentStep, models.CASCADE, related_name="tool_calls")
    tool_name = models.CharField(max_length=80)
    input_summary = models.TextField(blank=True, default="")
    output_summary = models.TextField(blank=True, default="")
    status = models.CharField(max_length=30)
    duration_ms = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_agent_tool_call"


class AgentModelCall(models.Model):
    step = models.ForeignKey(AgentStep, models.CASCADE, related_name="model_calls")
    provider = models.CharField(max_length=40)
    model = models.CharField(max_length=80, blank=True, default="")
    latency_ms = models.PositiveIntegerField(default=0)
    status = models.CharField(max_length=30)
    error_code = models.CharField(max_length=60, blank=True, default="")
    prompt_version = models.CharField(max_length=40)
    is_degraded = models.BooleanField(default=False)
    retry_no = models.PositiveSmallIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_agent_model_call"


class AgentReview(models.Model):
    run = models.ForeignKey(AgentRun, models.CASCADE, related_name="reviews")
    reviewer = models.ForeignKey(AgentDefinition, models.PROTECT)
    review_type = models.CharField(max_length=30)
    result = models.CharField(max_length=20)
    score = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    issues = models.JSONField(default=list)
    suggestions = models.JSONField(default=list)
    triggered_rework = models.BooleanField(default=False)
    review_round = models.PositiveSmallIntegerField(default=1)
    rework_target = models.CharField(max_length=60, blank=True, default="")
    resource = models.ForeignKey(
        "PersonalizedResource", models.SET_NULL, null=True, blank=True,
        related_name="quality_reviews",
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_agent_review"


class PersonalizedResource(TimeStampedModel):
    RESOURCE_TYPES = [
        ("document", "个性化讲解文档"), ("ppt", "个性化PPT课件"),
        ("mindmap", "知识点思维导图"), ("quiz", "多类型练习题库"),
        ("reading", "拓展阅读材料"), ("practice", "Python代码实操案例"),
        ("microcourse", "多模态微课资源"),
    ]
    knowledge_base = models.ForeignKey(
        CourseKnowledgeBase, models.PROTECT, related_name="resources"
    )
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_personalized_resources",
    )
    knowledge_point = models.ForeignKey(
        KnowledgePoint, models.PROTECT, related_name="resources"
    )
    resource_type = models.CharField(max_length=24, choices=RESOURCE_TYPES)
    title = models.CharField(max_length=180)
    summary = models.TextField()
    adaptation_reason = models.TextField(blank=True, default="")
    content = models.JSONField(default=dict)
    rendered_html = models.TextField(blank=True, default="")
    suitable_for = models.CharField(max_length=255)
    learning_objective = models.CharField(max_length=255)
    difficulty = models.CharField(max_length=20, default="中等")
    estimated_minutes = models.PositiveIntegerField(default=15)
    source_type = models.CharField(max_length=30, default="规则降级")
    generation_mode = models.CharField(max_length=30, default="RULE_FALLBACK")
    is_ai_generated = models.BooleanField(default=False)
    is_degraded = models.BooleanField(default=False)
    failure_code = models.CharField(max_length=60, blank=True, default="")
    latency_ms = models.PositiveIntegerField(default=0)
    input_tokens = models.PositiveIntegerField(default=0)
    output_tokens = models.PositiveIntegerField(default=0)
    prompt_version = models.CharField(max_length=40, blank=True, default="")
    confidence_status = models.CharField(max_length=20, default="依据部分充分")
    provider = models.CharField(max_length=40, blank=True, default="")
    model = models.CharField(max_length=80, blank=True, default="")
    citations = models.JSONField(default=list)
    file_path = models.CharField(max_length=500, blank=True, default="")
    audio_path = models.CharField(max_length=500, blank=True, default="")
    audio_generation_status = models.CharField(max_length=60, default="未生成")
    video_generation_status = models.CharField(max_length=60, default="未生成")
    version_no = models.PositiveIntegerField(default=1)
    parent = models.ForeignKey(
        "self", models.SET_NULL, null=True, blank=True, related_name="versions"
    )
    generation_key = models.CharField(max_length=80, unique=True)
    is_demo_preset = models.BooleanField(default=False)
    is_favorite = models.BooleanField(default=False)
    review_status = models.CharField(max_length=30, default="待教师审核")
    reviewed_by = models.ForeignKey(
        "app.Teacher", models.DO_NOTHING, null=True, blank=True,
        db_constraint=False, related_name="a3_reviewed_resources",
    )
    review_note = models.TextField(blank=True, default="")
    revision_reason = models.TextField(blank=True, default="")
    difference_summary = models.TextField(blank=True, default="")

    class Meta:
        db_table = "a3_personalized_resource"
        indexes = [models.Index(fields=["student", "resource_type", "review_status"])]

    @property
    def generation_source_label(self):
        if self.is_demo_preset or self.generation_mode == "DEMO_PRESET":
            return "演示预置资源，非本次在线AI生成"
        if self.generation_mode == "ONLINE_SPARK":
            return "讯飞星火在线生成"
        if self.generation_mode == "ONLINE_FALLBACK":
            return "DeepSeek备用生成"
        return "规则降级生成，本次未调用在线模型"


class ResourceCitation(models.Model):
    resource = models.ForeignKey(PersonalizedResource, models.CASCADE, related_name="citation_records")
    chunk = models.ForeignKey(KnowledgeChunk, models.PROTECT, related_name="resource_citations")
    document = models.ForeignKey(KnowledgeDocument, models.PROTECT)
    chapter = models.ForeignKey(CourseChapter, models.PROTECT)
    knowledge_point = models.ForeignKey(KnowledgePoint, models.PROTECT)
    chunk_no = models.PositiveIntegerField()
    relevance = models.DecimalField(max_digits=6, decimal_places=5)
    document_version = models.PositiveIntegerField()

    class Meta:
        db_table = "a3_resource_citation"
        constraints = [
            models.UniqueConstraint(fields=["resource", "chunk"], name="a3_unique_resource_chunk")
        ]


class ResourceFeedback(models.Model):
    resource = models.ForeignKey(PersonalizedResource, models.CASCADE, related_name="feedback")
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_resource_feedback",
    )
    useful = models.BooleanField(null=True, blank=True)
    rating = models.PositiveSmallIntegerField(null=True, blank=True)
    comment = models.CharField(max_length=500, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_resource_feedback"


class QuestionBank(TimeStampedModel):
    resource = models.OneToOneField(
        PersonalizedResource, models.CASCADE, related_name="question_bank"
    )
    title = models.CharField(max_length=180)
    pass_score = models.PositiveIntegerField(default=60)

    class Meta:
        db_table = "a3_question_bank"


class Question(models.Model):
    bank = models.ForeignKey(QuestionBank, models.CASCADE, related_name="questions")
    question_type = models.CharField(max_length=24)
    sequence = models.PositiveIntegerField()
    stem = models.TextField()
    options = models.JSONField(default=list)
    correct_answer = models.JSONField(default=list)
    explanation = models.TextField()
    difficulty = models.CharField(max_length=20)
    knowledge_point = models.ForeignKey(KnowledgePoint, models.PROTECT)
    design_purpose = models.CharField(max_length=255)
    profile_fit_reason = models.CharField(max_length=255)

    class Meta:
        db_table = "a3_question"
        ordering = ["sequence"]
        constraints = [
            models.UniqueConstraint(fields=["bank", "sequence"], name="a3_unique_question_seq")
        ]

    @property
    def question_type_display(self):
        return {
            "single": "单项选择题",
            "multiple": "多项选择题",
            "true_false": "判断题",
            "fill": "填空题",
            "short": "简答题",
            "code": "代码实践题",
        }.get(self.question_type, "综合练习题")

    @property
    def input_type(self):
        return "checkbox" if self.question_type == "multiple" else "radio"


class QuizAttempt(models.Model):
    bank = models.ForeignKey(QuestionBank, models.PROTECT, related_name="attempts")
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_quiz_attempts",
    )
    score = models.DecimalField(max_digits=6, decimal_places=2, default=0)
    correct_count = models.PositiveIntegerField(default=0)
    total_count = models.PositiveIntegerField(default=0)
    duration_seconds = models.PositiveIntegerField(default=0)
    status = models.CharField(max_length=20, default="进行中")
    started_at = models.DateTimeField(auto_now_add=True)
    submitted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "a3_quiz_attempt"


class QuizAnswer(models.Model):
    attempt = models.ForeignKey(QuizAttempt, models.CASCADE, related_name="answers")
    question = models.ForeignKey(Question, models.PROTECT)
    answer = models.JSONField(default=list)
    is_correct = models.BooleanField(default=False)
    duration_seconds = models.PositiveIntegerField(default=0)
    answered_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_quiz_answer"
        constraints = [
            models.UniqueConstraint(fields=["attempt", "question"], name="a3_unique_attempt_answer")
        ]


class WrongQuestion(models.Model):
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_wrong_questions",
    )
    question = models.ForeignKey(Question, models.CASCADE, related_name="wrong_book_entries")
    latest_answer = models.JSONField(default=list)
    wrong_count = models.PositiveIntegerField(default=1)
    mastered = models.BooleanField(default=False)
    updated_at = models.DateTimeField(auto_now=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_wrong_question"
        constraints = [
            models.UniqueConstraint(fields=["student", "question"], name="a3_unique_wrong_question")
        ]


class KnowledgeMastery(TimeStampedModel):
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_masteries",
    )
    knowledge_point = models.ForeignKey(KnowledgePoint, models.CASCADE, related_name="masteries")
    mastery = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    confidence = models.DecimalField(max_digits=4, decimal_places=3, default=0)
    attempts = models.PositiveIntegerField(default=0)
    correct_count = models.PositiveIntegerField(default=0)
    consecutive_errors = models.PositiveIntegerField(default=0)
    last_reason = models.CharField(max_length=255, blank=True, default="")

    class Meta:
        db_table = "a3_knowledge_mastery"
        constraints = [
            models.UniqueConstraint(fields=["student", "knowledge_point"], name="a3_unique_mastery")
        ]


class LearningGoal(TimeStampedModel):
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_learning_goals",
    )
    knowledge_base = models.ForeignKey(CourseKnowledgeBase, models.PROTECT)
    title = models.CharField(max_length=180)
    description = models.TextField(blank=True, default="")
    target_date = models.DateField(null=True, blank=True)
    weekly_minutes = models.PositiveIntegerField(default=210)
    status = models.CharField(max_length=20, default="进行中")

    class Meta:
        db_table = "a3_learning_goal"


class PersonalizedLearningPlan(models.Model):
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_learning_plans",
    )
    goal = models.ForeignKey(LearningGoal, models.PROTECT, related_name="plans")
    version_no = models.PositiveIntegerField(default=1)
    previous_plan = models.ForeignKey(
        "self", models.SET_NULL, null=True, blank=True, related_name="next_versions"
    )
    status = models.CharField(max_length=20, default="执行中")
    strategy_version = models.CharField(max_length=40, default="path-a3-v1")
    total_minutes = models.PositiveIntegerField(default=0)
    plan_reason = models.TextField(blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_personalized_learning_plan"
        constraints = [
            models.UniqueConstraint(fields=["goal", "version_no"], name="a3_unique_plan_version")
        ]


class LearningPlanNode(models.Model):
    plan = models.ForeignKey(PersonalizedLearningPlan, models.CASCADE, related_name="nodes")
    knowledge_point = models.ForeignKey(KnowledgePoint, models.PROTECT)
    resource = models.ForeignKey(
        PersonalizedResource, models.SET_NULL, null=True, blank=True, related_name="plan_nodes"
    )
    sequence = models.PositiveIntegerField()
    recommendation_reason = models.CharField(max_length=500)
    prerequisite_text = models.CharField(max_length=255, blank=True, default="")
    estimated_minutes = models.PositiveIntegerField(default=15)
    status = models.CharField(max_length=20, default="待学习")
    mastery = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    can_skip = models.BooleanField(default=False)
    dynamically_adjusted = models.BooleanField(default=False)

    class Meta:
        db_table = "a3_learning_plan_node"
        ordering = ["sequence"]
        constraints = [
            models.UniqueConstraint(fields=["plan", "sequence"], name="a3_unique_plan_node_seq")
        ]


class PathAdjustment(models.Model):
    plan = models.ForeignKey(PersonalizedLearningPlan, models.CASCADE, related_name="adjustments")
    trigger_type = models.CharField(max_length=40)
    before_state = models.JSONField(default=dict)
    after_state = models.JSONField(default=dict)
    explanation = models.TextField()
    status = models.CharField(max_length=20, default="待确认")
    created_at = models.DateTimeField(auto_now_add=True)
    decided_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "a3_path_adjustment"
        ordering = ["-created_at"]


class ResourceRecommendation(models.Model):
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_resource_recommendations",
    )
    goal = models.ForeignKey(LearningGoal, models.CASCADE, related_name="recommendations")
    resource = models.ForeignKey(PersonalizedResource, models.CASCADE, related_name="recommendations")
    knowledge_point = models.ForeignKey(KnowledgePoint, models.PROTECT)
    rank = models.PositiveIntegerField(default=1)
    reason = models.TextField()
    match_points = models.JSONField(default=list)
    strategy_version = models.CharField(max_length=40, default="recommend-a3-v1")
    status = models.CharField(max_length=20, default="待学习")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_resource_recommendation"
        ordering = ["rank"]


class RecommendationFeedback(models.Model):
    recommendation = models.OneToOneField(
        ResourceRecommendation, models.CASCADE, related_name="feedback"
    )
    accepted = models.BooleanField(null=True, blank=True)
    useful = models.BooleanField(null=True, blank=True)
    reason = models.CharField(max_length=500, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_recommendation_feedback"


class LearningBehaviorEvent(models.Model):
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_behavior_events",
    )
    resource = models.ForeignKey(
        PersonalizedResource, models.SET_NULL, null=True, blank=True, related_name="behavior_events"
    )
    event_type = models.CharField(max_length=40)
    duration_seconds = models.PositiveIntegerField(default=0)
    value = models.JSONField(default=dict)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_learning_behavior_event"
        indexes = [models.Index(fields=["student", "event_type", "created_at"])]


class LearningEffectReport(models.Model):
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_effect_reports",
    )
    goal = models.ForeignKey(LearningGoal, models.SET_NULL, null=True, blank=True)
    period_start = models.DateField()
    period_end = models.DateField()
    deterministic_metrics = models.JSONField(default=dict)
    ai_analysis = models.TextField(blank=True, default="")
    ai_suggestions = models.JSONField(default=list)
    teacher_opinion = models.TextField(blank=True, default="")
    source_type = models.CharField(max_length=30, default="平台确定性统计")
    provider = models.CharField(max_length=40, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_learning_effect_report"
        ordering = ["-created_at"]


class TutorConversation(models.Model):
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_tutor_conversations",
    )
    knowledge_base = models.ForeignKey(CourseKnowledgeBase, models.PROTECT)
    knowledge_point = models.ForeignKey(KnowledgePoint, models.PROTECT)
    resource = models.ForeignKey(PersonalizedResource, models.SET_NULL, null=True, blank=True)
    answer_style = models.CharField(max_length=30, default="简单解释")
    status = models.CharField(max_length=20, default="进行中")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_tutor_conversation"


class TutorMessage(models.Model):
    conversation = models.ForeignKey(TutorConversation, models.CASCADE, related_name="messages")
    role = models.CharField(max_length=20)
    content = models.TextField()
    citations = models.JSONField(default=list)
    confidence = models.DecimalField(max_digits=4, decimal_places=3, default=0)
    is_ai_generated = models.BooleanField(default=False)
    evidence_status = models.CharField(max_length=30, default="依据部分充分")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_tutor_message"


class GenerationJob(models.Model):
    student = models.ForeignKey(
        "app.Student", models.DO_NOTHING, db_constraint=False,
        related_name="a3_generation_jobs",
    )
    goal = models.ForeignKey(LearningGoal, models.PROTECT, related_name="generation_jobs")
    workflow = models.ForeignKey(AgentWorkflow, models.PROTECT)
    run = models.OneToOneField(
        AgentRun, models.SET_NULL, null=True, blank=True, related_name="generation_job"
    )
    course = models.ForeignKey(
        CourseKnowledgeBase, models.PROTECT, null=True, blank=True,
        related_name="generation_jobs",
    )
    chapter = models.ForeignKey(
        CourseChapter, models.PROTECT, null=True, blank=True,
        related_name="generation_jobs",
    )
    knowledge_point = models.ForeignKey(
        KnowledgePoint, models.PROTECT, null=True, blank=True,
        related_name="generation_jobs",
    )
    learning_goal = models.TextField(blank=True, default="")
    current_foundation = models.CharField(max_length=120, blank=True, default="")
    difficulty = models.CharField(max_length=20, default="中等")
    available_minutes = models.PositiveIntegerField(default=30)
    resource_preferences = models.JSONField(default=list)
    selected_resource_types = models.JSONField(default=list)
    resource_strategy = models.JSONField(default=dict)
    requested_types = models.JSONField(default=list)
    idempotency_key = models.CharField(max_length=80, unique=True)
    status = models.CharField(max_length=30, default="排队中")
    progress = models.PositiveSmallIntegerField(default=0)
    current_step = models.CharField(max_length=80, default="排队中")
    error_message = models.CharField(max_length=500, blank=True, default="")
    failure_stage = models.CharField(max_length=100, blank=True, default="")
    can_retry = models.BooleanField(default=True)
    retry_count = models.PositiveSmallIntegerField(default=0)
    source_label = models.CharField(max_length=30, default="待生成")
    created_at = models.DateTimeField(auto_now_add=True)
    started_at = models.DateTimeField(null=True, blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "a3_generation_job"
        ordering = ["-created_at"]


class WorkerHeartbeat(models.Model):
    worker_name = models.CharField(max_length=80, unique=True)
    process_id = models.PositiveIntegerField(default=0)
    host_name = models.CharField(max_length=120, blank=True, default="")
    status = models.CharField(max_length=30, default="运行中")
    current_job = models.ForeignKey(
        GenerationJob, models.SET_NULL, null=True, blank=True,
        related_name="worker_heartbeats",
    )
    started_at = models.DateTimeField()
    last_seen_at = models.DateTimeField()
    stopped_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "a3_worker_heartbeat"


class GenerationJobStep(models.Model):
    job = models.ForeignKey(GenerationJob, models.CASCADE, related_name="job_steps")
    step_code = models.CharField(max_length=60)
    step_name = models.CharField(max_length=100)
    sequence = models.PositiveIntegerField()
    status = models.CharField(max_length=30, default="等待中")
    progress = models.PositiveSmallIntegerField(default=0)
    duration_ms = models.PositiveIntegerField(default=0)
    detail = models.CharField(max_length=500, blank=True, default="")
    started_at = models.DateTimeField(null=True, blank=True)
    finished_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "a3_generation_job_step"
        ordering = ["sequence"]
        constraints = [
            models.UniqueConstraint(fields=["job", "sequence"], name="a3_unique_job_step")
        ]

    @property
    def duration_display(self):
        return f"{self.duration_ms / 1000:.1f}秒"


class GenerationArtifact(models.Model):
    job = models.ForeignKey(GenerationJob, models.CASCADE, related_name="artifacts")
    resource = models.ForeignKey(PersonalizedResource, models.CASCADE, related_name="artifacts")
    artifact_type = models.CharField(max_length=30)
    file_path = models.CharField(max_length=500, blank=True, default="")
    metadata = models.JSONField(default=dict)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_generation_artifact"


class AgentRunArtifact(models.Model):
    run = models.ForeignKey(AgentRun, models.CASCADE, related_name="artifacts")
    resource = models.ForeignKey(PersonalizedResource, models.CASCADE, related_name="agent_artifacts")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_agent_run_artifact"
        constraints = [
            models.UniqueConstraint(fields=["run", "resource"], name="a3_unique_run_artifact")
        ]


class ContentSafetyRecord(models.Model):
    run = models.ForeignKey(AgentRun, models.SET_NULL, null=True, blank=True, related_name="safety_records")
    resource = models.ForeignKey(
        PersonalizedResource, models.SET_NULL, null=True, blank=True, related_name="safety_records"
    )
    input_excerpt = models.CharField(max_length=500, blank=True, default="")
    result = models.CharField(max_length=30)
    checks = models.JSONField(default=dict)
    issues = models.JSONField(default=list)
    action = models.CharField(max_length=60)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "a3_content_safety_record"


class ModelProviderState(TimeStampedModel):
    provider = models.CharField(max_length=40, unique=True)
    model = models.CharField(max_length=80, blank=True, default="")
    configured = models.BooleanField(default=False)
    status = models.CharField(max_length=30, default="未配置")
    last_latency_ms = models.PositiveIntegerField(default=0)
    last_error_code = models.CharField(max_length=60, blank=True, default="")
    last_checked_at = models.DateTimeField(null=True, blank=True)
    # Compatibility fields already present in the delivered MySQL database.
    # Keeping them mapped prevents inserts from failing and makes connection
    # checks durable without exposing credentials or raw provider responses.
    last_success_at = models.DateTimeField(null=True, blank=True)
    last_test_result = models.CharField(max_length=120, blank=True, default="")

    class Meta:
        db_table = "a3_model_provider_state"

    @property
    def duration_display(self):
        return f"{self.last_latency_ms / 1000:.1f}秒"
