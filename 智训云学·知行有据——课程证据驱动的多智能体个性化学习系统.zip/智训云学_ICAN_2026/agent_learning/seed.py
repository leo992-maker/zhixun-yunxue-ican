"""Idempotent A3 course and s001 recording scenario seed."""

from __future__ import annotations

import hashlib
import json
from datetime import timedelta
from decimal import Decimal
from pathlib import Path

from django.db import transaction
from django.utils import timezone

from app.models import Student, Teacher
from agent_learning.models import (
    AgentDefinition, AgentWorkflow, CourseChapter, CourseKnowledgeBase,
    GenerationJob, KnowledgeChunk, KnowledgeDocument, KnowledgeMastery,
    KnowledgePoint, KnowledgePrerequisite, KnowledgeSource, KnowledgeVersion,
    LearningEffectReport, LearningGoal, ProfileConversation, ProfileDimension,
    ProfileEvidence, ProfileMessage, ProfileSnapshot, ProfileUpdateEvent,
)
from agent_learning.services.assessment import create_effect_report
from agent_learning.services.a3_prompts import AGENT_PROMPTS
from agent_learning.services.paths import create_learning_plan, refresh_recommendations
from agent_learning.services.rag import tokenize
from agent_learning.services.resources import generate_resource


DATA_FILE = Path(__file__).resolve().parent / "data" / "python_course.json"


AGENTS = [
    ("orchestrator", "编排智能体", "拆解目标、编排顺序、管理重试和失败降级"),
    ("profile_agent", "画像智能体", "读取并增量更新结构化学生画像"),
    ("retrieval_agent", "知识检索智能体", "从启用版本的课程知识库召回带来源证据"),
    ("resource_planner_agent", "资源策划智能体", "基于画像确定资源形式、难度和长度"),
    ("document_agent", "讲解文档智能体", "生成分层讲解并导出真实DOCX"),
    ("ppt_agent", "PPT课件智能体", "生成完整课件并用python-pptx导出"),
    ("mindmap_agent", "思维导图智能体", "生成可展开知识树并导出真实SVG"),
    ("question_agent", "题库智能体", "生成六种题型并提供在线评分"),
    ("reading_agent", "拓展阅读智能体", "只基于课程知识库组织拓展阅读"),
    ("practice_agent", "代码实操智能体", "生成静态安全的Python实践案例"),
    ("multimodal_agent", "多模态微课智能体", "生成脚本、分镜并按配置调用讯飞语音合成"),
    ("path_planner_agent", "路径规划智能体", "按先修关系、掌握度和时间预算生成动态路径"),
    ("tutor_agent", "课程辅导智能体", "基于课程RAG证据即时答疑"),
    ("assessment_agent", "学习评估智能体", "用行为和测验更新掌握度及效果报告"),
    ("reviewer_agent", "质量审核智能体", "核查正确性、画像适配、完整性和引用"),
    ("safety_agent", "内容安全智能体", "检测注入、敏感内容、虚假引用与越界内容"),
]


def _load_course():
    return json.loads(DATA_FILE.read_text(encoding="utf-8"))


@transaction.atomic
def seed_course(owner=None):
    payload = _load_course()
    kb, _ = CourseKnowledgeBase.objects.update_or_create(
        course_code=payload["course_code"],
        defaults={
            "name": payload["name"], "description": payload["description"],
            "owner": owner, "total_hours": payload["total_hours"],
            "status": "已启用", "current_version": 1,
        },
    )
    version, _ = KnowledgeVersion.objects.update_or_create(
        knowledge_base=kb, version_no=1,
        defaults={
            "version_label": "2026竞赛演示版",
            "change_note": "首个完整Python课程知识库；课程组自建原创内容。",
            "is_active": True,
        },
    )
    previous_point = None
    point_count = 0
    for chapter_data in payload["chapters"]:
        chapter, _ = CourseChapter.objects.update_or_create(
            knowledge_base=kb, chapter_no=chapter_data["no"],
            defaults={
                "title": chapter_data["title"], "objectives": chapter_data["objectives"],
                "prerequisite_summary": chapter_data["prerequisite"],
                "lecture": chapter_data["lecture"], "example_code": chapter_data["example_code"],
                "common_mistakes": chapter_data["mistakes"], "exercises": chapter_data["exercises"],
                "reference_answers": chapter_data["answers"], "practical_case": chapter_data["case"],
                "further_reading": chapter_data["reading"],
                "source_notes": [payload["source_policy"]], "is_active": True,
            },
        )
        for point_data in chapter_data["points"]:
            point, _ = KnowledgePoint.objects.update_or_create(
                point_code=point_data["code"],
                defaults={
                    "chapter": chapter, "point_no": point_data["no"],
                    "title": point_data["title"], "summary": point_data["summary"],
                    "difficulty": point_data["difficulty"],
                    "estimated_minutes": point_data["minutes"], "tags": point_data["tags"],
                    "is_active": True,
                },
            )
            if previous_point:
                KnowledgePrerequisite.objects.update_or_create(
                    knowledge_point=point, prerequisite=previous_point,
                    defaults={"required_mastery": 60, "reason": "按课程教学顺序建立先修关系"},
                )
            previous_point = point
            point_count += 1
            source_reference = f"智训云学课程组自建讲义·第{chapter.chapter_no}章·{point.title}·v1"
            content_a = (
                f"课程：《{kb.name}》\n章节：第{chapter.chapter_no}章 {chapter.title}\n知识点：{point.title}\n"
                f"章节目标：{'；'.join(chapter_data['objectives'])}\n前置知识：{chapter_data['prerequisite']}\n"
                f"知识点说明：{point.summary}\n教学讲义：{chapter_data['lecture']}"
            )
            content_b = (
                f"知识点：{point.title}\n示例代码：\n{chapter_data['example_code']}\n"
                f"易错点：{'；'.join(chapter_data['mistakes'])}\n练习题：{'；'.join(chapter_data['exercises'])}\n"
                f"参考答案：{'；'.join(chapter_data['answers'])}\n实操案例：{chapter_data['case']}\n"
                f"拓展阅读：{'；'.join(chapter_data['reading'])}\n资源来源：{source_reference}"
            )
            digest = hashlib.sha256((content_a + content_b).encode("utf-8")).hexdigest()
            document, _ = KnowledgeDocument.objects.update_or_create(
                knowledge_base=kb, version=version, sha256=digest,
                defaults={
                    "chapter": chapter, "knowledge_point": point,
                    "title": f"第{chapter.chapter_no}章·{point.title}课程讲义",
                    "extension": "md", "source_type": "课程自建",
                    "source_reference": source_reference,
                    "status": "已解析", "parse_message": "课程结构化数据安全入库，共2个片段",
                    "is_active": True, "created_by": owner,
                },
            )
            KnowledgeSource.objects.update_or_create(
                document=document, label=source_reference,
                defaults={
                    "publisher": "智训云学课程组", "original_reference": source_reference,
                    "copyright_note": "课程组自建原创内容；无外部网址和虚构页码。", "verified": True,
                },
            )
            for chunk_no, content in enumerate([content_a, content_b], 1):
                KnowledgeChunk.objects.update_or_create(
                    document=document, chunk_no=chunk_no,
                    defaults={
                        "chapter": chapter, "knowledge_point": point, "content": content,
                        "token_count": len(tokenize(content)),
                        "keywords": list(dict.fromkeys(point.tags + tokenize(point.title)))[:30],
                        "is_active": True,
                    },
                )
    return kb, version, point_count


@transaction.atomic
def seed_agents():
    definitions = {}
    for code, name, description in AGENTS:
        spec = AGENT_PROMPTS.get(code)
        definitions[code], _ = AgentDefinition.objects.update_or_create(
            code=code,
            defaults={
                "name": name, "role_description": description,
                "system_prompt_version": spec.version if spec else "a3-v1",
                "system_prompt": spec.system_prompt if spec else "",
                "input_schema": spec.input_schema if spec else {},
                "output_schema": spec.output_schema if spec else {},
                "tool_list": list(spec.tools) if spec else [],
                "enabled": True,
            },
        )
    workflow, _ = AgentWorkflow.objects.update_or_create(
        code="personalized_resource_generation", version="1.0",
        defaults={
            "name": "画像驱动的多资源生成与路径更新",
            "description": "需求理解→画像分析→知识检索→资源策划→专业资源并行生成→安全检查→质量审核→路径更新",
            "step_blueprint": [
                "profile_agent", "retrieval_agent", "resource_planner_agent",
                "document_agent", "ppt_agent", "mindmap_agent", "question_agent",
                "reading_agent", "practice_agent", "multimodal_agent", "safety_agent",
                "reviewer_agent", "path_planner_agent",
            ],
            "enabled": True,
        },
    )
    return definitions, workflow


def _seed_profile(student, focus_points):
    focus_titles = [item.title for item in focus_points]
    primary_title = focus_titles[0]
    secondary_title = focus_titles[1] if len(focus_titles) > 1 else primary_title
    conversation = ProfileConversation.objects.filter(student=student).order_by("pk").first()
    if not conversation:
        conversation = ProfileConversation.objects.create(
            student=student, status="已完成", extraction_mode="规则降级",
            ended_at=timezone.now(),
        )
    messages = [
        (1, "student", f"我是软件工程大二学生，Python基础中等，目标是掌握{primary_title}与{secondary_title}。"),
        (2, "student", f"已掌握课程基础内容，本次希望重点补强{primary_title}、{secondary_title}。"),
        (3, "student", "我偏好图解、代码案例和短时学习，每日可投入30分钟，喜欢后端开发，写过Python小项目。"),
    ]
    message_objects = []
    for sequence, role, content in messages:
        message, _ = ProfileMessage.objects.update_or_create(
            conversation=conversation, sequence=sequence,
            defaults={"role": role, "content": content, "is_ai_generated": False},
        )
        message_objects.append(message)
    values = {
        "background": {"专业": "软件工程", "年级": "大二"},
        "foundation": {"水平": "中等"},
        "goal": {"目标": f"掌握{primary_title}与{secondary_title}"},
        "mastered": {"知识点": ["基础语法", "分支", "循环"]},
        "weak_points": {"知识点": focus_titles},
        "cognitive_preference": {"偏好": ["图解", "分步"]},
        "resource_preference": {"形式": ["思维导图", "代码案例", "微课"]},
        "pace_time": {"节奏": "短时学习", "可投入": "每日30分钟"},
        "interest": {"方向": ["后端开发"]},
        "practice_ability": {"描述": ["写过Python小项目", "基础调试能力"]},
    }
    from agent_learning.services.profile import PROFILE_DIMENSIONS, serialize_current_profile
    for index, (code, value) in enumerate(values.items()):
        dimension, created = ProfileDimension.objects.update_or_create(
            student=student, dimension_code=code,
            defaults={
                "label": PROFILE_DIMENSIONS[code], "value": value,
                "source": "学生确认的画像访谈", "confidence": Decimal("0.950"),
                "evidence_message": message_objects[min(index // 4, 2)],
                "is_confirmed": True, "is_rejected": False,
            },
        )
        ProfileEvidence.objects.get_or_create(
            dimension=dimension, message=dimension.evidence_message,
            defaults={
                "source_type": "画像访谈", "excerpt": dimension.evidence_message.content,
                "confidence": Decimal("0.950"),
            },
        )
        if created:
            ProfileUpdateEvent.objects.create(
                student=student, dimension_code=code, old_value={}, new_value=value,
                source="画像访谈", reason="s001录屏画像确认", status="已确认",
            )
    if not ProfileSnapshot.objects.filter(student=student, trigger="s001录屏画像确认").exists():
        ProfileSnapshot.objects.create(
            student=student, dimensions=serialize_current_profile(student.pk),
            trigger="s001录屏画像确认",
        )


def seed_s001_demo(kb, workflow):
    student = Student.objects.select_related("user").get(user__username="s001")
    focus_points = list(
        KnowledgePoint.objects.filter(chapter__knowledge_base=kb, is_active=True)
        .select_related("chapter")
        .order_by("chapter__chapter_no", "point_no")[:2]
    )
    if not focus_points:
        raise RuntimeError("课程知识库没有可用于演示的有效知识点")
    _seed_profile(student, focus_points)
    primary_point = focus_points[0]
    secondary_point = focus_points[1] if len(focus_points) > 1 else primary_point
    goal_title = f"掌握{primary_point.title}与{secondary_point.title}"
    goal, _ = LearningGoal.objects.update_or_create(
        student=student, knowledge_base=kb, title=goal_title,
        defaults={
            "description": f"重点补强{primary_point.title}与{secondary_point.title}",
            "target_date": timezone.localdate() + timedelta(days=14),
            "weekly_minutes": 210, "status": "进行中",
        },
    )
    for point, score in zip(focus_points, (58, 45)):
        KnowledgeMastery.objects.update_or_create(
            student=student, knowledge_point=point,
            defaults={
                "mastery": score, "confidence": Decimal("0.780"),
                "attempts": 4, "correct_count": 2 if score > 50 else 1,
                "consecutive_errors": 1 if score > 50 else 2,
                "last_reason": "s001合成演示测验数据",
            },
        )
    mapping = {
        "document": primary_point, "ppt": primary_point,
        "mindmap": primary_point, "practice": primary_point,
        "quiz": secondary_point, "reading": secondary_point,
        "microcourse": secondary_point,
    }
    resources = []
    for resource_type, point in mapping.items():
        resources.append(generate_resource(
            student.pk, goal, point, resource_type, demo_preset=True,
            generation_key=f"preset-s001-{resource_type}-v1",
        ))
    plan = goal.plans.filter(status="执行中").order_by("-version_no").first()
    if not plan:
        plan = create_learning_plan(student.pk, goal, reason="s001录屏预置路径")
    refresh_recommendations(student.pk, goal)
    if not LearningEffectReport.objects.filter(student=student, goal=goal).exists():
        create_effect_report(student.pk, goal)
    primary_job, created = GenerationJob.objects.get_or_create(
        idempotency_key="demo-s001-a3-workflow-v1",
        defaults={
            "student": student, "goal": goal, "workflow": workflow,
            "course": kb, "chapter": primary_point.chapter,
            "knowledge_point": primary_point, "learning_goal": goal_title,
            "difficulty": primary_point.difficulty, "available_minutes": 30,
            "selected_resource_types": ["document", "ppt", "mindmap", "quiz", "practice"],
            "requested_types": ["document", "ppt", "mindmap", "quiz", "practice"],
            "status": "排队中", "current_step": "排队中",
        },
    )
    job = primary_job
    if not created and primary_job.status == "失败":
        completed_retry = GenerationJob.objects.filter(
            student=student,
            idempotency_key__startswith="demo-s001-a3-workflow-v1-retry-",
            status="已完成",
        ).order_by("-retry_count", "-created_at").first()
        if completed_retry:
            job = completed_retry
        else:
            retry_no = max(
                1,
                (GenerationJob.objects.filter(student=student).order_by("-retry_count").values_list("retry_count", flat=True).first() or 0) + 1,
            )
            job, created = GenerationJob.objects.get_or_create(
                idempotency_key=f"demo-s001-a3-workflow-v1-retry-{retry_no}",
                defaults={
                    "student": student, "goal": goal, "workflow": workflow,
                    "course": kb, "chapter": primary_point.chapter,
                    "knowledge_point": primary_point, "learning_goal": goal_title,
                    "difficulty": primary_point.difficulty, "available_minutes": 30,
                    "selected_resource_types": ["document", "ppt", "mindmap", "quiz", "practice"],
                    "requested_types": ["document", "ppt", "mindmap", "quiz", "practice"],
                    "status": "排队中", "current_step": "排队中", "retry_count": retry_no,
                },
            )
    return {
        "student": student, "goal": goal, "resources": resources,
        "plan": plan, "job": job, "job_created": created,
    }


def seed_a3_demo_data(process_demo_job=True):
    teacher = Teacher.objects.filter(user__username="t001").first()
    kb, version, point_count = seed_course(teacher)
    definitions, workflow = seed_agents()
    demo = seed_s001_demo(kb, workflow)
    if process_demo_job and demo["job_created"]:
        from app.agents.orchestrator import LearningOrchestrator
        LearningOrchestrator(demo["job"]).process()
    return {
        "knowledge_bases": CourseKnowledgeBase.objects.count(),
        "chapters": CourseChapter.objects.filter(knowledge_base=kb).count(),
        "knowledge_points": point_count,
        "documents": KnowledgeDocument.objects.filter(knowledge_base=kb).count(),
        "chunks": KnowledgeChunk.objects.filter(document__knowledge_base=kb).count(),
        "agents": len(definitions),
        "preset_resources": len(demo["resources"]),
        "demo_job_status": GenerationJob.objects.get(pk=demo["job"].pk).status,
    }
