"""Structured online reasoning for non-resource agents with explicit fallback."""

from __future__ import annotations

import json
import re

from agent_learning.services.providers import generate_with_fallback


def _parse_object(text, required):
    value = (text or "").strip()
    fenced = re.fullmatch(r"```(?:json)?\s*(.*?)\s*```", value, flags=re.I | re.S)
    if fenced:
        value = fenced.group(1)
    parsed = json.loads(value)
    if not isinstance(parsed, dict):
        raise ValueError("输出顶层必须是JSON对象")
    missing = [key for key in required if key not in parsed]
    if missing:
        raise ValueError(f"缺少字段：{', '.join(missing)}")
    return parsed


def structured_agent_call(agent, payload, deterministic_fallback, *, max_tokens=1800):
    spec = agent.prompt_spec
    messages = [
        {"role": "system", "content": spec.system_prompt},
        {
            "role": "user",
            "content": (
                f"输出契约：{json.dumps(spec.output_schema, ensure_ascii=False)}\n"
                f"输入：{json.dumps(payload, ensure_ascii=False)}"
            ),
        },
    ]
    result, attempts = generate_with_fallback(
        messages,
        max_tokens=max_tokens,
        json_mode=True,
        prompt_version=spec.version,
        use_case=f"a3_{agent.code}",
    )
    agent.capture_model_attempts(attempts)
    required = spec.output_schema.get("required", [])
    if result.is_ai_generated:
        try:
            value = _parse_object(result.text, required)
            value["_generation_mode"] = "ONLINE_SPARK" if result.provider == "spark" else "ONLINE_FALLBACK"
            return value
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            repair = [
                {"role": "system", "content": spec.system_prompt},
                {
                    "role": "user",
                    "content": (
                        f"上次输出不符合契约（{str(exc)[:160]}）。请只返回修复后的完整JSON。\n"
                        f"契约：{json.dumps(spec.output_schema, ensure_ascii=False)}\n"
                        f"待修复输出：{result.text[:8000]}"
                    ),
                },
            ]
            repaired, repair_attempts = generate_with_fallback(
                repair,
                max_tokens=max_tokens,
                json_mode=True,
                prompt_version=spec.version,
                use_case=f"a3_{agent.code}_schema_repair",
            )
            agent.capture_model_attempts(repair_attempts)
            if repaired.is_ai_generated:
                try:
                    value = _parse_object(repaired.text, required)
                    value["_generation_mode"] = "ONLINE_SPARK" if repaired.provider == "spark" else "ONLINE_FALLBACK"
                    return value
                except (ValueError, TypeError, json.JSONDecodeError):
                    pass
    fallback = deterministic_fallback() if callable(deterministic_fallback) else deterministic_fallback
    fallback["_generation_mode"] = "RULE_FALLBACK"
    return fallback
