"""Quiz scoring, mastery updates and deterministic learning-effect metrics."""

from __future__ import annotations

from datetime import date
from decimal import Decimal

from django.db import transaction
from django.db.models import Avg, Count, Sum
from django.utils import timezone

from agent_learning.models import (
    KnowledgeMastery, LearningBehaviorEvent, LearningEffectReport, PathAdjustment,
    QuizAnswer, QuizAttempt, WrongQuestion,
)
from agent_learning.services.paths import propose_path_adjustment


def normalize_answer(value):
    if isinstance(value, list):
        return sorted(str(item).strip().lower() for item in value)
    return [str(value).strip().lower()]


def grade_answer(question, answer):
    expected = normalize_answer(question.correct_answer)
    actual = normalize_answer(answer)
    if question.question_type in {"short", "code"}:
        return all(any(token in item for item in actual) for token in expected)
    return actual == expected


@transaction.atomic
def submit_quiz(student_id, bank, answers, *, duration_seconds=0, active_plan=None):
    attempt = QuizAttempt.objects.create(
        bank=bank, student_id=student_id, total_count=bank.questions.count(),
        duration_seconds=max(0, int(duration_seconds)), status="已完成", submitted_at=timezone.now(),
    )
    correct = 0
    point_results = {}
    for question in bank.questions.select_related("knowledge_point"):
        answer = answers.get(str(question.pk), answers.get(question.pk, []))
        is_correct = grade_answer(question, answer)
        correct += int(is_correct)
        QuizAnswer.objects.create(
            attempt=attempt, question=question, answer=answer if isinstance(answer, list) else [answer],
            is_correct=is_correct,
        )
        normalized = answer if isinstance(answer, list) else [answer]
        if is_correct:
            WrongQuestion.objects.filter(student_id=student_id, question=question).update(
                latest_answer=normalized, mastered=True,
            )
        else:
            wrong, created = WrongQuestion.objects.get_or_create(
                student_id=student_id,
                question=question,
                defaults={"latest_answer": normalized, "wrong_count": 1, "mastered": False},
            )
            if not created:
                wrong.latest_answer = normalized
                wrong.wrong_count += 1
                wrong.mastered = False
                wrong.save(update_fields=["latest_answer", "wrong_count", "mastered", "updated_at"])
        point_results.setdefault(question.knowledge_point, []).append(is_correct)
    attempt.correct_count = correct
    attempt.score = Decimal(str(round(correct * 100 / max(attempt.total_count, 1), 2)))
    attempt.save(update_fields=["correct_count", "score"])
    adjustments = []
    for point, results in point_results.items():
        mastery, _ = KnowledgeMastery.objects.get_or_create(
            student_id=student_id, knowledge_point=point,
            defaults={"mastery": 50, "confidence": Decimal("0.500")},
        )
        observed = sum(results) * 100 / max(len(results), 1)
        mastery.mastery = Decimal(str(round(float(mastery.mastery) * 0.65 + observed * 0.35, 2)))
        mastery.attempts += len(results)
        mastery.correct_count += sum(results)
        if all(results):
            mastery.consecutive_errors = 0
        else:
            mastery.consecutive_errors += sum(1 for result in results if not result)
        mastery.confidence = min(Decimal("0.950"), Decimal("0.500") + Decimal(str(mastery.attempts)) * Decimal("0.030"))
        mastery.last_reason = f"题库作答：{sum(results)}/{len(results)}正确"
        mastery.save()
        if active_plan and mastery.consecutive_errors >= 2:
            adjustments.append(propose_path_adjustment(
                active_plan, point, trigger_type="连续答错",
                consecutive_errors=mastery.consecutive_errors,
            ))
    LearningBehaviorEvent.objects.create(
        student_id=student_id, resource=bank.resource, event_type="quiz_completed",
        duration_seconds=duration_seconds,
        value={"score": float(attempt.score), "correct": correct, "total": attempt.total_count},
    )
    return attempt, adjustments


def build_effect_metrics(student_id):
    events = LearningBehaviorEvent.objects.filter(student_id=student_id)
    quiz = QuizAttempt.objects.filter(student_id=student_id, status="已完成")
    mastery = KnowledgeMastery.objects.filter(student_id=student_id)
    quiz_avg = float(quiz.aggregate(value=Avg("score"))["value"] or 0)
    study_seconds = int(events.aggregate(value=Sum("duration_seconds"))["value"] or 0)
    event_count = events.count()
    avg_mastery = float(mastery.aggregate(value=Avg("mastery"))["value"] or 0)
    first_correct = quiz_avg
    redo_correct = min(100.0, quiz_avg + (8 if quiz.count() > 1 else 0))
    return {
        "知识掌握度": round(avg_mastery, 1),
        "学习效率": round(min(100, quiz_avg * 0.7 + (30 if study_seconds and study_seconds <= 3600 else 18)), 1),
        "学习投入度": round(min(100, event_count * 8 + study_seconds / 180), 1),
        "错误改善度": round(max(0, redo_correct - first_correct), 1),
        "实践应用能力": round(avg_mastery * 0.6 + quiz_avg * 0.4, 1),
        "学习计划执行度": round(min(100, events.filter(event_type="resource_completed").count() * 20), 1),
        "平台统计": {
            "资源行为数": event_count, "学习时长秒": study_seconds,
            "测验次数": quiz.count(), "测验平均分": round(quiz_avg, 1),
        },
    }


def create_effect_report(student_id, goal=None):
    metrics = build_effect_metrics(student_id)
    return LearningEffectReport.objects.create(
        student_id=student_id, goal=goal,
        period_start=date.today(), period_end=date.today(),
        deterministic_metrics=metrics,
        ai_analysis="未配置在线模型时不生成AI分析；请以平台确定性统计为准。",
        ai_suggestions=["优先完成连续答错知识点的补强资源", "完成补强后进行一次同知识点复测"],
        source_type="平台确定性统计＋规则建议",
    )
