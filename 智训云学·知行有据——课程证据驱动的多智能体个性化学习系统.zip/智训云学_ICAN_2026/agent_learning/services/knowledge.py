"""Safe course-document ingestion, parsing and chunking."""

from __future__ import annotations

import hashlib
import re

from django.core.files.base import ContentFile
from django.db import transaction

from app.utils.file_parser import extract_file_evidence, validate_upload
from agent_learning.models import KnowledgeChunk, KnowledgeDocument, KnowledgeSource
from agent_learning.services.rag import tokenize


def split_text(text, target_chars=900, overlap_chars=120):
    paragraphs = [item.strip() for item in re.split(r"\n{2,}", text or "") if item.strip()]
    chunks, buffer = [], ""
    for paragraph in paragraphs:
        candidate = f"{buffer}\n{paragraph}".strip()
        if len(candidate) <= target_chars:
            buffer = candidate
            continue
        if buffer:
            chunks.append(buffer)
        while len(paragraph) > target_chars:
            chunks.append(paragraph[:target_chars])
            paragraph = paragraph[target_chars - overlap_chars:]
        buffer = paragraph
    if buffer:
        chunks.append(buffer)
    return chunks or ([text.strip()] if (text or "").strip() else [])


@transaction.atomic
def ingest_uploaded_document(uploaded, *, knowledge_base, version, chapter=None, point=None, teacher=None, source_reference=""):
    safe_name, extension = validate_upload(uploaded)
    raw = uploaded.read()
    uploaded.seek(0)
    digest = hashlib.sha256(raw).hexdigest()
    document, created = KnowledgeDocument.objects.get_or_create(
        knowledge_base=knowledge_base, version=version, sha256=digest,
        defaults={
            "chapter": chapter, "knowledge_point": point, "title": safe_name,
            "extension": extension.lstrip("."), "source_reference": source_reference or safe_name,
            "created_by": teacher, "status": "解析中", "parse_message": "等待静态解析",
        },
    )
    if not created:
        return document
    document.file.save(safe_name, ContentFile(raw), save=True)
    try:
        text = extract_file_evidence(document.file.path)
        chunks = split_text(text)
        if not chunks:
            raise ValueError("文档未提取到可用文本")
        for index, content in enumerate(chunks, 1):
            KnowledgeChunk.objects.create(
                document=document, chapter=chapter, knowledge_point=point,
                chunk_no=index, content=content, token_count=len(tokenize(content)),
                keywords=list(dict.fromkeys(tokenize(content)))[:30],
            )
        KnowledgeSource.objects.create(
            document=document, label=safe_name,
            original_reference=source_reference or safe_name,
            copyright_note="由课程教师上传；对外使用前需确认授权范围。",
            verified=bool(source_reference),
        )
        document.status = "已解析"
        document.parse_message = f"安全静态解析完成，共{len(chunks)}个片段"
    except Exception as exc:
        document.status = "解析失败"
        document.parse_message = str(exc)[:250]
    document.save(update_fields=["status", "parse_message", "updated_at"])
    return document

