"""Dynamic plan construction, adjustment and explainable recommendation."""

from __future__ import annotations

from decimal import Decimal

from django.db import transaction
from django.utils import timezone

from agent_learning.models import (
    KnowledgeMastery, LearningPlanNode, PathAdjustment, PersonalizedLearningPlan,
    ProfileDimension, RecommendationFeedback, ResourceRecommendation,
)
from agent_learning.services.rag import tokenize


def adjustment_decision(mastery, consecutive_errors, available_minutes, estimated_minutes):
    if consecutive_errors >= 2 or mastery < 50:
        return "insert_reinforcement", "连续答错或掌握度低于50%，插入补强资源"
    if mastery >= 85:
        return "allow_skip", "掌握度达到85%，允许跳过基础资源"
    if available_minutes < estimated_minutes:
        return "split_node", "可投入时间不足，将节点拆分为短时资源"
    return "keep", "当前学习表现与时间预算匹配，无需调整"


def _point_order(goal):
    """Return a goal-focused path plus at most two prerequisite levels.

    A course catalogue is not a personalized path.  Targets are inferred from the
    declared goal, explicitly measured weak points, and resources already produced
    for the goal.  The bounded prerequisite expansion keeps the path actionable
    while still respecting the knowledge graph.
    """
    chapters = goal.knowledge_base.chapters.filter(is_active=True).prefetch_related("points").order_by("chapter_no")
    ordered_points = []
    for chapter in chapters:
        ordered_points.extend(chapter.points.filter(is_active=True).order_by("point_no"))

    goal_text = f"{goal.title} {goal.description}"
    goal_terms = set(tokenize(goal_text))
    target_ids = {
        point.pk for point in ordered_points
        if goal_terms.intersection(
            tokenize(f"{point.title} {point.summary} {' '.join(point.tags or [])}")
        )
    }
    target_ids.update(
        KnowledgeMastery.objects.filter(
            student_id=goal.student_id,
            knowledge_point__chapter__knowledge_base=goal.knowledge_base,
            mastery__lt=70,
        ).values_list("knowledge_point_id", flat=True)
    )
    target_ids.update(
        goal.knowledge_base.resources.filter(student_id=goal.student_id)
        .values_list("knowledge_point_id", flat=True)
    )
    if not target_ids:
        target_ids = {point.pk for point in ordered_points[:6]}

    selected_ids = set(target_ids)

    def include_prerequisites(point, depth):
        if depth <= 0:
            return
        for link in point.prerequisite_links.select_related("prerequisite"):
            prerequisite = link.prerequisite
            selected_ids.add(prerequisite.pk)
            include_prerequisites(prerequisite, depth - 1)

    for point in ordered_points:
        if point.pk in target_ids:
            include_prerequisites(point, 2)
    return [point for point in ordered_points if point.pk in selected_ids]


@transaction.atomic
def create_learning_plan(student_id, goal, *, reason="根据画像、先修关系和掌握度生成"):
    previous = goal.plans.order_by("-version_no").first()
    version = (previous.version_no + 1) if previous else 1
    if previous:
        previous.status = "已被新版本替代"
        previous.save(update_fields=["status"])
    plan = PersonalizedLearningPlan.objects.create(
        student_id=student_id, goal=goal, version_no=version, previous_plan=previous,
        plan_reason=reason,
    )
    total = 0
    sequence = 1
    for point in _point_order(goal):
        mastery_obj = KnowledgeMastery.objects.filter(
            student_id=student_id, knowledge_point=point
        ).first()
        mastery = mastery_obj.mastery if mastery_obj else Decimal("0")
        prerequisites = point.prerequisite_links.select_related("prerequisite")
        prereq_text = "、".join(link.prerequisite.title for link in prerequisites)
        resource = point.resources.filter(student_id=student_id).order_by("-created_at").first()
        can_skip = mastery >= 85
        status = "可跳过" if can_skip else "待学习"
        LearningPlanNode.objects.create(
            plan=plan, knowledge_point=point, resource=resource, sequence=sequence,
            recommendation_reason=(
                f"当前掌握度{float(mastery):.0f}%，"
                + ("优先补强" if mastery < 60 else "用于巩固并进入下一知识点")
            ),
            prerequisite_text=prereq_text, estimated_minutes=point.estimated_minutes,
            status=status, mastery=mastery, can_skip=can_skip,
        )
        total += point.estimated_minutes
        sequence += 1
    plan.total_minutes = total
    plan.save(update_fields=["total_minutes"])
    return plan


@transaction.atomic
def propose_path_adjustment(plan, point, *, trigger_type, consecutive_errors=0, available_minutes=30):
    node = plan.nodes.filter(knowledge_point=point).first()
    mastery = node.mastery if node else Decimal("0")
    decision, explanation = adjustment_decision(
        float(mastery), consecutive_errors, available_minutes,
        node.estimated_minutes if node else point.estimated_minutes,
    )
    before = {
        "plan_version": plan.version_no,
        "node_sequence": node.sequence if node else None,
        "mastery": float(mastery),
        "status": node.status if node else "未在当前路径",
    }
    after = {"action": decision, "knowledge_point": point.title}
    return PathAdjustment.objects.create(
        plan=plan, trigger_type=trigger_type, before_state=before,
        after_state=after, explanation=explanation,
    )


@transaction.atomic
def accept_path_adjustment(adjustment):
    if adjustment.status == "已接受":
        return adjustment.plan.next_versions.order_by("-version_no").first() or adjustment.plan
    old = adjustment.plan
    new = PersonalizedLearningPlan.objects.create(
        student_id=old.student_id, goal=old.goal,
        version_no=old.version_no + 1, previous_plan=old,
        strategy_version=old.strategy_version,
        plan_reason=f"动态调整：{adjustment.explanation}", status="执行中",
    )
    action = adjustment.after_state.get("action")
    target_name = adjustment.after_state.get("knowledge_point")
    sequence = 1
    total = 0
    for node in old.nodes.select_related("knowledge_point", "resource").order_by("sequence"):
        if action == "insert_reinforcement" and node.knowledge_point.title == target_name:
            LearningPlanNode.objects.create(
                plan=new, knowledge_point=node.knowledge_point, resource=node.resource,
                sequence=sequence,
                recommendation_reason="评估发现连续错误，先插入短时补强资源",
                prerequisite_text=node.prerequisite_text,
                estimated_minutes=min(12, node.estimated_minutes), status="补强中",
                mastery=node.mastery, can_skip=False, dynamically_adjusted=True,
            )
            sequence += 1
            total += min(12, node.estimated_minutes)
        copied = LearningPlanNode.objects.create(
            plan=new, knowledge_point=node.knowledge_point, resource=node.resource,
            sequence=sequence, recommendation_reason=node.recommendation_reason,
            prerequisite_text=node.prerequisite_text,
            estimated_minutes=node.estimated_minutes,
            status="可跳过" if action == "allow_skip" and node.knowledge_point.title == target_name else node.status,
            mastery=node.mastery,
            can_skip=(action == "allow_skip" and node.knowledge_point.title == target_name) or node.can_skip,
            dynamically_adjusted=node.dynamically_adjusted or node.knowledge_point.title == target_name,
        )
        total += copied.estimated_minutes
        sequence += 1
    new.total_minutes = total
    new.save(update_fields=["total_minutes"])
    old.status = "已被动态调整"
    old.save(update_fields=["status"])
    adjustment.status = "已接受"
    adjustment.decided_at = timezone.now()
    adjustment.after_state = {**adjustment.after_state, "new_plan_id": new.pk, "new_plan_version": new.version_no}
    adjustment.save(update_fields=["status", "decided_at", "after_state"])
    return new


def _preferred_types(student_id):
    item = ProfileDimension.objects.filter(student_id=student_id, dimension_code="resource_preference").first()
    text = str(item.value if item else "")
    mapping = {"图": ["mindmap", "ppt"], "代码": ["practice"], "题": ["quiz"], "微课": ["microcourse"]}
    result = []
    for token, kinds in mapping.items():
        if token in text:
            result.extend(kinds)
    return result or ["document", "practice"]


@transaction.atomic
def refresh_recommendations(student_id, goal, *, limit=5):
    preferred = _preferred_types(student_id)
    resources = list(goal.knowledge_base.resources.filter(student_id=student_id).select_related("knowledge_point"))
    scored = []
    for resource in resources:
        mastery = KnowledgeMastery.objects.filter(
            student_id=student_id, knowledge_point=resource.knowledge_point
        ).first()
        mastery_value = float(mastery.mastery) if mastery else 0
        score = (100 - mastery_value) * 0.45
        reasons = [f"{resource.knowledge_point.title}掌握度{mastery_value:.0f}%"]
        if resource.resource_type in preferred:
            score += 25
            reasons.append("匹配画像中的资源形式偏好")
        if resource.estimated_minutes <= 30:
            score += 15
            reasons.append("符合每日30分钟时间预算")
        feedback = resource.feedback.filter(student_id=student_id).order_by("-created_at").first()
        if feedback and feedback.useful is False:
            score -= 30
            reasons.append("历史反馈为无用，已降低优先级")
        scored.append((score, resource, reasons))
    ResourceRecommendation.objects.filter(student_id=student_id, goal=goal).delete()
    recommendations = []
    for rank, (_, resource, reasons) in enumerate(sorted(scored, key=lambda item: -item[0])[:limit], 1):
        recommendations.append(ResourceRecommendation.objects.create(
            student_id=student_id, goal=goal, resource=resource,
            knowledge_point=resource.knowledge_point, rank=rank,
            reason="；".join(reasons), match_points=reasons,
        ))
    return recommendations
