"""Editable, evidence-aware teaching slides for the A3 PPT resource.

The source JSON is an outline. Diagrams below are native PowerPoint objects;
source names on the final slide come only from verified ResourceCitation data.
"""

from __future__ import annotations

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_AUTO_SIZE, MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt


NAVY = RGBColor(15, 31, 62)
BLUE = RGBColor(37, 99, 235)
CYAN = RGBColor(6, 182, 212)
INK = RGBColor(22, 38, 66)
MUTED = RGBColor(78, 96, 124)
PALE = RGBColor(242, 247, 255)
WHITE = RGBColor(255, 255, 255)
AMBER = RGBColor(180, 83, 9)
FONT = "Microsoft YaHei"


def _text(slide, x, y, w, h, value, size=20, color=INK, *, bold=False, align=PP_ALIGN.LEFT, font=FONT):
    shape = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    frame = shape.text_frame
    frame.clear()
    frame.word_wrap = True
    frame.auto_size = MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE
    frame.vertical_anchor = MSO_ANCHOR.MIDDLE
    frame.margin_left = frame.margin_right = Inches(.03)
    frame.margin_top = frame.margin_bottom = 0
    para = frame.paragraphs[0]
    para.text = str(value or "")
    para.alignment = align
    for run in para.runs:
        run.font.name = font
        run.font.size = Pt(size)
        run.font.bold = bold
        run.font.color.rgb = color
    return shape


def _block(slide, x, y, w, h, color, *, radius=False):
    kind = MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE
    shape = slide.shapes.add_shape(kind, Inches(x), Inches(y), Inches(w), Inches(h))
    shape.fill.solid()
    shape.fill.fore_color.rgb = color
    shape.line.fill.background()
    return shape


def _bullets(slide, values, *, x=.85, y=1.85, w=11.7, row=.88, size=23, limit=4, color=INK):
    for number, value in enumerate(values[:limit], 1):
        yy = y + (number - 1) * row
        _text(slide, x, yy, .53, .61, f"{number:02d}", 17, BLUE, bold=True)
        _text(slide, x + .64, yy - .04, w - .7, row - .10, value, size, color)


def _label(slide, value, x, y, w=11, *, color=BLUE):
    _text(slide, x, y, w, .30, value, 12, color, bold=True)


def _base(deck, resource, index, title):
    slide = deck.slides.add_slide(deck.slide_layouts[6])
    slide.background.fill.solid()
    slide.background.fill.fore_color.rgb = WHITE
    _block(slide, 0, 0, .13, 7.5, BLUE)
    _label(slide, resource.knowledge_base.name, .78, .33)
    _text(slide, .78, .78, 11.85, .67, title, 31, NAVY, bold=True)
    _block(slide, .79, 1.51, 1.02, .055, CYAN)
    _block(slide, .79, 6.89, 11.74, .015, RGBColor(213, 224, 239))
    source = resource.generation_source_label
    _text(slide, .80, 6.99, 9.95, .25,
          f"{resource.knowledge_point.title}    ·    {source}    ·    v{resource.version_no}", 10, MUTED)
    _text(slide, 11.85, 6.97, .7, .27, f"{index:02d}/09", 10, BLUE, align=PP_ALIGN.RIGHT)
    return slide


def _paired(slide, left_label, left, right_label, right):
    _label(slide, left_label, .95, 1.91, 5.5, color=AMBER)
    _label(slide, right_label, 7.05, 1.91, 5.5)
    _block(slide, 6.59, 2.03, .019, 3.71, RGBColor(212, 225, 242))
    _text(slide, .96, 2.47, 5.25, 2.63, left, 24, INK)
    _text(slide, 7.07, 2.47, 5.18, 2.63, right, 24, INK)


def _citations(resource):
    lines = []
    for item in resource.citations if isinstance(resource.citations, list) else []:
        if not isinstance(item, dict):
            continue
        doc = item.get("document") or "课程知识库文档"
        chapter = item.get("chapter") or "当前章节"
        chunk = item.get("chunk_no", "—")
        version = item.get("document_version", "—")
        lines.append(f"{doc}  /  {chapter}  /  片段{chunk}  /  v{version}")
    return list(dict.fromkeys(lines))


def build_teaching_deck(resource):
    """Build nine slide PowerPoint, independent from Django and model services."""
    content = resource.content if isinstance(resource.content, dict) else {}
    slides = content.get("slides", [])
    if not isinstance(slides, list) or len(slides) != 9:
        raise ValueError("PPT资源必须包含九页教学结构")
    deck = Presentation()
    deck.slide_width = Inches(13.333)
    deck.slide_height = Inches(7.5)
    for index, data in enumerate(slides, 1):
        title = str(data.get("title") or f"第{index}页")
        values = [str(item) for item in data.get("core_content", []) if str(item).strip()]
        if index == 1:
            slide = deck.slides.add_slide(deck.slide_layouts[6])
            slide.background.fill.solid()
            slide.background.fill.fore_color.rgb = NAVY
            _block(slide, .78, .84, 1.35, .08, CYAN)
            _label(slide, resource.knowledge_base.name, .79, 1.24, color=RGBColor(172, 224, 247))
            _text(slide, .77, 2.02, 11.8, 1.14, title, 47, WHITE, bold=True)
            _text(slide, .82, 3.31, 11.0, 1.03, "\n".join(values[:2]), 24, RGBColor(219, 233, 252))
            _label(slide, "你的学习目标", .82, 5.22, color=CYAN)
            _text(slide, .82, 5.60, 11.15, .62, resource.learning_objective, 20, WHITE)
            _text(slide, .82, 6.92, 10.9, .25,
                  f"{resource.knowledge_point.title}  ·  {resource.generation_source_label}", 10, RGBColor(189, 210, 237))
            continue

        slide = _base(deck, resource, index, title)
        if index == 2:
            _label(slide, "完成本节后，你能做到", .87, 1.87)
            _bullets(slide, values, y=2.35, row=1.03, size=24, limit=3)
            _text(slide, .89, 5.91, 11.5, .56, resource.adaptation_reason, 14, MUTED)
        elif index == 3:
            steps = values[:4]
            if not steps:
                steps = ["前置知识", "当前概念", "课程示例", "即时练习"]
            width = min(2.45, 10.9 / len(steps))
            gap = (11.0 - len(steps) * width) / max(len(steps) - 1, 1)
            for pos, step in enumerate(steps):
                x = .96 + pos * (width + gap)
                _text(slide, x, 2.60, width, .54, f"{pos + 1:02d}", 34, BLUE, bold=True)
                _block(slide, x, 3.36, width - .15, .055, CYAN)
                _text(slide, x, 3.72, width - .05, 1.66, step, 22, NAVY, bold=True)
            _label(slide, "按顺序理解，再用练习验证", .96, 6.10, color=MUTED)
        elif index == 4:
            _label(slide, "核心规则", .94, 1.88)
            _text(slide, .94, 2.36, 11.26, 1.46, values[0] if values else title, 29, NAVY, bold=True)
            if len(values) > 1:
                _block(slide, .94, 4.12, .055, 1.29, CYAN)
                _text(slide, 1.24, 4.14, 10.82, 1.24, "\n".join(values[1:3]), 19, MUTED)
            _label(slide, "下页用代码或课程案例验证", .95, 6.10, color=MUTED)
        elif index == 5:
            _label(slide, "先预测，再解释", .91, 1.88)
            for pos, value in enumerate(values[:2]):
                _text(slide, .93, 2.50 + pos * 1.15, 4.28, .92, value, 21, INK)
            _block(slide, 5.56, 1.91, 6.66, 4.34, NAVY, radius=True)
            _label(slide, "PYTHON / 课程示例", 5.89, 2.18, color=CYAN)
            _text(slide, 5.89, 2.78, 5.95, 3.04, data.get("code") or "# 本页未提供代码", 17,
                  RGBColor(226, 239, 255), font="Consolas")
        elif index == 6:
            _paired(slide, "常见误区", values[0] if values else "先检查适用条件",
                    "正确做法", values[1] if len(values) > 1 else "对照课程证据与示例")
            _label(slide, "请指出两个做法各自的依据", .96, 6.08, color=MUTED)
        elif index == 7:
            _label(slide, "先独立作答，再回到题库核对解析", .94, 1.89)
            _bullets(slide, values, y=2.43, row=1.39, size=25, limit=3)
            _label(slide, "答题结果会参与学习路径调整", .94, 6.10, color=MUTED)
        elif index == 8:
            stages = values[:3] or ["回顾核心概念", "完成练习", "按结果调整路径"]
            for pos, value in enumerate(stages):
                y = 2.05 + pos * 1.27
                _text(slide, .93, y, .86, .68, f"{pos + 1:02d}", 32, BLUE, bold=True)
                _block(slide, 2.02, y + .17, .055, .52, CYAN)
                _text(slide, 2.37, y, 9.78, .85, value, 23, NAVY)
            _label(slide, "反馈由实际作答触发；教师仍可复核内容", .95, 6.17, color=MUTED)
        else:
            refs = _citations(resource)
            _label(slide, "本次生成关联的课程知识库片段", .94, 1.89)
            if refs:
                _bullets(slide, refs, y=2.35, row=.89, size=18, limit=4)
                if len(refs) > 4:
                    _label(slide, f"另有 {len(refs) - 4} 条，详见网页成果的引用列表", .96, 6.12, color=MUTED)
            else:
                _text(slide, .96, 2.56, 11.3, 1.6, "本次未关联可核验的课程片段。请教师复核后使用。", 24, AMBER)
            _label(slide, f"生成方式：{resource.generation_source_label}；内容仍需教师核验", .96, 6.26, color=MUTED)
    return deck
