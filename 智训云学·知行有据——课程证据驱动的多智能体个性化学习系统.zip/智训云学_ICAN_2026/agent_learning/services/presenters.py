"""Presentation adapter: database JSON in, student-readable structures out."""

from __future__ import annotations

from pathlib import Path

from django.conf import settings

from agent_learning.models import PersonalizedResource


QUESTION_TYPE_LABELS = {
    "single": "单选题",
    "multiple": "多选题",
    "true_false": "判断题",
    "fill": "填空题",
    "short": "简答题",
    "code": "代码题",
}


def _list(value):
    if value is None or value == "":
        return []
    return value if isinstance(value, list) else [value]


def _text(value):
    if value is None:
        return ""
    if isinstance(value, (str, int, float)):
        return str(value)
    return ""


def _safe_media_file(relative):
    if not relative:
        return None
    root = Path(settings.MEDIA_ROOT).resolve()
    target = (root / relative).resolve()
    if root not in target.parents or not target.is_file():
        return None
    return target


class ResourcePresenter:
    def __init__(self, resource):
        self.resource = resource
        self.content = resource.content if isinstance(resource.content, dict) else {}

    def _source(self):
        resource = self.resource
        mode = resource.generation_mode
        if resource.is_demo_preset or mode == "DEMO_PRESET":
            return {"mode": "DEMO_PRESET", "label": resource.generation_source_label, "tone": "warn", "model": ""}
        if mode == "ONLINE_SPARK":
            return {"mode": mode, "label": resource.generation_source_label, "tone": "ok", "model": resource.model}
        if mode == "ONLINE_FALLBACK":
            return {"mode": mode, "label": resource.generation_source_label, "tone": "warn", "model": resource.model}
        return {"mode": "RULE_FALLBACK", "label": resource.generation_source_label, "tone": "warn", "model": ""}

    def _version_chain(self):
        root = self.resource
        while root.parent_id:
            root = root.parent
        items = []
        stack = [root]
        seen = set()
        while stack:
            current = stack.pop(0)
            if current.pk in seen:
                continue
            seen.add(current.pk)
            items.append(current)
            stack.extend(list(current.versions.order_by("version_no", "created_at")))
        return [
            {
                "id": item.pk,
                "version": item.version_no,
                "created_at": item.created_at,
                "reason": item.revision_reason or ("初始版本" if item.version_no == 1 else "版本修订"),
                "difference": item.difference_summary,
                "current": item.pk == self.resource.pk,
            }
            for item in sorted(items, key=lambda value: (value.version_no, value.created_at))
        ]

    def common(self):
        resource = self.resource
        file_target = _safe_media_file(resource.file_path)
        audio_target = _safe_media_file(resource.audio_path or self.content.get("audio_path", ""))
        citations = [
            {
                "document": _text(item.get("document")) or "课程知识库文档",
                "chapter": _text(item.get("chapter")) or resource.knowledge_point.chapter.title,
                "knowledge_point": _text(item.get("knowledge_point")) or resource.knowledge_point.title,
                "chunk_no": item.get("chunk_no", "—"),
                "relevance": item.get("relevance", "—"),
                "document_version": item.get("document_version", "—"),
                "source_reference": _text(item.get("source_reference")),
            }
            for item in resource.citations
            if isinstance(item, dict)
        ]
        current_goal = resource.learning_objective or f"掌握{resource.knowledge_point.title}"
        safe_summary = f"围绕本次目标“{current_goal}”学习“{resource.knowledge_point.title}”。"
        safe_adaptation_reason = (
            f"围绕本次学习目标“{current_goal}”和当前知识点“{resource.knowledge_point.title}”组织内容；"
            f"适合{resource.suitable_for or '希望按当前节奏完成学习闭环的学生'}。"
        )
        return {
            "id": resource.pk,
            "type": resource.resource_type,
            "type_label": resource.get_resource_type_display(),
            "title": resource.title,
            "summary": safe_summary,
            "course": resource.knowledge_base.name,
            "chapter": resource.knowledge_point.chapter.title,
            "chapter_no": resource.knowledge_point.chapter.chapter_no,
            "knowledge_point": resource.knowledge_point.title,
            "learning_objective": resource.learning_objective,
            "difficulty": resource.difficulty,
            "estimated_minutes": resource.estimated_minutes,
            "suitable_for": resource.suitable_for,
            "adaptation_reason": safe_adaptation_reason,
            "created_at": resource.created_at,
            "version": resource.version_no,
            "review_status": resource.review_status,
            "review_note": resource.review_note,
            "source": self._source(),
            "citation_count": len(citations),
            "citations": citations,
            "favorite": resource.is_favorite,
            "file_exists": bool(file_target),
            "file_name": file_target.name if file_target else "",
            "file_size": file_target.stat().st_size if file_target else 0,
            "audio_exists": bool(audio_target),
            "audio_path": resource.audio_path or self.content.get("audio_path", "") if audio_target else "",
            "versions": self._version_chain(),
        }

    def _document(self):
        content = self.content
        layered = content.get("layered_explanation", content.get("分层讲解", []))
        if isinstance(layered, dict):
            layered = [{"title": key, "content": _text(value)} for key, value in layered.items()]
        else:
            layered = [
                {"title": item.get("level", item.get("title", f"第{index}层")), "content": item.get("content", "")}
                if isinstance(item, dict) else {"title": f"第{index}层", "content": _text(item)}
                for index, item in enumerate(_list(layered), 1)
            ]
        codes = content.get("code_examples", [])
        if not codes and content.get("示例") and isinstance(content.get("示例"), str):
            codes = [{"title": "示例代码", "language": "python", "code": content["示例"]}]
        return {
            "objectives": _list(content.get("objectives", content.get("学习目标"))),
            "prerequisites": _list(content.get("prerequisites", content.get("前置知识提醒"))),
            "core_concepts": _list(content.get("core_concepts", content.get("关键概念"))),
            "layered_explanation": layered,
            "examples": [
                {
                    "title": _text(item.get("title")) or f"示例{index}",
                    "description": _text(item.get("description", item.get("content"))),
                }
                if isinstance(item, dict)
                else {"title": f"示例{index}", "description": _text(item)}
                for index, item in enumerate(_list(content.get("examples", [])), 1)
            ],
            "code_examples": [
                {"title": item.get("title", "示例代码"), "language": item.get("language", "python"), "code": item.get("code", "")}
                for item in codes if isinstance(item, dict)
            ],
            "common_mistakes": _list(content.get("common_mistakes", content.get("易错点"))),
            "exercises": [
                {
                    "title": _text(item.get("title")) or f"练习{index}",
                    "description": _text(item.get("description", item.get("stem", item.get("content")))),
                    "hint": _text(item.get("hint")),
                }
                if isinstance(item, dict)
                else {"title": f"练习{index}", "description": _text(item), "hint": ""}
                for index, item in enumerate(
                    _list(content.get("exercises", content.get("即时练习"))), 1
                )
            ],
            "summary": _list(content.get("summary", content.get("小结"))),
            "next_steps": _list(content.get("next_steps", content.get("下一步建议"))),
            "personalization_note": (
                f"围绕本次目标“{self.resource.learning_objective}”与知识点"
                f"“{self.resource.knowledge_point.title}”分层组织，便于按当前节奏学习和练习。"
            ),
        }

    def _ppt(self):
        slides = []
        for index, item in enumerate(_list(self.content.get("slides")), 1):
            if not isinstance(item, dict):
                continue
            slides.append({
                "index": index,
                "title": _text(item.get("title")) or f"第{index}页",
                "core_content": _list(item.get("core_content", item.get("bullets"))),
                "code": _text(item.get("code")),
                "visual_note": _text(item.get("visual_note")) or "本页采用蓝白科技教育风格呈现",
            })
        if len(slides) == 9:
            references = [
                f"{item.get('document', '课程知识库文档')} / {item.get('chapter', '当前章节')} / "
                f"片段{item.get('chunk_no', '—')} / v{item.get('document_version', '—')}"
                for item in self.resource.citations
                if isinstance(item, dict)
            ]
            slides[8]["core_content"] = list(dict.fromkeys(references)) or ["本次未关联可核验的课程片段，请教师复核后使用"]
            slides[8]["visual_note"] = "引用来自已检索到的课程文档和版本"
        return {"slides": slides, "slide_count": len(slides), "personalization_note": _text(self.content.get("personalization_note"))}

    def _mindmap_node(self, item, depth=0):
        if not isinstance(item, dict):
            return {"label": _text(item), "description": "", "children": [], "depth": depth}
        return {
            "label": _text(item.get("label")) or "知识节点",
            "description": _text(item.get("description")),
            "children": [self._mindmap_node(child, depth + 1) for child in _list(item.get("children"))],
            "depth": depth,
        }

    def _mindmap(self):
        tree = self._mindmap_node(self.content.get("tree", {}))

        def count(node):
            return 1 + sum(count(child) for child in node["children"])

        return {"tree": tree, "node_count": count(tree), "personalization_note": _text(self.content.get("personalization_note"))}

    def _quiz(self):
        try:
            questions = self.resource.question_bank.questions.select_related("knowledge_point").all()
            bank_id = self.resource.question_bank.pk
            pass_score = self.resource.question_bank.pass_score
        except QuestionBank.DoesNotExist:  # noqa: F821 - imported lazily below
            questions, bank_id, pass_score = [], None, 60
        return {
            "bank_id": bank_id,
            "pass_score": pass_score,
            "questions": [
                {
                    "id": item.pk,
                    "number": item.sequence,
                    "type": item.question_type,
                    "type_label": QUESTION_TYPE_LABELS.get(item.question_type, "练习题"),
                    "stem": item.stem,
                    "options": item.options,
                    "input_kind": "checkbox" if item.question_type == "multiple" else "radio" if item.question_type in {"single", "true_false"} else "textarea" if item.question_type in {"short", "code"} else "text",
                    "knowledge_point": item.knowledge_point.title,
                    "difficulty": item.difficulty,
                    "design_purpose": item.design_purpose,
                    "profile_fit_reason": item.profile_fit_reason,
                }
                for item in questions
            ],
            "personalization_note": _text(self.content.get("personalization_note")),
        }

    def _reading(self):
        return {
            "readings": [
                {
                    "title": _text(item.get("title")),
                    "summary": _text(item.get("summary")),
                    "recommendation_reason": _text(item.get("recommendation_reason")),
                    "relation": _text(item.get("relation")),
                    "order": item.get("order", index),
                    "estimated_minutes": item.get("estimated_minutes", 6),
                    "source": _text(item.get("source")),
                    "document_version": item.get("document_version", "—"),
                    "quoted_excerpt": _text(item.get("quoted_excerpt", item.get("summary"))),
                }
                for index, item in enumerate(_list(self.content.get("readings")), 1)
                if isinstance(item, dict)
            ],
            "personalization_note": _text(self.content.get("personalization_note")),
        }

    def _practice(self):
        content = self.content
        return {
            "scenario": _text(content.get("scenario", content.get("场景说明"))),
            "objectives": _list(content.get("objectives", content.get("实践目标"))),
            "prerequisites": _list(content.get("prerequisites", content.get("前置知识"))),
            "starter_code": _text(content.get("starter_code", content.get("起始代码"))),
            "io_examples": [item for item in _list(content.get("io_examples", content.get("输入输出示例"))) if isinstance(item, dict)],
            "step_hints": _list(content.get("step_hints", content.get("分步提示"))),
            "test_cases": [
                {
                    "input": _text(item.get("input", item.get("case", item.get("code")))),
                    "expected": _text(item.get(
                        "expected",
                        item.get("expected_output", item.get("output", item.get("result"))),
                    )),
                    "description": "",
                }
                if isinstance(item, dict)
                else {"input": "", "expected": "", "description": _text(item)}
                for item in _list(content.get("test_cases", content.get("测试用例")))
            ],
            "reference_implementation": _text(content.get("reference_implementation", content.get("参考实现"))),
            "common_errors": _list(content.get("common_errors", content.get("常见错误"))),
            "advanced_challenge": _text(content.get("advanced_challenge", content.get("进阶挑战"))),
            "safety_notice": "平台只进行安全静态解析，不在Web进程中直接执行不可信代码。",
            "personalization_note": _text(content.get("personalization_note")),
        }

    def _microcourse(self):
        frames = []
        for index, item in enumerate(_list(self.content.get("frames")), 1):
            if not isinstance(item, dict):
                continue
            frames.append({
                "index": item.get("index", index),
                "title": _text(item.get("title")) or f"第{index}幕",
                "visual": _text(item.get("visual")),
                "narration": _text(item.get("narration")),
                "teaching_purpose": _text(item.get("teaching_purpose")) or "帮助理解当前知识点",
            })
        audio_exists = bool(_safe_media_file(self.resource.audio_path or self.content.get("audio_path", "")))
        audio_status = self.resource.audio_generation_status
        if not audio_exists and (not audio_status or audio_status in {"未生成", "待生成"}):
            audio_status = "未记录语音生成结果，当前资源包含微课脚本和分镜。"
        video_exists = bool(_safe_media_file(self.resource.file_path))
        video_status = self.resource.video_generation_status or "视频尚未生成；可查看脚本与分镜"
        return {
            "title": _text(self.content.get("title")) or self.resource.title,
            "duration_minutes": self.content.get("duration_minutes", self.resource.estimated_minutes),
            "frames": frames,
            "script": _text(self.content.get("script")),
            "audio_status": audio_status,
            "video_status": video_status,
            "audio_exists": audio_exists,
            "video_exists": video_exists,
            "personalization_note": _text(self.content.get("personalization_note")),
        }

    def present(self):
        payload = self.common()
        adapter = getattr(self, f"_{self.resource.resource_type}", None)
        payload["body"] = adapter() if adapter else {"message": "该资源类型正在迁移为可视化展示。"}
        return payload


# Import after the presenter declaration to avoid a broad model import at module load.
from agent_learning.models import QuestionBank  # noqa: E402
