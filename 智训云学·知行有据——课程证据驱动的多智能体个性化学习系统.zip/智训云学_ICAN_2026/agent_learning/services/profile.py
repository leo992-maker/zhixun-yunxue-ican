"""Conversational profile extraction and non-destructive updates."""

from __future__ import annotations

import re
from decimal import Decimal

from django.db import transaction

from agent_learning.models import (
    ProfileDimension, ProfileEvidence, ProfileMessage, ProfileSnapshot,
    ProfileUpdateEvent,
)


PROFILE_DIMENSIONS = {
    "background": "专业与年级背景",
    "foundation": "当前知识基础",
    "goal": "学习目标",
    "mastered": "已掌握知识点",
    "weak_points": "薄弱知识点和高频易错点",
    "cognitive_preference": "认知与理解偏好",
    "resource_preference": "学习资源形式偏好",
    "pace_time": "学习节奏和可投入时间",
    "interest": "兴趣方向",
    "practice_ability": "实践能力与代码基础",
}


def _matched(text, options):
    found = [item for item in options if item.lower() in text.lower()]
    return list(dict.fromkeys(found))


def _phrases_after(text, markers):
    """Extract user-provided knowledge phrases without a course-topic allowlist."""
    marker_pattern = "|".join(re.escape(item) for item in sorted(markers, key=len, reverse=True))
    match = re.search(rf"(?:{marker_pattern})[是为：:\s]*(.{{2,80}}?)(?:[，。；;]|$)", text)
    if not match:
        return []
    raw = match.group(1).strip(" ：:，。；;")
    values = [item.strip() for item in re.split(r"[、,/]|和|与", raw) if item.strip()]
    return list(dict.fromkeys(values))[:12]


def extract_profile_dimensions(text):
    """Deterministic fallback extractor; its source is never labelled as AI."""
    text = (text or "").strip()
    result = {}
    majors = _matched(text, ["软件工程", "计算机科学", "人工智能", "数据科学", "网络工程"])
    grades = _matched(text, ["大一", "大二", "大三", "大四", "研一", "研二"])
    if majors or grades:
        result["background"] = {"专业": majors[0] if majors else "待确认", "年级": grades[0] if grades else "待确认"}
    foundation = _matched(text, ["零基础", "基础较弱", "初级", "中等", "较好", "熟练"])
    if foundation:
        result["foundation"] = {"水平": foundation[0]}
    goal_match = re.search(r"(?:目标|希望|想要|计划)[是：:\s]*(.{2,45}?)(?:[，。；;]|$)", text)
    if goal_match:
        result["goal"] = {"目标": goal_match.group(1).strip()}
    mastered = _phrases_after(text, ["已经掌握", "已掌握", "比较熟悉", "熟悉"])
    if mastered or any(token in text for token in ["已经掌握", "已掌握", "比较熟悉"]):
        result["mastered"] = {"知识点": mastered or ["待进一步确认"]}
    weak = _phrases_after(text, ["需要重点补强", "薄弱知识点", "薄弱点", "薄弱", "不熟悉", "不熟", "容易错", "不会"])
    if weak or any(token in text for token in ["薄弱", "不熟", "容易错", "不会"]):
        result["weak_points"] = {"知识点": weak or ["待进一步确认"]}
    cognitive = _matched(text, ["图解", "类比", "分步", "先例子后概念", "先概念后练习"])
    if cognitive:
        result["cognitive_preference"] = {"偏好": cognitive}
    resources = _matched(text, ["代码案例", "短视频", "PPT", "思维导图", "练习题", "讲解文档", "微课"])
    if resources:
        result["resource_preference"] = {"形式": resources}
    minutes = re.search(r"(?:每天|每日|每次|一周|每周)[^0-9]{0,6}(\d{1,4})\s*(分钟|小时)", text)
    if minutes or any(token in text for token in ["短时学习", "碎片时间", "集中学习"]):
        result["pace_time"] = {
            "节奏": "短时学习" if "短时" in text or "碎片" in text else "集中学习",
            "可投入": f"{minutes.group(1)}{minutes.group(2)}" if minutes else "待确认",
        }
    interests = _matched(text, ["数据分析", "Web开发", "人工智能", "自动化", "游戏开发", "算法", "后端开发"])
    if interests:
        result["interest"] = {"方向": interests}
    practice = _matched(text, ["写过Python", "做过项目", "能独立编程", "需要代码提示", "只会看代码", "调试能力"])
    if practice or any(token in text.lower() for token in ["python", "代码", "编程", "项目"]):
        result["practice_ability"] = {"描述": practice or ["有Python学习经历，待测验校准"]}
    return result


def serialize_current_profile(student_id):
    return {
        item.dimension_code: {
            "label": item.label, "value": item.value, "source": item.source,
            "confidence": float(item.confidence), "confirmed": item.is_confirmed,
        }
        for item in ProfileDimension.objects.filter(student_id=student_id)
    }


@transaction.atomic
def apply_profile_message(student_id, message, *, source="对话规则抽取", confidence=Decimal("0.760")):
    extracted = extract_profile_dimensions(message.content)
    events = []
    for code, value in extracted.items():
        current = ProfileDimension.objects.filter(student_id=student_id, dimension_code=code).first()
        old_value = current.value if current else {}
        dimension, _ = ProfileDimension.objects.update_or_create(
            student_id=student_id,
            dimension_code=code,
            defaults={
                "label": PROFILE_DIMENSIONS[code], "value": value, "source": source,
                "confidence": confidence, "evidence_message": message,
                "is_rejected": False,
            },
        )
        ProfileEvidence.objects.create(
            dimension=dimension, message=message, source_type=source,
            excerpt=message.content[:500], confidence=confidence,
        )
        events.append(ProfileUpdateEvent.objects.create(
            student_id=student_id, dimension_code=code, old_value=old_value,
            new_value=value, source=source, reason="从本轮画像访谈增量抽取",
        ))
    if extracted:
        ProfileSnapshot.objects.create(
            student_id=student_id, dimensions=serialize_current_profile(student_id),
            trigger="画像访谈增量更新",
        )
    return extracted, events


def next_profile_question(existing_codes):
    for code, label in PROFILE_DIMENSIONS.items():
        if code not in existing_codes:
            questions = {
                "background": "请介绍你的专业和年级。",
                "foundation": "你觉得当前 Python 基础处于什么水平？",
                "goal": "本阶段最想达成的学习目标是什么？",
                "mastered": "哪些 Python 知识点你已经比较熟悉？",
                "weak_points": "哪些知识点最容易出错或最没把握？",
                "cognitive_preference": "你更容易通过图解、类比还是分步说明理解概念？",
                "resource_preference": "你偏好讲义、PPT、思维导图、题目、代码案例还是微课？",
                "pace_time": "你每周或每天能投入多少时间，偏好怎样的学习节奏？",
                "interest": "你对 Python 的哪个应用方向最感兴趣？",
                "practice_ability": "你写过哪些 Python 程序或实践项目？",
            }
            return questions[code]
    return "画像核心维度已形成。请确认或修改推断结果，也可以继续补充学习经历。"
