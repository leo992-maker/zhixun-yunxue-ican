"""Model-provider abstraction with explicit, auditable degradation.

Spark's HTTP endpoint and bearer authentication follow the official iFlytek
HTTP documentation.  TTS uses the documented WebSocket HMAC handshake and
base64 payload.  No credential is ever persisted or returned to callers.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from dataclasses import dataclass, field
from email.utils import formatdate
from pathlib import Path
from urllib.parse import urlencode, urlparse

import requests
from django.conf import settings

from agent_learning.services.redaction import sanitize_error


@dataclass
class ProviderResult:
    text: str
    provider: str
    model: str
    is_ai_generated: bool
    degraded: bool = False
    error_code: str = ""
    error_message: str = ""
    latency_ms: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    raw: dict = field(default_factory=dict)


class ProviderError(RuntimeError):
    def __init__(self, message, code="PROVIDER_ERROR"):
        super().__init__(message)
        self.code = str(code)


class BaseModelProvider:
    provider_name = "base"

    def __init__(self, api_key="", base_url="", model=""):
        self.api_key = (api_key or "").strip()
        self.base_url = (base_url or "").rstrip("/")
        self.model = (model or "").strip()

    @property
    def configured(self):
        return bool(self.api_key and self.base_url and self.model)

    def generate(
        self, messages, *, temperature=0.3, max_tokens=1600, json_mode=False,
        prompt_version="a3-v1", use_case="a3_resource_generation",
    ):
        raise NotImplementedError

    def unavailable(self, message="模型密钥未配置"):
        return ProviderResult(
            text="", provider=self.provider_name, model=self.model,
            is_ai_generated=False, degraded=True,
            error_code="NOT_CONFIGURED", error_message=message,
        )

    def _record(self, result, use_case="a3_resource_generation", prompt_version="a3-v1"):
        try:
            from app.models import AIInvocationLog
            from django.db import connection, transaction

            if AIInvocationLog._meta.db_table not in connection.introspection.table_names():
                return result

            # The savepoint prevents an unavailable legacy audit table from
            # poisoning a surrounding TestCase or business transaction.
            with transaction.atomic():
                AIInvocationLog.objects.create(
                    use_case=use_case,
                    provider=result.provider,
                    model=result.model,
                    prompt_version=prompt_version,
                    status="success" if result.is_ai_generated else "degraded",
                    latency_ms=result.latency_ms,
                    input_tokens=result.input_tokens,
                    output_tokens=result.output_tokens,
                    error_code=result.error_code,
                )
        except Exception:
            # Invocation logging must never hide the provider result; the caller
            # still records the error in AgentRun/GenerationJob.
            pass
        try:
            from agent_learning.models import ModelProviderState

            ModelProviderState.objects.update_or_create(
                provider=result.provider,
                defaults={
                    "model": result.model,
                    "configured": self.configured,
                    "status": "连接正常" if result.is_ai_generated else "调用失败",
                    "last_latency_ms": result.latency_ms,
                    "last_error_code": result.error_code,
                    "last_checked_at": __import__("django.utils.timezone", fromlist=["now"]).now(),
                },
            )
        except Exception:
            pass
        return result


class OpenAICompatibleProvider(BaseModelProvider):
    provider_name = "openai-compatible"
    supports_json_mode = True

    def generate(
        self, messages, *, temperature=0.3, max_tokens=1600, json_mode=False,
        prompt_version="a3-v1", use_case="a3_resource_generation",
    ):
        if not self.configured:
            return self._record(self.unavailable(), use_case, prompt_version)
        started = time.perf_counter()
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
        }
        if json_mode and self.supports_json_mode:
            payload["response_format"] = {"type": "json_object"}
        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"},
                json=payload,
                timeout=getattr(settings, "AI_TIMEOUT", 60),
            )
            response.raise_for_status()
            body = response.json()
            content = body["choices"][0]["message"]["content"]
            usage = body.get("usage") or {}
            result = ProviderResult(
                text=content, provider=self.provider_name, model=self.model,
                is_ai_generated=True,
                latency_ms=int((time.perf_counter() - started) * 1000),
                input_tokens=int(usage.get("prompt_tokens") or 0),
                output_tokens=int(usage.get("completion_tokens") or 0),
                raw={"id": body.get("id", "")},
            )
        except requests.RequestException as exc:
            code = str(getattr(getattr(exc, "response", None), "status_code", "NETWORK_ERROR"))
            result = ProviderResult(
                text="", provider=self.provider_name, model=self.model,
                is_ai_generated=False, degraded=True, error_code=code,
                error_message=sanitize_error(exc, limit=300),
                latency_ms=int((time.perf_counter() - started) * 1000),
            )
        except (KeyError, ValueError, TypeError) as exc:
            result = ProviderResult(
                text="", provider=self.provider_name, model=self.model,
                is_ai_generated=False, degraded=True, error_code="INVALID_RESPONSE",
                error_message=sanitize_error(exc, limit=300),
                latency_ms=int((time.perf_counter() - started) * 1000),
            )
        return self._record(result, use_case, prompt_version)


class SparkProvider(OpenAICompatibleProvider):
    provider_name = "spark"

    def __init__(self):
        super().__init__(
            api_key=getattr(settings, "SPARK_API_PASSWORD", ""),
            base_url=getattr(settings, "SPARK_BASE_URL", "https://spark-api-open.xf-yun.com/v1"),
            model=getattr(settings, "SPARK_MODEL", "generalv3.5"),
        )


class DeepSeekProvider(OpenAICompatibleProvider):
    provider_name = "deepseek"

    def __init__(self):
        super().__init__(
            api_key=getattr(settings, "AI_API_KEY", ""),
            base_url=getattr(settings, "AI_BASE_URL", "https://api.deepseek.com"),
            model=getattr(settings, "AI_MODEL", "deepseek-flash"),
        )


class GLMProvider(OpenAICompatibleProvider):
    """Zhipu GLM through the iFlytek MaaS OpenAI-compatible endpoint."""

    provider_name = "glm"
    # The MaaS example exposes ordinary Chat Completions; keep JSON contract
    # enforcement in our schema/repair layer instead of sending an unsupported
    # response_format parameter to this endpoint.
    supports_json_mode = False

    def __init__(self):
        super().__init__(
            api_key=getattr(settings, "GLM_API_KEY", ""),
            base_url=getattr(settings, "GLM_BASE_URL", "https://maas-api.cn-huabei-1.xf-yun.com/v2"),
            model=getattr(settings, "GLM_MODEL", "xopglm5.3"),
        )


def get_model_provider():
    provider = getattr(settings, "A3_MODEL_PROVIDER", "spark").lower()
    if provider == "spark":
        return SparkProvider()
    if provider == "glm":
        return GLMProvider()
    return DeepSeekProvider()


def generate_with_fallback(
    messages, *, temperature=0.2, max_tokens=3200, json_mode=True,
    prompt_version="a3-v1", use_case="a3_resource_generation",
):
    """Try the configured A3 provider, then explicitly audit DeepSeek fallback."""

    primary = get_model_provider()
    attempts = []
    result = primary.generate(
        messages, temperature=temperature, max_tokens=max_tokens,
        json_mode=json_mode, prompt_version=prompt_version, use_case=use_case,
    )
    attempts.append(result)
    if result.is_ai_generated:
        return result, attempts
    if primary.provider_name in {"spark", "glm"}:
        fallback = DeepSeekProvider()
        fallback_result = fallback.generate(
            messages, temperature=temperature, max_tokens=max_tokens,
            json_mode=json_mode, prompt_version=prompt_version, use_case=use_case,
        )
        attempts.append(fallback_result)
        if fallback_result.is_ai_generated:
            return fallback_result, attempts
    return result, attempts


class SparkTTSProvider:
    """Synchronous iFlytek online TTS client used only by the background worker."""

    provider_name = "spark-tts"

    def __init__(self):
        self.app_id = getattr(settings, "SPARK_TTS_APP_ID", "").strip()
        self.api_key = getattr(settings, "SPARK_TTS_API_KEY", "").strip()
        self.api_secret = getattr(settings, "SPARK_TTS_API_SECRET", "").strip()
        self.voice = getattr(settings, "SPARK_TTS_VOICE", "xiaoyan").strip()
        self.url = getattr(settings, "SPARK_TTS_URL", "wss://tts-api.xfyun.cn/v2/tts")

    @property
    def configured(self):
        return bool(self.app_id and self.api_key and self.api_secret)

    def _auth_url(self):
        parsed = urlparse(self.url)
        date = formatdate(timeval=None, localtime=False, usegmt=True)
        signature_origin = f"host: {parsed.netloc}\ndate: {date}\nGET {parsed.path} HTTP/1.1"
        digest = hmac.new(
            self.api_secret.encode("utf-8"), signature_origin.encode("utf-8"), hashlib.sha256
        ).digest()
        signature = base64.b64encode(digest).decode("ascii")
        auth_origin = (
            f'api_key="{self.api_key}", algorithm="hmac-sha256", '
            f'headers="host date request-line", signature="{signature}"'
        )
        params = {
            "authorization": base64.b64encode(auth_origin.encode("utf-8")).decode("ascii"),
            "date": date,
            "host": parsed.netloc,
        }
        return f"{self.url}?{urlencode(params)}"

    def synthesize(self, text, output_path):
        if not self.configured:
            raise ProviderError("讯飞语音合成密钥未配置", "TTS_NOT_CONFIGURED")
        encoded = text.encode("utf-8")
        if len(encoded) >= 8000:
            raise ProviderError("单次语音合成文本超过官方 8000 字节限制", "TTS_TEXT_TOO_LONG")
        try:
            import websocket
        except ImportError as exc:
            raise ProviderError("缺少 websocket-client 运行依赖", "TTS_DEPENDENCY_MISSING") from exc

        ws = websocket.create_connection(self._auth_url(), timeout=getattr(settings, "AI_TIMEOUT", 60))
        payload = {
            "common": {"app_id": self.app_id},
            "business": {
                "aue": "lame", "sfl": 1, "auf": "audio/L16;rate=16000",
                "vcn": self.voice, "tte": "UTF8", "speed": 50, "volume": 50,
                "pitch": 50,
            },
            "data": {"status": 2, "text": base64.b64encode(encoded).decode("ascii")},
        }
        audio = bytearray()
        try:
            ws.send(json.dumps(payload, ensure_ascii=False))
            while True:
                frame = json.loads(ws.recv())
                if int(frame.get("code", 0)) != 0:
                    raise ProviderError(frame.get("message", "语音合成失败"), frame.get("code"))
                data = frame.get("data") or {}
                if data.get("audio"):
                    audio.extend(base64.b64decode(data["audio"]))
                if data.get("status") == 2:
                    break
        finally:
            ws.close()
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(audio)
        return path
