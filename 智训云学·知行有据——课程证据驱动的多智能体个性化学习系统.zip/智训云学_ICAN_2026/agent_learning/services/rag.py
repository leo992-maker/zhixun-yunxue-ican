"""Lightweight Chinese-aware BM25 retrieval with traceable evidence."""

from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import asdict, dataclass

from django.conf import settings

from agent_learning.models import KnowledgeChunk


TOKEN_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?|[\u4e00-\u9fff]+")


def tokenize(text):
    """Tokenize English/code words and add Chinese unigram/bigram recall."""
    tokens = []
    for item in TOKEN_RE.findall((text or "").lower()):
        if re.fullmatch(r"[\u4e00-\u9fff]+", item):
            tokens.extend(item)
            tokens.extend(item[index:index + 2] for index in range(max(0, len(item) - 1)))
            tokens.append(item)
        else:
            tokens.append(item)
    return [token for token in tokens if token.strip()]


def bm25_rank(query, documents, *, k1=1.5, b=0.75):
    """Return normalized ``(index, score)`` pairs for plain text documents."""
    query_tokens = tokenize(query)
    tokenized = [tokenize(text) for text in documents]
    if not query_tokens or not tokenized:
        return []
    avg_len = sum(len(item) for item in tokenized) / max(len(tokenized), 1)
    doc_freq = Counter()
    for tokens in tokenized:
        doc_freq.update(set(tokens))
    raw_scores = []
    for index, tokens in enumerate(tokenized):
        frequencies = Counter(tokens)
        score = 0.0
        for token in query_tokens:
            df = doc_freq.get(token, 0)
            if not df:
                continue
            idf = math.log(1 + (len(tokenized) - df + 0.5) / (df + 0.5))
            tf = frequencies[token]
            denominator = tf + k1 * (1 - b + b * len(tokens) / max(avg_len, 1))
            score += idf * (tf * (k1 + 1)) / denominator
        raw_scores.append(score)
    peak = max(raw_scores) if raw_scores else 0
    ranked = [(index, score / peak if peak else 0.0) for index, score in enumerate(raw_scores)]
    return sorted(ranked, key=lambda item: (-item[1], item[0]))


@dataclass(frozen=True)
class RetrievalEvidence:
    chunk_id: int
    content: str
    document_id: int
    document_title: str
    chapter_id: int
    chapter_title: str
    knowledge_point_id: int
    knowledge_point_title: str
    chunk_no: int
    relevance: float
    document_version: int
    source_reference: str

    def as_dict(self):
        return asdict(self)


def retrieve_evidence(knowledge_base, query, *, top_k=None, point=None):
    top_k = top_k or getattr(settings, "A3_EVIDENCE_TOP_K", 5)
    queryset = KnowledgeChunk.objects.filter(
        document__knowledge_base=knowledge_base,
        document__is_active=True,
        document__status="已解析",
        document__version__is_active=True,
        is_active=True,
    ).select_related("document__version", "chapter", "knowledge_point")
    if point is not None:
        queryset = queryset.filter(knowledge_point=point)
    chunks = list(queryset.order_by("document_id", "chunk_no"))
    ranks = bm25_rank(query, [chunk.content for chunk in chunks])
    minimum = getattr(settings, "A3_MIN_EVIDENCE_SCORE", 0.08)
    evidence = []
    seen = set()
    for index, score in ranks:
        chunk = chunks[index]
        fingerprint = (chunk.document_id, chunk.content.strip()[:120])
        if score < minimum or fingerprint in seen:
            continue
        seen.add(fingerprint)
        evidence.append(RetrievalEvidence(
            chunk_id=chunk.pk,
            content=chunk.content,
            document_id=chunk.document_id,
            document_title=chunk.document.title,
            chapter_id=chunk.chapter_id,
            chapter_title=chunk.chapter.title if chunk.chapter else "未绑定章节",
            knowledge_point_id=chunk.knowledge_point_id,
            knowledge_point_title=chunk.knowledge_point.title if chunk.knowledge_point else "未绑定知识点",
            chunk_no=chunk.chunk_no,
            relevance=round(score, 5),
            document_version=chunk.document.version.version_no,
            source_reference=chunk.document.source_reference,
        ))
        if len(evidence) >= top_k:
            break
    return evidence


INSUFFICIENT_EVIDENCE_MESSAGE = "当前知识库证据不足，未生成确定性结论。"

