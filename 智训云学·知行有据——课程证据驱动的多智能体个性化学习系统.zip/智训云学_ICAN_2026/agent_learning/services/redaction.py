"""Central redaction for logs, API errors and user-visible failure summaries."""

from __future__ import annotations

import re

from django.conf import settings


SECRET_SETTING_NAMES = (
    "SPARK_API_PASSWORD",
    "SPARK_TTS_APP_ID",
    "SPARK_TTS_API_KEY",
    "SPARK_TTS_API_SECRET",
    "AI_API_KEY",
    "GLM_API_KEY",
)


def sanitize_error(value, *, limit=500):
    text = str(value or "")
    for name in SECRET_SETTING_NAMES:
        secret = str(getattr(settings, name, "") or "")
        if len(secret) >= 4:
            text = text.replace(secret, "[已脱敏]")
    text = re.sub(r"(?i)(authorization|api[_-]?key|api[_-]?secret|api[_-]?password|password)\s*[:=]\s*[^\s,;]+", r"\1=[已脱敏]", text)
    text = re.sub(r"(?i)bearer\s+[A-Za-z0-9._~+/=-]+", "Bearer [已脱敏]", text)
    for root in (getattr(settings, "BASE_DIR", ""), getattr(settings, "MEDIA_ROOT", "")):
        if root:
            text = text.replace(str(root), "[项目目录]")
    text = re.sub(r"[A-Za-z]:\\(?:[^\s:\"']+\\){2,}[^\s:\"']*", "[本地路径]", text)
    return text[:limit]
