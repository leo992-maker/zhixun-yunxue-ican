"""Seven evidence-bounded resource generators and deterministic exporters."""

from __future__ import annotations

import hashlib
import html
import json
from pathlib import Path

from django.conf import settings
from django.db import models, transaction
from django.utils import timezone

from agent_learning.models import (
    KnowledgeDocument, PersonalizedResource, ProfileDimension, Question,
    QuestionBank, ResourceCitation,
)
from agent_learning.services.a3_prompts import RESOURCE_PROMPTS, build_resource_messages
from agent_learning.services.providers import SparkTTSProvider, generate_with_fallback
from agent_learning.services.rag import INSUFFICIENT_EVIDENCE_MESSAGE, retrieve_evidence
from agent_learning.services.redaction import sanitize_error
from agent_learning.services.schemas import RESOURCE_SCHEMAS, SchemaValidationError
from agent_learning.services.video_export import export_microcourse_video


RESOURCE_LABELS = dict(PersonalizedResource.RESOURCE_TYPES)
GENERATION_LABELS = {
    "ONLINE_SPARK": "讯飞星火在线生成",
    "ONLINE_FALLBACK": "DeepSeek备用生成",
    "RULE_FALLBACK": "规则降级生成，在线模型未返回有效结果",
    "DEMO_PRESET": "演示预置资源，非本次在线AI生成",
}


def profile_summary(student_id):
    dimensions = ProfileDimension.objects.filter(student_id=student_id).order_by("dimension_code")
    return {
        item.dimension_code: {
            "label": item.label,
            "value": item.value,
            "confirmed": item.is_confirmed,
            "source": item.source,
        }
        for item in dimensions
        if not item.is_rejected
    }


def _profile_value(profile, code, fallback):
    entry = profile.get(code, {}).get("value", {})
    if not entry:
        return fallback
    values = []
    for value in entry.values() if isinstance(entry, dict) else [entry]:
        values.extend(map(str, value)) if isinstance(value, list) else values.append(str(value))
    return "、".join(values) or fallback


def citation_payload(evidence):
    return [
        {
            "chunk_id": item.chunk_id,
            "document_id": item.document_id,
            "document": item.document_title,
            "chapter_id": item.chapter_id,
            "chapter": item.chapter_title,
            "knowledge_point_id": item.knowledge_point_id,
            "knowledge_point": item.knowledge_point_title,
            "chunk_no": item.chunk_no,
            "relevance": item.relevance,
            "document_version": item.document_version,
            "source_reference": item.source_reference,
        }
        for item in evidence
    ]


def _base_context(goal, point, evidence, profile, revision_feedback="", learning_goal=""):
    chapter = point.chapter
    effective_goal = (learning_goal or goal.title).strip()
    # Historical profile weaknesses can belong to a different chapter.  They
    # remain available in student_profile for personalization, but resource
    # subject matter is always bounded to the task's selected knowledge point.
    weak = f"当前知识点“{point.title}”的理解与应用"
    preference = _profile_value(profile, "resource_preference", "讲义与实践结合")
    pace = _profile_value(profile, "pace_time", "每次20分钟")
    scoped_profile = {
        code: value
        for code, value in profile.items()
        if code not in {"weak_points", "learning_goal", "mastered_points"}
    }
    return {
        "student_profile": scoped_profile,
        "learning_goal": effective_goal,
        "course": {"name": goal.knowledge_base.name, "code": goal.knowledge_base.course_code},
        "chapter": {"title": chapter.title, "number": chapter.chapter_no},
        "knowledge_point": {
            "title": point.title,
            "summary": point.summary,
            "difficulty": point.difficulty,
            "tags": point.tags,
        },
        "rag_evidence": [
            {
                "document": item.document_title,
                "chapter": item.chapter_title,
                "knowledge_point": item.knowledge_point_title,
                "excerpt": item.content,
                "version": item.document_version,
                "source": item.source_reference,
            }
            for item in evidence
        ],
        "profile_weakness": weak,
        "resource_preference": preference,
        "study_pace": pace,
        "revision_feedback": revision_feedback,
    }


def _evidence_sentences(context, limit=3):
    return [item["excerpt"].strip() for item in context["rag_evidence"][:limit] if item["excerpt"].strip()]


def _rule_document(context, evidence):
    point = context["knowledge_point"]
    sentences = _evidence_sentences(context)
    code = context.get("chapter_example_code") or (
        f'# 当前知识点：{point["title"]}\n'
        "# 请根据课程讲义补全并解释下面的学习示例\n"
        "learning_result = None"
    )
    return {
        "objectives": [context["learning_goal"], f"能够解释并应用“{point['title']}”"],
        "prerequisites": [context.get("prerequisite") or "阅读本章前置知识提醒", "能阅读基础Python代码"],
        "core_concepts": [point["title"], point["summary"], *point.get("tags", [])[:3]],
        "layered_explanation": [
            {"level": "直观理解", "content": f"先明确“{point['title']}”解决什么学习问题。"},
            {"level": "规则理解", "content": sentences[0] if sentences else point["summary"]},
            {"level": "迁移应用", "content": f"围绕薄弱点“{context['profile_weakness']}”完成代码或题目验证。"},
        ],
        "examples": [
            {"title": f"示例{index}", "description": sentence}
            for index, sentence in enumerate(
                sentences[1:3] or [f"从课程证据中定位“{point['title']}”的输入、过程与结果。"], 1
            )
        ],
        "code_examples": [{"title": "课程内示例", "language": "python", "code": code}],
        "common_mistakes": [f"只记住“{point['title']}”的结论而不验证适用条件", "忽略课程证据中的边界说明"],
        "exercises": [
            {"title": "概念复述", "description": f"用自己的话解释“{point['title']}”", "hint": "先说明适用条件，再说明执行过程。"},
            {"title": "最小验证", "description": "结合课程示例写出一个最小验证过程", "hint": "明确输入、过程和预期结果。"},
        ],
        "summary": [point["summary"], "用概念—示例—练习完成一次闭环"],
        "next_steps": [f"按{context['study_pace']}完成即时练习", "完成题库后根据结果进入补强或下一知识点"],
        "personalization_note": f"针对“{context['profile_weakness']}”并结合{context['resource_preference']}偏好组织。",
    }


def _rule_ppt(context, evidence):
    point = context["knowledge_point"]
    sentences = _evidence_sentences(context, 4)
    example_code = context.get("chapter_example_code") or f'# 学习示例：{point["title"]}\nlearning_result = None'
    slide_specs = [
        (point["title"], [context["course"]["name"], context["learning_goal"]], "", "封面：课程、知识点和个性化目标"),
        ("本节学习目标", [context["learning_goal"], "理解核心规则并完成即时练习"], "", "目标阶梯"),
        ("知识结构", ["前置知识", point["title"], "示例与练习", "学习小结"], "", "由前置到应用的结构图"),
        ("核心概念", [point["summary"], *(sentences[:1] or [])], "", "概念卡片与关键关系"),
        ("示例代码", ["阅读代码前先预测结果", "对照课程证据解释关键步骤"], example_code, "代码高亮与执行路径标注"),
        ("易错点对比", [f"易错：忽略“{point['title']}”的适用条件", "正确：用证据与最小示例验证"], "", "左右对比卡片"),
        ("即时练习", [f"解释“{point['title']}”的核心作用", "完成一个课程内最小案例"], "", "两道渐进式练习"),
        ("总结与下一步", [point["summary"], f"按{context['study_pace']}完成题库与实践"], "", "学习闭环路线"),
        ("内容依据", [f"课程知识库有效片段 {len(evidence)} 条", *[item.document_title for item in evidence[:3]]], "", "真实文档与版本清单"),
    ]
    return {
        "slides": [
            {"title": title, "core_content": bullets, "code": code, "visual_note": visual}
            for title, bullets, code, visual in slide_specs
        ],
        "personalization_note": f"按{context['resource_preference']}偏好与{context['study_pace']}节奏编排。",
    }


def _rule_mindmap(context, evidence):
    point = context["knowledge_point"]
    sentences = _evidence_sentences(context)
    tags = point.get("tags", []) or ["核心规则", "应用条件"]
    children = [
        {
            "label": "核心概念",
            "description": point["summary"],
            "children": [
                {"label": tag, "description": sentences[index % len(sentences)] if sentences else point["summary"], "children": []}
                for index, tag in enumerate(tags[:3])
            ],
        },
        {
            "label": "学习应用",
            "description": context["learning_goal"],
            "children": [
                {"label": "课程示例", "description": "对照知识库片段完成示例分析", "children": []},
                {"label": "即时练习", "description": "用题目检验概念与边界理解", "children": []},
            ],
        },
        {
            "label": "易错与下一步",
            "description": f"重点补强{context['profile_weakness']}",
            "children": [
                {"label": "高频易错", "description": "检查适用条件和边界", "children": []},
                {"label": "后续学习", "description": "完成练习后更新学习路径", "children": []},
            ],
        },
    ]
    return {
        "tree": {"label": point["title"], "description": point["summary"], "children": children},
        "personalization_note": f"突出薄弱点“{context['profile_weakness']}”并压缩为可展开节点。",
    }


def _rule_quiz(context, evidence):
    point = context["knowledge_point"]
    title, summary = point["title"], point["summary"]
    concepts = [title, *point.get("tags", [])[:2]]
    while len(concepts) < 3:
        concepts.append(f"{title}的应用条件")
    questions = [
        {"type": "single", "stem": f"下列哪一项是本次学习的核心知识点？", "options": [title, "与本章无关的内容", "未在课程中出现的概念", "仅用于调试的字段"], "answer": [title], "explanation": summary, "design_purpose": "确认核心概念识别", "profile_fit_reason": f"先建立{title}的清晰定位"},
        {"type": "multiple", "stem": f"学习“{title}”时应同时关注哪些内容？", "options": [concepts[0], concepts[1], concepts[2], "脱离课程证据的结论"], "answer": concepts[:3], "explanation": "课程知识点由概念、适用条件和应用共同构成。", "design_purpose": "检查结构化理解", "profile_fit_reason": f"补强{context['profile_weakness']}"},
        {"type": "true_false", "stem": f'“{summary}”属于当前课程知识点的学习依据。', "options": ["正确", "错误"], "answer": ["正确"], "explanation": "该表述来自当前知识点摘要。", "design_purpose": "判断证据一致性", "profile_fit_reason": "避免把其他知识点结论混入本节"},
        {"type": "fill", "stem": "本次资源围绕的核心知识点是____。", "options": [], "answer": [title], "explanation": f"本次任务选择的知识点是{title}。", "design_purpose": "强化知识点名称与目标", "profile_fit_reason": "帮助建立学习索引"},
        {"type": "short", "stem": f"请用自己的话说明“{title}”的核心作用。", "options": [], "answer": [title], "explanation": summary, "design_purpose": "检查概念表达", "profile_fit_reason": f"针对{context['profile_weakness']}进行主动回忆"},
        {"type": "code", "stem": f"请写一段最小Python示例或伪代码，并用注释说明它如何体现“{title}”。", "options": [], "answer": [title], "explanation": "代码或伪代码需要在注释中准确对应当前知识点；平台只做静态解析。", "design_purpose": "从概念迁移到代码表达", "profile_fit_reason": f"适配{context['resource_preference']}偏好"},
    ]
    return {"questions": questions, "personalization_note": f"六种题型共同诊断“{context['profile_weakness']}”。"}


def _rule_reading(context, evidence):
    return {
        "readings": [
            {
                "title": item.document_title,
                "summary": item.content[:320],
                "recommendation_reason": f"直接支撑“{context['knowledge_point']['title']}”并补强{context['profile_weakness']}。",
                "relation": item.knowledge_point_title,
                "order": index,
                "estimated_minutes": max(3, min(12, len(item.content) // 180 + 2)),
                "source": item.source_reference or item.document_title,
                "document_version": item.document_version,
                "quoted_excerpt": item.content[:220],
            }
            for index, item in enumerate(evidence[:3], 1)
        ],
        "personalization_note": f"按从概念到应用的顺序适配{context['study_pace']}节奏。",
    }


def _rule_practice(context, evidence):
    point = context["knowledge_point"]
    example_code = context.get("chapter_example_code") or (
        f'# 实践知识点：{point["title"]}\n'
        "def learning_case(input_data):\n"
        "    # TODO: 根据课程证据补全处理过程\n"
        "    return input_data"
    )
    return {
        "scenario": f"在课程练习场景中应用“{point['title']}”完成一个可静态检查的小案例。",
        "objectives": [context["learning_goal"], "能够用注释解释关键步骤与边界"],
        "prerequisites": [context.get("prerequisite") or "本章前置知识", "基础Python语法"],
        "starter_code": example_code,
        "io_examples": [{"input": "课程给定的最小输入", "output": "与当前知识点一致的结果说明"}],
        "step_hints": ["先写清输入与预期结果", f"标注“{point['title']}”对应的关键步骤", "检查边界并补充测试用例"],
        "test_cases": [
            {"input": "典型输入", "expected_output": "体现当前知识点的正确结果"},
            {"input": "边界输入", "expected_output": "按课程边界条件处理"},
            {"input": "不符合前置条件的输入", "expected_output": "给出安全、可解释的处理说明"},
        ],
        "reference_implementation": example_code,
        "common_errors": ["代码与当前知识点无关", "注释没有说明适用条件", "把未执行的代码声称为已通过测试"],
        "advanced_challenge": f"把“{point['title']}”迁移到一个新的课程内场景，并说明变化。",
        "safety_notice": "平台只进行安全静态解析，不在Web进程中直接执行不可信代码。",
        "personalization_note": f"针对{context['profile_weakness']}并适配{context['resource_preference']}偏好。",
    }


def _rule_microcourse(context, evidence):
    point = context["knowledge_point"]
    specs = [
        ("问题导入", f"从一个常见学习困惑引出“{point['title']}”。", "问题卡片与课程场景", "激活已有经验"),
        ("核心规则", point["summary"], "概念关系与关键规则", "建立准确概念"),
        ("代码演示", f"逐步观察“{point['title']}”在课程示例中的体现。", "代码高亮与步骤标注", "连接概念与代码"),
        ("错误对比", f"对比忽略适用条件与正确应用“{point['title']}”的差异。", "正确/错误双栏", "修正高频误区"),
        ("即时练习", f"暂停并用自己的话解释“{point['title']}”。", "可暂停题卡", "即时检索练习"),
        ("总结与下一步", f"完成题库和实践后，系统将根据结果调整下一步。", "学习路径与资源卡", "形成学习闭环"),
    ]
    frames = [
        {"index": index, "title": title, "visual": visual, "narration": narration, "teaching_purpose": purpose}
        for index, (title, narration, visual, purpose) in enumerate(specs, 1)
    ]
    return {
        "title": f"{point['title']}个性化微课",
        "duration_minutes": 6,
        "frames": frames,
        "script": "\n\n".join(f"第{item['index']}幕 {item['title']}：{item['narration']}" for item in frames),
        "personalization_note": f"脚本重点补强{context['profile_weakness']}并匹配{context['study_pace']}节奏。",
    }


RULE_BUILDERS = {
    "document": _rule_document,
    "ppt": _rule_ppt,
    "mindmap": _rule_mindmap,
    "quiz": _rule_quiz,
    "reading": _rule_reading,
    "practice": _rule_practice,
    "microcourse": _rule_microcourse,
}


def _canonicalize_model_content(resource_type, content, evidence):
    """Deterministically replace fields that must come from verified sources."""
    if resource_type == "reading":
        for index, item in enumerate(content["readings"]):
            source = evidence[min(index, len(evidence) - 1)]
            item["source"] = source.source_reference or source.document_title
            item["document_version"] = source.document_version
            item["quoted_excerpt"] = source.content[:220]
    return content


def _model_content(resource_type, context, evidence, agent=None):
    schema = RESOURCE_SCHEMAS[resource_type]
    spec = RESOURCE_PROMPTS[resource_type]
    messages = build_resource_messages(resource_type, context)
    result, attempts = generate_with_fallback(
        messages, max_tokens=5200, json_mode=True,
        prompt_version=spec.version, use_case=f"a3_{resource_type}_generation",
    )
    if agent:
        agent.capture_model_attempts(attempts)
    validation_error = None
    if result.is_ai_generated:
        try:
            return _canonicalize_model_content(resource_type, schema.parse(result.text), evidence), result
        except SchemaValidationError as exc:
            validation_error = str(exc)
    if result.is_ai_generated and validation_error:
        repair_messages = [
            {"role": "system", "content": spec.system_prompt},
            {
                "role": "user",
                "content": (
                    f"上次输出未通过{schema.name}校验：{validation_error}。"
                    "请只返回修复后的完整JSON对象。\n"
                    f"Schema：{json.dumps(spec.output_schema, ensure_ascii=False)}\n"
                    f"待修复输出：{result.text[:12000]}"
                ),
            },
        ]
        repaired, repair_attempts = generate_with_fallback(
            repair_messages, max_tokens=5200, json_mode=True,
            prompt_version=spec.version, use_case=f"a3_{resource_type}_schema_repair",
        )
        if agent:
            agent.capture_model_attempts(repair_attempts)
        if repaired.is_ai_generated:
            try:
                return _canonicalize_model_content(resource_type, schema.parse(repaired.text), evidence), repaired
            except SchemaValidationError:
                pass
    return None, result


def _export_root(student_id):
    path = Path(settings.MEDIA_ROOT) / "a3" / "generated" / f"student_{student_id}"
    path.mkdir(parents=True, exist_ok=True)
    return path


def export_docx(resource):
    from docx import Document
    from docx.shared import Pt

    content = resource.content
    document = Document()
    document.styles["Normal"].font.name = "Microsoft YaHei"
    document.styles["Normal"].font.size = Pt(10.5)
    document.add_heading(resource.title, 0)
    document.add_paragraph(f"课程：{resource.knowledge_base.name}")
    document.add_paragraph(f"知识点：{resource.knowledge_point.title}")
    sections = [
        ("本节学习目标", "objectives"), ("前置知识提醒", "prerequisites"),
        ("核心概念", "core_concepts"), ("分层讲解", "layered_explanation"),
        ("示例", "examples"), ("高频易错点", "common_mistakes"),
        ("即时练习", "exercises"), ("学习小结", "summary"),
        ("下一步建议", "next_steps"),
    ]
    for heading, key in sections:
        document.add_heading(heading, level=1)
        for item in content.get(key, []):
            if isinstance(item, dict):
                label = item.get("level") or item.get("title") or "学习内容"
                value = item.get("content") or item.get("code") or ""
                document.add_paragraph(f"{label}：{value}", style="List Bullet")
            else:
                document.add_paragraph(str(item), style="List Bullet")
    for code in content.get("code_examples", []):
        document.add_heading(code.get("title", "示例代码"), level=1)
        document.add_paragraph(code.get("code", ""))
    document.add_heading("AI个性化说明", level=1)
    document.add_paragraph(content.get("personalization_note", resource.adaptation_reason))
    document.add_heading("内容依据", level=1)
    for citation in resource.citations:
        document.add_paragraph(
            f"{citation['document']} / {citation['chapter']} / {citation['knowledge_point']} / "
            f"片段{citation['chunk_no']} / v{citation['document_version']}",
            style="List Bullet",
        )
    path = _export_root(resource.student_id) / f"resource-{resource.pk}-v{resource.version_no}.docx"
    document.save(path)
    return path


def export_pptx(resource):
    from agent_learning.services.ppt_export import build_teaching_deck

    deck = build_teaching_deck(resource)
    path = _export_root(resource.student_id) / f"resource-{resource.pk}-v{resource.version_no}.pptx"
    deck.save(path)
    return path


def export_mindmap_svg(resource):
    tree = resource.content["tree"]
    children = tree.get("children", [])
    width, height = 1200, max(450, 190 + len(children) * 145)
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="#f8fbff"/>',
        '<style>text{font-family:"Microsoft YaHei",sans-serif}.root{fill:#2563eb}.node{fill:#fff;stroke:#93c5fd;stroke-width:2}.edge{stroke:#93c5fd;stroke-width:2}.desc{fill:#64748b;font-size:12px}</style>',
        '<rect class="root" x="35" y="170" width="250" height="78" rx="20"/>',
        f'<text x="160" y="217" text-anchor="middle" fill="white" font-size="23">{html.escape(str(tree.get("label", "知识点")))}</text>',
    ]
    for index, child in enumerate(children):
        y = 55 + index * 145
        parts.extend([
            f'<line class="edge" x1="285" y1="209" x2="365" y2="{y + 42}"/>',
            f'<rect class="node" x="365" y="{y}" width="270" height="84" rx="15"/>',
            f'<text x="500" y="{y + 34}" text-anchor="middle" fill="#0f172a" font-size="20">{html.escape(str(child.get("label", "分支")))}</text>',
            f'<text class="desc" x="500" y="{y + 59}" text-anchor="middle">{html.escape(str(child.get("description", ""))[:28])}</text>',
        ])
        for sub_index, sub in enumerate(child.get("children", [])[:3]):
            sx, sy = 745, y - 8 + sub_index * 67
            parts.extend([
                f'<line class="edge" x1="635" y1="{y + 42}" x2="{sx}" y2="{sy + 27}"/>',
                f'<rect class="node" x="{sx}" y="{sy}" width="365" height="55" rx="12"/>',
                f'<text x="{sx + 182}" y="{sy + 23}" text-anchor="middle" fill="#334155" font-size="16">{html.escape(str(sub.get("label", "节点")))}</text>',
                f'<text class="desc" x="{sx + 182}" y="{sy + 42}" text-anchor="middle">{html.escape(str(sub.get("description", ""))[:38])}</text>',
            ])
    parts.append("</svg>")
    path = _export_root(resource.student_id) / f"resource-{resource.pk}-v{resource.version_no}.svg"
    path.write_text("".join(parts), encoding="utf-8")
    return path


def _create_questions(resource):
    bank, _ = QuestionBank.objects.update_or_create(
        resource=resource, defaults={"title": resource.title, "pass_score": 60}
    )
    bank.questions.all().delete()
    for index, item in enumerate(resource.content.get("questions", []), 1):
        Question.objects.create(
            bank=bank,
            question_type=item["type"],
            sequence=index,
            stem=item["stem"],
            options=item.get("options", []),
            correct_answer=item["answer"],
            explanation=item["explanation"],
            difficulty=resource.difficulty,
            knowledge_point=resource.knowledge_point,
            design_purpose=item.get("design_purpose", "诊断当前知识点理解"),
            profile_fit_reason=item.get("profile_fit_reason", resource.adaptation_reason),
        )


def _generation_mode(result, demo_preset):
    if demo_preset:
        return "DEMO_PRESET"
    if result and result.is_ai_generated and result.provider == "spark":
        return "ONLINE_SPARK"
    if result and result.is_ai_generated and result.provider == "deepseek":
        return "ONLINE_FALLBACK"
    return "RULE_FALLBACK"


def generate_resource(
    student_id, goal, point, resource_type, *, run=None, demo_preset=False,
    generation_key=None, agent=None, parent=None, revision_feedback="",
    learning_goal="",
):
    if resource_type not in RULE_BUILDERS:
        raise ValueError(f"不支持的资源类型：{resource_type}")
    if point.chapter.knowledge_base_id != goal.knowledge_base_id:
        raise ValueError("任务知识点不属于所选课程")
    effective_goal = (learning_goal or goal.title).strip()
    evidence = retrieve_evidence(
        goal.knowledge_base,
        f"{effective_goal} {point.chapter.title} {point.title} {point.summary}",
        point=point,
    )
    if not evidence:
        raise ValueError(INSUFFICIENT_EVIDENCE_MESSAGE)
    profile = profile_summary(student_id)
    context = _base_context(
        goal, point, evidence, profile, revision_feedback, effective_goal
    )
    context["chapter_example_code"] = point.chapter.example_code
    context["prerequisite"] = point.chapter.prerequisite_summary

    model_result = None
    content = None
    if not demo_preset:
        content, model_result = _model_content(resource_type, context, evidence, agent=agent)
    used_model_content = content is not None
    if content is None:
        content = RULE_BUILDERS[resource_type](context, evidence)
        RESOURCE_SCHEMAS[resource_type].validate(content)

    mode = _generation_mode(model_result if used_model_content else None, demo_preset)
    if model_result and not model_result.is_ai_generated:
        mode = "RULE_FALLBACK" if not demo_preset else "DEMO_PRESET"
    source_type = GENERATION_LABELS[mode]
    provider_name = model_result.provider if mode in {"ONLINE_SPARK", "ONLINE_FALLBACK"} else ""
    model_name = model_result.model if provider_name else ""
    citations = citation_payload(evidence)
    key = generation_key or hashlib.sha256(
        f"{student_id}:{goal.pk}:{point.pk}:{resource_type}:{timezone.now().isoformat()}".encode()
    ).hexdigest()[:80]
    existing = PersonalizedResource.objects.filter(generation_key=key).first()
    if existing:
        return existing
    adaptation_reason = (
        f"围绕本次目标“{effective_goal}”和知识点“{point.title}”生成；"
        f"匹配{context['resource_preference']}偏好与{context['study_pace']}学习节奏。"
    )
    version_no = parent.version_no + 1 if parent else 1
    with transaction.atomic():
        resource = PersonalizedResource.objects.create(
            knowledge_base=goal.knowledge_base,
            student_id=student_id,
            knowledge_point=point,
            resource_type=resource_type,
            title=f"{point.title} · {RESOURCE_LABELS[resource_type]}",
            summary=f"围绕“{effective_goal}”学习{point.title}，重点补强{context['profile_weakness']}。",
            adaptation_reason=adaptation_reason,
            content=content,
            rendered_html="",
            suitable_for=f"偏好{context['resource_preference']}、{context['study_pace']}的学习者",
            learning_objective=effective_goal,
            difficulty=point.difficulty,
            estimated_minutes=point.estimated_minutes if resource_type in {"document", "practice"} else max(6, min(18, point.estimated_minutes)),
            source_type=source_type,
            generation_mode=mode,
            is_ai_generated=bool(mode in {"ONLINE_SPARK", "ONLINE_FALLBACK"}),
            is_degraded=bool(mode == "RULE_FALLBACK"),
            failure_code=(model_result.error_code if model_result else ""),
            latency_ms=(model_result.latency_ms if model_result else 0),
            input_tokens=(model_result.input_tokens if model_result else 0),
            output_tokens=(model_result.output_tokens if model_result else 0),
            prompt_version=RESOURCE_PROMPTS[resource_type].version,
            confidence_status="依据充分",
            provider=provider_name,
            model=model_name,
            citations=citations,
            version_no=version_no,
            parent=parent,
            generation_key=key,
            is_demo_preset=demo_preset,
            revision_reason=revision_feedback if parent else "",
            difference_summary=(f"v{version_no}根据质量审核意见修订：{revision_feedback[:180]}" if parent else ""),
            audio_generation_status="待生成" if resource_type == "microcourse" else "未生成",
            video_generation_status="未生成",
        )
        for item in evidence:
            ResourceCitation.objects.create(
                resource=resource,
                chunk_id=item.chunk_id,
                document_id=item.document_id,
                chapter_id=item.chapter_id,
                knowledge_point_id=item.knowledge_point_id,
                chunk_no=item.chunk_no,
                relevance=item.relevance,
                document_version=item.document_version,
            )
        KnowledgeDocument.objects.filter(pk__in={item.document_id for item in evidence}).update(
            citation_count=models.F("citation_count") + 1
        )
        if resource_type == "quiz":
            _create_questions(resource)

    file_path = ""
    if resource_type == "document":
        file_path = str(export_docx(resource).relative_to(settings.MEDIA_ROOT)).replace("\\", "/")
    elif resource_type == "ppt":
        file_path = str(export_pptx(resource).relative_to(settings.MEDIA_ROOT)).replace("\\", "/")
    elif resource_type == "mindmap":
        file_path = str(export_mindmap_svg(resource).relative_to(settings.MEDIA_ROOT)).replace("\\", "/")

    if resource_type == "microcourse":
        tts = SparkTTSProvider()
        if tts.configured:
            target = _export_root(student_id) / f"resource-{resource.pk}-v{resource.version_no}.mp3"
            try:
                tts.synthesize(content["script"], target)
                resource.audio_path = str(target.relative_to(settings.MEDIA_ROOT)).replace("\\", "/")
                resource.audio_generation_status = "讯飞语音合成已完成"
            except Exception as exc:
                resource.audio_generation_status = f"讯飞语音合成失败：{sanitize_error(exc, limit=38)}"[:60]
        else:
            resource.audio_generation_status = "讯飞语音服务未配置"
        target = _export_root(student_id) / f"resource-{resource.pk}-v{resource.version_no}.mp4"
        try:
            audio = Path(settings.MEDIA_ROOT) / resource.audio_path if resource.audio_path else None
            has_audio = export_microcourse_video(content, target, audio_path=audio)
            file_path = str(target.relative_to(settings.MEDIA_ROOT)).replace("\\", "/")
            resource.video_generation_status = "分镜MP4已生成（含语音）" if has_audio else "静音分镜MP4已生成（语音不可用）"
        except Exception:
            # A failed encoder must not invalidate the generated script, frames
            # or successfully synthesized MP3; never link to a partial MP4.
            resource.video_generation_status = "视频合成失败；脚本、分镜和可用语音仍可查看"

    resource.file_path = file_path
    resource.save(update_fields=[
        "file_path", "audio_path", "audio_generation_status", "video_generation_status", "updated_at",
    ])
    return resource
