"""Content-safety and anti-hallucination checks for A3 outputs."""

from __future__ import annotations

import re


INJECTION_PATTERNS = [
    r"忽略.{0,12}(系统|之前|以上).{0,12}(指令|提示)",
    r"(?:system prompt|developer message|ignore previous)",
    r"越狱|jailbreak|绕过.{0,8}(安全|限制)",
]
SENSITIVE_PATTERNS = [r"制作.{0,5}(炸弹|毒品)", r"窃取.{0,8}(密码|密钥)", r"自残|自杀方法"]
FAKE_SOURCE_PATTERNS = [r"https?://[^\s\])>]+", r"第\s*\d+\s*页"]


def inspect_input(text):
    checks = {
        "prompt_injection": any(re.search(pattern, text or "", re.I) for pattern in INJECTION_PATTERNS),
        "sensitive_content": any(re.search(pattern, text or "", re.I) for pattern in SENSITIVE_PATTERNS),
        "course_scope": any(token in (text or "").lower() for token in ["python", "函数", "异常", "列表", "循环", "文件", "类", "数据"]),
    }
    issues = [label for label, failed in checks.items() if failed and label != "course_scope"]
    if text and not checks["course_scope"]:
        issues.append("out_of_course_scope")
    return {"allowed": not issues, "checks": checks, "issues": issues}


def validate_citations(citations, evidence):
    valid_ids = {item.chunk_id for item in evidence}
    cited_ids = {int(item.get("chunk_id", 0)) for item in citations}
    return cited_ids.issubset(valid_ids) and bool(cited_ids)


def inspect_output(content, citations, evidence):
    text = content if isinstance(content, str) else str(content)
    fake_reference = bool(FAKE_SOURCE_PATTERNS[0] and re.search(FAKE_SOURCE_PATTERNS[0], text))
    page_reference = bool(re.search(FAKE_SOURCE_PATTERNS[1], text))
    citation_valid = validate_citations(citations, evidence) if evidence else not citations
    issues = []
    if fake_reference:
        issues.append("unverified_external_link")
    if page_reference:
        issues.append("unverified_page_number")
    if not citation_valid:
        issues.append("invalid_citation")
    checks = {
        "citation_valid": citation_valid,
        "no_unverified_link": not fake_reference,
        "no_unverified_page": not page_reference,
        "html_not_executable": "<script" not in text.lower(),
    }
    if not checks["html_not_executable"]:
        issues.append("executable_html")
    return {"passed": not issues, "checks": checks, "issues": issues}
