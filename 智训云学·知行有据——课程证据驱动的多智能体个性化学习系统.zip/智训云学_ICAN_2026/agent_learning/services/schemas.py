"""Strict JSON contracts for the seven A3 learning-resource agents."""

from __future__ import annotations

import json
import re


class SchemaValidationError(ValueError):
    pass


class ResourceSchema:
    name = "ResourceSchema"
    required: dict[str, type] = {}
    property_schemas: dict[str, dict] = {}

    @classmethod
    def json_schema(cls):
        type_names = {str: "string", list: "array", dict: "object", int: "integer"}
        properties = {
            key: dict(cls.property_schemas.get(key) or {"type": type_names.get(value, "string")})
            for key, value in cls.required.items()
        }
        return {
            "title": cls.name,
            "type": "object",
            "additionalProperties": False,
            "required": list(cls.required),
            "properties": properties,
        }

    @classmethod
    def validate(cls, value):
        if not isinstance(value, dict):
            raise SchemaValidationError(f"{cls.name} 顶层必须是JSON对象")
        missing = [key for key in cls.required if key not in value]
        if missing:
            raise SchemaValidationError(f"{cls.name} 缺少字段：{', '.join(missing)}")
        unexpected = sorted(set(value) - set(cls.required))
        if unexpected:
            raise SchemaValidationError(f"{cls.name} 包含未声明字段：{', '.join(unexpected)}")
        for key, expected in cls.required.items():
            if not isinstance(value[key], expected):
                raise SchemaValidationError(f"{cls.name}.{key} 类型不正确")
        cls.validate_nested(value)
        return value

    @classmethod
    def validate_nested(cls, value):
        return None

    @classmethod
    def parse(cls, raw_text):
        text = (raw_text or "").strip()
        fenced = re.fullmatch(r"```(?:json)?\s*(.*?)\s*```", text, flags=re.I | re.S)
        if fenced:
            text = fenced.group(1)
        try:
            value = json.loads(text)
        except (TypeError, json.JSONDecodeError) as exc:
            raise SchemaValidationError(f"{cls.name} 不是有效JSON") from exc
        return cls.validate(value)


def _require_object_items(items, required, label):
    if not items:
        raise SchemaValidationError(f"{label} 至少需要一项")
    for index, item in enumerate(items, 1):
        if not isinstance(item, dict):
            raise SchemaValidationError(f"{label}第{index}项必须是对象")
        for key, kind in required.items():
            if key not in item or not isinstance(item[key], kind):
                raise SchemaValidationError(f"{label}第{index}项的{key}字段无效")


TEXT_LIST_SCHEMA = {"type": "array", "items": {"type": "string"}, "minItems": 1}


class DocumentResourceSchema(ResourceSchema):
    name = "DocumentResourceSchema"
    required = {
        "objectives": list,
        "prerequisites": list,
        "core_concepts": list,
        "layered_explanation": list,
        "examples": list,
        "code_examples": list,
        "common_mistakes": list,
        "exercises": list,
        "summary": list,
        "next_steps": list,
        "personalization_note": str,
    }
    property_schemas = {
        **{key: TEXT_LIST_SCHEMA for key in (
            "objectives", "prerequisites", "core_concepts", "common_mistakes", "summary", "next_steps"
        )},
        "layered_explanation": {
            "type": "array", "minItems": 1,
            "items": {"type": "object", "additionalProperties": False,
                      "required": ["level", "content"],
                      "properties": {"level": {"type": "string"}, "content": {"type": "string"}}},
        },
        "examples": {
            "type": "array", "minItems": 1,
            "items": {"type": "object", "additionalProperties": False,
                      "required": ["title", "description"],
                      "properties": {"title": {"type": "string"}, "description": {"type": "string"}}},
        },
        "code_examples": {
            "type": "array", "minItems": 1,
            "items": {"type": "object", "additionalProperties": False,
                      "required": ["title", "language", "code"],
                      "properties": {"title": {"type": "string"}, "language": {"type": "string"}, "code": {"type": "string"}}},
        },
        "exercises": {
            "type": "array", "minItems": 1,
            "items": {"type": "object", "additionalProperties": False,
                      "required": ["title", "description", "hint"],
                      "properties": {"title": {"type": "string"}, "description": {"type": "string"}, "hint": {"type": "string"}}},
        },
        "personalization_note": {"type": "string"},
    }

    @classmethod
    def validate_nested(cls, value):
        for key in ("objectives", "prerequisites", "core_concepts", "common_mistakes", "summary", "next_steps"):
            if not value[key] or any(not isinstance(item, str) for item in value[key]):
                raise SchemaValidationError(f"讲义{key}必须是非空文本列表")
        _require_object_items(value["layered_explanation"], {"level": str, "content": str}, "分层讲解")
        _require_object_items(value["examples"], {"title": str, "description": str}, "示例")
        _require_object_items(value["code_examples"], {"title": str, "language": str, "code": str}, "示例代码")
        _require_object_items(value["exercises"], {"title": str, "description": str, "hint": str}, "即时练习")


class PPTResourceSchema(ResourceSchema):
    name = "PPTResourceSchema"
    required = {"slides": list, "personalization_note": str}
    property_schemas = {
        "slides": {
            "type": "array", "minItems": 9, "maxItems": 9,
            "items": {"type": "object", "additionalProperties": False,
                      "required": ["title", "core_content", "code", "visual_note"],
                      "properties": {
                          "title": {"type": "string"},
                          "core_content": {"type": "array", "items": {"type": "string"}, "minItems": 1},
                          "code": {"type": "string"}, "visual_note": {"type": "string"},
                      }},
        },
        "personalization_note": {"type": "string"},
    }

    @classmethod
    def validate_nested(cls, value):
        if len(value["slides"]) != 9:
            raise SchemaValidationError("PPT必须包含9页完整教学结构")
        _require_object_items(
            value["slides"],
            {"title": str, "core_content": list, "code": str, "visual_note": str},
            "幻灯片",
        )


class MindmapResourceSchema(ResourceSchema):
    name = "MindmapResourceSchema"
    required = {"tree": dict, "personalization_note": str}
    property_schemas = {
        "tree": {
            "type": "object", "additionalProperties": False,
            "required": ["label", "description", "children"],
            "properties": {
                "label": {"type": "string"}, "description": {"type": "string"},
                "children": {"type": "array", "minItems": 2, "items": {"type": "object"}},
            },
        },
        "personalization_note": {"type": "string"},
    }

    @classmethod
    def validate_nested(cls, value):
        def validate_node(node, label):
            if not isinstance(node, dict):
                raise SchemaValidationError(f"{label}必须是节点对象")
            required = {"label": str, "description": str, "children": list}
            for key, kind in required.items():
                if key not in node or not isinstance(node[key], kind):
                    raise SchemaValidationError(f"{label}的{key}字段无效")
            for index, child in enumerate(node["children"], 1):
                validate_node(child, f"{label}子节点{index}")
        validate_node(value["tree"], "思维导图中心主题")
        if len(value["tree"]["children"]) < 2:
            raise SchemaValidationError("思维导图至少需要两个一级分支")


class QuizResourceSchema(ResourceSchema):
    name = "QuizResourceSchema"
    required = {"questions": list, "personalization_note": str}
    property_schemas = {
        "questions": {
            "type": "array", "minItems": 6, "maxItems": 6,
            "items": {"type": "object", "additionalProperties": False,
                      "required": ["type", "stem", "options", "answer", "explanation", "design_purpose", "profile_fit_reason"],
                      "properties": {
                          "type": {"type": "string", "enum": ["single", "multiple", "true_false", "fill", "short", "code"]},
                          "stem": {"type": "string"}, "options": {"type": "array", "items": {"type": "string"}},
                          "answer": {"type": "array", "items": {"type": "string"}, "minItems": 1},
                          "explanation": {"type": "string"}, "design_purpose": {"type": "string"},
                          "profile_fit_reason": {"type": "string"},
                      }},
        },
        "personalization_note": {"type": "string"},
    }

    @classmethod
    def validate_nested(cls, value):
        _require_object_items(
            value["questions"],
            {
                "type": str,
                "stem": str,
                "options": list,
                "answer": list,
                "explanation": str,
                "design_purpose": str,
                "profile_fit_reason": str,
            },
            "练习题",
        )
        allowed = {"single", "multiple", "true_false", "fill", "short", "code"}
        invalid = [item["type"] for item in value["questions"] if item["type"] not in allowed]
        if invalid:
            raise SchemaValidationError("题型必须是单选、多选、判断、填空、简答或代码题")
        if {item["type"] for item in value["questions"]} != allowed:
            raise SchemaValidationError("题库必须完整包含六种题型")
        if len(value["questions"]) != 6:
            raise SchemaValidationError("题库必须恰好包含六道不同题型的题目")


class ReadingResourceSchema(ResourceSchema):
    name = "ReadingResourceSchema"
    required = {"readings": list, "personalization_note": str}
    property_schemas = {
        "readings": {
            "type": "array", "minItems": 1, "maxItems": 3,
            "items": {"type": "object", "additionalProperties": False,
                      "required": ["title", "summary", "recommendation_reason", "relation", "order", "estimated_minutes", "source", "document_version", "quoted_excerpt"],
                      "properties": {
                          "title": {"type": "string"}, "summary": {"type": "string"},
                          "recommendation_reason": {"type": "string"}, "relation": {"type": "string"},
                          "order": {"type": "integer"}, "estimated_minutes": {"type": "integer"},
                          "source": {"type": "string"}, "document_version": {"type": "integer"},
                          "quoted_excerpt": {"type": "string"},
                      }},
        },
        "personalization_note": {"type": "string"},
    }

    @classmethod
    def validate_nested(cls, value):
        _require_object_items(
            value["readings"],
            {
                "title": str,
                "summary": str,
                "recommendation_reason": str,
                "relation": str,
                "order": int,
                "estimated_minutes": int,
                "source": str,
                "document_version": int,
                "quoted_excerpt": str,
            },
            "拓展阅读",
        )


class PracticeResourceSchema(ResourceSchema):
    name = "PracticeResourceSchema"
    required = {
        "scenario": str,
        "objectives": list,
        "prerequisites": list,
        "starter_code": str,
        "io_examples": list,
        "step_hints": list,
        "test_cases": list,
        "reference_implementation": str,
        "common_errors": list,
        "advanced_challenge": str,
        "safety_notice": str,
        "personalization_note": str,
    }
    property_schemas = {
        "scenario": {"type": "string"},
        "objectives": {"type": "array", "items": {"type": "string"}, "minItems": 1},
        "prerequisites": {"type": "array", "items": {"type": "string"}, "minItems": 1},
        "starter_code": {"type": "string"},
        "io_examples": {
            "type": "array", "minItems": 1,
            "items": {"type": "object", "additionalProperties": False,
                      "required": ["input", "output"],
                      "properties": {"input": {"type": "string"}, "output": {"type": "string"}}},
        },
        "step_hints": {"type": "array", "items": {"type": "string"}, "minItems": 1},
        "test_cases": {
            "type": "array", "minItems": 2,
            "items": {"type": "object", "additionalProperties": False,
                      "required": ["input", "expected_output"],
                      "properties": {"input": {"type": "string"}, "expected_output": {"type": "string"}}},
        },
        "reference_implementation": {"type": "string"},
        "common_errors": {"type": "array", "items": {"type": "string"}, "minItems": 1},
        "advanced_challenge": {"type": "string"}, "safety_notice": {"type": "string"},
        "personalization_note": {"type": "string"},
    }

    @classmethod
    def validate_nested(cls, value):
        for key in ("objectives", "prerequisites", "step_hints", "common_errors"):
            if not value[key] or any(not isinstance(item, str) for item in value[key]):
                raise SchemaValidationError(f"代码实操{key}必须是非空文本列表")
        _require_object_items(value["io_examples"], {"input": str, "output": str}, "输入输出示例")
        _require_object_items(value["test_cases"], {"input": str, "expected_output": str}, "测试用例")


class MicrocourseResourceSchema(ResourceSchema):
    name = "MicrocourseResourceSchema"
    required = {
        "title": str,
        "duration_minutes": int,
        "frames": list,
        "script": str,
        "personalization_note": str,
    }
    property_schemas = {
        "title": {"type": "string"}, "duration_minutes": {"type": "integer"},
        "frames": {
            "type": "array", "minItems": 6, "maxItems": 6,
            "items": {"type": "object", "additionalProperties": False,
                      "required": ["index", "title", "visual", "narration", "teaching_purpose"],
                      "properties": {
                          "index": {"type": "integer"}, "title": {"type": "string"},
                          "visual": {"type": "string"}, "narration": {"type": "string"},
                          "teaching_purpose": {"type": "string"},
                      }},
        },
        "script": {"type": "string"}, "personalization_note": {"type": "string"},
    }

    @classmethod
    def validate_nested(cls, value):
        if len(value["frames"]) != 6:
            raise SchemaValidationError("微课必须包含六幕分镜")
        _require_object_items(
            value["frames"],
            {
                "index": int,
                "title": str,
                "visual": str,
                "narration": str,
                "teaching_purpose": str,
            },
            "微课分镜",
        )


RESOURCE_SCHEMAS = {
    "document": DocumentResourceSchema,
    "ppt": PPTResourceSchema,
    "mindmap": MindmapResourceSchema,
    "quiz": QuizResourceSchema,
    "reading": ReadingResourceSchema,
    "practice": PracticeResourceSchema,
    "microcourse": MicrocourseResourceSchema,
}
