"""Course-scoped tutor with retrieval evidence and explicit provenance."""

from __future__ import annotations

from decimal import Decimal

from django.db import transaction

from agent_learning.models import TutorConversation, TutorMessage
from agent_learning.services.providers import generate_with_fallback
from agent_learning.services.rag import INSUFFICIENT_EVIDENCE_MESSAGE, retrieve_evidence
from agent_learning.services.resources import citation_payload, profile_summary
from agent_learning.services.safety import inspect_input, inspect_output


STYLE_INSTRUCTIONS = {
    "简单解释": "用通俗语言和一个短例子回答",
    "详细讲解": "分步骤解释概念、规则、边界和易错点",
    "举例说明": "用两个由浅入深的例子说明",
    "图解说明": "用安全Markdown流程图式文本说明",
    "代码示例": "给出短小Python代码并解释，不执行代码",
    "出一道相似题": "先提示思路，再给一道相似题，不直接泄露答案",
    "生成微课讲解": "给出3至5帧微课脚本与每帧旁白",
}


@transaction.atomic
def answer_tutor(student_id, knowledge_base, point, question, *, style="简单解释", resource=None):
    safety = inspect_input(question)
    conversation = TutorConversation.objects.create(
        student_id=student_id, knowledge_base=knowledge_base,
        knowledge_point=point, resource=resource, answer_style=style,
    )
    TutorMessage.objects.create(
        conversation=conversation, role="student", content=question,
        citations=[], confidence=1, is_ai_generated=False, evidence_status="学生输入",
    )
    if not safety["allowed"]:
        answer = f"该问题包含提示词注入、敏感内容或超出《{knowledge_base.name}》课程范围，学习导师未继续处理。"
        return TutorMessage.objects.create(
            conversation=conversation, role="tutor", content=answer,
            citations=[], confidence=0, is_ai_generated=False, evidence_status="安全拒绝",
        )
    evidence = retrieve_evidence(knowledge_base, f"{point.title} {question}", point=point)
    if not evidence:
        return TutorMessage.objects.create(
            conversation=conversation, role="tutor", content=INSUFFICIENT_EVIDENCE_MESSAGE,
            citations=[], confidence=0, is_ai_generated=False, evidence_status="依据不足",
        )
    context = "\n\n".join(item.content for item in evidence)
    result, _attempts = generate_with_fallback([
        {
            "role": "system",
            "content": f"你是《{knowledge_base.name}》课程内学习导师。只能依据提供的知识库证据回答，不得虚构教材、作者、链接或页码；证据不足必须说明。",
        },
        {
            "role": "user",
            "content": f"回答方式：{STYLE_INSTRUCTIONS.get(style, STYLE_INSTRUCTIONS['简单解释'])}\n问题：{question}\n课程证据：{context[:6000]}",
        },
    ], temperature=0.2, max_tokens=1000, json_mode=False,
       prompt_version="a3-tutor-v2", use_case="a3_tutor_answer")
    if result.is_ai_generated:
        content = result.text
        output_check = inspect_output(content, citation_payload(evidence), evidence)
        if not output_check["passed"]:
            return TutorMessage.objects.create(
                conversation=conversation, role="tutor",
                content="生成内容未通过课程依据与安全检查，请换一种问法或联系教师核实。",
                citations=[], confidence=0, is_ai_generated=False,
                evidence_status="生成内容未通过安全检查",
            )
        # A retrieval score cannot establish the factual accuracy of the model's
        # answer. Keep the existing UI field neutral until a calibrated study exists.
        confidence = Decimal("0.000")
        source = True
    else:
        content = (
            f"规则降级讲解：{point.summary}\n\n"
            f"结合课程资料，建议先按“具体规则—短代码—边界测试”的顺序理解。"
            f"针对你的问题“{question[:80]}”，可先检查输入、执行路径和返回值。"
        )
        confidence = Decimal("0.720")
        source = False
    status = "依据充分"
    if source:
        status = "依据充分·星火" if result.provider == "spark" else "依据充分·备用模型"
    return TutorMessage.objects.create(
        conversation=conversation, role="tutor", content=content,
        citations=citation_payload(evidence), confidence=confidence,
        is_ai_generated=source, evidence_status=status,
    )
