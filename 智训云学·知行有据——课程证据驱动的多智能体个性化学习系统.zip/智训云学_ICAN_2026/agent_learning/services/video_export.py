"""Render an honest, six-scene microcourse MP4 from storyboard and optional TTS.

This is a slide video, not a text-to-video model.  The bundled OFL Chinese
font ensures the same glyphs render in Docker and on the developer's machine.
"""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


FONT_PATH = Path(__file__).resolve().parents[2] / "assets" / "fonts" / "NotoSansSC-VF.ttf"
SIZE = (1280, 720)


class VideoExportError(RuntimeError):
    """Expected encoder, font, audio, or storyboard failure."""


def _run(command, *, timeout):
    try:
        result = subprocess.run(command, capture_output=True, text=True, timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise VideoExportError("视频工具未安装或处理超时") from exc
    if result.returncode:
        raise VideoExportError("媒体编码失败，请确认 FFmpeg 可用且音频文件有效")
    return result.stdout


def _audio_duration(path, ffprobe):
    result = json.loads(_run([
        ffprobe, "-v", "error", "-show_entries", "format=duration",
        "-of", "json", str(path),
    ], timeout=12))
    seconds = float(result.get("format", {}).get("duration", 0))
    if not 0.5 <= seconds <= 480:
        raise VideoExportError("语音长度不在可处理范围内")
    return seconds


def _font(size, font_path):
    try:
        return ImageFont.truetype(str(font_path), size)
    except (OSError, ValueError) as exc:
        raise VideoExportError("缺少可用的中文字体文件") from exc


def _wrap(draw, value, font, max_width, max_lines):
    """Pixel-based wrapping works for mixed Chinese, ASCII, and punctuation."""
    lines, line = [], ""
    for char in str(value or "").replace("\r", "").strip():
        if char == "\n":
            lines.append(line)
            line = ""
            continue
        if draw.textlength(line + char, font=font) > max_width and line:
            lines.append(line)
            line = char
        else:
            line += char
    if line:
        lines.append(line)
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        tail = lines[-1]
        while tail and draw.textlength(tail + "…", font=font) > max_width:
            tail = tail[:-1]
        lines[-1] = tail + "…"
    return lines


def _lines(draw, text, xy, font, *, width, count, fill, spacing):
    x, y = xy
    for line in _wrap(draw, text, font, width, count):
        draw.text((x, y), line, font=font, fill=fill)
        y += spacing


def _render(frame, index, total, title, target, font_path):
    image = Image.new("RGB", SIZE, "#F5F9FE")
    draw = ImageDraw.Draw(image)
    white, navy, blue, muted = "#FFFFFF", "#10243C", "#196BC1", "#52647B"
    draw.rectangle((0, 0, 1280, 180), fill=navy)
    draw.rounded_rectangle((72, 43, 223, 85), 18, fill="#21A6B6")
    draw.text((91, 50), "智训云学  ·  微课", font=_font(19, font_path), fill=white)
    draw.text((1080, 48), f"{index:02d} / {total:02d}", font=_font(25, font_path), fill="#BDDEF6")
    _lines(draw, title, (72, 107), _font(36, font_path), width=1120, count=1, fill=white, spacing=48)
    draw.rounded_rectangle((60, 207, 1220, 628), radius=28, fill=white, outline="#DDE8F4", width=2)
    scene_title = str(frame.get("title") or f"第{index}幕")
    _lines(draw, scene_title, (95, 239), _font(39, font_path), width=1040, count=1, fill=navy, spacing=52)
    draw.rectangle((95, 317, 105, 423), fill="#F39A38")
    draw.text((127, 318), "画面设计", font=_font(21, font_path), fill=blue)
    _lines(draw, frame.get("visual", ""), (127, 351), _font(26, font_path), width=1000, count=2, fill=navy, spacing=38)
    draw.text((96, 453), "讲解旁白", font=_font(21, font_path), fill=blue)
    _lines(draw, frame.get("narration", ""), (96, 488), _font(28, font_path), width=1055, count=3, fill=navy, spacing=39)
    _lines(draw, "学习目标：" + str(frame.get("teaching_purpose", "")),
           (75, 652), _font(19, font_path), width=1040, count=1, fill=muted, spacing=28)
    draw.rectangle((1074, 690, 1074 + int(144 * index / total), 697), fill=blue)
    image.save(target, format="PNG", optimize=True)


def export_microcourse_video(content, target, *, audio_path=None, ffmpeg="ffmpeg", ffprobe="ffprobe", font_path=FONT_PATH):
    """Create an H.264/yuv420p MP4; return whether a valid narration was muxed.

    Output is atomically replaced only after a successful encode.  With no TTS
    audio it creates a clearly labelled silent storyboard, so model service
    availability never masquerades as a completed voice track.
    """
    frames = content.get("frames") if isinstance(content, dict) else None
    if not isinstance(frames, list) or not 1 <= len(frames) <= 12 or not all(isinstance(x, dict) for x in frames):
        raise VideoExportError("微课缺少有效分镜")
    font_path, target = Path(font_path), Path(target)
    if not font_path.is_file():
        raise VideoExportError("缺少可嵌入的中文字体")
    audio = Path(audio_path) if audio_path else None
    if audio and not audio.is_file():
        raise VideoExportError("语音文件不存在")
    duration = _audio_duration(audio, ffprobe) if audio else len(frames) * 5.0
    # A little extra time on information-dense scenes, while preserving exact
    # total audio length and keeping the six title cards in sync with speech.
    weights = [max(12, len(str(x.get("narration", "")))) for x in frames]
    durations = [duration * weight / sum(weights) for weight in weights]
    target.parent.mkdir(parents=True, exist_ok=True)
    partial = target.with_name(target.stem + ".part.mp4")
    try:
        with tempfile.TemporaryDirectory(prefix="a3-video-") as temp:
            directory = Path(temp)
            slides = []
            for index, frame in enumerate(frames, 1):
                slide = directory / f"slide-{index:02d}.png"
                _render(frame, index, len(frames), str(content.get("title", "个性化微课")), slide, font_path)
                slides.append(slide)
            manifest = directory / "slides.txt"
            with manifest.open("w", encoding="utf-8") as handle:
                for slide, seconds in zip(slides, durations):
                    handle.write(f"file '{slide}'\nduration {seconds:.4f}\n")
                handle.write(f"file '{slides[-1]}'\n")
            command = [ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", str(manifest)]
            if audio:
                command += ["-i", str(audio)]
            command += ["-vf", "fps=25,format=yuv420p", "-c:v", "libx264", "-preset", "veryfast", "-crf", "25"]
            command += ["-c:a", "aac", "-b:a", "128k"] if audio else ["-an"]
            command += ["-t", f"{duration:.3f}", "-movflags", "+faststart", str(partial)]
            _run(command, timeout=180)
            if not partial.is_file() or partial.stat().st_size < 1000:
                raise VideoExportError("视频文件未正确生成")
            os.replace(partial, target)
    finally:
        partial.unlink(missing_ok=True)
    return bool(audio)
