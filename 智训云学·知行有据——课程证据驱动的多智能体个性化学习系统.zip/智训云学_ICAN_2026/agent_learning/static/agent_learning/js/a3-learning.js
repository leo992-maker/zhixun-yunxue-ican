(() => {
  "use strict";

  const csrf = () => document.cookie.split("; ").find(value => value.startsWith("csrftoken="))?.split("=")[1] || "";
  const escapeHtml = value => String(value ?? "").replace(/[&<>'"]/g, character => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[character]));
  const readable = value => Array.isArray(value) ? value.join("、") : (value && typeof value === "object" ? Object.values(value).map(readable).join("；") : String(value ?? ""));
  const post = async (url, body) => {
    const response = await fetch(url, {method:"POST", headers:{"Content-Type":"application/json", "X-CSRFToken":csrf(), "Accept":"application/json"}, body:JSON.stringify(body)});
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "请求失败");
    return data;
  };

  const showMessage = (root, message, isError = false) => {
    if (!root) return;
    root.hidden = false;
    root.classList.toggle("alert-error", isError);
    root.classList.toggle("alert-success", !isError);
    root.textContent = message;
  };

  document.querySelectorAll("[data-a3-profile-form]").forEach(form => form.addEventListener("submit", async event => {
    event.preventDefault();
    const button = form.querySelector("button[type=submit]");
    const textarea = form.querySelector("textarea");
    button.disabled = true;
    try { await post(form.action, {content:textarea.value}); location.reload(); }
    catch (error) { alert(error.message); button.disabled = false; }
  }));

  document.querySelectorAll("[data-profile-action]").forEach(button => button.addEventListener("click", async () => {
    const body = {action:button.dataset.profileAction};
    if (body.action === "modify") {
      const value = prompt("请输入修正后的画像内容");
      if (!value) return;
      body.value = value;
    }
    try { await post(button.dataset.url, body); location.reload(); }
    catch (error) { alert(error.message); }
  }));

  const renderCompactJob = (root, job) => {
    const bar = root.querySelector("[data-job-progress]");
    if (bar) bar.style.width = `${job.progress}%`;
    const status = root.querySelector("[data-job-status]");
    if (status) status.textContent = `${job.status} · ${job.progress}% · ${job.current_step}`;
    const list = root.querySelector("[data-job-steps]");
    if (list) list.innerHTML = job.steps.map(step => `<div class="a3-timeline-item ${step.status === "失败" ? "failed" : step.status === "等待中" ? "waiting" : ""}"><h4>${escapeHtml(step.name)} · ${escapeHtml(step.status)}</h4><p>${escapeHtml(step.detail || "等待执行")} · ${escapeHtml(step.duration || "0.0秒")}</p></div>`).join("");
  };

  document.querySelectorAll("[data-job-poll]:not([data-job-page])").forEach(root => {
    const poll = async () => {
      try {
        const response = await fetch(root.dataset.jobPoll, {headers:{"Accept":"application/json"}});
        const data = await response.json();
        if (response.ok) {
          renderCompactJob(root, data.job);
          if (["排队中", "已领取", "执行中"].includes(data.job.status)) setTimeout(poll, 1800);
        }
      } catch (_) { setTimeout(poll, 3500); }
    };
    poll();
  });

  document.querySelectorAll("[data-resource-action]").forEach(button => button.addEventListener("click", async () => {
    try {
      await post(button.dataset.url, {action:button.dataset.resourceAction, useful:button.dataset.useful || null});
      button.textContent = button.dataset.resourceAction === "add_to_path" ? "已加入学习路径" : "已记录";
      button.disabled = true;
    } catch (error) { alert(error.message); }
  }));

  document.querySelectorAll("[data-copy-code]").forEach(button => button.addEventListener("click", async () => {
    const code = button.closest(".a3-code-card")?.querySelector("code")?.textContent || "";
    try { await navigator.clipboard.writeText(code); button.textContent = "已复制"; }
    catch (_) { button.textContent = "请手动选择复制"; }
  }));

  document.querySelectorAll("[data-quiz-form]").forEach(form => form.addEventListener("submit", async event => {
    event.preventDefault();
    const answers = {};
    form.querySelectorAll("[data-question]").forEach(block => {
      const chosen = [...block.querySelectorAll("input:checked")].map(input => input.value);
      const textInput = block.querySelector("textarea,input[type=text]");
      answers[block.dataset.question] = chosen.length ? chosen : (textInput ? textInput.value : []);
    });
    const submit = form.querySelector("button[type=submit]");
    submit.disabled = true;
    try {
      const data = await post(form.action, {answers, duration_seconds:120});
      showMessage(form.querySelector("[data-quiz-result]"), `本次得分 ${data.score} 分，答对 ${data.correct}/${data.total} 题。${data.adjustments.length ? "系统已生成补强路径建议。" : ""}`);
      data.details.forEach(item => {
        const block = form.querySelector(`[data-question="${item.question_id}"]`);
        const feedback = block?.querySelector("[data-answer-feedback]");
        if (!feedback) return;
        feedback.hidden = false;
        feedback.classList.toggle("correct", item.correct);
        feedback.innerHTML = `<strong>${item.correct ? "回答正确" : "回答有误"}</strong><p><b>正确答案：</b>${escapeHtml(readable(item.correct_answer))}</p><p><b>解析：</b>${escapeHtml(item.explanation)}</p>${item.added_to_wrong_book ? "<p>这道题已加入错题本，连续答错时系统会推荐补强资源。</p>" : ""}`;
      });
      submit.textContent = "已提交";
    } catch (error) { showMessage(form.querySelector("[data-quiz-result]"), error.message, true); submit.disabled = false; }
  }));

  document.querySelectorAll("[data-ppt-viewer]").forEach(viewer => {
    const pages = [...viewer.querySelectorAll("[data-slide-index]")];
    const thumbs = [...viewer.querySelectorAll("[data-slide-thumb]")];
    let current = 0;
    const show = index => {
      if (!pages.length) return;
      current = (index + pages.length) % pages.length;
      pages.forEach((page, pageIndex) => { page.hidden = pageIndex !== current; });
      thumbs.forEach((thumb, thumbIndex) => thumb.classList.toggle("active", thumbIndex === current));
      const label = viewer.querySelector("[data-slide-current]");
      if (label) label.textContent = `${current + 1} / ${pages.length}`;
    };
    viewer.querySelector("[data-slide-prev]")?.addEventListener("click", () => show(current - 1));
    viewer.querySelector("[data-slide-next]")?.addEventListener("click", () => show(current + 1));
    thumbs.forEach(thumb => thumb.addEventListener("click", () => show(Number(thumb.dataset.slideThumb))));
  });

  document.querySelectorAll("[data-mindmap-fullscreen]").forEach(button => button.addEventListener("click", async () => {
    const panel = button.closest("[data-mindmap-panel]")?.querySelector(".a3-mindmap-readable");
    if (!panel) return;
    try { if (!document.fullscreenElement) await panel.requestFullscreen(); else await document.exitFullscreen(); }
    catch (_) { panel.classList.toggle("a3-pseudo-fullscreen"); }
  }));

  document.querySelectorAll("[data-generation-form]").forEach(form => {
    const course = form.querySelector("[data-course-select]");
    const chapter = form.querySelector("[data-chapter-select]");
    const point = form.querySelector("[data-point-select]");
    const goal = form.querySelector("[data-goal-select]");
    const update = () => {
      [...chapter.options].forEach(option => { option.hidden = option.dataset.course !== course.value; });
      if (chapter.selectedOptions[0]?.hidden) chapter.value = [...chapter.options].find(option => !option.hidden)?.value || "";
      [...point.options].forEach(option => { option.hidden = option.dataset.course !== course.value || option.dataset.chapter !== chapter.value; });
      if (point.selectedOptions[0]?.hidden) point.value = [...point.options].find(option => !option.hidden)?.value || "";
      [...goal.options].forEach(option => { option.hidden = option.dataset.course !== course.value; });
      if (goal.selectedOptions[0]?.hidden) goal.value = [...goal.options].find(option => !option.hidden)?.value || "";
    };
    course?.addEventListener("change", update);
    chapter?.addEventListener("change", update);
    update();
    form.addEventListener("submit", event => {
      if (form.querySelectorAll('input[name="resource_types"]:checked').length < 5) {
        event.preventDefault();
        alert("请至少保留5类资源，以形成完整学习组合。");
      }
    });
  });

  const resourceLabels = {document:"个性化讲义", ppt:"PPT课件", mindmap:"思维导图", quiz:"多类型题库", reading:"拓展阅读", practice:"代码实操", microcourse:"多模态微课"};
  const renderDrawer = (root, node) => {
    const drawer = root.querySelector("[data-agent-drawer]");
    const content = root.querySelector("[data-drawer-content]");
    if (!drawer || !content) return;
    const calls = (node.model_calls || []).map(call => `<li>${escapeHtml(call.provider)} ${escapeHtml(call.model)} · ${escapeHtml(call.status)} · ${escapeHtml(call.duration)}${call.error_code ? ` · ${escapeHtml(call.error_code)}` : ""}</li>`).join("") || "<li>本步骤未调用生成模型</li>";
    const handoffs = (node.handoffs || []).map(item => `<li>${escapeHtml(typeof item === "string" ? item : `${item.sender} → ${item.receiver}：${item.content}`)}</li>`).join("") || "<li>无额外交接摘要</li>";
    const developer = node.developer || (node.input_schema ? {input_schema:node.input_schema, output_schema:node.output_schema} : null);
    content.innerHTML = `<span class="a3-chip ${node.degraded ? "warn" : "ok"}">${node.degraded ? "含降级" : "正常"}</span><h2>${escapeHtml(node.agent)} · ${escapeHtml(node.name)}</h2><dl class="a3-business-dl"><dt>上游智能体</dt><dd>${escapeHtml(node.upstream || "按流程记录")}</dd><dt>下游智能体</dt><dd>${escapeHtml(node.downstream || "按流程记录")}</dd><dt>输入摘要</dt><dd>${escapeHtml(node.input_summary)}</dd><dt>输出摘要</dt><dd>${escapeHtml(node.output_summary)}</dd><dt>实际模型</dt><dd>${escapeHtml(node.provider)} ${escapeHtml(node.model)}</dd><dt>提示词版本</dt><dd>${escapeHtml(node.prompt_version)}</dd><dt>执行耗时</dt><dd>${escapeHtml(node.duration)}</dd><dt>使用工具</dt><dd>${escapeHtml((node.tools || []).join("、") || "无")}</dd><dt>引用数量</dt><dd>${escapeHtml(node.citation_count || 0)}条</dd><dt>重试次数</dt><dd>${escapeHtml(node.retry_count || 0)}次</dd></dl><h3>模型调用记录</h3><ul>${calls}</ul><h3>协作交接</h3><ul>${handoffs}</ul>${node.rework && Object.keys(node.rework).length ? `<h3>返工信息</h3><p>${escapeHtml(readable(node.rework))}</p>` : ""}${developer ? `<details><summary>管理员开发信息</summary><p>这里只展示Schema，不展示完整系统提示词和原始模型响应。</p><pre>${escapeHtml(JSON.stringify(developer, null, 2))}</pre></details>` : ""}`;
    drawer.hidden = false;
  };

  const renderDag = (root, nodes) => {
    const target = root.querySelector("[data-agent-dag]");
    if (!target) return;
    if (!nodes.length) { target.innerHTML = '<div class="a3-empty">协作步骤尚未开始。</div>'; return; }
    target.innerHTML = nodes.map((node, index) => `<button type="button" class="a3-agent-node ${node.status === "失败" ? "failed" : node.degraded ? "degraded" : ""}" data-agent-node="${index}"><span>${escapeHtml(node.agent)}</span><strong>${escapeHtml(node.name)}</strong><small>${escapeHtml(node.status)} · ${escapeHtml(node.duration)}</small><small>${escapeHtml(node.provider || "未调用生成模型")}${node.degraded ? " · 已降级" : ""}${node.rework && Object.keys(node.rework).length ? " · 已返工" : ""}</small></button>`).join('<span class="a3-dag-arrow">↓</span>');
    target.querySelectorAll("[data-agent-node]").forEach(button => button.addEventListener("click", () => renderDrawer(root, nodes[Number(button.dataset.agentNode)])));
  };

  document.querySelectorAll("[data-drawer-close]").forEach(button => button.addEventListener("click", () => { button.closest("[data-agent-drawer]").hidden = true; }));

  document.querySelectorAll("[data-job-page]").forEach(root => {
    const render = job => {
      renderCompactJob(root, job);
      const source = root.querySelector("[data-job-source]"); if (source) source.textContent = job.source_label;
      const worker = root.querySelector("[data-worker-banner]");
      if (worker) { worker.classList.toggle("offline", !job.worker.running); worker.innerHTML = `<strong>${escapeHtml(job.worker.label)}</strong><span>${job.worker.running ? "页面将自动刷新进度。" : "任务保留在队列中，启动服务后会继续处理。"}</span>`; }
      const summary = root.querySelector("[data-job-summary]");
      if (summary) summary.innerHTML = [["课程",job.course],["章节",job.chapter],["知识点",job.knowledge_point],["学习目标",job.learning_goal],["难度",job.difficulty],["每日时间",`${job.available_minutes}分钟`]].map(([label,value]) => `<div><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join("");
      const evidenceLine = root.querySelector("[data-job-evidence]");
      if (evidenceLine) {
        const citedSteps = (job.agent_steps || []).filter(step => Number(step.citation_count) > 0).length;
        const online = (job.artifacts || []).filter(item => ["ONLINE_SPARK", "ONLINE_FALLBACK"].includes(item.source_mode)).length;
        const quiz = (job.artifacts || []).find(item => item.type === "quiz");
        const proof = [
          ["01 学生请求", job.learning_goal || "等待输入"],
          ["02 课程依据", citedSteps ? `${citedSteps}个协作步骤记录了引用` : "尚无引用步骤"],
          ["03 实际生成", job.artifact_count ? `${online}份在线生成 / ${job.artifact_count - online}份其他来源` : "等待资源生成"],
          ["04 练习反馈", quiz ? "题库已生成；作答后查看学习路径" : "等待题库，尚无作答反馈"],
        ];
        evidenceLine.innerHTML = proof.map(([label, value]) => `<div><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join("");
      }
      const strategy = root.querySelector("[data-job-strategy]");
      if (strategy) {
        const reasons = job.strategy?.reasons || {};
        const orderLabel = item => {
          if (typeof item === "string") return resourceLabels[item] || item;
          if (!item || typeof item !== "object") return "";
          const kind = item.resource_type || item.type || item.resource || item.code;
          return resourceLabels[kind] || item.name || item.title || kind || "";
        };
        const learningOrder = (job.strategy.learning_order || []).map(orderLabel).filter(Boolean);
        strategy.innerHTML = Object.keys(reasons).length ? `<div class="a3-strategy-cards">${Object.entries(reasons).map(([kind,reason]) => `<article><strong>${escapeHtml(resourceLabels[kind] || kind)}</strong><p>${escapeHtml(readable(reason))}</p></article>`).join("")}</div><div class="a3-plan-order"><strong>推荐学习顺序</strong><p>${escapeHtml(learningOrder.join(" → ") || "按成果卡片顺序学习")}</p><span>预计总时间 ${escapeHtml(job.strategy.estimated_total_minutes || job.total_estimated_minutes)} 分钟</span></div>` : '<div class="a3-empty">资源策划智能体尚未完成。</div>';
      }
      renderDag(root, job.agent_steps || []);
      const artifacts = root.querySelector("[data-job-artifacts]");
      if (artifacts) artifacts.innerHTML = job.artifacts.length ? job.artifacts.map(item => `<article class="a3-resource-card"><div class="a3-resource-meta"><span class="a3-chip">${escapeHtml(item.type_label)}</span><span class="a3-chip ${item.source_mode === "ONLINE_SPARK" ? "ok" : "warn"}">${escapeHtml(item.source)}</span></div><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.difficulty)} · ${escapeHtml(item.estimated_minutes)}分钟 · 版本${escapeHtml(item.version)} · ${escapeHtml(item.review_status)}</p><div class="a3-inline"><a class="btn btn-primary btn-small" href="${escapeHtml(item.view_url)}">查看学习内容</a><button class="btn btn-secondary btn-small" type="button" data-result-add-path data-resource-url="/api/a3/resources/${escapeHtml(item.resource_id)}/action/">加入路径</button>${item.download_url ? `<a class="btn btn-secondary btn-small" href="${escapeHtml(item.download_url)}">下载文件</a>` : ""}</div></article>`).join("") : '<div class="a3-empty">成果生成中，请稍后查看。</div>';
      root.querySelectorAll("[data-result-add-path]").forEach(button => button.addEventListener("click", async () => { try { await post(button.dataset.resourceUrl, {action:"add_to_path"}); button.textContent="已加入路径"; button.disabled=true; } catch(error) { alert(error.message); } }));
      const count = root.querySelector("[data-artifact-count]"); if (count) count.textContent = `${job.artifact_count}份成果`;
      const resultSummary = root.querySelector("[data-result-summary]"); if (resultSummary) resultSummary.textContent = `已生成${job.artifact_count}份资源，预计总学习时间${job.total_estimated_minutes}分钟，教师审核状态逐资源显示。`;
      const error = root.querySelector("[data-job-error]");
      if (job.status === "失败") showMessage(error, `失败阶段：${job.failure_stage || "生成流程"}。${job.error || "请查看管理员日志。"}`, true); else if (error) error.hidden = true;
      const retry = root.querySelector("[data-job-retry]"); if (retry) retry.hidden = !(job.status === "失败" && job.can_retry);
    };
    const poll = async () => {
      try { const response=await fetch(root.dataset.apiUrl,{headers:{"Accept":"application/json"}}); const data=await response.json(); if(!response.ok)throw new Error(data.error||"加载失败"); render(data.job); if(["排队中","已领取","执行中"].includes(data.job.status))setTimeout(poll,1600); }
      catch(error) { showMessage(root.querySelector("[data-job-error]"), `状态加载失败：${error.message}`, true); setTimeout(poll,4000); }
    };
    root.querySelector("[data-job-retry]")?.addEventListener("click", async buttonEvent => { const button=buttonEvent.currentTarget; button.disabled=true; try{const data=await post(root.dataset.retryUrl,{}); location.href=data.detail_url;}catch(error){showMessage(root.querySelector("[data-job-error]"),error.message,true);button.disabled=false;} });
    poll();
  });

  document.querySelectorAll("[data-agent-run-page]").forEach(root => {
    const load = async () => {
      try {
        const response = await fetch(root.dataset.apiUrl, {headers:{"Accept":"application/json"}});
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "加载失败");
        const run = data.run;
        const summary = root.querySelector("[data-run-summary]");
        if (summary) summary.innerHTML = [["状态",run.status],["学生",run.student],["学习目标",run.learning_goal],["实际模型",`${run.provider} ${run.model}`],["总耗时",run.duration],["降级状态",run.degraded?"含降级步骤":"未降级"]].map(([label,value])=>`<div><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`).join("");
        renderDag(root, run.nodes || []);
        const shared = root.querySelector("[data-shared-context]"); if(shared)shared.innerHTML=`<div class="a3-info-grid"><div><span>课程</span><strong>${escapeHtml(readable(run.shared_context.course))}</strong></div><div><span>章节</span><strong>${escapeHtml(readable(run.shared_context.chapter))}</strong></div><div><span>知识点</span><strong>${escapeHtml(readable(run.shared_context.knowledge_point))}</strong></div><div><span>证据</span><strong>${escapeHtml(run.shared_context.evidence_count)}条</strong></div><div><span>成果</span><strong>${escapeHtml(run.shared_context.artifact_count)}份</strong></div><div><span>审核</span><strong>${escapeHtml(run.shared_context.review_count)}条</strong></div></div>`;
        const reviews=root.querySelector("[data-run-reviews]");if(reviews)reviews.innerHTML=run.reviews.length?run.reviews.map(item=>`<article><strong>第${escapeHtml(item.round)}轮 · ${escapeHtml(item.resource)} · ${escapeHtml(item.score)}分 · ${escapeHtml(item.result)}</strong><p>${escapeHtml(readable(item.issues) || "未发现问题")}</p><p>${escapeHtml(readable(item.suggestions))}</p></article>`).join(""):'<div class="a3-empty">暂无审核记录。</div>';
      } catch(error) { const summary=root.querySelector("[data-run-summary]"); if(summary)summary.innerHTML=`<div class="alert alert-error">${escapeHtml(error.message)}</div>`; }
    };
    load();
  });

  document.querySelectorAll("[data-tutor-form]").forEach(form => form.addEventListener("submit", event => {
    event.preventDefault();
    const output = document.querySelector("[data-tutor-output]");
    output.textContent = "正在检索课程知识库…";
    fetch(form.action, {method:"POST", headers:{"Content-Type":"application/json","X-CSRFToken":csrf()}, body:JSON.stringify({point_id:form.point_id.value,style:form.style.value,question:form.question.value})}).then(async response => {
      if (!response.ok) { const error=await response.json(); throw new Error(error.error||"请求失败"); }
      const reader=response.body.getReader(), decoder=new TextDecoder(); let buffer="", answer="";
      while (true) { const {value,done}=await reader.read(); if(done)break; buffer+=decoder.decode(value,{stream:true}); const events=buffer.split("\n\n"); buffer=events.pop(); for(const raw of events){const type=(raw.match(/event: (.+)/)||[])[1],data=(raw.match(/data: (.+)/)||[])[1];if(type==="delta"&&data){answer+=JSON.parse(data).text;output.textContent=answer;}} }
    }).catch(error => { output.textContent=error.message; });
  }));
})();
