"""Competition acceptance tests for the A3 resource-generation experience.

All provider credentials are disabled here.  Online-provider labels are tested
with explicit ProviderResult fixtures, never with fabricated network success.
"""

from __future__ import annotations

import json
import tempfile
from datetime import timedelta
from io import StringIO
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from django.core.management import call_command
from django.core.management.base import CommandError
from django.template.loader import render_to_string
from django.test import RequestFactory, SimpleTestCase, TestCase, TransactionTestCase, override_settings
from django.utils import timezone

from agent_learning.management.commands.run_agent_worker import claim_job
from agent_learning.models import (
    AgentDefinition,
    AgentMessage,
    AgentReview,
    AgentRun,
    AgentSharedContext,
    AgentStep,
    AgentWorkflow,
    CourseChapter,
    CourseKnowledgeBase,
    GenerationJob,
    KnowledgeChunk,
    KnowledgeDocument,
    KnowledgeMastery,
    KnowledgePoint,
    KnowledgeVersion,
    LearningGoal,
    ModelProviderState,
    PersonalizedResource,
    WorkerHeartbeat,
)
from agent_learning.seed import seed_agents
from agent_learning.services.a3_prompts import RESOURCE_PROMPTS
from agent_learning.services.presenters import ResourcePresenter
from agent_learning.services.providers import ProviderResult
from agent_learning.services.resources import generate_resource
from agent_learning.services.schemas import RESOURCE_SCHEMAS, SchemaValidationError
from agent_learning.views import JsonResponse, admin_agent_run_detail, admin_providers
from app.agents.orchestrator import LearningOrchestrator
from app.agents.resource_planner_agent import ResourcePlannerAgent
from app.agents.reviewer_agent import ReviewerAgent


OFFLINE_SETTINGS = {
    "SPARK_API_PASSWORD": "",
    "AI_API_KEY": "",
    "A3_MODEL_PROVIDER": "spark",
    "SPARK_TTS_APP_ID": "",
    "SPARK_TTS_API_KEY": "",
    "SPARK_TTS_API_SECRET": "",
    "A3_MIN_EVIDENCE_SCORE": 0.01,
}


class StaticCompetitionContractTests(SimpleTestCase):
    root = Path(__file__).resolve().parent

    def test_ordinary_templates_have_no_placeholder_or_direct_api_links(self):
        templates = list((self.root / "templates" / "a3").rglob("*.html"))
        self.assertTrue(templates)
        for path in templates:
            text = path.read_text(encoding="utf-8")
            self.assertNotRegex(text, r'''href\s*=\s*["']#["']''', path.name)
            self.assertNotRegex(text, r'''href\s*=\s*["']javascript:void''', path.name)
            self.assertNotRegex(text, r'''href\s*=\s*["'][^"']*/api/a3/''', path.name)

    def test_no_generic_raw_resource_dictionary_renderer_remains(self):
        text = "\n".join(
            path.read_text(encoding="utf-8")
            for path in (self.root / "templates" / "a3").rglob("*.html")
        )
        self.assertNotIn("for heading, value in resource.content.items", text)
        self.assertNotIn("for heading,value in resource.content.items", text)

    def test_browser_script_contains_no_console_debug_output(self):
        script = (self.root / "static" / "agent_learning" / "js" / "a3-learning.js").read_text(encoding="utf-8")
        self.assertNotIn("console.log", script)
        self.assertNotIn("console.error", script)

    def test_json_response_emits_readable_utf8_chinese(self):
        response = JsonResponse({"message": "函数生成完成"})
        body = response.content.decode("utf-8")
        self.assertIn("函数生成完成", body)
        self.assertNotIn("\\u", body)

    def test_seven_resource_agents_have_unique_prompts_and_schemas(self):
        self.assertEqual(set(RESOURCE_PROMPTS), set(RESOURCE_SCHEMAS))
        self.assertEqual(len({item.system_prompt for item in RESOURCE_PROMPTS.values()}), 7)
        self.assertEqual(len({item.version for item in RESOURCE_PROMPTS.values()}), 7)
        self.assertEqual(
            {item.output_schema["title"] for item in RESOURCE_PROMPTS.values()},
            {schema.name for schema in RESOURCE_SCHEMAS.values()},
        )

    def test_reading_and_microcourse_nested_contracts_are_not_cross_wired(self):
        reading = {
            "readings": [{
                "title": "课程片段", "summary": "摘要", "recommendation_reason": "补强",
                "relation": "当前知识点", "order": 1, "estimated_minutes": 5,
                "source": "课程组讲义", "document_version": 1, "quoted_excerpt": "片段",
            }],
            "personalization_note": "按画像推荐",
        }
        self.assertEqual(RESOURCE_SCHEMAS["reading"].validate(reading), reading)
        invalid_microcourse = {
            "title": "微课", "duration_minutes": 6, "frames": [], "script": "讲稿",
            "personalization_note": "按画像推荐",
        }
        with self.assertRaises(SchemaValidationError):
            RESOURCE_SCHEMAS["microcourse"].validate(invalid_microcourse)

    def test_student_cannot_open_admin_agent_run_detail(self):
        request = RequestFactory().get("/admin/agent-runs/1/")
        response = admin_agent_run_detail.__wrapped__(
            request, SimpleNamespace(), SimpleNamespace(role_name="学生"), 1
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, "/student/dashboard/")


@override_settings(**OFFLINE_SETTINGS)
class ResourcePresentationContractTests(TestCase):
    student_id = 910001

    @classmethod
    def setUpClass(cls):
        cls._temp_media = tempfile.TemporaryDirectory()
        cls._media_override = override_settings(MEDIA_ROOT=Path(cls._temp_media.name))
        cls._media_override.enable()
        super().setUpClass()

    @classmethod
    def tearDownClass(cls):
        super().tearDownClass()
        cls._media_override.disable()
        cls._temp_media.cleanup()

    @classmethod
    def setUpTestData(cls):
        cls.kb = CourseKnowledgeBase.objects.create(
            course_code="ACCEPT-PY", name="录屏验收课程", description="测试", status="已启用"
        )
        cls.version = KnowledgeVersion.objects.create(
            knowledge_base=cls.kb, version_no=1, version_label="v1", is_active=True
        )
        cls.chapter = CourseChapter.objects.create(
            knowledge_base=cls.kb, chapter_no=1, title="循环结构",
            objectives=["掌握循环控制"], lecture="循环可以重复处理序列中的元素。",
            example_code="for item in items:\n    print(item)",
            common_mistakes=["边界条件错误"], exercises=["遍历一个列表"],
            reference_answers=["使用for循环"],
        )
        cls.point = KnowledgePoint.objects.create(
            chapter=cls.chapter, point_code="ACCEPT-LOOP", point_no=1,
            title="循环控制", summary="理解for与while循环、终止条件和遍历过程。",
            tags=["for", "while", "遍历"], estimated_minutes=22,
        )
        cls.document = KnowledgeDocument.objects.create(
            knowledge_base=cls.kb, version=cls.version, chapter=cls.chapter,
            knowledge_point=cls.point, title="循环控制课程讲义", extension="md",
            sha256="9" * 64, source_reference="课程组自建循环讲义v1",
            status="已解析", is_active=True,
        )
        cls.chunk = KnowledgeChunk.objects.create(
            document=cls.document, chapter=cls.chapter, knowledge_point=cls.point,
            chunk_no=1, content="for循环逐项遍历可迭代对象，while循环依据条件重复执行。",
            token_count=20, keywords=["循环", "遍历"],
        )
        cls.goal = LearningGoal.objects.create(
            student_id=cls.student_id, knowledge_base=cls.kb,
            title="掌握循环控制", description="独立完成列表遍历", weekly_minutes=150,
        )
        cls.workflow = AgentWorkflow.objects.create(
            code="personalized_resource_generation", version="1.0", name="验收工作流",
            description="验收", step_blueprint=[], enabled=True,
        )

    def test_generation_job_persists_real_scope_and_worker_claim_preserves_it(self):
        job = GenerationJob.objects.create(
            student_id=self.student_id, goal=self.goal, workflow=self.workflow,
            course=self.kb, chapter=self.chapter, knowledge_point=self.point,
            learning_goal="掌握循环边界", selected_resource_types=["document", "ppt", "mindmap", "quiz", "practice"],
            requested_types=["document", "ppt", "mindmap", "quiz", "practice"],
            idempotency_key="accept-job-scope",
        )
        claimed = claim_job()
        self.assertEqual(claimed.pk, job.pk)
        self.assertEqual(claimed.knowledge_point_id, self.point.pk)
        self.assertEqual(claimed.chapter_id, self.chapter.pk)
        self.assertEqual(claimed.course_id, self.kb.pk)
        self.assertEqual(claimed.status, "已领取")

    def test_loop_resource_contains_no_fixed_exception_example(self):
        resource = generate_resource(
            self.student_id, self.goal, self.point, "document", generation_key="accept-loop-document"
        )
        serialized = json.dumps(resource.content, ensure_ascii=False)
        self.assertIn("循环控制", serialized)
        self.assertNotIn("ZeroDivisionError", serialized)
        self.assertNotIn("safe_divide", serialized)
        self.assertNotIn("异常捕获顺序", serialized)

    def test_resource_uses_task_learning_goal_and_practice_hides_dict_repr(self):
        task_goal = "理解循环条件并独立完成列表遍历"
        resource = generate_resource(
            self.student_id,
            self.goal,
            self.point,
            "practice",
            generation_key="accept-task-learning-goal",
            learning_goal=task_goal,
        )
        self.assertEqual(resource.learning_objective, task_goal)
        self.assertIn(task_goal, resource.summary)
        self.assertNotIn("异常", resource.summary)
        html = render_to_string(
            "a3/resources/practice.html",
            {"presentation": ResourcePresenter(resource).present()},
        )
        self.assertIn("预期结果", html)
        self.assertNotIn("{'input'", html)

    def test_source_modes_are_exact_and_never_mix_rule_with_model(self):
        rule = generate_resource(
            self.student_id, self.goal, self.point, "document", generation_key="accept-rule"
        )
        self.assertEqual(rule.generation_mode, "RULE_FALLBACK")
        self.assertEqual(rule.provider, "")
        self.assertEqual(rule.model, "")
        with patch("agent_learning.services.resources._model_content", return_value=(
            rule.content,
            ProviderResult("{}", "spark", "spark-test", True, latency_ms=18),
        )):
            spark = generate_resource(
                self.student_id, self.goal, self.point, "document", generation_key="accept-spark"
            )
        self.assertEqual(spark.generation_mode, "ONLINE_SPARK")
        self.assertEqual(spark.source_type, "讯飞星火在线生成")
        with patch("agent_learning.services.resources._model_content", return_value=(
            rule.content,
            ProviderResult("{}", "deepseek", "deepseek-test", True, latency_ms=21),
        )):
            fallback = generate_resource(
                self.student_id, self.goal, self.point, "document", generation_key="accept-fallback"
            )
        self.assertEqual(fallback.generation_mode, "ONLINE_FALLBACK")
        self.assertEqual(fallback.source_type, "DeepSeek备用生成")

    def test_demo_preset_is_explicitly_not_online(self):
        resource = generate_resource(
            self.student_id, self.goal, self.point, "document",
            generation_key="accept-demo", demo_preset=True,
        )
        presented = ResourcePresenter(resource).present()
        self.assertEqual(resource.generation_mode, "DEMO_PRESET")
        self.assertIn("非本次在线AI生成", presented["source"]["label"])
        self.assertEqual(presented["source"]["model"], "")

    def test_student_document_template_is_readable_not_python_repr(self):
        resource = generate_resource(
            self.student_id, self.goal, self.point, "document", generation_key="accept-presenter-doc"
        )
        presentation = ResourcePresenter(resource).present()
        html = render_to_string(
            "a3/resource_detail.html",
            {"presentation": presentation, "resource": resource, "quality_reviews": [],
             "role": SimpleNamespace(role_name="学生"),
             "user": SimpleNamespace(real_name="测试学生", display_name="测试学生")},
        )
        for label in ("所属课程", "所属章节", "当前知识点", "学习目标", "适合学生", "个性化适配原因", "内容依据"):
            self.assertIn(label, html)
        self.assertNotIn("{'", html)
        self.assertNotIn("[{", html)
        for internal in (">metadata<", ">questions<", ">slides<", ">frames<", ">audio_status<", ">video_status<"):
            self.assertNotIn(internal, html.lower())
        self.assertNotIn('href="/api/a3/', html)
        self.assertNotIn('href="#"', html)

    def test_historical_profile_note_is_not_exposed_as_current_adaptation(self):
        resource = generate_resource(
            self.student_id, self.goal, self.point, "document", generation_key="accept-safe-adaptation"
        )
        resource.adaptation_reason = "针对异常捕获顺序组织"
        resource.content["personalization_note"] = "针对异常捕获顺序组织"
        resource.save(update_fields=["adaptation_reason", "content"])
        presentation = ResourcePresenter(resource).present()
        self.assertIn("循环控制", presentation["adaptation_reason"])
        self.assertNotIn("异常捕获顺序", presentation["adaptation_reason"])
        self.assertNotIn("异常捕获顺序", presentation["body"]["personalization_note"])

    def test_admin_provider_check_persists_safe_success_state(self):
        request = RequestFactory().post("/admin/providers/", {"provider": "spark"})
        request.session = {}
        result = ProviderResult("连接正常", "spark", "spark-test", True, latency_ms=321)
        with (
            patch("agent_learning.views.SparkProvider.generate", return_value=result),
            patch("agent_learning.views.render", return_value=SimpleNamespace(status_code=200)),
        ):
            response = admin_providers.__wrapped__(
                request,
                SimpleNamespace(real_name="管理员", display_name="管理员"),
                SimpleNamespace(role_name="管理员"),
            )
        self.assertEqual(response.status_code, 200)
        state = ModelProviderState.objects.get(provider="spark")
        self.assertEqual(state.status, "连接成功")
        self.assertEqual(state.last_latency_ms, 321)
        self.assertEqual(state.last_test_result, "连接成功")
        self.assertIsNotNone(state.last_success_at)

    def test_pptx_is_real_wide_and_preview_hides_raw_slides(self):
        from pptx import Presentation

        resource = generate_resource(
            self.student_id, self.goal, self.point, "ppt", generation_key="accept-ppt"
        )
        target = Path(self._temp_media.name) / resource.file_path
        deck = Presentation(target)
        self.assertTrue(target.is_file())
        self.assertEqual(len(deck.slides), 9)
        self.assertAlmostEqual(deck.slide_width / deck.slide_height, 16 / 9, places=2)
        html = render_to_string("a3/resources/ppt.html", {"presentation": ResourcePresenter(resource).present()})
        self.assertIn("PPTX文件真实存在", html)
        self.assertIn("上一页", html)
        self.assertIn("下一页", html)
        self.assertNotIn("[{", html)
        self.assertNotIn(">slides<", html.lower())

    def test_microcourse_has_six_storyboards_and_truthful_media_status(self):
        resource = generate_resource(
            self.student_id, self.goal, self.point, "microcourse", generation_key="accept-microcourse"
        )
        presentation = ResourcePresenter(resource).present()
        html = render_to_string("a3/resources/microcourse.html", {"presentation": presentation})
        self.assertEqual(len(presentation["body"]["frames"]), 6)
        self.assertEqual(html.count("a3-scene-card"), 6)
        self.assertIn("讯飞语音服务未配置", html)
        self.assertIn("静音分镜MP4已生成", html)
        self.assertIn("下载MP4", html)
        self.assertTrue((Path(self._temp_media.name) / resource.file_path).is_file())
        self.assertFalse(presentation["body"]["audio_exists"])

    def test_quiz_template_hides_answer_until_submit(self):
        resource = generate_resource(
            self.student_id, self.goal, self.point, "quiz", generation_key="accept-quiz-hidden"
        )
        first = resource.question_bank.questions.first()
        first.correct_answer = ["仅提交后可见的验收答案"]
        first.save(update_fields=["correct_answer"])
        html = render_to_string("a3/resources/quiz.html", {"presentation": ResourcePresenter(resource).present()})
        self.assertNotIn("仅提交后可见的验收答案", html)
        self.assertIn("提交答案并查看得分", html)

    def test_worker_missing_page_message_is_explicit(self):
        job = GenerationJob.objects.create(
            student_id=self.student_id, goal=self.goal, workflow=self.workflow,
            course=self.kb, chapter=self.chapter, knowledge_point=self.point,
            learning_goal=self.goal.title, requested_types=["document"], selected_resource_types=["document"],
            idempotency_key="accept-worker-page",
        )
        html = render_to_string(
            "a3/generation_job_detail.html",
            {"job": job, "worker_state": {"running": False}, "api_url": "/program-api/", "retry_url": "",
             "role": SimpleNamespace(role_name="学生"),
             "user": SimpleNamespace(real_name="测试学生", display_name="测试学生")},
        )
        self.assertIn("后台多智能体生成服务未运行，请启动Agent Worker", html)

    def test_worker_status_reports_active_process_and_duplicate_guard(self):
        WorkerHeartbeat.objects.create(
            worker_name="accept-worker", process_id=424242, host_name="test",
            status="运行中", started_at=timezone.now(), last_seen_at=timezone.now(),
        )
        output = StringIO()
        call_command("worker_status", "--pid", stdout=output)
        self.assertEqual(output.getvalue().strip(), "424242")
        with self.assertRaises(CommandError):
            call_command("run_agent_worker", "--once", verbosity=0)


@override_settings(**OFFLINE_SETTINGS)
class OrchestratorReworkContractTests(TransactionTestCase):
    reset_sequences = True
    student_id = 920001

    def setUp(self):
        self._temp_media = tempfile.TemporaryDirectory()
        self._media_override = override_settings(MEDIA_ROOT=Path(self._temp_media.name))
        self._media_override.enable()
        self.kb = CourseKnowledgeBase.objects.create(
            course_code="ORCH-PY", name="编排验收课程", description="测试", status="已启用"
        )
        version = KnowledgeVersion.objects.create(
            knowledge_base=self.kb, version_no=1, version_label="v1", is_active=True
        )
        self.chapter = CourseChapter.objects.create(
            knowledge_base=self.kb, chapter_no=1, title="面向对象基础",
            objectives=["理解类与对象"], lecture="类描述对象共同结构，对象是类的实例。",
            example_code="class Student:\n    pass", common_mistakes=["混淆类和对象"],
            exercises=["定义一个简单类"], reference_answers=["使用class语句"],
        )
        self.point = KnowledgePoint.objects.create(
            chapter=self.chapter, point_code="ORCH-OOP", point_no=1, title="类与对象",
            summary="理解类、对象、属性与方法之间的关系。", tags=["类", "对象"],
        )
        document = KnowledgeDocument.objects.create(
            knowledge_base=self.kb, version=version, chapter=self.chapter,
            knowledge_point=self.point, title="类与对象讲义", extension="md",
            sha256="8" * 64, source_reference="课程组自建面向对象讲义v1",
            status="已解析", is_active=True,
        )
        KnowledgeChunk.objects.create(
            document=document, chapter=self.chapter, knowledge_point=self.point,
            chunk_no=1, content="类定义属性与方法，对象通过实例化获得独立状态。",
            token_count=18, keywords=["类", "对象"],
        )
        self.goal = LearningGoal.objects.create(
            student_id=self.student_id, knowledge_base=self.kb,
            title="掌握类与对象", description="完成最小类设计", weekly_minutes=120,
        )
        _, self.workflow = seed_agents()

    def tearDown(self):
        self._media_override.disable()
        self._temp_media.cleanup()
        super().tearDown()

    def test_agent_run_has_independent_steps_handoffs_and_real_v2_rework(self):
        job = GenerationJob.objects.create(
            student_id=self.student_id, goal=self.goal, workflow=self.workflow,
            course=self.kb, chapter=self.chapter, knowledge_point=self.point,
            learning_goal="掌握类与对象", difficulty="中等", available_minutes=30,
            requested_types=["document", "mindmap"], selected_resource_types=["document", "mindmap"],
            idempotency_key="accept-orchestrator-rework",
        )
        review_round = {"count": 0}

        def controlled_review(agent, resources, point, profile=None, evidence=None):
            review_round["count"] += 1
            results = []
            for index, resource in enumerate(resources):
                should_rework = review_round["count"] == 1 and index == 0
                results.append({
                    "resource_id": resource.pk,
                    "resource_type": resource.resource_type,
                    "score": 68 if should_rework else 92,
                    "passed": not should_rework,
                    "issues": ["需要补充层次说明"] if should_rework else [],
                    "suggestions": ["增加从概念到实例的过渡"] if should_rework else [],
                    "requires_rework": should_rework,
                    "rework_target": resource.resource_type if should_rework else "",
                })
            return results

        def shrinking_plan(agent, requested_types, profile=None, job=None):
            return {
                "selected_types": ["document"],
                "reasons": {"document": "模型只建议讲义"},
                "learning_order": [{"resource_type": "document"}],
                "estimated_total_minutes": 20,
                "parallel_groups": [["document"]],
                "complementarity": "模型原始策划结果",
            }

        with patch.object(ReviewerAgent, "review", new=controlled_review), patch.object(
            ResourcePlannerAgent, "plan", new=shrinking_plan
        ):
            resources = LearningOrchestrator(job).process()

        job.refresh_from_db()
        run = job.run
        self.assertEqual(job.status, "已完成")
        self.assertEqual(job.knowledge_point_id, self.point.pk)
        self.assertEqual(job.selected_resource_types, ["document", "mindmap"])
        self.assertEqual(job.resource_strategy["model_recommended_types"], ["document"])
        self.assertEqual(job.resource_strategy["learning_order"], ["document", "mindmap"])
        self.assertTrue(AgentSharedContext.objects.filter(run=run).exists())
        self.assertTrue(AgentStep.objects.filter(run=run, agent__code="document_agent").exists())
        self.assertTrue(AgentStep.objects.filter(run=run, agent__code="mindmap_agent").exists())
        self.assertTrue(AgentMessage.objects.filter(step__run=run, message_type="handoff").exclude(content="").exists())
        self.assertTrue(AgentReview.objects.filter(run=run, review_round=1, triggered_rework=True).exists())
        self.assertTrue(AgentReview.objects.filter(run=run, review_round=2, triggered_rework=False).exists())
        revised = next(item for item in resources if item.version_no == 2)
        self.assertIsNotNone(revised.parent_id)
        self.assertEqual(revised.version_no, revised.parent.version_no + 1)
        self.assertTrue(revised.revision_reason)
        self.assertTrue(revised.difference_summary)
        rework_step = AgentStep.objects.get(run=run, rework_info__to_resource_id=revised.pk)
        self.assertEqual(rework_step.retry_count, 1)
