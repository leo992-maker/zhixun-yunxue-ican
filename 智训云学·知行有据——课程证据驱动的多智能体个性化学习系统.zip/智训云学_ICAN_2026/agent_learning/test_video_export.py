"""Database-free regression tests for microcourse MP4 and authenticated playback."""

import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from django.template.loader import render_to_string
from django.test import RequestFactory, SimpleTestCase, override_settings

from agent_learning.services.video_export import VideoExportError, export_microcourse_video
from agent_learning.views import resource_video_download


FRAMES = [
    {"title": f"第{i}幕", "visual": "函数与参数", "narration": "中文讲解函数的用途", "teaching_purpose": "理解当前知识点"}
    for i in range(1, 3)
]
CONTENT = {"title": "函数学习微课", "frames": FRAMES}


class VideoExportTests(SimpleTestCase):
    def test_invalid_frames_and_missing_encoder_leave_no_partial_video(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "lesson.mp4"
            with self.assertRaises(VideoExportError):
                export_microcourse_video({"frames": []}, target)
            with self.assertRaises(VideoExportError):
                export_microcourse_video(CONTENT, target, ffmpeg="does-not-exist-ffmpeg")
            self.assertFalse(target.exists())
            self.assertFalse((Path(directory) / "lesson.part.mp4").exists())

    def test_silent_and_narrated_mp4_have_truthful_tracks(self):
        if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
            self.skipTest("FFmpeg is installed by Docker; not available in this test environment")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            audio = root / "narration.mp3"
            subprocess.run([
                "ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "lavfi",
                "-i", "sine=frequency=440:duration=2", "-y", str(audio),
            ], check=True, capture_output=True, timeout=15)
            for voice in (False, True):
                target = root / ("voice.mp4" if voice else "silent.mp4")
                self.assertEqual(export_microcourse_video(
                    CONTENT, target, audio_path=audio if voice else None,
                ), voice)
                result = subprocess.run([
                    "ffprobe", "-v", "error", "-show_entries", "stream=codec_name",
                    "-of", "json", str(target),
                ], check=True, capture_output=True, text=True, timeout=15)
                codecs = [stream["codec_name"] for stream in json.loads(result.stdout)["streams"]]
                self.assertIn("h264", codecs)
                self.assertEqual("aac" in codecs, voice)

    def test_template_exposes_player_and_download_only_when_file_exists(self):
        payload = {"presentation": {"id": 7, "body": {
            "title": "函数学习微课", "duration_minutes": 6, "frames": FRAMES,
            "audio_exists": False, "audio_status": "讯飞语音服务未配置",
            "video_exists": True, "video_status": "静音分镜MP4已生成（语音未配置）",
        }}}
        markup = render_to_string("a3/resources/microcourse.html", payload)
        self.assertIn("<video", markup)
        self.assertIn("/video/?download=1", markup)
        self.assertIn("视频为静音版", markup)
        self.assertIn("生成时语音：讯飞语音服务未配置", markup)
        self.assertIn("更新语音配置不会自动改写已有MP4", markup)
        payload["presentation"]["body"]["video_exists"] = False
        markup = render_to_string("a3/resources/microcourse.html", payload)
        self.assertNotIn("<video", markup)


class VideoPlaybackTests(SimpleTestCase):
    def test_owner_can_stream_partial_content_but_other_student_cannot(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            video = root / "lesson.mp4"
            video.write_bytes(b"0123456789")
            resource = SimpleNamespace(file_path="lesson.mp4", student_id=42)
            role = SimpleNamespace(role_name="学生")
            factory = RequestFactory()
            with override_settings(MEDIA_ROOT=root), patch(
                "agent_learning.views.get_object_or_404", return_value=resource
            ), patch("agent_learning.views._student", return_value=SimpleNamespace(pk=42)):
                request = factory.get("/lesson/video/", HTTP_RANGE="bytes=2-5")
                response = resource_video_download.__wrapped__(request, None, role, 7)
                self.assertEqual(response.status_code, 206)
                self.assertEqual(response["Content-Range"], "bytes 2-5/10")
                self.assertEqual(b"".join(response.streaming_content), b"2345")
                invalid = resource_video_download.__wrapped__(
                    factory.get("/lesson/video/", HTTP_RANGE="bytes=99-"), None, role, 7
                )
                self.assertEqual(invalid.status_code, 416)
            with override_settings(MEDIA_ROOT=root), patch(
                "agent_learning.views.get_object_or_404", return_value=resource
            ), patch("agent_learning.views._student", return_value=SimpleNamespace(pk=43)):
                denied = resource_video_download.__wrapped__(factory.get("/lesson/video/"), None, role, 7)
                self.assertEqual(denied.status_code, 403)

    def test_path_escape_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            resource = SimpleNamespace(file_path="../outside.mp4", student_id=42)
            with override_settings(MEDIA_ROOT=Path(directory)), patch(
                "agent_learning.views.get_object_or_404", return_value=resource
            ), patch("agent_learning.views._student", return_value=SimpleNamespace(pk=42)):
                response = resource_video_download.__wrapped__(
                    RequestFactory().get("/lesson/video/"), None, SimpleNamespace(role_name="学生"), 7
                )
                self.assertEqual(response.status_code, 404)
