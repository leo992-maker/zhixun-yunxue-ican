from django.urls import path

from . import views


urlpatterns = [
    # Student A3 mainline. Existing B1 pages remain available as extensions.
    path("student/dashboard/", views.student_home, name="a3_student_home"),
    path("student/profile-interview/", views.profile_interview, name="a3_profile_interview"),
    path("student/learning-path/", views.learning_path, name="a3_learning_path"),
    path("student/resource-center/", views.resource_center, name="a3_resource_center"),
    path("student/generation-jobs/<int:job_id>/", views.student_generation_job_detail, name="a3_student_generation_job_detail"),
    path("student/resources/", views.my_resources, name="a3_my_resources"),
    path("student/resources/<int:resource_id>/", views.resource_detail, name="a3_resource_detail"),
    path("student/resources/<int:resource_id>/download/", views.resource_download, name="a3_resource_download"),
    path("student/resources/<int:resource_id>/audio/", views.resource_audio_download, name="a3_resource_audio_download"),
    path("student/resources/<int:resource_id>/video/", views.resource_video_download, name="a3_resource_video_download"),
    path("student/question-bank/", views.question_bank, name="a3_question_bank"),
    path("student/code-practice/", views.code_practice, name="a3_code_practice"),
    path("student/tutor/", views.tutor_page, name="a3_tutor"),
    path("student/effect-report/", views.effect_report, name="a3_effect_report"),
    path("student/extensions/", views.extension_hub, name="a3_extensions"),

    path("api/a3/profile/message/", views.profile_message_api, name="a3_profile_message_api"),
    path("api/a3/profile/dimensions/<int:dimension_id>/", views.profile_dimension_api, name="a3_profile_dimension_api"),
    path("api/a3/jobs/", views.generation_job_api, name="a3_generation_job_api"),
    path("api/a3/jobs/<int:job_id>/", views.generation_job_status_api, name="a3_generation_job_status_api"),
    path("api/a3/jobs/<int:job_id>/retry/", views.generation_job_retry_api, name="a3_generation_job_retry_api"),
    path("api/a3/agent-runs/<int:run_id>/", views.agent_run_status_api, name="a3_agent_run_status_api"),
    path("api/a3/resources/<int:resource_id>/action/", views.resource_action_api, name="a3_resource_action_api"),
    path("api/a3/quizzes/<int:bank_id>/submit/", views.quiz_submit_api, name="a3_quiz_submit_api"),
    path("api/a3/path/adjustments/<int:adjustment_id>/", views.path_adjustment_api, name="a3_path_adjustment_api"),
    path("api/a3/tutor/ask/", views.tutor_ask_api, name="a3_tutor_ask_api"),
    path("api/a3/tutor/ask/stream/", views.tutor_ask_stream_api, name="a3_tutor_ask_stream_api"),

    # Teacher A3 operations.
    path("teacher/dashboard/", views.teacher_home, name="a3_teacher_home"),
    path("teacher/knowledge-base/", views.teacher_knowledge_base, name="a3_teacher_knowledge_base"),
    path("teacher/knowledge-base/upload/", views.teacher_document_upload, name="a3_teacher_document_upload"),
    path("teacher/knowledge-base/documents/<int:document_id>/action/", views.teacher_document_action, name="a3_teacher_document_action"),
    path("teacher/chapters/", views.teacher_chapters, name="a3_teacher_chapters"),
    path("teacher/generation-jobs/", views.teacher_generation_jobs, name="a3_teacher_generation_jobs"),
    path("teacher/generation-jobs/<int:job_id>/", views.teacher_generation_job_detail, name="a3_teacher_generation_job_detail"),
    path("teacher/resource-reviews/", views.teacher_resource_reviews, name="a3_teacher_resource_reviews"),
    path("teacher/resource-reviews/<int:resource_id>/", views.teacher_resource_review_detail, name="a3_teacher_resource_review_detail"),
    path("teacher/student-profiles/", views.teacher_student_profiles, name="a3_teacher_student_profiles"),
    path("teacher/learning-paths/", views.teacher_learning_paths, name="a3_teacher_learning_paths"),
    path("teacher/learning-analytics/", views.teacher_learning_analytics, name="a3_teacher_learning_analytics"),
    path("teacher/content-safety/", views.teacher_content_safety, name="a3_teacher_content_safety"),

    # Administrator monitoring.
    path("admin/dashboard/", views.admin_monitor, name="a3_admin_home"),
    path("admin/agent-monitor/", views.admin_monitor, name="a3_admin_agent_monitor"),
    path("admin/providers/", views.admin_providers, name="a3_admin_providers"),
    path("admin/generation-jobs/", views.admin_generation_jobs, name="a3_admin_generation_jobs"),
    path("admin/generation-jobs/<int:job_id>/", views.admin_generation_job_detail, name="a3_admin_generation_job_detail"),
    path("admin/agent-runs/<int:run_id>/", views.admin_agent_run_detail, name="a3_admin_agent_run_detail"),
    path("admin/ai-statistics/", views.admin_ai_statistics, name="a3_admin_ai_statistics"),
    path("admin/safety-statistics/", views.admin_safety_statistics, name="a3_admin_safety_statistics"),
    path("admin/knowledge-statistics/", views.admin_knowledge_statistics, name="a3_admin_knowledge_statistics"),
    path("admin/system-health/", views.admin_system_health, name="a3_admin_system_health"),
    path("admin/open-source/", views.admin_open_source, name="a3_admin_open_source"),
]
