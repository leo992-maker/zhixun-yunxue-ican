"""A3 role pages and JSON endpoints."""

from __future__ import annotations

import json
import mimetypes
import re
import uuid
from datetime import timedelta
from pathlib import Path

from django.conf import settings
from django.db import connection, transaction
from django.db.models import Avg, Count, Q
from django.http import FileResponse, HttpResponse, JsonResponse as DjangoJsonResponse, StreamingHttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_GET, require_POST

from app.models import AIInvocationLog, Student, Teacher
from app.views import (
    ROLE_ADMIN, ROLE_STUDENT, ROLE_TEACHER, api_login_required, enforce_role,
    login_required, pop_flash, set_flash,
)
from agent_learning.models import (
    AgentDefinition, AgentMessage, AgentReview, AgentRun, AgentStep,
    ContentSafetyRecord, CourseChapter, CourseKnowledgeBase,
    GenerationJob, KnowledgeDocument, KnowledgePoint, KnowledgeVersion,
    LearningBehaviorEvent, LearningEffectReport, LearningGoal, PathAdjustment,
    LearningPlanNode, ModelProviderState, PersonalizedLearningPlan, PersonalizedResource, ProfileConversation,
    ProfileDimension, ProfileMessage, ProfileSnapshot, ProfileUpdateEvent,
    QuestionBank, ResourceFeedback, WorkerHeartbeat,
)
from agent_learning.services.assessment import create_effect_report, submit_quiz
from agent_learning.services.knowledge import ingest_uploaded_document
from agent_learning.services.paths import accept_path_adjustment
from agent_learning.services.profile import (
    apply_profile_message, next_profile_question, serialize_current_profile,
)
from agent_learning.services.presenters import ResourcePresenter
from agent_learning.services.providers import DeepSeekProvider, GLMProvider, SparkProvider, SparkTTSProvider
from agent_learning.services.redaction import sanitize_error
from agent_learning.services.resources import profile_summary
from agent_learning.services.tutor import answer_tutor


class JsonResponse(DjangoJsonResponse):
    """Readable UTF-8 API responses without changing the API/HTML boundary."""

    def __init__(self, data, *args, **kwargs):
        params = kwargs.pop("json_dumps_params", {})
        params.setdefault("ensure_ascii", False)
        super().__init__(data, *args, json_dumps_params=params, **kwargs)


def _worker_state():
    cutoff = timezone.now() - timedelta(seconds=15)
    worker = WorkerHeartbeat.objects.filter(status="运行中", last_seen_at__gte=cutoff).order_by("-last_seen_at").first()
    return {
        "running": bool(worker),
        "label": "后台多智能体生成服务运行正常" if worker else "后台多智能体生成服务未运行，请启动Agent Worker。",
        "last_seen_at": worker.last_seen_at if worker else None,
        "current_job_id": worker.current_job_id if worker else None,
    }


def _duration_text(milliseconds):
    seconds = max(0, int(milliseconds or 0)) / 1000
    return f"{seconds:.1f}秒"


def _student(user):
    return get_object_or_404(Student.objects.select_related("major", "class_field"), user=user)


def _teacher(user):
    return get_object_or_404(Teacher, user=user)


def _flash(request):
    message, level = pop_flash(request)
    return {"flash_message": message, "flash_level": level}


def _a3_context(request, user, role, **extra):
    context = {"user": user, "role": role, **_flash(request)}
    context.update(extra)
    return context


def _json_payload(request):
    if request.content_type and "application/json" in request.content_type:
        try:
            return json.loads(request.body or b"{}")
        except json.JSONDecodeError:
            return {}
    return request.POST.dict()


@login_required
def student_home(request, user, role):
    blocked = enforce_role(role, ROLE_STUDENT)
    if blocked:
        return blocked
    student = _student(user)
    dimensions = list(ProfileDimension.objects.filter(student=student).order_by("dimension_code"))
    goal = LearningGoal.objects.filter(student=student, status="进行中").order_by("-updated_at").first()
    plan = goal.plans.filter(status="执行中").order_by("-version_no").first() if goal else None
    recommendations = list(goal.recommendations.select_related("resource", "knowledge_point").order_by("rank")[:5]) if goal else []
    resources = PersonalizedResource.objects.filter(student=student).select_related("knowledge_point").order_by("-created_at")[:6]
    changes = ProfileUpdateEvent.objects.filter(student=student).order_by("-created_at")[:5]
    latest_job = GenerationJob.objects.filter(student=student).order_by("-created_at").first()
    confirmed = sum(1 for item in dimensions if item.is_confirmed)
    return render(request, "a3/student_home.html", _a3_context(
        request, user, role, student=student, dimensions=dimensions,
        profile_completeness=min(100, len(dimensions) * 10), confirmed_dimensions=confirmed,
        goal=goal, plan=plan, recommendations=recommendations, resources=resources,
        changes=changes, latest_job=latest_job, worker_state=_worker_state(),
    ))


@login_required
def profile_interview(request, user, role):
    blocked = enforce_role(role, ROLE_STUDENT)
    if blocked:
        return blocked
    student = _student(user)
    conversation = ProfileConversation.objects.filter(student=student).order_by("-started_at").first()
    if not conversation:
        conversation = ProfileConversation.objects.create(
            student=student,
            extraction_mode="规则抽取",
        )
    messages = conversation.messages.order_by("sequence")
    dimensions = ProfileDimension.objects.filter(student=student).order_by("dimension_code")
    snapshots = ProfileSnapshot.objects.filter(student=student).order_by("-created_at")[:6]
    return render(request, "a3/profile_interview.html", _a3_context(
        request, user, role, student=student, conversation=conversation,
        messages=messages, dimensions=dimensions, snapshots=snapshots,
        next_question=next_profile_question(set(dimensions.values_list("dimension_code", flat=True))),
    ))


@require_POST
@api_login_required
def profile_message_api(request, user, role):
    if role.role_name != ROLE_STUDENT:
        return JsonResponse({"success": False, "error": "仅学生可进行画像访谈"}, status=403)
    student = _student(user)
    payload = _json_payload(request)
    content = (payload.get("content") or "").strip()
    if not content or len(content) > 2000:
        return JsonResponse({"success": False, "error": "请输入1至2000字的画像访谈内容"}, status=400)
    conversation = ProfileConversation.objects.filter(student=student, status="进行中").order_by("-started_at").first()
    if not conversation:
        conversation = ProfileConversation.objects.create(
            student=student,
            extraction_mode="规则抽取",
        )
    sequence = (conversation.messages.order_by("-sequence").values_list("sequence", flat=True).first() or 0) + 1
    message = ProfileMessage.objects.create(
        conversation=conversation, role="student", content=content, sequence=sequence,
        is_ai_generated=False,
    )
    extracted, events = apply_profile_message(student.pk, message)
    current_codes = set(ProfileDimension.objects.filter(student=student).values_list("dimension_code", flat=True))
    question = next_profile_question(current_codes)
    reply = ProfileMessage.objects.create(
        conversation=conversation, role="profile_agent", content=question,
        sequence=sequence + 1, is_ai_generated=False,
    )
    return JsonResponse({
        "success": True, "source": "规则抽取访谈（未调用AI）",
        "extracted": extracted, "event_count": len(events),
        "reply": {"content": reply.content, "sequence": reply.sequence},
        "profile": serialize_current_profile(student.pk),
    })


@require_POST
@api_login_required
def profile_dimension_api(request, user, role, dimension_id):
    if role.role_name != ROLE_STUDENT:
        return JsonResponse({"success": False, "error": "仅学生可修改自己的画像"}, status=403)
    student = _student(user)
    dimension = get_object_or_404(ProfileDimension, pk=dimension_id, student=student)
    payload = _json_payload(request)
    action = payload.get("action")
    old = dimension.value
    if action == "confirm":
        dimension.is_confirmed, dimension.is_rejected = True, False
        reason = "学生确认AI或规则推断"
    elif action == "reject":
        dimension.is_confirmed, dimension.is_rejected = False, True
        reason = "学生拒绝推断，保留历史但不用于推荐"
    elif action == "modify":
        value = (payload.get("value") or "").strip()
        if not value:
            return JsonResponse({"success": False, "error": "修改值不能为空"}, status=400)
        dimension.value = {"学生修改": value}
        dimension.source = "学生手动修改"
        dimension.is_confirmed, dimension.is_rejected = True, False
        reason = "学生修改并确认"
    else:
        return JsonResponse({"success": False, "error": "不支持的画像操作"}, status=400)
    dimension.save()
    ProfileUpdateEvent.objects.create(
        student=student, dimension_code=dimension.dimension_code,
        old_value=old, new_value=dimension.value, source="学生操作", reason=reason,
        status="已确认" if dimension.is_confirmed else "已拒绝",
    )
    ProfileSnapshot.objects.create(
        student=student, dimensions=serialize_current_profile(student.pk), trigger=reason,
    )
    return JsonResponse({"success": True, "value": dimension.value, "confirmed": dimension.is_confirmed})


@login_required
def resource_center(request, user, role):
    blocked = enforce_role(role, ROLE_STUDENT)
    if blocked:
        return blocked
    student = _student(user)
    goals = LearningGoal.objects.filter(student=student).select_related("knowledge_base")
    courses = CourseKnowledgeBase.objects.filter(status="已启用").order_by("name")
    chapters = CourseChapter.objects.filter(knowledge_base__in=courses, is_active=True).select_related("knowledge_base").order_by("knowledge_base_id", "chapter_no")
    points = KnowledgePoint.objects.filter(
        chapter__knowledge_base__status="已启用", is_active=True
    ).select_related("chapter", "chapter__knowledge_base").order_by("chapter__knowledge_base_id", "chapter__chapter_no", "point_no")
    jobs = GenerationJob.objects.filter(student=student).prefetch_related("job_steps", "artifacts")[:10]
    profile_data = profile_summary(student.pk)
    profile_cards = []
    for item in profile_data.values():
        parts = []
        for label, value in (item.get("value") or {}).items():
            readable = "、".join(map(str, value)) if isinstance(value, list) else str(value)
            parts.append(f"{label}：{readable}")
        profile_cards.append({"label": item.get("label", "画像维度"), "value": "；".join(parts), "source": item.get("source", "")})
    return render(request, "a3/resource_center.html", _a3_context(
        request, user, role, student=student, goals=goals, courses=courses,
        chapters=chapters, points=points, jobs=jobs,
        profile_cards=profile_cards, worker_state=_worker_state(),
        resource_types=PersonalizedResource.RESOURCE_TYPES,
    ))


@require_POST
@api_login_required
def generation_job_api(request, user, role):
    if role.role_name != ROLE_STUDENT:
        return JsonResponse({"success": False, "error": "仅学生可创建生成任务"}, status=403)
    student = _student(user)
    payload = _json_payload(request)
    goal = get_object_or_404(LearningGoal, pk=payload.get("goal_id"), student=student)
    course = get_object_or_404(CourseKnowledgeBase, pk=payload.get("course_id") or goal.knowledge_base_id, status="已启用")
    if course.pk != goal.knowledge_base_id:
        return JsonResponse({"success": False, "error": "所选课程与学习目标不一致"}, status=400)
    chapter = get_object_or_404(CourseChapter, pk=payload.get("chapter_id"), knowledge_base=course, is_active=True)
    point = get_object_or_404(KnowledgePoint, pk=payload.get("knowledge_point_id"), chapter=chapter, is_active=True)
    requested = request.POST.getlist("resource_types") if request.POST else payload.get("resource_types", [])
    if isinstance(requested, str):
        requested = [item for item in requested.split(",") if item]
    supported = {item[0] for item in PersonalizedResource.RESOURCE_TYPES}
    requested = [item for item in requested if item in supported]
    if len(set(requested)) < 5:
        return JsonResponse({"success": False, "error": "一次任务请至少选择5类资源"}, status=400)
    workflow = get_object_or_404(
        __import__("agent_learning.models", fromlist=["AgentWorkflow"]).AgentWorkflow,
        code="personalized_resource_generation", version="1.0", enabled=True,
    )
    learning_goal = (payload.get("learning_goal") or goal.title).strip()[:500]
    if not learning_goal:
        return JsonResponse({"success": False, "error": "请确认本次学习目标"}, status=400)
    try:
        available_minutes = max(10, min(240, int(payload.get("available_minutes") or 30)))
    except (TypeError, ValueError):
        return JsonResponse({"success": False, "error": "每日可投入时间必须是10至240分钟"}, status=400)
    preferences = request.POST.getlist("resource_preferences") if request.POST else payload.get("resource_preferences", [])
    if isinstance(preferences, str):
        preferences = [item.strip() for item in preferences.split(",") if item.strip()]
    key = uuid.uuid4().hex[:80]
    job, created = GenerationJob.objects.get_or_create(
        idempotency_key=key,
        defaults={
            "student": student,
            "goal": goal,
            "workflow": workflow,
            "course": course,
            "chapter": chapter,
            "knowledge_point": point,
            "learning_goal": learning_goal,
            "current_foundation": (payload.get("current_foundation") or "以当前画像与测验记录为准")[:120],
            "difficulty": (payload.get("difficulty") or point.difficulty)[:20],
            "available_minutes": available_minutes,
            "resource_preferences": preferences[:10],
            "requested_types": list(dict.fromkeys(requested)),
            "selected_resource_types": list(dict.fromkeys(requested)),
        },
    )
    if request.content_type and "application/json" in request.content_type:
        return JsonResponse({
            "success": True,
            "created": created,
            "job_id": job.pk,
            "status": job.status,
            "detail_url": reverse("a3_student_generation_job_detail", args=[job.pk]),
        }, status=201 if created else 200)
    set_flash(request, f"生成任务 #{job.pk} 已进入队列，Agent Worker 将异步处理。")
    return redirect("a3_student_generation_job_detail", job_id=job.pk)


@require_GET
@api_login_required
def generation_job_status_api(request, user, role, job_id):
    query = GenerationJob.objects.select_related(
        "course", "chapter", "knowledge_point", "goal", "student__user", "run",
    ).prefetch_related(
        "job_steps", "run__steps__agent", "run__steps__tool_calls",
        "run__steps__model_calls", "run__steps__messages", "artifacts__resource__knowledge_point__chapter",
    )
    if role.role_name == ROLE_STUDENT:
        query = query.filter(student=_student(user))
    job = get_object_or_404(query, pk=job_id)
    if role.role_name not in {ROLE_STUDENT, ROLE_TEACHER, ROLE_ADMIN}:
        return JsonResponse({"success": False, "error": "无权查看该任务"}, status=403)
    if role.role_name == ROLE_STUDENT:
        detail_url = reverse("a3_student_generation_job_detail", args=[job.pk])
    elif role.role_name == ROLE_TEACHER:
        detail_url = reverse("a3_teacher_generation_job_detail", args=[job.pk])
    else:
        detail_url = reverse("a3_admin_generation_job_detail", args=[job.pk])
    artifacts = []
    for artifact in job.artifacts.select_related("resource", "resource__knowledge_point__chapter").all():
        presented = ResourcePresenter(artifact.resource).common()
        artifacts.append({
            "resource_id": artifact.resource_id,
            "type": artifact.artifact_type,
            "type_label": artifact.resource.get_resource_type_display(),
            "title": artifact.resource.title,
            "difficulty": artifact.resource.difficulty,
            "estimated_minutes": artifact.resource.estimated_minutes,
            "source": presented["source"]["label"],
            "source_mode": presented["source"]["mode"],
            "version": artifact.resource.version_no,
            "review_status": artifact.resource.review_status,
            "view_url": reverse("a3_resource_detail", args=[artifact.resource_id]),
            "download_url": reverse("a3_resource_download", args=[artifact.resource_id]) if presented["file_exists"] else "",
            "file_exists": presented["file_exists"],
        })
    agent_steps = []
    if job.run_id:
        all_messages = list(
            AgentMessage.objects.filter(step__run=job.run, message_type="handoff")
            .values("sender", "receiver")
        )
        name_by_code = {
            code: name
            for code, name in AgentDefinition.objects.filter(
                code__in={
                    value
                    for message in all_messages
                    for value in (message["sender"], message["receiver"])
                }
            ).values_list("code", "name")
        }
        for item in job.run.steps.select_related("agent").prefetch_related("tool_calls", "model_calls", "messages").all():
            model_calls = list(item.model_calls.all())
            upstream = list(dict.fromkeys(
                name_by_code.get(message["sender"], message["sender"])
                for message in all_messages
                if message["receiver"] == item.agent.code
            ))
            downstream = list(dict.fromkeys(
                name_by_code.get(message["receiver"], message["receiver"])
                for message in all_messages
                if message["sender"] == item.agent.code
            ))
            node = {
                "id": item.pk,
                "agent_code": item.agent.code,
                "agent": item.agent.name,
                "name": item.step_name,
                "status": item.status,
                "input_summary": item.input_summary,
                "output_summary": item.output_summary,
                "duration": _duration_text(item.duration_ms),
                "tools": [call.tool_name for call in item.tool_calls.all()] or item.tools,
                "provider": item.provider or "未调用生成模型",
                "model": item.model,
                "prompt_version": item.prompt_version,
                "citation_count": len(item.citations),
                "upstream": "、".join(upstream) or "流程起点",
                "downstream": "、".join(downstream) or "流程终点",
                "degraded": item.is_degraded,
                "retry_count": item.retry_count,
                "rework": item.rework_info,
                "handoffs": [message.content for message in item.messages.all() if message.message_type == "handoff"][-4:],
                "model_calls": [{
                    "provider": call.provider,
                    "model": call.model,
                    "status": call.status,
                    "duration": _duration_text(call.latency_ms),
                    "error_code": call.error_code,
                    "prompt_version": call.prompt_version,
                    "degraded": call.is_degraded,
                } for call in model_calls],
            }
            if role.role_name == ROLE_ADMIN:
                node["developer"] = {"input_schema": item.input_schema, "output_schema": item.output_schema}
            agent_steps.append(node)
    worker = _worker_state()
    return JsonResponse({
        "success": True, "job": {
            "id": job.pk, "status": job.status, "progress": job.progress,
            "current_step": job.current_step, "error": sanitize_error(job.error_message),
            "failure_stage": job.failure_stage, "can_retry": job.can_retry,
            "source_label": job.source_label, "retry_count": job.retry_count,
            "course": job.course.name if job.course_id else job.goal.knowledge_base.name,
            "chapter": job.chapter.title if job.chapter_id else "待补齐",
            "knowledge_point": job.knowledge_point.title if job.knowledge_point_id else "待补齐",
            "learning_goal": job.learning_goal or job.goal.title,
            "difficulty": job.difficulty, "available_minutes": job.available_minutes,
            "student_profile_summary": job.current_foundation,
            "strategy": job.resource_strategy,
            "worker": worker,
            "detail_url": detail_url,
            "steps": [{
                "name": item.step_name, "status": item.status, "progress": item.progress,
                "duration": _duration_text(item.duration_ms), "detail": item.detail,
            } for item in job.job_steps.all()],
            "agent_steps": agent_steps,
            "artifacts": artifacts,
            "artifact_count": len(artifacts),
            "total_estimated_minutes": sum(item["estimated_minutes"] for item in artifacts),
        }
    })


@require_POST
@api_login_required
def generation_job_retry_api(request, user, role, job_id):
    if role.role_name != ROLE_STUDENT:
        return JsonResponse({"success": False, "error": "仅任务所有者可重试"}, status=403)
    student = _student(user)
    job = get_object_or_404(GenerationJob, pk=job_id, student=student)
    if job.status not in {"失败", "已完成"}:
        return JsonResponse({"success": False, "error": "任务正在执行或排队中"}, status=409)
    retry_no = job.retry_count + 1
    retry = GenerationJob.objects.create(
        student=student, goal=job.goal, workflow=job.workflow,
        course=job.course, chapter=job.chapter, knowledge_point=job.knowledge_point,
        learning_goal=job.learning_goal, current_foundation=job.current_foundation,
        difficulty=job.difficulty, available_minutes=job.available_minutes,
        resource_preferences=job.resource_preferences,
        requested_types=job.requested_types,
        selected_resource_types=job.requested_types,
        resource_strategy=job.resource_strategy,
        idempotency_key=f"{job.idempotency_key[:60]}-retry-{retry_no}",
        retry_count=retry_no,
    )
    return JsonResponse({
        "success": True,
        "job_id": retry.pk,
        "status": retry.status,
        "detail_url": reverse("a3_student_generation_job_detail", args=[retry.pk]),
    }, status=201)


def _generation_job_page(request, user, role, job_id, required_role):
    blocked = enforce_role(role, required_role)
    if blocked:
        return blocked
    query = GenerationJob.objects.select_related("student__user", "goal", "course", "chapter", "knowledge_point", "run")
    if required_role == ROLE_STUDENT:
        query = query.filter(student=_student(user))
    job = get_object_or_404(query, pk=job_id)
    return render(request, "a3/generation_job_detail.html", _a3_context(
        request, user, role, job=job,
        api_url=reverse("a3_generation_job_status_api", args=[job.pk]),
        retry_url=reverse("a3_generation_job_retry_api", args=[job.pk]) if required_role == ROLE_STUDENT else "",
        worker_state=_worker_state(),
    ))


@login_required
def student_generation_job_detail(request, user, role, job_id):
    return _generation_job_page(request, user, role, job_id, ROLE_STUDENT)


@login_required
def teacher_generation_job_detail(request, user, role, job_id):
    return _generation_job_page(request, user, role, job_id, ROLE_TEACHER)


@login_required
def admin_generation_job_detail(request, user, role, job_id):
    return _generation_job_page(request, user, role, job_id, ROLE_ADMIN)


@login_required
def my_resources(request, user, role):
    blocked = enforce_role(role, ROLE_STUDENT)
    if blocked:
        return blocked
    student = _student(user)
    resources = PersonalizedResource.objects.filter(student=student).select_related("knowledge_point").order_by("-created_at")
    kind = request.GET.get("type")
    if kind:
        resources = resources.filter(resource_type=kind)
    return render(request, "a3/resources.html", _a3_context(
        request, user, role, student=student, resources=resources,
        resource_types=PersonalizedResource.RESOURCE_TYPES,
    ))


@login_required
def resource_detail(request, user, role, resource_id):
    resource = get_object_or_404(
        PersonalizedResource.objects.select_related("knowledge_point", "knowledge_base").prefetch_related("citation_records__document"),
        pk=resource_id,
    )
    if role.role_name == ROLE_STUDENT and resource.student_id != _student(user).pk:
        return redirect("a3_my_resources")
    presentation = ResourcePresenter(resource).present()
    quality_reviews = resource.quality_reviews.select_related("run").order_by("review_round", "created_at")
    return render(request, "a3/resource_detail.html", _a3_context(
        request, user, role, resource=resource, presentation=presentation,
        quality_reviews=quality_reviews,
    ))


@login_required
def resource_download(request, user, role, resource_id):
    resource = get_object_or_404(PersonalizedResource, pk=resource_id)
    if role.role_name == ROLE_STUDENT and resource.student_id != _student(user).pk:
        return JsonResponse({"success": False, "error": "无权下载该资源"}, status=403)
    if not resource.file_path:
        return JsonResponse({"success": False, "error": "该资源没有可下载文件"}, status=404)
    root = Path(settings.MEDIA_ROOT).resolve()
    target = (root / resource.file_path).resolve()
    if root not in target.parents or not target.is_file():
        return JsonResponse({"success": False, "error": "资源文件不存在或路径无效"}, status=404)
    mime = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
    return FileResponse(target.open("rb"), as_attachment=True, filename=target.name, content_type=mime)


@login_required
def resource_audio_download(request, user, role, resource_id):
    resource = get_object_or_404(PersonalizedResource, pk=resource_id)
    if role.role_name == ROLE_STUDENT and resource.student_id != _student(user).pk:
        return JsonResponse({"success": False, "error": "无权下载该资源"}, status=403)
    relative = resource.audio_path or (resource.content.get("audio_path", "") if isinstance(resource.content, dict) else "")
    if not relative:
        return JsonResponse({"success": False, "error": "当前微课没有可下载音频"}, status=404)
    root = Path(settings.MEDIA_ROOT).resolve()
    target = (root / relative).resolve()
    if root not in target.parents or not target.is_file():
        return JsonResponse({"success": False, "error": "音频文件不存在或路径无效"}, status=404)
    return FileResponse(
        target.open("rb"),
        as_attachment=request.GET.get("download") == "1",
        filename=target.name,
        content_type="audio/mpeg",
    )


@login_required
def resource_video_download(request, user, role, resource_id):
    resource = get_object_or_404(PersonalizedResource, pk=resource_id, resource_type="microcourse")
    if role.role_name == ROLE_STUDENT and resource.student_id != _student(user).pk:
        return JsonResponse({"success": False, "error": "无权查看该资源"}, status=403)
    root = Path(settings.MEDIA_ROOT).resolve()
    target = (root / resource.file_path).resolve() if resource.file_path else None
    if not target or root not in target.parents or target.suffix.lower() != ".mp4" or not target.is_file():
        return JsonResponse({"success": False, "error": "微课视频尚未生成"}, status=404)
    size = target.stat().st_size
    requested_range = request.headers.get("Range", "")
    if requested_range:
        match = re.fullmatch(r"bytes=(\d*)-(\d*)", requested_range)
        if not match or (not match.group(1) and not match.group(2)):
            response = HttpResponse(status=416)
            response["Content-Range"] = f"bytes */{size}"
            return response
        first, last = match.groups()
        if first:
            start = int(first)
            end = min(int(last), size - 1) if last else size - 1
        else:
            end = size - 1
            start = max(0, size - int(last))
        if start >= size or end < start:
            response = HttpResponse(status=416)
            response["Content-Range"] = f"bytes */{size}"
            return response

        def chunks():
            remaining = end - start + 1
            with target.open("rb") as handle:
                handle.seek(start)
                while remaining:
                    block = handle.read(min(65536, remaining))
                    if not block:
                        break
                    remaining -= len(block)
                    yield block

        response = StreamingHttpResponse(chunks(), status=206, content_type="video/mp4")
        response["Content-Length"] = str(end - start + 1)
        response["Content-Range"] = f"bytes {start}-{end}/{size}"
        response["Accept-Ranges"] = "bytes"
        return response
    response = FileResponse(
        target.open("rb"), as_attachment=request.GET.get("download") == "1",
        filename=target.name, content_type="video/mp4",
    )
    response["Accept-Ranges"] = "bytes"
    return response


@require_POST
@api_login_required
def resource_action_api(request, user, role, resource_id):
    if role.role_name != ROLE_STUDENT:
        return JsonResponse({"success": False, "error": "仅学生可执行资源操作"}, status=403)
    student = _student(user)
    resource = get_object_or_404(PersonalizedResource, pk=resource_id, student=student)
    payload = _json_payload(request)
    action = payload.get("action")
    if action == "favorite":
        resource.is_favorite = not resource.is_favorite
        resource.save(update_fields=["is_favorite"])
    elif action == "feedback":
        ResourceFeedback.objects.create(
            resource=resource, student=student,
            useful=str(payload.get("useful", "")).lower() in {"true", "1", "yes"},
            comment=(payload.get("comment") or "")[:500],
        )
    elif action in {"opened", "completed"}:
        LearningBehaviorEvent.objects.create(
            student=student, resource=resource,
            event_type="resource_opened" if action == "opened" else "resource_completed",
            duration_seconds=max(0, int(payload.get("duration_seconds") or 0)),
        )
    elif action == "add_to_path":
        goal = LearningGoal.objects.filter(student=student, knowledge_base=resource.knowledge_base, status="进行中").first()
        plan = goal.plans.filter(status="执行中").order_by("-version_no").first() if goal else None
        if not plan:
            return JsonResponse({"success": False, "error": "请先建立当前课程的学习路径"}, status=409)
        existing = LearningPlanNode.objects.filter(plan=plan, resource=resource).first()
        if not existing:
            sequence = (plan.nodes.order_by("-sequence").values_list("sequence", flat=True).first() or 0) + 1
            LearningPlanNode.objects.create(
                plan=plan, knowledge_point=resource.knowledge_point, resource=resource,
                sequence=sequence, recommendation_reason=resource.adaptation_reason or resource.summary,
                estimated_minutes=resource.estimated_minutes, status="待学习",
                mastery=0, dynamically_adjusted=True,
            )
    else:
        return JsonResponse({"success": False, "error": "不支持的操作"}, status=400)
    return JsonResponse({"success": True, "favorite": resource.is_favorite})


@login_required
def question_bank(request, user, role):
    blocked = enforce_role(role, ROLE_STUDENT)
    if blocked:
        return blocked
    student = _student(user)
    banks = QuestionBank.objects.filter(resource__student=student).select_related("resource", "resource__knowledge_point").prefetch_related("questions")
    return render(request, "a3/question_bank.html", _a3_context(request, user, role, student=student, banks=banks))


@login_required
def code_practice(request, user, role):
    blocked = enforce_role(role, ROLE_STUDENT)
    if blocked:
        return blocked
    student = _student(user)
    resources = PersonalizedResource.objects.filter(student=student, resource_type="practice").select_related("knowledge_point")
    return render(request, "a3/resources.html", _a3_context(
        request, user, role, student=student, resources=resources,
        resource_types=PersonalizedResource.RESOURCE_TYPES, page_title="代码实操",
        execution_notice="学生代码只做静态解析，不在Web进程中执行。",
    ))


@require_POST
@api_login_required
def quiz_submit_api(request, user, role, bank_id):
    if role.role_name != ROLE_STUDENT:
        return JsonResponse({"success": False, "error": "仅学生可提交题库"}, status=403)
    student = _student(user)
    bank = get_object_or_404(QuestionBank, pk=bank_id, resource__student=student)
    payload = _json_payload(request)
    answers = payload.get("answers", {})
    if not isinstance(answers, dict):
        return JsonResponse({"success": False, "error": "答案格式无效"}, status=400)
    goal = LearningGoal.objects.filter(student=student, status="进行中").first()
    plan = goal.plans.filter(status="执行中").order_by("-version_no").first() if goal else None
    attempt, adjustments = submit_quiz(
        student.pk, bank, answers,
        duration_seconds=payload.get("duration_seconds", 0), active_plan=plan,
    )
    return JsonResponse({
        "success": True, "attempt_id": attempt.pk, "score": float(attempt.score),
        "correct": attempt.correct_count, "total": attempt.total_count,
        "adjustments": [{"id": item.pk, "reason": item.explanation} for item in adjustments],
        "details": [{
            "question_id": answer.question_id, "correct": answer.is_correct,
            "correct_answer": answer.question.correct_answer,
            "explanation": answer.question.explanation,
            "added_to_wrong_book": not answer.is_correct,
        } for answer in attempt.answers.select_related("question").all()],
    })


@login_required
def learning_path(request, user, role):
    blocked = enforce_role(role, ROLE_STUDENT)
    if blocked:
        return blocked
    student = _student(user)
    goal = LearningGoal.objects.filter(student=student, status="进行中").first()
    plans = PersonalizedLearningPlan.objects.filter(student=student, goal=goal).prefetch_related("nodes__knowledge_point", "nodes__resource", "adjustments").order_by("-version_no") if goal else []
    active_plan = next((item for item in plans if item.status == "执行中"), plans[0] if plans else None)
    return render(request, "a3/learning_path.html", _a3_context(
        request, user, role, student=student, goal=goal, plans=plans, active_plan=active_plan,
    ))


@require_POST
@api_login_required
def path_adjustment_api(request, user, role, adjustment_id):
    if role.role_name != ROLE_STUDENT:
        return JsonResponse({"success": False, "error": "仅学生可确认路径调整"}, status=403)
    student = _student(user)
    adjustment = get_object_or_404(PathAdjustment, pk=adjustment_id, plan__student=student)
    payload = _json_payload(request)
    if payload.get("action") == "accept":
        new_plan = accept_path_adjustment(adjustment)
        if not (request.content_type and "application/json" in request.content_type):
            set_flash(request, f"已接受调整，当前路径升级为v{new_plan.version_no}。")
            return redirect("a3_learning_path")
        return JsonResponse({"success": True, "status": adjustment.status, "new_plan_version": new_plan.version_no})
    if payload.get("action") == "reject":
        adjustment.status = "已拒绝"
        adjustment.decided_at = timezone.now()
        adjustment.save(update_fields=["status", "decided_at"])
        if not (request.content_type and "application/json" in request.content_type):
            set_flash(request, "已拒绝本次路径调整，原路径继续有效。")
            return redirect("a3_learning_path")
        return JsonResponse({"success": True, "status": adjustment.status})
    return JsonResponse({"success": False, "error": "无效操作"}, status=400)


@login_required
def tutor_page(request, user, role):
    blocked = enforce_role(role, ROLE_STUDENT)
    if blocked:
        return blocked
    student = _student(user)
    points = KnowledgePoint.objects.filter(chapter__knowledge_base__status="已启用", is_active=True).select_related("chapter")
    conversations = student.a3_tutor_conversations.prefetch_related("messages").order_by("-created_at")[:8]
    return render(request, "a3/tutor.html", _a3_context(
        request, user, role, student=student, points=points, conversations=conversations,
    ))


@require_POST
@api_login_required
def tutor_ask_api(request, user, role):
    if role.role_name != ROLE_STUDENT:
        return JsonResponse({"success": False, "error": "仅学生可使用课程导师"}, status=403)
    student = _student(user)
    payload = _json_payload(request)
    point = get_object_or_404(KnowledgePoint.objects.select_related("chapter__knowledge_base"), pk=payload.get("point_id"))
    question = (payload.get("question") or "").strip()
    if not question:
        return JsonResponse({"success": False, "error": "问题不能为空"}, status=400)
    message = answer_tutor(
        student.pk, point.chapter.knowledge_base, point, question,
        style=payload.get("style", "简单解释"),
    )
    return JsonResponse({
        "success": True, "message_id": message.pk, "content": message.content,
        "citations": message.citations, "confidence": float(message.confidence),
        "is_ai_generated": message.is_ai_generated, "evidence_status": message.evidence_status,
    })


@require_POST
@api_login_required
def tutor_ask_stream_api(request, user, role):
    if role.role_name != ROLE_STUDENT:
        return JsonResponse({"success": False, "error": "仅学生可使用课程导师"}, status=403)
    student = _student(user)
    request_payload = _json_payload(request)
    point = get_object_or_404(
        KnowledgePoint.objects.select_related("chapter__knowledge_base"),
        pk=request_payload.get("point_id"),
    )
    question = (request_payload.get("question") or "").strip()
    if not question:
        return JsonResponse({"success": False, "error": "问题不能为空"}, status=400)
    message = answer_tutor(
        student.pk, point.chapter.knowledge_base, point, question,
        style=request_payload.get("style", "简单解释"),
    )
    payload = {
        "success": True, "message_id": message.pk, "content": message.content,
        "citations": message.citations, "confidence": float(message.confidence),
        "is_ai_generated": message.is_ai_generated, "evidence_status": message.evidence_status,
    }

    def stream():
        text = payload["content"]
        yield "event: meta\ndata: " + json.dumps({key: value for key, value in payload.items() if key != "content"}, ensure_ascii=False) + "\n\n"
        for index in range(0, len(text), 18):
            yield "event: delta\ndata: " + json.dumps({"text": text[index:index + 18]}, ensure_ascii=False) + "\n\n"
        yield "event: done\ndata: {}\n\n"

    return StreamingHttpResponse(stream(), content_type="text/event-stream; charset=utf-8")


@login_required
def effect_report(request, user, role):
    blocked = enforce_role(role, ROLE_STUDENT)
    if blocked:
        return blocked
    student = _student(user)
    goal = LearningGoal.objects.filter(student=student, status="进行中").first()
    report = LearningEffectReport.objects.filter(student=student).order_by("-created_at").first()
    if not report:
        report = create_effect_report(student.pk, goal)
    metrics = report.deterministic_metrics if isinstance(report.deterministic_metrics, dict) else {}
    metric_cards = [{"label": label, "value": value} for label, value in metrics.items() if label != "平台统计" and not isinstance(value, (dict, list))]
    stats = metrics.get("平台统计", {}) if isinstance(metrics.get("平台统计"), dict) else {}
    platform_stats = [{"label": label, "value": value} for label, value in stats.items()]
    return render(request, "a3/effect_report.html", _a3_context(
        request, user, role, student=student, goal=goal, report=report,
        metric_cards=metric_cards, platform_stats=platform_stats,
    ))


@login_required
def extension_hub(request, user, role):
    blocked = enforce_role(role, ROLE_STUDENT)
    if blocked:
        return blocked
    return render(request, "a3/generic.html", _a3_context(
        request, user, role, title="拓展能力", description="原B1软件实训评价与就业能力模块保留为项目创新拓展。",
        cards=[
            ("代码实训与AI评价", "/student/training/", "复用安全上传、版本提交、成果证据和教师复核"),
            ("评价报告", "/student/evaluations/", "查看原B1实训评价与进步对比"),
            ("就业与成长", "/student/recommendations/", "岗位匹配、简历诊断和模拟面试拓展能力"),
        ],
    ))


# ----------------------------- Teacher pages -----------------------------

@login_required
def teacher_home(request, user, role):
    blocked = enforce_role(role, ROLE_TEACHER)
    if blocked:
        return blocked
    teacher = _teacher(user)
    kb = CourseKnowledgeBase.objects.filter(owner=teacher).first() or CourseKnowledgeBase.objects.first()
    return render(request, "a3/teacher_home.html", _a3_context(
        request, user, role, teacher=teacher, knowledge_base=kb,
        chapter_count=kb.chapters.count() if kb else 0,
        point_count=KnowledgePoint.objects.filter(chapter__knowledge_base=kb).count() if kb else 0,
        pending_reviews=PersonalizedResource.objects.filter(review_status="待教师审核").count(),
        running_jobs=GenerationJob.objects.filter(status__in=["排队中", "已领取", "执行中"]).count(),
        recent_jobs=GenerationJob.objects.select_related("student__user", "goal")[:8],
    ))


@login_required
def teacher_knowledge_base(request, user, role):
    blocked = enforce_role(role, ROLE_TEACHER)
    if blocked:
        return blocked
    teacher = _teacher(user)
    if request.method == "POST":
        name = (request.POST.get("name") or "").strip()
        code = (request.POST.get("course_code") or "").strip()
        if name and code:
            kb, _ = CourseKnowledgeBase.objects.get_or_create(
                course_code=code,
                defaults={"name": name, "description": request.POST.get("description", ""), "owner": teacher},
            )
            KnowledgeVersion.objects.get_or_create(
                knowledge_base=kb, version_no=1,
                defaults={"version_label": "v1", "change_note": "教师创建"},
            )
            set_flash(request, f"课程知识库“{kb.name}”已保存。")
            return redirect("a3_teacher_knowledge_base")
    bases = CourseKnowledgeBase.objects.prefetch_related("chapters", "documents__version").order_by("course_code")
    return render(request, "a3/teacher_kb.html", _a3_context(
        request, user, role, teacher=teacher, bases=bases,
    ))


@require_POST
@login_required
def teacher_document_upload(request, user, role):
    blocked = enforce_role(role, ROLE_TEACHER)
    if blocked:
        return blocked
    teacher = _teacher(user)
    kb = get_object_or_404(CourseKnowledgeBase, pk=request.POST.get("knowledge_base_id"))
    version = kb.versions.filter(is_active=True).order_by("-version_no").first()
    chapter = CourseChapter.objects.filter(pk=request.POST.get("chapter_id"), knowledge_base=kb).first()
    point = KnowledgePoint.objects.filter(pk=request.POST.get("point_id"), chapter__knowledge_base=kb).first()
    uploaded = request.FILES.get("document")
    if not uploaded or not version:
        set_flash(request, "请选择有效文件和知识库版本。", "error")
    else:
        document = ingest_uploaded_document(
            uploaded, knowledge_base=kb, version=version, chapter=chapter,
            point=point, teacher=teacher,
            source_reference=(request.POST.get("source_reference") or "").strip(),
        )
        set_flash(request, f"文档已保存，解析状态：{document.status}。", "success" if document.status == "已解析" else "error")
    return redirect("a3_teacher_knowledge_base")


@require_POST
@login_required
def teacher_document_action(request, user, role, document_id):
    blocked = enforce_role(role, ROLE_TEACHER)
    if blocked:
        return blocked
    document = get_object_or_404(KnowledgeDocument, pk=document_id)
    action = request.POST.get("action")
    if action == "toggle":
        document.is_active = not document.is_active
        document.save(update_fields=["is_active", "updated_at"])
        set_flash(request, f"文档已{'启用' if document.is_active else '停用'}。")
    elif action == "delete" and request.POST.get("confirm") == "DELETE":
        title = document.title
        document.delete()
        set_flash(request, f"文档“{title}”已删除。")
    else:
        set_flash(request, "删除需要二次确认并输入 DELETE。", "error")
    return redirect("a3_teacher_knowledge_base")


@login_required
def teacher_chapters(request, user, role):
    blocked = enforce_role(role, ROLE_TEACHER)
    if blocked:
        return blocked
    if request.method == "POST":
        kb = get_object_or_404(CourseKnowledgeBase, pk=request.POST.get("knowledge_base_id"))
        kind = request.POST.get("kind")
        if kind == "chapter":
            CourseChapter.objects.update_or_create(
                knowledge_base=kb, chapter_no=int(request.POST.get("chapter_no") or 1),
                defaults={
                    "title": request.POST.get("title", "未命名章节"),
                    "objectives": [request.POST.get("objective", "待完善")],
                    "lecture": request.POST.get("lecture", "待完善"),
                },
            )
        elif kind == "point":
            chapter = get_object_or_404(CourseChapter, pk=request.POST.get("chapter_id"), knowledge_base=kb)
            KnowledgePoint.objects.update_or_create(
                point_code=request.POST.get("point_code"),
                defaults={
                    "chapter": chapter, "point_no": int(request.POST.get("point_no") or 1),
                    "title": request.POST.get("title", "未命名知识点"),
                    "summary": request.POST.get("summary", "待完善"),
                },
            )
        set_flash(request, "章节或知识点已保存。")
        return redirect("a3_teacher_chapters")
    bases = CourseKnowledgeBase.objects.prefetch_related("chapters__points")
    return render(request, "a3/teacher_chapters.html", _a3_context(request, user, role, bases=bases))


def _teacher_generic(request, user, role, title, description, cards):
    blocked = enforce_role(role, ROLE_TEACHER)
    if blocked:
        return blocked
    return render(request, "a3/generic.html", _a3_context(
        request, user, role, title=title, description=description, cards=cards,
    ))


@login_required
def teacher_generation_jobs(request, user, role):
    return _teacher_generic(request, user, role, "资源生成任务", "查看队列、进度、失败原因与重试记录。", [
        (f"任务 {job.created_at:%m-%d %H:%M} · {job.status}", reverse("a3_teacher_generation_job_detail", args=[job.pk]), f"{job.learning_goal or job.goal.title} · {job.progress}% · {job.current_step}")
        for job in GenerationJob.objects.select_related("goal")[:30]
    ])


@login_required
def teacher_resource_reviews(request, user, role):
    blocked = enforce_role(role, ROLE_TEACHER)
    if blocked:
        return blocked
    resources = PersonalizedResource.objects.select_related("student__user", "knowledge_point").order_by("review_status", "-created_at")
    return render(request, "a3/teacher_reviews.html", _a3_context(request, user, role, resources=resources))


@login_required
def teacher_resource_review_detail(request, user, role, resource_id):
    blocked = enforce_role(role, ROLE_TEACHER)
    if blocked:
        return blocked
    teacher = _teacher(user)
    resource = get_object_or_404(PersonalizedResource, pk=resource_id)
    if request.method == "POST":
        action = request.POST.get("action")
        status_map = {
            "approve": "教师已通过",
            "reject": "教师已驳回",
            "request_changes": "教师要求修改",
        }
        resource.review_status = status_map.get(action, "待教师审核")
        resource.reviewed_by = teacher
        resource.review_note = (request.POST.get("note") or "")[:2000]
        resource.save(update_fields=["review_status", "reviewed_by", "review_note", "updated_at"])
        set_flash(request, f"资源已{resource.review_status}。")
        return redirect("a3_teacher_resource_reviews")
    return resource_detail.__wrapped__(request, user, role, resource_id)


@login_required
def teacher_student_profiles(request, user, role):
    return _teacher_generic(request, user, role, "学生画像", "查看画像维度、证据、确认状态与历史变化。", [
        (item.user.real_name, f"/teacher/student-profiles/?student={item.pk}", f"画像维度 {item.a3_profile_dimensions.count()} · 快照 {item.a3_profile_snapshots.count()}")
        for item in Student.objects.select_related("user").prefetch_related("a3_profile_dimensions", "a3_profile_snapshots")[:40]
    ])


@login_required
def teacher_learning_paths(request, user, role):
    return _teacher_generic(request, user, role, "学习路径管理", "查看每位学生的路径版本、动态节点与调整原因。", [
        (f"{item.student.user.real_name} · 路径v{item.version_no}", f"{reverse('a3_teacher_learning_paths')}?plan={item.pk}", f"{item.goal.title} · {item.status} · {item.nodes.count()}节点")
        for item in PersonalizedLearningPlan.objects.select_related("student__user", "goal").prefetch_related("nodes")[:40]
    ])


@login_required
def teacher_learning_analytics(request, user, role):
    return _teacher_generic(request, user, role, "学情与效果分析", "区分平台确定性统计、AI分析、AI建议和教师意见。", [
        (item.student.user.real_name, f"{reverse('a3_teacher_learning_analytics')}?report={item.pk}", f"报告期 {item.period_start} 至 {item.period_end} · {item.source_type}")
        for item in LearningEffectReport.objects.select_related("student__user")[:30]
    ])


@login_required
def teacher_content_safety(request, user, role):
    return _teacher_generic(request, user, role, "内容安全记录", "查看注入、敏感内容、课程范围、引用真实性和执行HTML检查。", [
        (f"安全记录 {item.created_at:%m-%d %H:%M} · {item.result}", f"{reverse('a3_teacher_content_safety')}?record={item.pk}", f"动作：{item.action} · 问题：{', '.join(item.issues) or '无'}")
        for item in ContentSafetyRecord.objects.select_related("resource")[:50]
    ])


# ----------------------------- Admin pages -----------------------------

def _admin_guard(role):
    return enforce_role(role, ROLE_ADMIN)


@login_required
def admin_monitor(request, user, role):
    blocked = _admin_guard(role)
    if blocked:
        return blocked
    runs = AgentRun.objects.select_related("workflow", "student__user").prefetch_related("steps__agent", "reviews")[:30]
    jobs = GenerationJob.objects.select_related("goal", "student__user")[:15]
    total_jobs = GenerationJob.objects.count()
    completed_jobs = GenerationJob.objects.filter(status="已完成").count()
    failed_jobs = GenerationJob.objects.filter(status="失败").count()
    agent_counts = AgentStep.objects.values("agent__name").annotate(count=Count("id")).order_by("-count")[:20]
    return render(request, "a3/admin_monitor.html", _a3_context(
        request, user, role, runs=runs, jobs=jobs,
        total_runs=AgentRun.objects.count(), completed_runs=AgentRun.objects.filter(status="已完成").count(),
        failed_runs=AgentRun.objects.filter(status="失败").count(),
        average_duration_display=_duration_text(AgentRun.objects.aggregate(value=Avg("duration_ms"))["value"] or 0),
        total_jobs=total_jobs,
        success_rate=round(completed_jobs * 100 / max(total_jobs, 1), 1),
        failure_rate=round(failed_jobs * 100 / max(total_jobs, 1), 1),
        degraded_count=AgentRun.objects.filter(is_degraded=True).count(),
        rework_count=AgentReview.objects.filter(triggered_rework=True).count(),
        safety_block_count=ContentSafetyRecord.objects.exclude(result="通过").count(),
        agent_counts=agent_counts,
        worker_state=_worker_state(),
        provider_states=ModelProviderState.objects.order_by("provider"),
    ))


@require_GET
@api_login_required
def agent_run_status_api(request, user, role, run_id):
    if role.role_name != ROLE_ADMIN:
        return JsonResponse({"success": False, "error": "仅管理员可查看AgentRun开发详情"}, status=403)
    run = get_object_or_404(
        AgentRun.objects.select_related("workflow", "student__user").prefetch_related(
            "steps__agent", "steps__tool_calls", "steps__model_calls", "steps__messages",
            "reviews__resource", "safety_records", "artifacts__resource",
        ),
        pk=run_id,
    )
    steps = list(run.steps.select_related("agent").prefetch_related("tool_calls", "model_calls", "messages").all())
    nodes = []
    for index, step in enumerate(steps):
        nodes.append({
            "id": step.pk,
            "sequence": step.sequence,
            "agent": step.agent.name,
            "agent_code": step.agent.code,
            "name": step.step_name,
            "status": step.status,
            "upstream": steps[index - 1].agent.name if index else "需求输入",
            "downstream": steps[index + 1].agent.name if index + 1 < len(steps) else "生成完成",
            "input_summary": step.input_summary,
            "output_summary": step.output_summary,
            "provider": step.provider or "未调用生成模型",
            "model": step.model,
            "prompt_version": step.prompt_version,
            "duration": _duration_text(step.duration_ms),
            "tools": [item.tool_name for item in step.tool_calls.all()] or step.tools,
            "citation_count": len(step.citations),
            "degraded": step.is_degraded,
            "retry_count": step.retry_count,
            "rework": step.rework_info,
            "handoffs": [{"sender": item.sender, "receiver": item.receiver, "content": item.content} for item in step.messages.all()],
            "model_calls": [{
                "provider": item.provider, "model": item.model, "status": item.status,
                "duration": _duration_text(item.latency_ms), "error_code": item.error_code,
                "prompt_version": item.prompt_version, "degraded": item.is_degraded,
            } for item in step.model_calls.all()],
            "input_schema": step.input_schema,
            "output_schema": step.output_schema,
        })
    shared = run.shared_context if hasattr(run, "shared_context") else None
    return JsonResponse({
        "success": True,
        "run": {
            "status": run.status,
            "workflow": run.workflow.name,
            "student": run.student.user.real_name if run.student_id else "系统任务",
            "learning_goal": run.learning_goal,
            "input_summary": run.input_summary,
            "output_summary": run.output_summary,
            "provider": run.provider or "逐步骤记录",
            "model": run.model,
            "duration": _duration_text(run.duration_ms),
            "degraded": run.is_degraded,
            "failure_reason": sanitize_error(run.failure_reason),
            "nodes": nodes,
            "reviews": [{
                "resource": item.resource.title if item.resource_id else "工作流",
                "round": item.review_round, "score": float(item.score), "result": item.result,
                "issues": item.issues, "suggestions": item.suggestions,
                "triggered_rework": item.triggered_rework,
            } for item in run.reviews.select_related("resource").all()],
            "shared_context": {
                "learning_goal": shared.learning_goal if shared else {},
                "course": shared.course if shared else {},
                "chapter": shared.chapter if shared else {},
                "knowledge_point": shared.knowledge_point if shared else {},
                "selected_resource_types": shared.selected_resource_types if shared else [],
                "evidence_count": len(shared.rag_evidence) if shared else 0,
                "artifact_count": len(shared.generated_artifacts) if shared else 0,
                "review_count": len(shared.review_results) if shared else 0,
                "learning_path_update": shared.learning_path_update if shared else {},
            },
        },
    })


@login_required
def admin_agent_run_detail(request, user, role, run_id):
    blocked = _admin_guard(role)
    if blocked:
        return blocked
    run = get_object_or_404(AgentRun.objects.select_related("workflow", "student__user"), pk=run_id)
    return render(request, "a3/agent_run_detail.html", _a3_context(
        request, user, role, run=run,
        api_url=reverse("a3_agent_run_status_api", args=[run.pk]),
    ))


def _admin_generic(request, user, role, title, description, cards):
    blocked = _admin_guard(role)
    if blocked:
        return blocked
    return render(request, "a3/generic.html", _a3_context(request, user, role, title=title, description=description, cards=cards))


@login_required
def admin_providers(request, user, role):
    blocked = _admin_guard(role)
    if blocked:
        return blocked
    test_result = None
    provider_code = ""
    state_model = ""
    state_configured = False
    latency = 0
    if request.method == "POST":
        provider_code = request.POST.get("provider")
        if provider_code in {"spark", "glm", "deepseek"}:
            provider = {
                "spark": SparkProvider,
                "glm": GLMProvider,
                "deepseek": DeepSeekProvider,
            }[provider_code]()
            state_model = provider.model
            state_configured = provider.configured
            result = provider.generate(
                [{"role": "user", "content": "仅返回：连接正常"}],
                max_tokens=16, temperature=0, json_mode=False,
                prompt_version="a3-connection-test-v1", use_case="a3_connection_test",
            )
            test_result = {
                "provider": {
                    "spark": "科大讯飞星火",
                    "glm": "GLM-5.3（讯飞 MaaS）",
                    "deepseek": "DeepSeek",
                }[provider_code],
                "success": result.is_ai_generated,
                "status": "连接成功" if result.is_ai_generated else "连接失败",
                "error_code": result.error_code,
                "error": sanitize_error(result.error_message, limit=220),
                "duration": _duration_text(result.latency_ms),
            }
            latency = result.latency_ms
        elif provider_code == "spark-tts":
            tts = SparkTTSProvider()
            state_model = getattr(settings, "SPARK_TTS_VOICE", "")
            state_configured = tts.configured
            if not tts.configured:
                test_result = {"provider": "讯飞语音合成", "success": False, "status": "未配置", "error_code": "TTS_NOT_CONFIGURED", "error": "讯飞语音服务未配置", "duration": "0.0秒"}
            else:
                target = Path(settings.MEDIA_ROOT) / "a3" / "provider-tests" / f"tts-{uuid.uuid4().hex}.mp3"
                started = timezone.now()
                try:
                    tts.synthesize("连接测试", target)
                    latency = int((timezone.now() - started).total_seconds() * 1000)
                    test_result = {"provider": "讯飞语音合成", "success": True, "status": "连接成功", "error_code": "", "error": "", "duration": _duration_text(latency)}
                    if target.is_file():
                        target.unlink()
                except Exception as exc:
                    latency = int((timezone.now() - started).total_seconds() * 1000)
                    test_result = {"provider": "讯飞语音合成", "success": False, "status": "连接失败", "error_code": getattr(exc, "code", "TTS_ERROR"), "error": sanitize_error(exc, limit=220), "duration": _duration_text(latency)}
        if test_result and provider_code in {"spark", "glm", "deepseek", "spark-tts"}:
            now = timezone.now()
            state_defaults = {
                "model": state_model,
                "configured": state_configured,
                "status": test_result["status"],
                "last_latency_ms": max(0, latency),
                "last_error_code": test_result["error_code"],
                "last_checked_at": now,
                "last_test_result": sanitize_error(
                    test_result["error"] or test_result["status"], limit=120
                ),
            }
            if test_result["success"]:
                state_defaults["last_success_at"] = now
            ModelProviderState.objects.update_or_create(
                provider=provider_code,
                defaults=state_defaults,
            )
    providers = [
        {"code": "spark", "name": "科大讯飞星火", "configured": SparkProvider().configured, "model": getattr(settings, "SPARK_MODEL", ""), "state": ModelProviderState.objects.filter(provider="spark").first()},
        {"code": "glm", "name": "GLM-5.3（讯飞 MaaS）", "configured": GLMProvider().configured, "model": getattr(settings, "GLM_MODEL", ""), "state": ModelProviderState.objects.filter(provider="glm").first()},
        {"code": "deepseek", "name": "DeepSeek备用模型", "configured": DeepSeekProvider().configured, "model": getattr(settings, "AI_MODEL", ""), "state": ModelProviderState.objects.filter(provider="deepseek").first()},
        {"code": "spark-tts", "name": "讯飞语音合成", "configured": SparkTTSProvider().configured, "model": getattr(settings, "SPARK_TTS_VOICE", ""), "state": ModelProviderState.objects.filter(provider="spark-tts").first()},
    ]
    return render(request, "a3/admin_providers.html", _a3_context(request, user, role, providers=providers, test_result=test_result))


@login_required
def admin_generation_jobs(request, user, role):
    return _admin_generic(request, user, role, "生成任务监控", "跨学生查看队列、进度、来源、失败和重试。", [
        (f"任务 {job.created_at:%m-%d %H:%M} · {job.status}", reverse("a3_admin_generation_job_detail", args=[job.pk]), f"{job.student.user.real_name} · {job.progress}% · {job.source_label}")
        for job in GenerationJob.objects.select_related("student__user")[:50]
    ])


@login_required
def admin_ai_statistics(request, user, role):
    stats = AIInvocationLog.objects.values("provider", "model", "status").annotate(count=Count("log_id"))[:30]
    return _admin_generic(request, user, role, "AI调用统计", "调用日志只记录提供者、模型、耗时、用量、状态和错误码，不含API Key。", [
        (f"{item['provider']} · {item['model']}", f"{reverse('a3_admin_ai_statistics')}?provider={item['provider']}", f"状态 {item['status']} · {item['count']}次") for item in stats
    ])


@login_required
def admin_safety_statistics(request, user, role):
    stats = ContentSafetyRecord.objects.values("result", "action").annotate(count=Count("id"))
    return _admin_generic(request, user, role, "内容安全统计", "汇总安全审核结果与处置动作。", [
        (item["result"], f"{reverse('a3_admin_safety_statistics')}?result={item['result']}", f"{item['action']} · {item['count']}条") for item in stats
    ])


@login_required
def admin_knowledge_statistics(request, user, role):
    return _admin_generic(request, user, role, "课程知识库统计", "查看课程、章节、知识点、文档、片段和引用规模。", [
        (kb.name, f"{reverse('a3_admin_knowledge_statistics')}?course={kb.pk}", f"{kb.chapters.count()}章 · {KnowledgePoint.objects.filter(chapter__knowledge_base=kb).count()}知识点 · {kb.documents.count()}文档 · {sum(doc.chunks.count() for doc in kb.documents.all())}片段")
        for kb in CourseKnowledgeBase.objects.prefetch_related("chapters", "documents__chunks")
    ])


@login_required
def admin_system_health(request, user, role):
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            database = "正常" if cursor.fetchone() else "异常"
    except Exception:
        database = "异常"
    return _admin_generic(request, user, role, "系统健康检查", "Web、数据库、任务队列和静态文件健康状态。", [
        ("Web进程", "/health/live/", "正常"), ("数据库就绪", "/health/ready/", database),
        ("Agent Worker", reverse("a3_admin_agent_monitor"), _worker_state()["label"]),
    ])


@login_required
def admin_open_source(request, user, role):
    return _admin_generic(request, user, role, "开源与AI工具披露", "公开依赖、模型提供者、AI Coding参与和人工审核边界。", [
        ("开源软件说明", f"{reverse('a3_admin_open_source')}?section=open-source", "Django、PyMySQL、python-docx、python-pptx、pypdf等"),
        ("AI Coding披露", f"{reverse('a3_admin_open_source')}?section=ai-coding", "如实记录Codex参与、人工决策和实际测试"),
        ("科大讯飞接入", reverse("a3_admin_providers"), "查看文本与TTS的实际配置与最近连接测试"),
    ])
