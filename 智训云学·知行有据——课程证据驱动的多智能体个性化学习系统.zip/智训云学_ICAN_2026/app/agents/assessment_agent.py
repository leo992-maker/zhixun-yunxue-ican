from agent_learning.services.assessment import create_effect_report, submit_quiz
from .base_agent import BaseAgent


class AssessmentAgent(BaseAgent):
    code = "assessment_agent"
    tool_name = "learning_effect_assessor"

    def assess_quiz(self, *args, **kwargs):
        return submit_quiz(*args, **kwargs)

    def report(self, *args, **kwargs):
        return create_effect_report(*args, **kwargs)

