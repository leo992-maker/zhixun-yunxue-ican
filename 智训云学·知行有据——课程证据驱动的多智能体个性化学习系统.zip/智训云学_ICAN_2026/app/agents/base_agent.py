from __future__ import annotations

import time

from django.utils import timezone

from agent_learning.models import AgentMessage, AgentModelCall, AgentStep, AgentToolCall
from agent_learning.services.a3_prompts import AGENT_PROMPTS
from agent_learning.services.redaction import sanitize_error


class BaseAgent:
    code = "base"
    tool_name = "none"

    def __init__(self, definition):
        self.definition = definition
        self.prompt_spec = AGENT_PROMPTS.get(self.code)
        self.model_attempts = []

    def capture_model_attempts(self, attempts):
        self.model_attempts.extend(attempts or [])

    def _record_model_calls(self, step):
        for retry_no, result in enumerate(self.model_attempts):
            AgentModelCall.objects.create(
                step=step,
                provider=result.provider,
                model=result.model,
                latency_ms=result.latency_ms,
                status="success" if result.is_ai_generated else "failed",
                error_code=result.error_code,
                prompt_version=self.prompt_spec.version if self.prompt_spec else self.definition.system_prompt_version,
                is_degraded=result.degraded or retry_no > 0,
                retry_no=retry_no,
            )
        successful = next((item for item in reversed(self.model_attempts) if item.is_ai_generated), None)
        if successful:
            step.provider = successful.provider
            step.model = successful.model
        step.is_degraded = bool(self.model_attempts) and (
            not successful or successful.provider != "spark" or len(self.model_attempts) > 1
        )

    def execute(self, run, sequence, step_name, function, *, input_summary="", tool_name=None):
        step = AgentStep.objects.create(
            run=run, agent=self.definition, sequence=sequence, step_name=step_name,
            status="执行中", input_summary=input_summary, started_at=timezone.now(),
            tools=[tool_name or self.tool_name] if (tool_name or self.tool_name) != "none" else [],
            prompt_version=self.prompt_spec.version if self.prompt_spec else self.definition.system_prompt_version,
            input_schema=self.prompt_spec.input_schema if self.prompt_spec else self.definition.input_schema,
            output_schema=self.prompt_spec.output_schema if self.prompt_spec else self.definition.output_schema,
        )
        AgentMessage.objects.create(
            step=step, sender="orchestrator", receiver=self.code,
            content=input_summary or step_name,
        )
        started = time.perf_counter()
        try:
            result = function()
            duration = int((time.perf_counter() - started) * 1000)
            summary = self.summarize(result)
            step.status = "已完成"
            step.output_summary = summary
            step.duration_ms = duration
            step.finished_at = timezone.now()
            self._record_model_calls(step)
            step.save(update_fields=[
                "status", "output_summary", "duration_ms", "finished_at", "provider",
                "model", "is_degraded",
            ])
            if tool_name or self.tool_name != "none":
                AgentToolCall.objects.create(
                    step=step, tool_name=tool_name or self.tool_name,
                    input_summary=input_summary, output_summary=summary,
                    status="success", duration_ms=duration,
                )
            AgentMessage.objects.create(
                step=step, sender=self.code, receiver="orchestrator",
                content=summary,
            )
            return result, step
        except Exception as exc:
            duration = int((time.perf_counter() - started) * 1000)
            error = sanitize_error(exc)
            step.status = "失败"
            step.output_summary = error
            step.duration_ms = duration
            step.finished_at = timezone.now()
            self._record_model_calls(step)
            step.save(update_fields=[
                "status", "output_summary", "duration_ms", "finished_at", "provider",
                "model", "is_degraded",
            ])
            if tool_name or self.tool_name != "none":
                AgentToolCall.objects.create(
                    step=step, tool_name=tool_name or self.tool_name,
                    input_summary=input_summary, output_summary=error,
                    status="failed", duration_ms=duration,
                )
            raise

    @staticmethod
    def summarize(result):
        if isinstance(result, (str, int, float)):
            return str(result)[:500]
        if isinstance(result, (list, tuple, set)):
            return f"完成 {len(result)} 项"
        if isinstance(result, dict):
            parts = []
            for key, value in list(result.items())[:8]:
                if str(key).startswith("_"):
                    continue
                if isinstance(value, (list, tuple, set, dict)):
                    parts.append(f"{key}：{len(value)}项")
                else:
                    parts.append(f"{key}：{value}")
            return "；".join(parts)[:500]
        if hasattr(result, "title"):
            return f"已生成：{result.title}"[:500]
        return sanitize_error(result)
