from agent_learning.services.resources import generate_resource
from .base_agent import BaseAgent


class DocumentAgent(BaseAgent):
    code = "document_agent"
    tool_name = "docx_exporter"

    def generate(self, student_id, goal, point, **kwargs):
        return generate_resource(student_id, goal, point, "document", agent=self, **kwargs)
