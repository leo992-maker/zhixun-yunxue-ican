from agent_learning.services.resources import generate_resource
from .base_agent import BaseAgent


class MindmapAgent(BaseAgent):
    code = "mindmap_agent"
    tool_name = "mermaid_svg_renderer"

    def generate(self, student_id, goal, point, **kwargs):
        return generate_resource(student_id, goal, point, "mindmap", agent=self, **kwargs)
