from agent_learning.services.resources import generate_resource
from .base_agent import BaseAgent


class MultimodalAgent(BaseAgent):
    code = "multimodal_agent"
    tool_name = "spark_tts_if_configured"

    def generate(self, student_id, goal, point, **kwargs):
        return generate_resource(student_id, goal, point, "microcourse", agent=self, **kwargs)
