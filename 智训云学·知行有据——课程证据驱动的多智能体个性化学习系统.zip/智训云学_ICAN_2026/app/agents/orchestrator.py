"""Persistent multi-agent orchestration with scoped knowledge and real rework."""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from django.db import OperationalError, close_old_connections
from django.utils import timezone

from agent_learning.models import (
    AgentDefinition, AgentMessage, AgentReview, AgentRun, AgentRunArtifact,
    AgentSharedContext, ContentSafetyRecord, GenerationArtifact,
    GenerationJobStep, KnowledgePoint, WorkerHeartbeat,
)
from agent_learning.services.a3_prompts import AGENT_PROMPTS
from agent_learning.services.redaction import sanitize_error
from .base_agent import BaseAgent
from .document_agent import DocumentAgent
from .mindmap_agent import MindmapAgent
from .multimodal_agent import MultimodalAgent
from .path_planner_agent import PathPlannerAgent
from .ppt_agent import PPTAgent
from .practice_agent import PracticeAgent
from .profile_agent import ProfileAgent
from .question_agent import QuestionAgent
from .resource_planner_agent import ResourcePlannerAgent
from .retrieval_agent import RetrievalAgent
from .reviewer_agent import ReviewerAgent
from .safety_agent import SafetyAgent


class ReadingAgent(BaseAgent):
    code = "reading_agent"
    tool_name = "knowledge_reading_builder"

    def generate(self, student_id, goal, point, **kwargs):
        from agent_learning.services.resources import generate_resource

        return generate_resource(student_id, goal, point, "reading", agent=self, **kwargs)


AGENT_CLASSES = {
    "profile_agent": ProfileAgent,
    "retrieval_agent": RetrievalAgent,
    "resource_planner_agent": ResourcePlannerAgent,
    "document_agent": DocumentAgent,
    "ppt_agent": PPTAgent,
    "mindmap_agent": MindmapAgent,
    "question_agent": QuestionAgent,
    "reading_agent": ReadingAgent,
    "practice_agent": PracticeAgent,
    "multimodal_agent": MultimodalAgent,
    "safety_agent": SafetyAgent,
    "reviewer_agent": ReviewerAgent,
    "path_planner_agent": PathPlannerAgent,
}
RESOURCE_AGENT = {
    "document": "document_agent",
    "ppt": "ppt_agent",
    "mindmap": "mindmap_agent",
    "quiz": "question_agent",
    "reading": "reading_agent",
    "practice": "practice_agent",
    "microcourse": "multimodal_agent",
}
RESOURCE_PURPOSE = {
    "document": "用分层讲解建立概念理解",
    "ppt": "用逐页结构形成知识框架",
    "mindmap": "把关键关系转成可展开的图解",
    "quiz": "通过作答诊断理解并更新掌握度",
    "reading": "结合课程知识片段补充学习依据",
    "practice": "把概念迁移到代码实践",
    "microcourse": "用脚本、分镜和语音支持短时复习",
}


class LearningOrchestrator:
    def __init__(self, job):
        self.job = job
        self.sequence = 0
        self.run = None
        self.shared = None

    def _agent(self, code):
        definition = AgentDefinition.objects.get(code=code, enabled=True)
        spec = AGENT_PROMPTS.get(code)
        if spec and (
            definition.system_prompt_version != spec.version
            or definition.output_schema != spec.output_schema
        ):
            definition.system_prompt_version = spec.version
            definition.system_prompt = spec.system_prompt
            definition.input_schema = spec.input_schema
            definition.output_schema = spec.output_schema
            definition.tool_list = list(spec.tools)
            definition.save(update_fields=[
                "system_prompt_version", "system_prompt", "input_schema",
                "output_schema", "tool_list", "updated_at",
            ])
        return AGENT_CLASSES[code](definition)

    def _touch_worker(self):
        WorkerHeartbeat.objects.filter(current_job=self.job, status="运行中").update(last_seen_at=timezone.now())

    def _job_step(self, code, name, progress):
        self.sequence += 1
        step, _ = GenerationJobStep.objects.get_or_create(
            job=self.job,
            sequence=self.sequence,
            defaults={"step_code": code, "step_name": name},
        )
        step.status = "执行中"
        step.progress = progress
        step.started_at = timezone.now()
        step.save(update_fields=["status", "progress", "started_at"])
        self.job.current_step = name
        self.job.progress = progress
        self.job.save(update_fields=["current_step", "progress"])
        self._touch_worker()
        return step

    @staticmethod
    def _finish_job_step(step, detail=""):
        step.status = "已完成"
        step.progress = 100
        step.finished_at = timezone.now()
        step.detail = str(detail)[:500]
        if step.started_at:
            step.duration_ms = int((step.finished_at - step.started_at).total_seconds() * 1000)
        step.save(update_fields=["status", "progress", "finished_at", "detail", "duration_ms"])

    @staticmethod
    def _fail_job_step(step, error):
        step.status = "失败"
        step.finished_at = timezone.now()
        step.detail = sanitize_error(error)
        if step.started_at:
            step.duration_ms = int((step.finished_at - step.started_at).total_seconds() * 1000)
        step.save(update_fields=["status", "finished_at", "detail", "duration_ms"])

    def _execute(self, code, name, progress, callback, input_summary=""):
        job_step = self._job_step(code, name, progress)
        agent = self._agent(code)
        try:
            result, agent_step = agent.execute(
                self.run,
                self.sequence,
                name,
                lambda: callback(agent),
                input_summary=input_summary,
            )
        except Exception as exc:
            self._fail_job_step(job_step, exc)
            raise
        self._finish_job_step(job_step, agent_step.output_summary)
        return result, agent_step

    @staticmethod
    def _handoff(step, sender, receiver, content):
        AgentMessage.objects.create(
            step=step,
            sender=sender,
            receiver=receiver,
            message_type="handoff",
            content=str(content)[:1000],
        )

    def _resolve_point(self):
        point = self.job.knowledge_point
        if point:
            return point
        artifact_point = self.job.artifacts.select_related("resource__knowledge_point").first()
        if artifact_point:
            point = artifact_point.resource.knowledge_point
        else:
            point = KnowledgePoint.objects.filter(
                chapter__knowledge_base=self.job.goal.knowledge_base,
                is_active=True,
            ).order_by("chapter__chapter_no", "point_no").first()
        if not point:
            raise ValueError("任务未绑定有效知识点，且无法从旧任务安全补齐")
        self.job.course = self.job.goal.knowledge_base
        self.job.chapter = point.chapter
        self.job.knowledge_point = point
        if not self.job.learning_goal:
            self.job.learning_goal = self.job.goal.title
        if not self.job.selected_resource_types:
            self.job.selected_resource_types = self.job.requested_types
        self.job.save(update_fields=[
            "course", "chapter", "knowledge_point", "learning_goal", "selected_resource_types",
        ])
        return point

    def _persist_artifact(self, resource):
        AgentRunArtifact.objects.get_or_create(run=self.run, resource=resource)
        GenerationArtifact.objects.get_or_create(
            job=self.job,
            resource=resource,
            defaults={
                "artifact_type": resource.resource_type,
                "file_path": resource.file_path,
                "metadata": {
                    "source": resource.source_type,
                    "generation_mode": resource.generation_mode,
                    "version": resource.version_no,
                },
            },
        )

    def process(self):
        started = time.perf_counter()
        self.job.status = "执行中"
        self.job.started_at = timezone.now()
        self.job.can_retry = True
        self.job.save(update_fields=["status", "started_at", "can_retry"])
        point = self._resolve_point()
        if self.job.course_id != self.job.goal.knowledge_base_id:
            raise ValueError("任务课程与学习目标课程不一致")
        if self.job.chapter_id != point.chapter_id or point.chapter.knowledge_base_id != self.job.course_id:
            raise ValueError("任务章节、知识点与课程范围不一致")
        learning_goal = self.job.learning_goal or self.job.goal.title
        self.run = AgentRun.objects.create(
            workflow=self.job.workflow,
            student_id=self.job.student_id,
            learning_goal=learning_goal,
            input_summary=f"课程={self.job.course.name}；章节={self.job.chapter.title}；知识点={point.title}；资源类型={len(self.job.selected_resource_types or self.job.requested_types)}类",
            status="执行中",
            started_at=timezone.now(),
        )
        self.job.run = self.run
        self.job.save(update_fields=["run"])
        self.shared = AgentSharedContext.objects.create(
            run=self.run,
            learning_goal={"text": learning_goal, "difficulty": self.job.difficulty, "available_minutes": self.job.available_minutes},
            course={"id": self.job.course_id, "name": self.job.course.name, "code": self.job.course.course_code},
            chapter={"id": self.job.chapter_id, "title": self.job.chapter.title, "number": self.job.chapter.chapter_no},
            knowledge_point={"id": point.pk, "title": point.title, "summary": point.summary},
            selected_resource_types=self.job.selected_resource_types or self.job.requested_types,
        )
        try:
            profile, profile_step = self._execute(
                "profile_agent",
                "画像分析",
                8,
                lambda agent: agent.analyze(self.job.student_id, learning_goal, self.job.available_minutes),
                f"分析学生当前基础、薄弱点、偏好与{self.job.available_minutes}分钟时间预算",
            )
            self.shared.student_profile = profile
            self.shared.save(update_fields=["student_profile", "updated_at"])

            evidence, retrieval_step = self._execute(
                "retrieval_agent",
                "知识检索",
                18,
                lambda agent: agent.retrieve(self.job.goal, point, learning_goal),
                f"限定《{self.job.course.name}》/第{self.job.chapter.chapter_no}章/{point.title}检索",
            )
            if not evidence:
                raise ValueError("当前课程、章节与知识点范围内证据不足，未生成资源主体")
            evidence_payload = [item.as_dict() for item in evidence]
            retrieval_step.citations = evidence_payload
            retrieval_step.save(update_fields=["citations"])
            self.shared.rag_evidence = evidence_payload
            self.shared.save(update_fields=["rag_evidence", "updated_at"])

            strategy, planner_step = self._execute(
                "resource_planner_agent",
                "资源策划",
                26,
                lambda agent: agent.plan(
                    self.job.selected_resource_types or self.job.requested_types,
                    profile,
                    self.job,
                ),
                f"围绕{point.title}规划资源目标、时长、顺序、并行关系与互补方式",
            )
            requested = list(dict.fromkeys(
                kind for kind in (self.job.selected_resource_types or self.job.requested_types)
                if kind in RESOURCE_AGENT
            ))
            if not requested:
                raise ValueError("资源策划未返回有效资源类型")
            model_selected = [kind for kind in strategy.get("selected_types", []) if kind in RESOURCE_AGENT]
            strategy["model_recommended_types"] = list(dict.fromkeys(model_selected))
            strategy["model_reasons"] = strategy.get("reasons", {})
            # The student's final checkbox choices are authoritative.  Spark plans
            # sequencing and complementarity, while deterministic code prevents a
            # model response from silently dropping requested deliverables.
            selected = requested
            strategy["selected_types"] = selected
            strategy["reasons"] = {
                kind: f"围绕“{point.title}”，{RESOURCE_PURPOSE[kind]}。"
                for kind in selected
            }
            order = []
            for item in strategy.get("learning_order", []):
                kind = item if isinstance(item, str) else (
                    item.get("resource_type") or item.get("type") or item.get("resource")
                    if isinstance(item, dict) else ""
                )
                if kind in selected and kind not in order:
                    order.append(kind)
            strategy["learning_order"] = order + [kind for kind in selected if kind not in order]
            self.job.resource_strategy = strategy
            self.job.selected_resource_types = selected
            self.job.save(update_fields=["resource_strategy", "selected_resource_types"])
            self.shared.resource_strategy = strategy
            self.shared.selected_resource_types = selected
            self.shared.save(update_fields=["resource_strategy", "selected_resource_types", "updated_at"])

            resources = []
            generation_steps = {}
            for resource_type in selected:
                code = RESOURCE_AGENT[resource_type]
                generation_steps[resource_type] = self._job_step(
                    code,
                    f"生成{dict(__import__('agent_learning.models', fromlist=['PersonalizedResource']).PersonalizedResource.RESOURCE_TYPES)[resource_type]}",
                    30 + min(35, len(generation_steps) * 5),
                )

            def generate_one(resource_type):
                close_old_connections()
                try:
                    agent = self._agent(RESOURCE_AGENT[resource_type])
                    key = f"job-{self.job.pk}-{resource_type}-retry-{self.job.retry_count}-v1"

                    def generate_with_deadlock_retry():
                        last_error = None
                        for attempt in range(3):
                            try:
                                return agent.generate(
                                    self.job.student_id,
                                    self.job.goal,
                                    point,
                                    run=self.run,
                                    generation_key=key,
                                    learning_goal=learning_goal,
                                )
                            except OperationalError as exc:
                                last_error = exc
                                if not exc.args or int(exc.args[0]) not in {1205, 1213} or attempt == 2:
                                    raise
                                close_old_connections()
                                time.sleep(0.15 * (attempt + 1))
                        raise last_error

                    result, agent_step = agent.execute(
                        self.run,
                        generation_steps[resource_type].sequence,
                        generation_steps[resource_type].step_name,
                        generate_with_deadlock_retry,
                        input_summary=f"课程={self.job.course.name}；章节={self.job.chapter.title}；知识点={point.title}；目标={learning_goal}",
                    )
                    agent_step.citations = evidence_payload
                    agent_step.save(update_fields=["citations"])
                    self._handoff(agent_step, "resource_planner_agent", agent.code, f"按策划生成{resource_type}，只使用共享上下文中的{point.title}与{len(evidence)}条证据")
                    return result, agent_step
                finally:
                    close_old_connections()

            with ThreadPoolExecutor(max_workers=min(4, len(selected))) as executor:
                futures = {executor.submit(generate_one, kind): kind for kind in selected}
                for future in as_completed(futures):
                    kind = futures[future]
                    resource, agent_step = future.result()
                    resources.append(resource)
                    self._finish_job_step(generation_steps[kind], agent_step.output_summary)
                    self._persist_artifact(resource)

            self.shared.generated_artifacts = [
                {"resource_id": item.pk, "type": item.resource_type, "version": item.version_no, "generation_mode": item.generation_mode}
                for item in resources
            ]
            self.shared.save(update_fields=["generated_artifacts", "updated_at"])

            safety_results, safety_step = self._execute(
                "safety_agent",
                "内容安全检查",
                72,
                lambda agent: agent.inspect(resources, evidence),
                f"检查{len(resources)}份资源的注入、课程越界、虚假引用、外链、HTML脚本与不安全代码",
            )
            for resource, result in safety_results:
                ContentSafetyRecord.objects.create(
                    run=self.run,
                    resource=resource,
                    result="通过" if result["passed"] else "拒绝",
                    checks=result["checks"],
                    issues=result["issues"],
                    action="进入质量审核" if result["passed"] else "阻断并等待教师处理",
                )
                if not result["passed"]:
                    resource.review_status = "安全审核驳回"
                    resource.save(update_fields=["review_status"])
                self._handoff(safety_step, RESOURCE_AGENT[resource.resource_type], "safety_agent", f"交付{resource.title} v{resource.version_no}进行确定性安全检查")
            self.shared.safety_results = [
                {"resource_id": resource.pk, "passed": result["passed"], "issues": result["issues"]}
                for resource, result in safety_results
            ]
            self.shared.save(update_fields=["safety_results", "updated_at"])

            reviews, review_step = self._execute(
                "reviewer_agent",
                "质量审核",
                82,
                lambda agent: agent.review(resources, point, profile, evidence_payload),
                f"审核{point.title}的一致性、完整性、画像适配、引用充分性与文件真实性",
            )
            reviewer = AgentDefinition.objects.get(code="reviewer_agent")
            resource_by_id = {item.pk: item for item in resources}
            for review in reviews:
                resource = resource_by_id[review["resource_id"]]
                AgentReview.objects.create(
                    run=self.run,
                    reviewer=reviewer,
                    resource=resource,
                    review_type="resource_quality",
                    result="通过" if review["passed"] else "返工",
                    score=review["score"],
                    issues=review["issues"],
                    suggestions=review["suggestions"],
                    triggered_rework=not review["passed"],
                    review_round=1,
                    rework_target=review["rework_target"],
                )
            self._handoff(review_step, "safety_agent", "reviewer_agent", "安全检查结果和资源文件真实性已交付质量审核")

            reworked = []
            for review in [item for item in reviews if not item["passed"]]:
                previous = resource_by_id[review["resource_id"]]
                feedback = "；".join(review["suggestions"] or review["issues"] or ["按Schema和当前知识点重新生成"])
                code = RESOURCE_AGENT[previous.resource_type]
                revised, rework_step = self._execute(
                    code,
                    f"{previous.get_resource_type_display()}返工生成v{previous.version_no + 1}",
                    88,
                    lambda agent, previous=previous, feedback=feedback: agent.generate(
                        self.job.student_id,
                        self.job.goal,
                        point,
                        run=self.run,
                        generation_key=f"job-{self.job.pk}-{previous.resource_type}-retry-{self.job.retry_count}-v{previous.version_no + 1}",
                        parent=previous,
                        revision_feedback=feedback,
                        learning_goal=learning_goal,
                    ),
                    f"携带质量审核修改意见返工：{feedback[:260]}",
                )
                rework_step.retry_count = 1
                rework_step.rework_info = {"from_resource_id": previous.pk, "from_version": previous.version_no, "to_resource_id": revised.pk, "to_version": revised.version_no, "reason": feedback}
                rework_step.save(update_fields=["retry_count", "rework_info"])
                previous.review_status = "质量审核返工"
                previous.save(update_fields=["review_status"])
                self._persist_artifact(revised)
                reworked.append(revised)

            if reworked:
                second_reviews, second_step = self._execute(
                    "reviewer_agent",
                    "返工版本复审",
                    91,
                    lambda agent: agent.review(reworked, point, profile, evidence_payload),
                    "复审v2；最多自动返工一次，不进入无限循环",
                )
                for review in second_reviews:
                    resource = next(item for item in reworked if item.pk == review["resource_id"])
                    AgentReview.objects.create(
                        run=self.run,
                        reviewer=reviewer,
                        resource=resource,
                        review_type="resource_quality",
                        result="通过" if review["passed"] else "待教师处理",
                        score=review["score"],
                        issues=review["issues"],
                        suggestions=review["suggestions"],
                        triggered_rework=False,
                        review_round=2,
                        rework_target="",
                    )
                    if not review["passed"]:
                        resource.review_status = "质量复审未通过，待教师处理"
                        resource.save(update_fields=["review_status"])
                resources.extend(reworked)

            all_reviews = [
                {**item, "score": float(item["score"])}
                for item in self.run.reviews.values(
                    "resource_id", "score", "result", "issues", "suggestions",
                    "review_round", "triggered_rework",
                )
            ]
            self.shared.review_results = all_reviews
            self.shared.generated_artifacts = [
                {"resource_id": item.pk, "type": item.resource_type, "version": item.version_no, "parent_id": item.parent_id, "generation_mode": item.generation_mode}
                for item in resources
            ]
            self.shared.save(update_fields=["review_results", "generated_artifacts", "updated_at"])

            path_context = {
                "mastery": "读取当前知识点掌握度",
                "quiz_results": "生成后待学生完成",
                "time_budget": self.job.available_minutes,
                "preferences": profile.get("preferences", {}),
                "prerequisites": point.chapter.prerequisite_summary,
                "resources": self.shared.generated_artifacts,
                "reviews": all_reviews,
            }
            path_result, path_step = self._execute(
                "path_planner_agent",
                "学习路径更新",
                95,
                lambda agent: agent.plan(self.job.student_id, self.job.goal, path_context),
                "按掌握度、测验、时间、偏好、先修关系、新资源与审核结果更新路径",
            )
            self._handoff(path_step, "reviewer_agent", "path_planner_agent", "已交付资源版本链、审核分数和返工结论用于路径规划")
            self.shared.learning_path_update = {
                "plan_id": path_result["plan"].pk,
                "version": path_result["plan"].version_no,
                "reason": path_result["plan"].plan_reason,
                "recommendation_count": len(path_result["recommendations"]),
            }
            self.shared.save(update_fields=["learning_path_update", "updated_at"])

            modes = {item.generation_mode for item in resources}
            if modes == {"ONLINE_SPARK"}:
                source_label = "讯飞星火在线生成"
            elif "ONLINE_SPARK" in modes or "ONLINE_FALLBACK" in modes:
                source_label = "混合在线生成，实际模型逐资源记录"
            elif modes == {"DEMO_PRESET"}:
                source_label = "演示预置资源"
            else:
                source_label = "规则降级生成"
            self.job.status = "已完成"
            self.job.progress = 100
            self.job.current_step = "生成完成"
            self.job.source_label = source_label
            self.job.finished_at = timezone.now()
            self.job.error_message = ""
            self.job.failure_stage = ""
            self.job.save(update_fields=[
                "status", "progress", "current_step", "source_label", "finished_at",
                "error_message", "failure_stage",
            ])
            online_resource = next((item for item in resources if item.provider), None)
            self.run.status = "已完成"
            self.run.output_summary = f"生成{len(resources)}个资源版本；知识点={point.title}；返工{len(reworked)}个；路径v{path_result['plan'].version_no}"
            self.run.provider = online_resource.provider if online_resource else ""
            self.run.model = online_resource.model if online_resource else ""
            self.run.finished_at = timezone.now()
            self.run.duration_ms = int((time.perf_counter() - started) * 1000)
            self.run.is_degraded = any(item.generation_mode != "ONLINE_SPARK" for item in resources)
            self.run.save(update_fields=[
                "status", "output_summary", "provider", "model", "finished_at",
                "duration_ms", "is_degraded",
            ])
            self._touch_worker()
            return resources
        except Exception as exc:
            error = sanitize_error(exc)
            self.job.status = "失败"
            self.job.error_message = error
            self.job.failure_stage = self.job.current_step
            self.job.current_step = "生成失败"
            self.job.finished_at = timezone.now()
            self.job.can_retry = True
            self.job.save(update_fields=[
                "status", "error_message", "failure_stage", "current_step",
                "finished_at", "can_retry",
            ])
            if self.run:
                self.run.status = "失败"
                self.run.failure_reason = error
                self.run.finished_at = timezone.now()
                self.run.duration_ms = int((time.perf_counter() - started) * 1000)
                self.run.save(update_fields=["status", "failure_reason", "finished_at", "duration_ms"])
            self._touch_worker()
            raise
