from agent_learning.services.paths import create_learning_plan, refresh_recommendations
from agent_learning.services.agent_reasoning import structured_agent_call
from .base_agent import BaseAgent


class PathPlannerAgent(BaseAgent):
    code = "path_planner_agent"
    tool_name = "dynamic_path_planner"

    def plan(self, student_id, goal, context=None):
        plan = create_learning_plan(student_id, goal)
        recommendations = refresh_recommendations(student_id, goal)

        def fallback():
            return {
                "reason": plan.plan_reason or "根据掌握度、先修关系、时间预算与新资源生成学习顺序。",
                "recommended_order": [item.resource.title for item in recommendations],
                "next_action": "先完成当前知识点讲解与题库，再根据作答结果决定补强或进入下一节点。",
            }

        explanation = structured_agent_call(self, context or {}, fallback)
        plan.plan_reason = explanation.get("reason", fallback()["reason"])
        plan.save(update_fields=["plan_reason"])
        return {"plan": plan, "recommendations": recommendations, "explanation": explanation}
