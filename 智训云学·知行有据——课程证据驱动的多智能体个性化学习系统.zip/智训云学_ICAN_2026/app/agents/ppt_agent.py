from agent_learning.services.resources import generate_resource
from .base_agent import BaseAgent


class PPTAgent(BaseAgent):
    code = "ppt_agent"
    tool_name = "python-pptx"

    def generate(self, student_id, goal, point, **kwargs):
        return generate_resource(student_id, goal, point, "ppt", agent=self, **kwargs)
