from agent_learning.services.resources import generate_resource
from .base_agent import BaseAgent


class PracticeAgent(BaseAgent):
    code = "practice_agent"
    tool_name = "static_code_case_builder"

    def generate(self, student_id, goal, point, **kwargs):
        return generate_resource(student_id, goal, point, "practice", agent=self, **kwargs)
