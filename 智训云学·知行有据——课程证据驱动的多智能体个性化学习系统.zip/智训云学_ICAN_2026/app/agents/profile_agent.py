from agent_learning.services.resources import profile_summary
from agent_learning.services.agent_reasoning import structured_agent_call
from .base_agent import BaseAgent


class ProfileAgent(BaseAgent):
    code = "profile_agent"
    tool_name = "profile_store"

    def analyze(self, student_id, learning_goal="", available_minutes=30):
        profile = profile_summary(student_id)
        weak = profile.get("weak_points", {}).get("value", {})
        preferences = profile.get("resource_preference", {}).get("value", {})

        def fallback():
            return {
                "current_foundation": profile.get("foundation", {}).get("value", {"说明": "画像中尚未明确"}),
                "mastered": profile.get("mastered", {}).get("value", {"说明": "待通过测验确认"}),
                "weak_points": weak or {"说明": "以当前知识点为本次诊断重点"},
                "learning_goal": learning_goal,
                "preferences": preferences or {"形式": ["讲义", "题库", "代码实践"]},
                "time_budget": f"本次可投入{available_minutes}分钟",
                "practice_ability": profile.get("practice_ability", {}).get("value", {"说明": "待实践任务验证"}),
                "resource_advice": ["先建立概念结构", "再用练习和实践检验", "根据结果调整路径"],
            }

        result = structured_agent_call(
            self,
            {"profile_dimensions": profile, "learning_goal": learning_goal, "available_minutes": available_minutes},
            fallback,
        )
        result["dimension_count"] = len(profile)
        result["dimensions"] = list(profile)
        return result
