from agent_learning.services.resources import generate_resource
from .base_agent import BaseAgent


class QuestionAgent(BaseAgent):
    code = "question_agent"
    tool_name = "quiz_builder"

    def generate(self, student_id, goal, point, **kwargs):
        return generate_resource(student_id, goal, point, "quiz", agent=self, **kwargs)
