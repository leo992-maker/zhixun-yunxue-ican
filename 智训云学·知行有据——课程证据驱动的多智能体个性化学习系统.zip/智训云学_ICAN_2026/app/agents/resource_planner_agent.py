from agent_learning.services.agent_reasoning import structured_agent_call
from .base_agent import BaseAgent


class ResourcePlannerAgent(BaseAgent):
    code = "resource_planner_agent"
    tool_name = "resource_strategy"

    def plan(self, requested_types, profile=None, job=None):
        supported = ["document", "ppt", "mindmap", "quiz", "reading", "practice", "microcourse"]
        selected = [item for item in requested_types if item in supported]
        selected = list(dict.fromkeys(selected or supported[:5]))
        minutes = max(5, int(getattr(job, "available_minutes", 30) or 30))
        reasons = {
            "document": "建立分层概念理解",
            "ppt": "用逐页结构快速形成知识框架",
            "mindmap": "显化概念关系和学习顺序",
            "quiz": "诊断理解并更新掌握度",
            "reading": "回到真实课程片段补充依据",
            "practice": "把概念迁移到代码表达",
            "microcourse": "用脚本、分镜和语音支持短时复习",
        }

        def fallback():
            return {
                "selected_types": selected,
                "reasons": {kind: reasons[kind] for kind in selected},
                "learning_order": selected,
                "estimated_total_minutes": sum(12 if kind not in {"document", "practice"} else 20 for kind in selected),
                "parallel_groups": [[kind for kind in selected if kind in {"document", "ppt", "mindmap", "reading"}], [kind for kind in selected if kind in {"quiz", "practice", "microcourse"}]],
                "complementarity": "讲解与结构资源并行生成，题库和实践负责检验，微课用于复习。",
            }

        return structured_agent_call(
            self,
            {
                "student_profile": profile or {},
                "learning_goal": getattr(job, "learning_goal", "") if job else "",
                "knowledge_point": getattr(getattr(job, "knowledge_point", None), "title", "") if job else "",
                "selected_resource_types": selected,
                "available_minutes": minutes,
            },
            fallback,
        )
