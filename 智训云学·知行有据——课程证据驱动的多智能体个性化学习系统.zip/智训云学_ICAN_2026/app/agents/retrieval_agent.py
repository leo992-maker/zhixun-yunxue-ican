from agent_learning.services.rag import retrieve_evidence
from .base_agent import BaseAgent


class RetrievalAgent(BaseAgent):
    code = "retrieval_agent"
    tool_name = "bm25_course_retrieval"

    def retrieve(self, goal, point, learning_goal=""):
        query_goal = (learning_goal or goal.title).strip()
        return retrieve_evidence(
            goal.knowledge_base,
            f"{query_goal} {point.title} {point.summary}",
            point=point,
        )
