import json
from pathlib import Path

from django.conf import settings

from agent_learning.services.agent_reasoning import structured_agent_call
from agent_learning.services.schemas import RESOURCE_SCHEMAS, SchemaValidationError
from .base_agent import BaseAgent


class ReviewerAgent(BaseAgent):
    code = "reviewer_agent"
    tool_name = "quality_gate"

    def _deterministic_review(self, resource, point, profile=None):
        issues = []
        suggestions = []
        if not resource.citations:
            issues.append("缺少课程知识库引用")
            suggestions.append("补充当前课程、章节和知识点的有效证据")
        if any(item.get("knowledge_point_id") != point.pk for item in resource.citations):
            issues.append("存在不属于当前知识点的引用")
            suggestions.append("重新限定RAG检索范围")
        if point.title not in f"{resource.title} {resource.summary}":
            issues.append("标题或摘要未明确当前知识点")
            suggestions.append(f"在标题和摘要中明确“{point.title}”")
        try:
            RESOURCE_SCHEMAS[resource.resource_type].validate(resource.content)
        except SchemaValidationError as exc:
            issues.append(f"资源结构不完整：{str(exc)[:120]}")
            suggestions.append("按对应资源Schema补全缺失字段")
        current_scope = " ".join(
            [point.title, point.summary] + [str(item) for item in (point.tags or [])]
        )
        serialized = json.dumps(resource.content, ensure_ascii=False)
        weak_points = (profile or {}).get("weak_points", [])
        if isinstance(weak_points, str):
            weak_points = [weak_points]
        unrelated = [
            str(item)
            for item in weak_points
            if len(str(item).strip()) >= 2
            and str(item) in serialized
            and str(item) not in current_scope
        ]
        if unrelated:
            issues.append("出现与当前知识点无关的历史画像内容")
            suggestions.append("移除旧任务薄弱点，仅围绕当前知识点重新生成")
        if resource.resource_type in {"document", "ppt", "mindmap"}:
            target = Path(settings.MEDIA_ROOT) / resource.file_path if resource.file_path else None
            if not target or not target.is_file():
                issues.append("真实导出文件不存在")
                suggestions.append("重新执行确定性文件导出并验证可打开")
        score = max(0, 100 - len(issues) * 22)
        return {
            "resource_id": resource.pk,
            "resource_type": resource.resource_type,
            "score": score,
            "passed": score >= 75 and not issues,
            "issues": issues,
            "suggestions": suggestions,
            "requires_rework": bool(issues),
            "rework_target": resource.resource_type if issues else "",
        }

    def review(self, resources, point, profile=None, evidence=None):
        deterministic = [
            self._deterministic_review(resource, point, profile) for resource in resources
        ]

        def fallback():
            failed = [item for item in deterministic if not item["passed"]]
            return {
                "score": min((item["score"] for item in deterministic), default=100),
                "issues": [issue for item in failed for issue in item["issues"]],
                "suggestions": [suggestion for item in failed for suggestion in item["suggestions"]],
                "passed": not failed,
                "requires_rework": bool(failed),
                "rework_target": failed[0]["resource_type"] if failed else "",
            }

        advisory = structured_agent_call(
            self,
            {
                "resources": [
                    {
                        "id": item.pk,
                        "type": item.resource_type,
                        "title": item.title,
                        "summary": item.summary,
                        "source": item.source_type,
                        "citation_count": len(item.citations),
                        "deterministic_review": next(row for row in deterministic if row["resource_id"] == item.pk),
                    }
                    for item in resources
                ],
                "student_profile": profile or {},
                "knowledge_point": {"id": point.pk, "title": point.title, "summary": point.summary},
                "rag_evidence": evidence or [],
            },
            fallback,
        )
        for item in deterministic:
            if advisory.get("requires_rework") and advisory.get("rework_target") == item["resource_type"]:
                item["passed"] = False
                item["requires_rework"] = True
                item["score"] = min(item["score"], int(advisory.get("score") or 70))
                item["issues"] = list(dict.fromkeys(item["issues"] + list(advisory.get("issues") or [])))
                item["suggestions"] = list(dict.fromkeys(item["suggestions"] + list(advisory.get("suggestions") or [])))
                item["rework_target"] = item["resource_type"]
        return deterministic
