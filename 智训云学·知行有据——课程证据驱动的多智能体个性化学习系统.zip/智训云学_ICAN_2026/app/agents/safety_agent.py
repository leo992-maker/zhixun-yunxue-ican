from agent_learning.services.safety import inspect_output
from .base_agent import BaseAgent


class SafetyAgent(BaseAgent):
    code = "safety_agent"
    tool_name = "content_safety_rules"

    def inspect(self, resources, evidence):
        results = []
        for resource in resources:
            results.append((resource, inspect_output(resource.content, resource.citations, evidence)))
        return results

