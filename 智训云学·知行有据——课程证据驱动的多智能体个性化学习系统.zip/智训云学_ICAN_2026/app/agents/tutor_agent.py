from agent_learning.services.tutor import answer_tutor
from .base_agent import BaseAgent


class TutorAgent(BaseAgent):
    code = "tutor_agent"
    tool_name = "course_rag_tutor"

    def answer(self, *args, **kwargs):
        return answer_tutor(*args, **kwargs)

