"""Backward-compatible AI import surface."""

from .services.ai_service import (
    AIResult,
    call_chat,
    call_structured,
    is_ai_configured,
    stream_chat,
)


def call_ai_chat(messages, temperature=0.7, max_tokens=800):
    result = call_chat(
        messages,
        temperature=temperature,
        max_tokens=max_tokens,
        use_case="legacy_chat",
    )
    return result.success, result.content if result.success else result.error or result.code


__all__ = [
    "AIResult",
    "call_ai_chat",
    "call_chat",
    "call_structured",
    "is_ai_configured",
    "stream_chat",
]
