# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Ability(models.Model):
    ability_id = models.AutoField(primary_key=True, db_comment='能力项唯一ID')
    ability_name = models.CharField(unique=True, max_length=60, db_comment='能力名称')
    ability_type = models.CharField(max_length=20, db_comment='能力类型')
    description = models.CharField(max_length=255, blank=True, null=True, db_comment='能力说明')

    class Meta:
        managed = False
        db_table = 'ability'
        db_table_comment = '能力项表'


class Assessment(models.Model):
    assessment_id = models.AutoField(primary_key=True, db_comment='测评唯一ID')
    assessment_name = models.CharField(max_length=80, db_comment='测评名称')
    assessment_type = models.CharField(max_length=30, db_comment='测评类型')
    description = models.TextField(blank=True, null=True, db_comment='测评说明')

    class Meta:
        managed = False
        db_table = 'assessment'
        db_table_comment = '测评表'


class AssessmentResult(models.Model):
    result_id = models.AutoField(primary_key=True, db_comment='测评结果唯一ID')
    student = models.ForeignKey('Student', models.DO_NOTHING, db_comment='学生ID')
    assessment = models.ForeignKey(Assessment, models.DO_NOTHING, db_comment='测评ID')
    score = models.IntegerField(blank=True, null=True, db_comment='测评分数，0至100')
    result_text = models.TextField(blank=True, null=True, db_comment='测评结果说明')
    test_time = models.DateTimeField(blank=True, null=True, db_comment='测评时间')

    class Meta:
        managed = False
        db_table = 'assessment_result'
        db_table_comment = '测评结果表'


class CareerReport(models.Model):
    report_id = models.AutoField(primary_key=True, db_comment='报告唯一ID')
    student = models.ForeignKey('Student', models.DO_NOTHING, db_comment='学生ID')
    target_position = models.ForeignKey('JobPosition', models.DO_NOTHING, blank=True, null=True, db_comment='目标岗位ID')
    gap_analysis = models.TextField(blank=True, null=True, db_comment='能力差距分析')
    plan_content = models.TextField(blank=True, null=True, db_comment='发展规划内容')
    create_time = models.DateTimeField(blank=True, null=True, db_comment='生成时间')

    class Meta:
        managed = False
        db_table = 'career_report'
        db_table_comment = '生涯报告表'


class ClassInfo(models.Model):
    class_id = models.AutoField(primary_key=True, db_comment='班级唯一ID')
    major = models.ForeignKey('Major', models.DO_NOTHING, db_comment='专业ID')
    class_name = models.CharField(max_length=50, db_comment='班级名称')
    grade = models.CharField(max_length=10, db_comment='年级')

    class Meta:
        managed = False
        db_table = 'class_info'
        unique_together = (('major', 'class_name'),)
        db_table_comment = '班级表'


class Company(models.Model):
    company_id = models.AutoField(primary_key=True, db_comment='企业唯一ID')
    company_name = models.CharField(unique=True, max_length=80, db_comment='企业名称')
    industry = models.CharField(max_length=60, db_comment='行业')
    contact_person = models.CharField(max_length=30, blank=True, null=True, db_comment='联系人')
    contact_phone = models.CharField(max_length=20, blank=True, null=True, db_comment='联系电话')

    class Meta:
        managed = False
        db_table = 'company'
        db_table_comment = '企业表'


class Course(models.Model):
    course_id = models.AutoField(primary_key=True, db_comment='课程唯一ID')
    major = models.ForeignKey('Major', models.DO_NOTHING, db_comment='所属专业ID')
    teacher = models.ForeignKey('Teacher', models.DO_NOTHING, db_comment='授课教师ID')
    course_name = models.CharField(max_length=80, db_comment='课程名称')
    course_type = models.CharField(max_length=20, db_comment='课程类型')
    description = models.TextField(blank=True, null=True, db_comment='课程说明')
    create_time = models.DateTimeField(db_comment='创建时间')

    class Meta:
        managed = False
        db_table = 'course'
        db_table_comment = '课程表'


class CourseModule(models.Model):
    pk = models.CompositePrimaryKey('course_id', 'module_id')
    course = models.ForeignKey(Course, models.DO_NOTHING, db_comment='课程ID')
    module = models.ForeignKey('MicroModule', models.DO_NOTHING, db_comment='微模块ID')
    module_order = models.IntegerField(db_comment='模块顺序')

    class Meta:
        managed = False
        db_table = 'course_module'
        db_table_comment = '课程-微模块关系表，m:n联系转关系表'


class InterviewRecord(models.Model):
    interview_id = models.AutoField(primary_key=True, db_comment='面试记录唯一ID')
    student = models.ForeignKey('Student', models.DO_NOTHING, db_comment='学生ID')
    position = models.ForeignKey('JobPosition', models.DO_NOTHING, blank=True, null=True, db_comment='目标岗位ID')
    question = models.TextField(db_comment='面试问题')
    answer = models.TextField(blank=True, null=True, db_comment='学生回答')
    ai_score = models.IntegerField(blank=True, null=True, db_comment='AI面试评分，0至100')
    feedback = models.TextField(blank=True, null=True, db_comment='面试反馈')
    interview_time = models.DateTimeField(blank=True, null=True, db_comment='面试时间')

    class Meta:
        managed = False
        db_table = 'interview_record'
        db_table_comment = '模拟面试记录表'


class JobPosition(models.Model):
    position_id = models.AutoField(primary_key=True, db_comment='岗位唯一ID')
    company = models.ForeignKey(Company, models.DO_NOTHING, db_comment='企业ID')
    position_name = models.CharField(max_length=80, db_comment='岗位名称')
    industry = models.CharField(max_length=60, blank=True, null=True, db_comment='岗位行业方向')
    salary_range = models.CharField(max_length=50, blank=True, null=True, db_comment='薪资范围')
    description = models.TextField(blank=True, null=True, db_comment='岗位描述')

    class Meta:
        managed = False
        db_table = 'job_position'
        db_table_comment = '岗位表'


class LearningPath(models.Model):
    path_id = models.AutoField(primary_key=True, db_comment='学习路径唯一ID')
    path_name = models.CharField(max_length=80, db_comment='路径名称')
    major = models.ForeignKey('Major', models.DO_NOTHING, blank=True, null=True, db_comment='适用专业ID')
    target_position = models.ForeignKey(JobPosition, models.DO_NOTHING, blank=True, null=True, db_comment='目标岗位ID')
    description = models.TextField(blank=True, null=True, db_comment='路径说明')
    create_time = models.DateTimeField(db_comment='创建时间')

    class Meta:
        managed = False
        db_table = 'learning_path'
        db_table_comment = '学习路径表'


class LearningRecord(models.Model):
    record_id = models.AutoField(primary_key=True, db_comment='学习记录唯一ID')
    student = models.ForeignKey('Student', models.DO_NOTHING, db_comment='学生ID')
    module = models.ForeignKey('MicroModule', models.DO_NOTHING, db_comment='微模块ID')
    progress = models.IntegerField(db_comment='学习进度，0至100')
    study_time = models.IntegerField(db_comment='学习时长，分钟')
    score = models.IntegerField(blank=True, null=True, db_comment='学习得分，0至100')
    status = models.CharField(max_length=20, db_comment='学习状态')
    last_study_time = models.DateTimeField(blank=True, null=True, db_comment='最后学习时间')

    class Meta:
        managed = False
        db_table = 'learning_record'
        unique_together = (('student', 'module'),)
        db_table_comment = '学习记录表'


class Major(models.Model):
    major_id = models.AutoField(primary_key=True, db_comment='专业唯一ID')
    major_name = models.CharField(unique=True, max_length=60, db_comment='专业名称')
    college = models.CharField(max_length=60, db_comment='所属学院')
    description = models.CharField(max_length=255, blank=True, null=True, db_comment='专业说明')

    class Meta:
        managed = False
        db_table = 'major'
        db_table_comment = '专业表'


class MicroModule(models.Model):
    module_id = models.AutoField(primary_key=True, db_comment='微模块唯一ID')
    module_name = models.CharField(max_length=80, db_comment='模块名称')
    module_type = models.CharField(max_length=20, db_comment='模块类型：专业模块/生涯模块/融合模块')
    duration = models.IntegerField(db_comment='时长，分钟，题目要求5至15分钟')
    knowledge_point = models.CharField(max_length=120, blank=True, null=True, db_comment='知识点')
    difficulty = models.CharField(max_length=10, db_comment='难度')
    description = models.TextField(blank=True, null=True, db_comment='模块说明')

    class Meta:
        managed = False
        db_table = 'micro_module'
        db_table_comment = '微模块表'


class ModuleAbility(models.Model):
    pk = models.CompositePrimaryKey('module_id', 'ability_id')
    module = models.ForeignKey(MicroModule, models.DO_NOTHING, db_comment='微模块ID')
    ability = models.ForeignKey(Ability, models.DO_NOTHING, db_comment='能力项ID')
    weight = models.DecimalField(max_digits=4, decimal_places=2, db_comment='能力权重，0至1')

    class Meta:
        managed = False
        db_table = 'module_ability'
        db_table_comment = '微模块-能力关系表，m:n联系转关系表'


class PathModule(models.Model):
    pk = models.CompositePrimaryKey('path_id', 'module_id')
    path = models.ForeignKey(LearningPath, models.DO_NOTHING, db_comment='学习路径ID')
    module = models.ForeignKey(MicroModule, models.DO_NOTHING, db_comment='微模块ID')
    module_order = models.IntegerField(db_comment='路径中的模块顺序')

    class Meta:
        managed = False
        db_table = 'path_module'
        db_table_comment = '学习路径-微模块表，m:n联系转关系表'


class PositionAbility(models.Model):
    pk = models.CompositePrimaryKey('position_id', 'ability_id')
    position = models.ForeignKey(JobPosition, models.DO_NOTHING, db_comment='岗位ID')
    ability = models.ForeignKey(Ability, models.DO_NOTHING, db_comment='能力项ID')
    required_level = models.CharField(max_length=20, db_comment='要求等级')

    class Meta:
        managed = False
        db_table = 'position_ability'
        db_table_comment = '岗位-能力要求表，m:n联系转关系表'


class ProcessScore(models.Model):
    score_id = models.AutoField(primary_key=True, db_comment='成绩记录唯一ID')
    student = models.OneToOneField('Student', models.DO_NOTHING, db_comment='学生ID')
    module_completion_rate = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True, db_comment='模块平均完成度')
    learning_avg_score = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True, db_comment='学习平均分')
    training_avg_score = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True, db_comment='实训平均分')
    assessment_avg_score = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True, db_comment='测评平均分')
    total_score = models.DecimalField(max_digits=5, decimal_places=2, blank=True, null=True, db_comment='过程性总成绩')
    update_time = models.DateTimeField(blank=True, null=True, db_comment='更新时间')

    class Meta:
        managed = False
        db_table = 'process_score'
        db_table_comment = '过程性成绩表'


class QaRecord(models.Model):
    qa_id = models.AutoField(primary_key=True, db_comment='答疑记录唯一ID')
    student = models.ForeignKey('Student', models.DO_NOTHING, db_comment='提问学生ID')
    teacher = models.ForeignKey('Teacher', models.DO_NOTHING, blank=True, null=True, db_comment='答疑教师ID')
    question_content = models.TextField(db_comment='问题内容')
    ai_answer = models.TextField(blank=True, null=True, db_comment='AI辅助回答')
    teacher_answer = models.TextField(blank=True, null=True, db_comment='教师回答')
    status = models.CharField(max_length=20, db_comment='答疑状态')
    create_time = models.DateTimeField(blank=True, null=True, db_comment='提问时间')
    answer_time = models.DateTimeField(blank=True, null=True, db_comment='回复时间')

    class Meta:
        managed = False
        db_table = 'qa_record'
        db_table_comment = '师生互动与AI答疑记录表'


class Recommendation(models.Model):
    recommend_id = models.AutoField(primary_key=True, db_comment='推荐记录唯一ID')
    student = models.ForeignKey('Student', models.DO_NOTHING, db_comment='学生ID')
    recommend_type = models.CharField(max_length=20, db_comment='推荐类型')
    module = models.ForeignKey(MicroModule, models.DO_NOTHING, blank=True, null=True, db_comment='被推荐微模块ID')
    position = models.ForeignKey(JobPosition, models.DO_NOTHING, blank=True, null=True, db_comment='被推荐岗位ID')
    path = models.ForeignKey(LearningPath, models.DO_NOTHING, blank=True, null=True, db_comment='被推荐学习路径ID')
    reason = models.TextField(db_comment='推荐理由')
    recommend_time = models.DateTimeField(blank=True, null=True, db_comment='推荐时间')

    class Meta:
        managed = False
        db_table = 'recommendation'
        db_table_comment = '推荐记录表'


class Resume(models.Model):
    resume_id = models.AutoField(primary_key=True, db_comment='简历唯一ID')
    student = models.ForeignKey('Student', models.DO_NOTHING, db_comment='学生ID')
    target_position = models.ForeignKey(JobPosition, models.DO_NOTHING, blank=True, null=True, db_comment='目标岗位ID')
    resume_content = models.TextField(db_comment='简历内容')
    ai_comment = models.TextField(blank=True, null=True, db_comment='AI优化建议')
    match_score = models.IntegerField(blank=True, null=True, db_comment='岗位匹配度，0至100')
    update_time = models.DateTimeField(blank=True, null=True, db_comment='更新时间')

    class Meta:
        managed = False
        db_table = 'resume'
        db_table_comment = '简历表'


class RoleInfo(models.Model):
    role_id = models.AutoField(primary_key=True, db_comment='角色唯一ID')
    role_name = models.CharField(unique=True, max_length=20, db_comment='角色名称：管理员/教师/学生')
    description = models.CharField(max_length=200, blank=True, null=True, db_comment='角色说明')

    class Meta:
        managed = False
        db_table = 'role_info'
        db_table_comment = '角色表'


class Student(models.Model):
    student_id = models.AutoField(primary_key=True, db_comment='学生唯一ID')
    user = models.OneToOneField('UserAccount', models.DO_NOTHING, db_comment='用户ID，体现用户与学生的一对一关系')
    major = models.ForeignKey(Major, models.DO_NOTHING, db_comment='专业ID')
    class_field = models.ForeignKey(ClassInfo, models.DO_NOTHING, db_column='class_id', db_comment='班级ID')  # Field renamed because it was a Python reserved word.
    student_no = models.CharField(unique=True, max_length=30, db_comment='学号')
    enrollment_year = models.TextField(db_comment='入学年份')  # This field type is a guess.

    class Meta:
        managed = False
        db_table = 'student'
        db_table_comment = '学生表'


class StudentPath(models.Model):
    pk = models.CompositePrimaryKey('student_id', 'path_id')
    student = models.ForeignKey(Student, models.DO_NOTHING, db_comment='学生ID')
    path = models.ForeignKey(LearningPath, models.DO_NOTHING, db_comment='学习路径ID')
    assign_time = models.DateTimeField(db_comment='分配时间')
    status = models.CharField(max_length=20, db_comment='路径状态')

    class Meta:
        managed = False
        db_table = 'student_path'
        db_table_comment = '学生学习路径表'


class StudentProfile(models.Model):
    profile_id = models.AutoField(primary_key=True, db_comment='画像唯一ID')
    student = models.OneToOneField(Student, models.DO_NOTHING, db_comment='学生ID')
    foundation_level = models.CharField(max_length=20, blank=True, null=True, db_comment='专业基础水平')
    learning_habit = models.CharField(max_length=100, blank=True, null=True, db_comment='学习习惯')
    weak_ability = models.CharField(max_length=100, blank=True, null=True, db_comment='能力短板')
    career_interest = models.CharField(max_length=100, blank=True, null=True, db_comment='职业倾向')
    update_time = models.DateTimeField(blank=True, null=True, db_comment='更新时间')

    class Meta:
        managed = False
        db_table = 'student_profile'
        db_table_comment = '学生画像表'


class Teacher(models.Model):
    teacher_id = models.AutoField(primary_key=True, db_comment='教师唯一ID')
    user = models.OneToOneField('UserAccount', models.DO_NOTHING, db_comment='用户ID，体现用户与教师的一对一关系')
    teacher_no = models.CharField(unique=True, max_length=30, db_comment='教师工号')
    title = models.CharField(max_length=30, blank=True, null=True, db_comment='职称')
    department = models.CharField(max_length=60, db_comment='所属院系')

    class Meta:
        managed = False
        db_table = 'teacher'
        db_table_comment = '教师表'


class TrainingRecord(models.Model):
    training_record_id = models.AutoField(primary_key=True, db_comment='实训记录唯一ID')
    student = models.ForeignKey(Student, models.DO_NOTHING, db_comment='学生ID')
    task = models.ForeignKey('TrainingTask', models.DO_NOTHING, db_comment='实训任务ID')
    submit_content = models.TextField(blank=True, null=True, db_comment='提交内容')
    ai_score = models.IntegerField(blank=True, null=True, db_comment='AI评分，0至100')
    teacher_score = models.IntegerField(blank=True, null=True, db_comment='教师评分，0至100')
    feedback = models.TextField(blank=True, null=True, db_comment='评价反馈')
    correction_suggestion = models.TextField(blank=True, null=True, db_comment='AI过程纠错或优化建议')
    status = models.CharField(max_length=20, db_comment='状态')
    submit_time = models.DateTimeField(blank=True, null=True, db_comment='提交时间')

    class Meta:
        managed = False
        db_table = 'training_record'
        unique_together = (('student', 'task'),)
        db_table_comment = '实训记录表'


class TrainingStep(models.Model):
    step_id = models.AutoField(primary_key=True, db_comment='实训步骤唯一ID')
    task = models.ForeignKey('TrainingTask', models.DO_NOTHING, db_comment='实训任务ID')
    step_order = models.IntegerField(db_comment='步骤顺序')
    step_name = models.CharField(max_length=80, db_comment='步骤名称')
    step_hint = models.TextField(blank=True, null=True, db_comment='AI步骤提示或引导内容')

    class Meta:
        managed = False
        db_table = 'training_step'
        unique_together = (('task', 'step_order'),)
        db_table_comment = '实训步骤表，用于体现AI引导与闯关训练'


class TrainingTask(models.Model):
    task_id = models.AutoField(primary_key=True, db_comment='实训任务唯一ID')
    teacher = models.ForeignKey(Teacher, models.DO_NOTHING, db_comment='发布教师ID')
    position = models.ForeignKey(JobPosition, models.DO_NOTHING, blank=True, null=True, db_comment='关联岗位ID')
    task_name = models.CharField(max_length=80, db_comment='任务名称')
    scene_type = models.CharField(max_length=30, db_comment='职场场景类型')
    difficulty = models.CharField(max_length=10, db_comment='任务难度')
    requirement = models.TextField(db_comment='任务要求')
    deliverable = models.CharField(max_length=120, blank=True, null=True, db_comment='提交成果形式')
    publish_time = models.DateTimeField(db_comment='发布时间')

    class Meta:
        managed = False
        db_table = 'training_task'
        db_table_comment = '实训任务表'


class UserAccount(models.Model):
    user_id = models.AutoField(primary_key=True, db_comment='用户唯一ID')
    role = models.ForeignKey(RoleInfo, models.DO_NOTHING, db_comment='角色ID')
    username = models.CharField(unique=True, max_length=50, db_comment='登录账号')
    password = models.CharField(max_length=128, db_comment='Django安全哈希密码，兼容旧明文首次登录升级')
    real_name = models.CharField(max_length=30, db_comment='真实姓名')
    phone = models.CharField(unique=True, max_length=20, blank=True, null=True, db_comment='联系电话')
    email = models.CharField(unique=True, max_length=80, blank=True, null=True, db_comment='邮箱')
    status = models.CharField(max_length=20, db_comment='账号状态')
    create_time = models.DateTimeField(db_comment='创建时间')

    @property
    def display_name(self):
        """Role-aware display name used consistently across the platform."""
        from app.services.identity_service import account_display_name

        try:
            role_name = self.role.role_name
        except (AttributeError, RoleInfo.DoesNotExist):
            role_name = ""
        return account_display_name(self.real_name, role_name)

    class Meta:
        managed = False
        db_table = 'user_account'
        db_table_comment = '用户账号表'


class WarningRecord(models.Model):
    warning_id = models.AutoField(primary_key=True, db_comment='预警记录唯一ID')
    student = models.ForeignKey(Student, models.DO_NOTHING, db_comment='学生ID')
    warning_type = models.CharField(max_length=30, db_comment='预警类型')
    warning_reason = models.TextField(db_comment='预警原因')
    warning_level = models.CharField(max_length=20, db_comment='预警等级')
    create_time = models.DateTimeField(blank=True, null=True, db_comment='生成时间')
    status = models.CharField(max_length=20, db_comment='处理状态')

    class Meta:
        managed = False
        db_table = 'warning_record'
        db_table_comment = '预警记录表'


class EvaluationRubric(models.Model):
    rubric_id = models.AutoField(primary_key=True)
    task = models.ForeignKey(TrainingTask, models.DO_NOTHING)
    created_by = models.ForeignKey(Teacher, models.DO_NOTHING)
    rubric_name = models.CharField(max_length=120)
    description = models.TextField(blank=True, null=True)
    version_no = models.PositiveIntegerField(default=1)
    total_weight = models.DecimalField(max_digits=5, decimal_places=2, default=100)
    source = models.CharField(max_length=30, default='teacher')
    prompt_version = models.CharField(max_length=40, blank=True, default='')
    status = models.CharField(max_length=20, default='草稿')
    is_active = models.BooleanField(default=False)
    create_time = models.DateTimeField(auto_now_add=True)
    update_time = models.DateTimeField(auto_now=True)

    class Meta:
        managed = False
        db_table = 'evaluation_rubric'
        unique_together = (('task', 'version_no'),)


class RubricDimension(models.Model):
    dimension_id = models.AutoField(primary_key=True)
    rubric = models.ForeignKey(EvaluationRubric, models.DO_NOTHING, related_name='dimensions')
    dimension_order = models.PositiveIntegerField(default=1)
    dimension_name = models.CharField(max_length=80)
    weight = models.DecimalField(max_digits=5, decimal_places=2)
    max_score = models.DecimalField(max_digits=6, decimal_places=2, default=100)
    criteria = models.TextField()
    excellent_standard = models.TextField(blank=True, default='')
    qualified_standard = models.TextField(blank=True, default='')
    common_issues = models.TextField(blank=True, default='')
    ai_enabled = models.BooleanField(default=True)
    teacher_review_required = models.BooleanField(default=False)

    class Meta:
        managed = False
        db_table = 'rubric_dimension'
        unique_together = (('rubric', 'dimension_order'), ('rubric', 'dimension_name'))


class TrainingSubmission(models.Model):
    submission_id = models.AutoField(primary_key=True)
    student = models.ForeignKey(Student, models.DO_NOTHING, related_name='submissions')
    task = models.ForeignKey(TrainingTask, models.DO_NOTHING, related_name='submissions')
    rubric = models.ForeignKey(EvaluationRubric, models.DO_NOTHING, blank=True, null=True)
    version_no = models.PositiveIntegerField(default=1)
    text_content = models.TextField(blank=True, default='')
    status = models.CharField(max_length=30, default='已提交')
    idempotency_key = models.CharField(max_length=64, unique=True)
    submitted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        managed = False
        db_table = 'training_submission'
        unique_together = (('student', 'task', 'version_no'),)


class SubmissionFile(models.Model):
    file_id = models.AutoField(primary_key=True)
    submission = models.ForeignKey(TrainingSubmission, models.DO_NOTHING, related_name='files')
    original_name = models.CharField(max_length=255)
    stored_path = models.CharField(max_length=500)
    extension = models.CharField(max_length=20)
    mime_type = models.CharField(max_length=120)
    file_size = models.BigIntegerField()
    sha256 = models.CharField(max_length=64)
    parse_status = models.CharField(max_length=30, default='已保存')
    parse_message = models.CharField(max_length=255, blank=True, default='')
    create_time = models.DateTimeField(auto_now_add=True)

    class Meta:
        managed = False
        db_table = 'submission_file'
        unique_together = (('submission', 'sha256'),)


class AIEvaluation(models.Model):
    evaluation_id = models.AutoField(primary_key=True)
    submission = models.ForeignKey(TrainingSubmission, models.DO_NOTHING, related_name='evaluations')
    rubric = models.ForeignKey(EvaluationRubric, models.DO_NOTHING)
    total_score = models.DecimalField(max_digits=6, decimal_places=2)
    summary = models.TextField()
    strengths_json = models.JSONField(default=list)
    critical_issues_json = models.JSONField(default=list)
    general_issues_json = models.JSONField(default=list)
    suggestions_json = models.JSONField(default=list)
    recommended_modules_json = models.JSONField(default=list)
    source = models.CharField(max_length=30, default='deepseek')
    is_ai_generated = models.BooleanField(default=True)
    confidence = models.DecimalField(max_digits=4, decimal_places=3, default=0)
    requires_teacher_review = models.BooleanField(default=True)
    model_name = models.CharField(max_length=80, blank=True, default='')
    prompt_version = models.CharField(max_length=40)
    raw_response_json = models.JSONField(default=dict)
    status = models.CharField(max_length=30, default='待教师复核')
    evaluated_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        managed = False
        db_table = 'ai_evaluation'


class AIEvaluationDimension(models.Model):
    detail_id = models.AutoField(primary_key=True)
    evaluation = models.ForeignKey(AIEvaluation, models.DO_NOTHING, related_name='dimension_details')
    dimension = models.ForeignKey(RubricDimension, models.DO_NOTHING)
    score = models.DecimalField(max_digits=6, decimal_places=2)
    max_score = models.DecimalField(max_digits=6, decimal_places=2)
    reason = models.TextField()
    evidence = models.TextField()
    file_name = models.CharField(max_length=255, blank=True, default='')
    line_reference = models.CharField(max_length=200, blank=True, default='')
    confidence = models.DecimalField(max_digits=4, decimal_places=3, default=0)

    class Meta:
        managed = False
        db_table = 'ai_evaluation_dimension'
        unique_together = (('evaluation', 'dimension'),)


class TeacherReview(models.Model):
    review_id = models.AutoField(primary_key=True)
    evaluation = models.OneToOneField(AIEvaluation, models.DO_NOTHING, related_name='teacher_review')
    teacher = models.ForeignKey(Teacher, models.DO_NOTHING)
    adjusted_scores_json = models.JSONField(default=dict)
    teacher_comment = models.TextField(blank=True, default='')
    ai_error_notes = models.TextField(blank=True, default='')
    decision = models.CharField(max_length=20)
    teacher_score = models.DecimalField(max_digits=6, decimal_places=2)
    final_score = models.DecimalField(max_digits=6, decimal_places=2)
    review_time = models.DateTimeField(auto_now=True)

    class Meta:
        managed = False
        db_table = 'teacher_review'


class ReportSnapshot(models.Model):
    snapshot_id = models.AutoField(primary_key=True)
    report_type = models.CharField(max_length=60)
    scope_type = models.CharField(max_length=30)
    scope_id = models.PositiveIntegerField(blank=True, null=True)
    filters_json = models.JSONField(default=dict)
    data_json = models.JSONField(default=dict)
    generated_by = models.ForeignKey(UserAccount, models.DO_NOTHING, blank=True, null=True)
    generated_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        managed = False
        db_table = 'report_snapshot'


class AIInvocationLog(models.Model):
    log_id = models.AutoField(primary_key=True)
    use_case = models.CharField(max_length=60)
    provider = models.CharField(max_length=30)
    model = models.CharField(max_length=80)
    prompt_version = models.CharField(max_length=40)
    status = models.CharField(max_length=20)
    latency_ms = models.PositiveIntegerField(default=0)
    input_tokens = models.PositiveIntegerField(default=0)
    output_tokens = models.PositiveIntegerField(default=0)
    error_code = models.CharField(max_length=40, blank=True, default='')
    create_time = models.DateTimeField(auto_now_add=True)

    class Meta:
        managed = False
        db_table = 'ai_invocation_log'


class OperationLog(models.Model):
    operation_id = models.AutoField(primary_key=True)
    operator = models.ForeignKey(UserAccount, models.DO_NOTHING, blank=True, null=True)
    action = models.CharField(max_length=80)
    target_type = models.CharField(max_length=60)
    target_id = models.CharField(max_length=60, blank=True, default='')
    detail_json = models.JSONField(default=dict)
    ip_address = models.GenericIPAddressField(blank=True, null=True)
    create_time = models.DateTimeField(auto_now_add=True)

    class Meta:
        managed = False
        db_table = 'operation_log'


class Notification(models.Model):
    notification_id = models.AutoField(primary_key=True)
    user = models.ForeignKey(UserAccount, models.DO_NOTHING, related_name='notifications')
    title = models.CharField(max_length=120)
    content = models.TextField()
    notification_type = models.CharField(max_length=30, default='系统')
    link = models.CharField(max_length=255, blank=True, default='')
    is_read = models.BooleanField(default=False)
    create_time = models.DateTimeField(auto_now_add=True)

    class Meta:
        managed = False
        db_table = 'notification'


class ScoreWeightConfig(models.Model):
    config_id = models.AutoField(primary_key=True)
    config_name = models.CharField(max_length=80, unique=True)
    module_weight = models.DecimalField(max_digits=5, decimal_places=2, default=30)
    training_weight = models.DecimalField(max_digits=5, decimal_places=2, default=40)
    assessment_weight = models.DecimalField(max_digits=5, decimal_places=2, default=20)
    career_quality_weight = models.DecimalField(max_digits=5, decimal_places=2, default=10)
    is_active = models.BooleanField(default=True)
    update_time = models.DateTimeField(auto_now=True)

    class Meta:
        managed = False
        db_table = 'score_weight_config'
