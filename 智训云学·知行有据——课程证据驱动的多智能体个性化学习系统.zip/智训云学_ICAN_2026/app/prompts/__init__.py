"""Versioned prompt templates used by the DeepSeek integration."""
