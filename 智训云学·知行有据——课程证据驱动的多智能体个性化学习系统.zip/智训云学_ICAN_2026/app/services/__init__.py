"""Business services for the competition platform."""
