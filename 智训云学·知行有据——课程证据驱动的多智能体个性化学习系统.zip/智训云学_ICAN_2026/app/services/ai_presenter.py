"""Normalize AI and legacy text fields into safe template view models.

The existing database stores AI output in TextField columns.  This module keeps
those columns and old rows compatible while preventing templates from rendering
raw JSON, Python literals, Markdown markers, or HTML supplied by a model.
"""

from __future__ import annotations

import ast
import json
import logging
import re
from typing import Any

logger = logging.getLogger(__name__)

SOURCE_AI = "AI生成"
SOURCE_RULE = "规则降级"
SOURCE_PLATFORM = "平台数据"
SOURCE_INSUFFICIENT = "证据不足"


def _clean_text(value: Any, default: str = "暂无数据", limit: int = 3000) -> str:
    if value is None:
        return default
    text = str(value).replace("\x00", "").strip()
    text = re.sub(r"```(?:json|python|html)?", "", text, flags=re.I)
    text = text.replace("```", "")
    text = re.sub(r"^\s{0,3}#{1,6}\s*", "", text, flags=re.M)
    text = re.sub(r"\*\*([^*]+)\*\*", r"\1", text)
    text = re.sub(r"__([^_]+)__", r"\1", text)
    text = re.sub(r"^\s*[-*+]\s+", "", text, flags=re.M)
    text = re.sub(r"<\s*(script|style)[^>]*>.*?<\s*/\s*\1\s*>", "", text, flags=re.I | re.S)
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text).strip()
    return (text or default)[:limit]


def _as_list(value: Any, *, limit: int = 8) -> list[str]:
    if value is None:
        return []
    if isinstance(value, dict):
        values = [f"{_clean_text(key)}：{_clean_text(item)}" for key, item in value.items()]
    elif isinstance(value, (list, tuple, set)):
        values = [_clean_text(item) for item in value]
    else:
        text = _clean_text(value, default="")
        values = [item.strip() for item in re.split(r"[\n；;]+", text) if item.strip()]
    return [item for item in values if item][:limit]


def _source_from_text(text: str) -> str:
    lowered = text.lower()
    if any(token in lowered for token in ("deepseek", "ai生成", "ai 生成")):
        return SOURCE_AI
    if any(token in text for token in ("规则降级", "规则解读", "未调用AI", "规则预检")):
        return SOURCE_RULE
    return SOURCE_PLATFORM


def _parse_payload(raw: Any) -> tuple[Any | None, str]:
    if isinstance(raw, (dict, list)):
        return raw, SOURCE_AI
    text = str(raw or "").strip()
    source = _source_from_text(text)
    if not text:
        return None, source
    candidates = [text]
    for marker in ("DeepSeek解读：", "AI解读：", "结构化结果："):
        if marker in text:
            candidates.insert(0, text.split(marker, 1)[1].strip())
    starts = [position for position in (text.find("{"), text.find("[")) if position >= 0]
    if starts:
        candidates.insert(0, text[min(starts):])
    for candidate in candidates:
        candidate = re.sub(r"^```(?:json)?\s*|\s*```$", "", candidate, flags=re.I)
        end = max(candidate.rfind("}"), candidate.rfind("]"))
        if end >= 0:
            candidate = candidate[: end + 1]
        try:
            return json.loads(candidate), source
        except (json.JSONDecodeError, TypeError):
            try:
                parsed = ast.literal_eval(candidate)
                if isinstance(parsed, (dict, list)):
                    return parsed, source
            except (ValueError, SyntaxError):
                continue
    return None, source


def _labelled_sections(raw: Any) -> dict[str, str]:
    text = str(raw or "")
    sections: dict[str, str] = {}
    pattern = re.compile(r"^【([^】]+)】\s*(.*)$", re.M)
    matches = list(pattern.finditer(text))
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        sections[match.group(1)] = _clean_text(match.group(2) + text[match.end():end], default="")
    return sections


def present_assessment(raw: Any, score: Any = None) -> dict[str, Any]:
    data, detected_source = _parse_payload(raw)
    sections = _labelled_sections(raw)
    if not isinstance(data, dict):
        data = {}
    fallback = _clean_text(raw, default="本次测评已完成，建议结合目标岗位持续补齐能力证据。")
    return {
        "score": score,
        "summary": _clean_text(data.get("summary") or sections.get("结论") or fallback),
        "strengths": _as_list(data.get("strengths") or sections.get("优势")),
        "risks": _as_list(data.get("risks") or sections.get("风险")),
        "position_fit": _clean_text(data.get("position_fit") or sections.get("岗位匹配") or "需结合目标岗位进一步确认"),
        "stage_goals": _as_list(data.get("stage_goals") or sections.get("阶段目标")),
        "recommended_modules": _as_list(data.get("recommended_modules") or sections.get("推荐微模块")),
        "recommended_training": _as_list(data.get("recommended_training") or sections.get("推荐实训")),
        "source": sections.get("来源") or detected_source,
        "confidence": _clean_text(data.get("confidence") or sections.get("置信度") or "需教师确认", limit=60),
    }


def present_career_report(gap_analysis: Any, raw: Any, target_position: str = "") -> dict[str, Any]:
    data, detected_source = _parse_payload(raw)
    sections = _labelled_sections(raw)
    if not isinstance(data, dict):
        data = {}
    stages = []
    for index, stage in enumerate(data.get("stages") or []):
        if not isinstance(stage, dict):
            continue
        stages.append({
            "period": _clean_text(stage.get("period") or f"阶段{index + 1}"),
            "goal": _clean_text(stage.get("goal")),
            "modules": _as_list(stage.get("modules")),
            "training": _as_list(stage.get("training")),
            "deliverable": _clean_text(stage.get("deliverable") or "形成可复用的学习或项目成果"),
            "success_metric": _clean_text(stage.get("success_metric") or "由学习记录与教师复核共同确认"),
        })
    if not stages and sections.get("成长阶段"):
        for index, item in enumerate(_as_list(sections["成长阶段"], limit=6)):
            stages.append({"period": f"阶段{index + 1}", "goal": item, "modules": [], "training": [], "deliverable": "完成阶段成果", "success_metric": "达到阶段目标"})
    summary_fallback = _clean_text(raw, default="建议先完成推荐微模块，并通过实训持续补齐岗位能力证据。")
    return {
        "target_position": _clean_text(target_position or "待匹配"),
        "gap_analysis": _clean_text(data.get("gap_analysis") or gap_analysis or sections.get("能力差距") or "暂无明确差距数据"),
        "plan_summary": _clean_text(data.get("plan_summary") or sections.get("计划摘要") or summary_fallback),
        "strengths": _as_list(data.get("strengths") or sections.get("优势能力")),
        "risks": _as_list(data.get("risks") or sections.get("风险短板")),
        "stages": stages,
        "evidence_sources": _as_list(data.get("evidence_sources") or sections.get("数据依据")),
        "source": sections.get("来源") or detected_source,
        "confidence": _clean_text(data.get("confidence") or sections.get("置信度") or "需教师确认", limit=60),
    }


def present_resume(raw: Any, match_score: Any = None) -> dict[str, Any]:
    data, detected_source = _parse_payload(raw)
    sections = _labelled_sections(raw)
    if not isinstance(data, dict):
        data = {}
    return {
        "match_score": match_score,
        "summary": _clean_text(data.get("summary") or sections.get("结论") or raw or "暂无诊断结果"),
        "keyword_coverage": _as_list(data.get("keyword_coverage") or sections.get("关键词覆盖")),
        "strengths": _as_list(data.get("strengths") or sections.get("核心优势")),
        "missing_evidence": _as_list(data.get("missing_evidence") or sections.get("缺失证据")),
        "star_rewrites": _as_list(data.get("star_rewrites") or sections.get("STAR改写")),
        "suggestions": _as_list(data.get("suggestions") or sections.get("改进建议")),
        "source": sections.get("来源") or detected_source,
        "confidence": _clean_text(data.get("confidence") or sections.get("置信度") or "需教师确认", limit=60),
    }


def present_interview(raw: Any, score: Any = None) -> dict[str, Any]:
    data, detected_source = _parse_payload(raw)
    sections = _labelled_sections(raw)
    if not isinstance(data, dict):
        data = {}
    feedback = data.get("feedback")
    return {
        "total_score": score if score is not None else data.get("total_score"),
        "professionalism": data.get("professionalism"),
        "logic": data.get("logic"),
        "clarity": data.get("clarity"),
        "authenticity": data.get("authenticity"),
        "job_fit": data.get("job_fit"),
        "career_quality": data.get("career_quality"),
        "evidence": _clean_text(data.get("evidence") or sections.get("回答证据") or "证据需结合回答确认"),
        "feedback": _clean_text(feedback or sections.get("反馈") or raw or "等待作答"),
        "next_question": _clean_text(data.get("next_question") or sections.get("下一步练习") or "结合岗位要求补充具体项目案例"),
        "source": sections.get("来源") or detected_source,
        "confidence": _clean_text(data.get("confidence") or sections.get("置信度") or "需教师确认", limit=60),
    }


def _section(name: str, value: Any) -> str:
    if isinstance(value, (list, tuple)):
        content = "\n".join(f"- {_clean_text(item)}" for item in value if item)
    else:
        content = _clean_text(value, default="")
    return f"【{name}】\n{content}" if content else ""


def format_assessment_storage(data: dict[str, Any], source: str = SOURCE_AI) -> str:
    parts = [
        _section("来源", source), _section("结论", data.get("summary")),
        _section("优势", _as_list(data.get("strengths"))), _section("风险", _as_list(data.get("risks"))),
        _section("岗位匹配", data.get("position_fit")), _section("阶段目标", _as_list(data.get("stage_goals"))),
        _section("推荐微模块", _as_list(data.get("recommended_modules"))),
        _section("推荐实训", _as_list(data.get("recommended_training"))), _section("置信度", data.get("confidence")),
    ]
    return "\n\n".join(item for item in parts if item)


def format_career_storage(data: dict[str, Any], source: str = SOURCE_AI) -> str:
    stages = []
    for stage in data.get("stages") or []:
        if isinstance(stage, dict):
            stages.append(" · ".join(filter(None, [_clean_text(stage.get("period"), default=""), _clean_text(stage.get("goal"), default=""), _clean_text(stage.get("deliverable"), default="")])))
    parts = [
        _section("来源", source), _section("能力差距", data.get("gap_analysis")),
        _section("计划摘要", data.get("plan_summary")), _section("成长阶段", stages),
        _section("数据依据", _as_list(data.get("evidence_sources"))), _section("置信度", data.get("confidence")),
    ]
    return "\n\n".join(item for item in parts if item)


def format_resume_storage(data: dict[str, Any], source: str = SOURCE_AI) -> str:
    parts = [
        _section("来源", source), _section("结论", data.get("summary")),
        _section("关键词覆盖", _as_list(data.get("keyword_coverage"))), _section("核心优势", _as_list(data.get("strengths"))),
        _section("缺失证据", _as_list(data.get("missing_evidence"))), _section("STAR改写", _as_list(data.get("star_rewrites"))),
        _section("改进建议", _as_list(data.get("suggestions"))), _section("置信度", data.get("confidence")),
    ]
    return "\n\n".join(item for item in parts if item)


def format_interview_storage(data: dict[str, Any], source: str = SOURCE_AI) -> str:
    parts = [
        _section("来源", source), _section("反馈", data.get("feedback")),
        _section("回答证据", data.get("evidence")), _section("下一步练习", data.get("next_question")),
        _section("置信度", data.get("confidence")),
    ]
    return "\n\n".join(item for item in parts if item)
