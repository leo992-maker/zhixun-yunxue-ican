"""Rubric validation, evidence-bounded AI evaluation and explicit fallback."""

import json
from decimal import Decimal, ROUND_HALF_UP

from app.prompts.templates import get_prompt
from app.services.ai_service import call_structured

DEFAULT_RUBRIC = [
    ("任务完成度", 20, "交付物是否覆盖任务要求"),
    ("功能正确性", 20, "关键功能、数据流程和结果是否正确"),
    ("代码规范", 12, "命名、结构、注释与可维护性"),
    ("项目结构", 10, "目录与模块职责是否清晰"),
    ("数据库设计", 12, "表结构、约束、索引与一致性"),
    ("异常与安全", 10, "异常处理、输入校验与安全边界"),
    ("测试完整性", 8, "自动化测试与关键路径覆盖"),
    ("文档质量", 8, "说明、部署与交付文档是否可复现"),
]


class InvalidRubric(ValueError):
    pass


def clamp(value, minimum=0, maximum=100):
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        parsed = minimum
    return max(minimum, min(maximum, parsed))


def validate_dimensions(dimensions):
    if not 1 <= len(dimensions) <= 13:
        raise InvalidRubric("量规维度数量必须在1至13个之间")
    total = Decimal("0")
    cleaned = []
    for index, item in enumerate(dimensions, 1):
        name = str(item.get("name") or "").strip()
        if not name:
            raise InvalidRubric(f"第{index}个维度缺少名称")
        weight = Decimal(str(item.get("weight") or 0))
        max_score = Decimal(str(item.get("max_score") or 100))
        if weight <= 0 or max_score <= 0:
            raise InvalidRubric(f"维度“{name}”的权重和满分必须大于0")
        total += weight
        cleaned.append({**item, "name": name, "weight": weight, "max_score": max_score})
    if total.quantize(Decimal("0.01")) != Decimal("100.00"):
        raise InvalidRubric(f"量规权重之和必须为100，当前为{total}")
    return cleaned


def default_dimensions():
    return [
        {
            "name": name,
            "weight": weight,
            "max_score": 100,
            "criteria": criteria,
            "excellent_standard": f"提供充分、可定位证据，{criteria}",
            "qualified_standard": f"提供基本证据，{criteria}",
            "common_issues": "证据缺失、实现不完整或说明与成果不一致",
            "ai_enabled": True,
            "teacher_review_required": name in {"功能正确性", "数据库设计", "异常与安全"},
        }
        for name, weight, criteria in DEFAULT_RUBRIC
    ]


def generate_rubric(task_data):
    system_prompt, task_prompt, version = get_prompt("rubric_generation")
    result = call_structured(
        [
            {"role": "system", "content": system_prompt},
            {"role": "system", "content": task_prompt},
            {"role": "user", "content": json.dumps(task_data, ensure_ascii=False)},
        ],
        use_case="rubric_generation",
    )
    if result.success and isinstance(result.data, dict):
        try:
            result.data["dimensions"] = validate_dimensions(result.data.get("dimensions") or [])
            return result
        except InvalidRubric as exc:
            result.success = False
            result.code = "RUBRIC_INVALID"
            result.error = str(exc)
    result.data = {
        "name": f"{task_data.get('task_name', '软件实训')}默认量规",
        "description": "DeepSeek 未配置或暂不可用，使用平台可解释默认量规；发布前需教师确认。",
        "dimensions": default_dimensions(),
        "source": "rule_based_fallback",
    }
    return result


def _fallback_evaluation(dimensions, evidence_bundle, error_code):
    evidence_chars = sum(len(item.get("content_excerpt") or "") for item in evidence_bundle)
    file_count = len(evidence_bundle)
    base = min(82, 42 + file_count * 5 + min(evidence_chars // 500, 20))
    rows = []
    for item in dimensions:
        max_score = float(item.get("max_score") or 100)
        score = round(base / 100 * max_score, 1)
        rows.append({
            "dimension_id": item.get("dimension_id"),
            "name": item["name"],
            "score": score,
            "max_score": max_score,
            "reason": "仅完成可解释的文件存在性与文本可读性预检，未进行语义评价。",
            "evidence": evidence_bundle[0]["file_name"] if evidence_bundle else "证据不足",
            "file_name": evidence_bundle[0]["file_name"] if evidence_bundle else "",
            "line_reference": "证据不足",
            "confidence": 0.25,
        })
    return {
        "total_score": base,
        "summary": "【事实】系统已完成文件安全与可读性预检。\n【推断】DeepSeek 未返回有效语义评价。\n【建议】请教师复核，配置模型后重新评价。",
        "strengths": ["成果已成功保存并通过基础文件安全检查"] if file_count else [],
        "critical_issues": [],
        "general_issues": ["当前结果不是AI语义评价，不应作为最终成绩"],
        "suggestions": ["由教师查看原始成果并复核", "配置 DeepSeek 后重新发起结构化评价"],
        "recommended_modules": [],
        "requires_teacher_review": True,
        "confidence": 0.25,
        "dimensions": rows,
        "source": "rule_based_fallback",
        "is_ai_generated": False,
        "fallback_reason": error_code,
    }


def _normalize(data, dimensions, evidence_bundle):
    known_files = {item["file_name"] for item in evidence_bundle}
    by_id = {str(item.get("dimension_id")): item for item in dimensions if item.get("dimension_id") is not None}
    by_name = {item["name"]: item for item in dimensions}
    normalized = []
    for raw in data.get("dimensions") or []:
        config = by_id.get(str(raw.get("dimension_id"))) or by_name.get(str(raw.get("name")))
        if not config:
            continue
        max_score = float(config.get("max_score") or 100)
        file_name = str(raw.get("file_name") or "")
        if file_name and file_name not in known_files:
            file_name = ""
            raw["evidence"] = "证据不足"
            raw["line_reference"] = "证据不足"
        normalized.append({
            "dimension_id": config.get("dimension_id"),
            "name": config["name"],
            "score": round(clamp(raw.get("score"), 0, max_score), 1),
            "max_score": max_score,
            "reason": str(raw.get("reason") or "证据不足")[:2000],
            "evidence": str(raw.get("evidence") or "证据不足")[:3000],
            "file_name": file_name,
            "line_reference": str(raw.get("line_reference") or "证据不足")[:200],
            "confidence": round(clamp(raw.get("confidence"), 0, 1), 2),
        })
    for config in dimensions:
        if not any(row["name"] == config["name"] for row in normalized):
            normalized.append({
                "dimension_id": config.get("dimension_id"),
                "name": config["name"],
                "score": 0,
                "max_score": float(config.get("max_score") or 100),
                "reason": "模型未返回该维度，需教师复核。",
                "evidence": "证据不足",
                "file_name": "",
                "line_reference": "证据不足",
                "confidence": 0,
            })
    weighted = Decimal("0")
    for row in normalized:
        config = by_id.get(str(row.get("dimension_id"))) or by_name.get(row["name"])
        if not config:
            continue
        ratio = Decimal(str(row["score"])) / Decimal(str(row["max_score"] or 100))
        weighted += ratio * Decimal(str(config.get("weight") or 0))
    total = weighted.quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)
    return {
        "total_score": float(total),
        "summary": str(data.get("summary") or "")[:5000],
        "strengths": list(data.get("strengths") or [])[:12],
        "critical_issues": list(data.get("critical_issues") or [])[:12],
        "general_issues": list(data.get("general_issues") or [])[:20],
        "suggestions": list(data.get("suggestions") or [])[:20],
        "recommended_modules": list(data.get("recommended_modules") or [])[:12],
        "requires_teacher_review": bool(data.get("requires_teacher_review", True)),
        "confidence": round(clamp(data.get("confidence"), 0, 1), 2),
        "dimensions": normalized,
        "source": "deepseek",
        "is_ai_generated": True,
    }


def evaluate_submission(task_data, dimensions, evidence_bundle, version_no):
    dimensions = validate_dimensions(dimensions)
    system_prompt, task_prompt, prompt_version = get_prompt("training_evaluation")
    payload = {
        "task": task_data,
        "rubric_version": task_data.get("rubric_version"),
        "submission_version": version_no,
        "rubric_dimensions": [
            {**item, "weight": float(item["weight"]), "max_score": float(item["max_score"])}
            for item in dimensions
        ],
        "evidence_bundle": evidence_bundle,
    }
    result = call_structured(
        [
            {"role": "system", "content": system_prompt},
            {"role": "system", "content": task_prompt},
            {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
        ],
        use_case="training_evaluation",
        max_tokens=3500,
    )
    if result.success and isinstance(result.data, dict):
        result.data = _normalize(result.data, dimensions, evidence_bundle)
        result.data["model"] = result.model
        result.data["prompt_version"] = prompt_version
        return result
    result.data = _fallback_evaluation(dimensions, evidence_bundle, result.code)
    result.data["model"] = result.model or "未调用"
    result.data["prompt_version"] = prompt_version
    return result


def compare_versions(previous, current):
    before = {row["name"]: row for row in previous.get("dimensions") or []}
    after = {row["name"]: row for row in current.get("dimensions") or []}
    changes = []
    for name in sorted(set(before) | set(after)):
        old_score = float(before.get(name, {}).get("score") or 0)
        new_score = float(after.get(name, {}).get("score") or 0)
        delta = round(new_score - old_score, 1)
        changes.append({
            "name": name,
            "previous_score": old_score,
            "current_score": new_score,
            "delta": delta,
            "status": "已改善" if delta > 0 else "需继续改进" if delta < 0 else "保持不变",
        })
    return {
        "score_delta": round(float(current.get("total_score") or 0) - float(previous.get("total_score") or 0), 1),
        "dimensions": changes,
    }
