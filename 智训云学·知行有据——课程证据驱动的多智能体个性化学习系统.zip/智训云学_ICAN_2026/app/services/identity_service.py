"""Identity display helpers shared by views, templates and demo-data scripts."""

TEACHER_ROLE = "教师"
TEACHER_SUFFIXES = ("副教授", "教授", "讲师", "助教", "老师")

# Synthetic competition-demo identities; none represents a real person.
DEMO_TEACHER_NAMES = {
    "t001": "张小华",
    "t002": "李文静",
    "t003": "王建国",
    "t004": "陈思远",
    "t005": "刘晨",
    "t006": "赵欣",
    "t007": "周宁",
    "t008": "吴昊",
    "t009": "郑洁",
    "t010": "孙明",
}


def normalize_teacher_real_name(value):
    """Return a natural teacher name without a trailing professional title."""
    name = (value or "").strip()
    changed = True
    while name and changed:
        changed = False
        for suffix in TEACHER_SUFFIXES:
            if name.endswith(suffix):
                name = name[: -len(suffix)].strip()
                changed = True
                break
    return name


def teacher_display_name(value):
    """Display a teacher once with the friendly ``老师`` suffix."""
    natural_name = normalize_teacher_real_name(value)
    return f"{natural_name}老师" if natural_name else "教师"


def account_display_name(real_name, role_name):
    """Add a title only for teachers; other roles keep their stored real name."""
    if role_name == TEACHER_ROLE:
        return teacher_display_name(real_name)
    return (real_name or "").strip()
