"""Authentication and account-security helpers."""

import hmac
import hashlib
import re
from datetime import timedelta

from django.contrib.auth.hashers import check_password, identify_hasher, make_password
from django.core.cache import cache
from django.utils import timezone

MAX_LOGIN_FAILURES = 5
LOGIN_WINDOW_MINUTES = 15
MIN_PASSWORD_LENGTH = 8


def is_password_hash(value):
    try:
        identify_hasher(value or "")
        return True
    except ValueError:
        return False


def hash_password(raw_password):
    return make_password(raw_password)


def verify_and_upgrade_password(account, raw_password):
    """Verify hashes and transparently upgrade a matching legacy plaintext row."""
    stored = account.password or ""
    if is_password_hash(stored):
        return check_password(raw_password, stored)
    valid = hmac.compare_digest(stored, raw_password or "")
    if valid:
        account.password = make_password(raw_password)
        account.save(update_fields=["password"])
    return valid


def password_errors(password):
    errors = []
    if len(password or "") < MIN_PASSWORD_LENGTH:
        errors.append(f"密码至少需要 {MIN_PASSWORD_LENGTH} 位")
    if not re.search(r"[A-Za-z]", password or ""):
        errors.append("密码需包含字母")
    if not re.search(r"\d", password or ""):
        errors.append("密码需包含数字")
    if (password or "").lower() in {"12345678", "password", "admin123", "qwerty123"}:
        errors.append("请勿使用常见弱密码")
    return errors


def _failure_times(request):
    threshold = timezone.now() - timedelta(minutes=LOGIN_WINDOW_MINUTES)
    parsed = []
    for value in request.session.get("login_failures", []):
        try:
            item = timezone.datetime.fromisoformat(value)
            if timezone.is_naive(item):
                item = timezone.make_aware(item)
            if item >= threshold:
                parsed.append(item)
        except (TypeError, ValueError):
            continue
    return parsed


def _failure_cache_key(request, identifier=""):
    address = request.META.get("REMOTE_ADDR") or "unknown"
    digest = hashlib.sha256(f"{address}|{identifier.lower()}".encode("utf-8")).hexdigest()[:32]
    return f"login-fail:{digest}"


def login_is_limited(request, identifier=""):
    cached = int(cache.get(_failure_cache_key(request, identifier), 0) or 0)
    return max(len(_failure_times(request)), cached) >= MAX_LOGIN_FAILURES


def register_login_failure(request, identifier=""):
    failures = _failure_times(request)
    failures.append(timezone.now())
    request.session["login_failures"] = [item.isoformat() for item in failures]
    request.session.modified = True
    key = _failure_cache_key(request, identifier)
    if cache.add(key, 1, timeout=LOGIN_WINDOW_MINUTES * 60):
        cached = 1
    else:
        try:
            cached = cache.incr(key)
        except ValueError:
            cached = 1
            cache.set(key, cached, timeout=LOGIN_WINDOW_MINUTES * 60)
    return max(MAX_LOGIN_FAILURES - max(len(failures), cached), 0)


def clear_login_failures(request, identifier=""):
    request.session.pop("login_failures", None)
    cache.delete(_failure_cache_key(request, identifier))
