(function () {
    'use strict';

    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        return parts.length === 2 ? parts.pop().split(';').shift() : '';
    }

    function appendInline(parent, text) {
        const pattern = /(\*\*[^*]+\*\*|`[^`]+`)/g;
        let cursor = 0;
        let match;
        while ((match = pattern.exec(text)) !== null) {
            if (match.index > cursor) parent.appendChild(document.createTextNode(text.slice(cursor, match.index)));
            const token = match[0];
            const element = document.createElement(token.startsWith('**') ? 'strong' : 'code');
            element.textContent = token.startsWith('**') ? token.slice(2, -2) : token.slice(1, -1);
            parent.appendChild(element);
            cursor = match.index + token.length;
        }
        if (cursor < text.length) parent.appendChild(document.createTextNode(text.slice(cursor)));
    }

    function renderMarkdown(value) {
        const fragment = document.createDocumentFragment();
        const lines = String(value || '').replace(/\r\n?/g, '\n').split('\n');
        let list = null;
        let codeBlock = null;
        let codeLines = [];

        function flushList() { list = null; }
        function flushCode() {
            if (!codeBlock) return;
            const pre = document.createElement('pre');
            const code = document.createElement('code');
            code.textContent = codeLines.join('\n');
            pre.appendChild(code);
            fragment.appendChild(pre);
            codeBlock = null;
            codeLines = [];
        }

        lines.forEach(function (rawLine) {
            const line = rawLine.trimEnd();
            if (/^```/.test(line.trim())) {
                flushList();
                if (codeBlock) flushCode(); else codeBlock = true;
                return;
            }
            if (codeBlock) { codeLines.push(rawLine); return; }
            if (!line.trim()) { flushList(); return; }

            const heading = /^(#{1,3})\s+(.+)$/.exec(line);
            if (heading) {
                flushList();
                const level = Math.min(heading[1].length + 1, 4);
                const element = document.createElement('h' + level);
                appendInline(element, heading[2]);
                fragment.appendChild(element);
                return;
            }

            const unordered = /^[-*]\s+(.+)$/.exec(line);
            const ordered = /^\d+[.)]\s+(.+)$/.exec(line);
            if (unordered || ordered) {
                const kind = ordered ? 'ol' : 'ul';
                if (!list || list.tagName.toLowerCase() !== kind) {
                    list = document.createElement(kind);
                    fragment.appendChild(list);
                }
                const item = document.createElement('li');
                appendInline(item, (unordered || ordered)[1]);
                list.appendChild(item);
                return;
            }

            flushList();
            const paragraph = document.createElement('p');
            appendInline(paragraph, line.replace(/^>\s?/, ''));
            fragment.appendChild(paragraph);
        });
        flushCode();
        if (!fragment.childNodes.length) {
            const paragraph = document.createElement('p');
            paragraph.textContent = '暂时没有可展示的内容。';
            fragment.appendChild(paragraph);
        }
        return fragment;
    }

    document.addEventListener('DOMContentLoaded', function () {
        const root = document.getElementById('ai-assistant-root');
        if (!root) return;
        const panel = document.getElementById('ai-assistant-panel');
        const openButtons = Array.from(document.querySelectorAll('[data-ai-open]'));
        const closeButtons = Array.from(root.querySelectorAll('[data-ai-close]'));
        const backdrop = root.querySelector('.ai-backdrop');
        const clearBtn = document.getElementById('ai-clear-btn');
        const copyBtn = document.getElementById('ai-copy-btn');
        const regenerateBtn = document.getElementById('ai-regenerate-btn');
        const messagesEl = document.getElementById('ai-messages');
        const loadingEl = document.getElementById('ai-loading');
        const form = document.getElementById('ai-input-form');
        const input = document.getElementById('ai-input');
        const quickRow = document.getElementById('ai-quick-row');
        const sendBtn = document.getElementById('ai-send-btn');
        const welcome = messagesEl.querySelector('[data-welcome-message]').cloneNode(true);
        const pageContext = root.dataset.page || window.location.pathname;
        let history = [];
        let busy = false;
        let lastPrompt = '';
        let lastAnswer = '';
        let previousFocus = null;

        function setOpen(open) {
            panel.hidden = !open;
            backdrop.hidden = !open || window.innerWidth >= 1440;
            document.body.classList.toggle('ai-open', open);
            document.body.classList.toggle('ai-docked', open && window.innerWidth >= 1440);
            openButtons.forEach(function (button) { button.setAttribute('aria-expanded', String(open)); });
            if (open) {
                previousFocus = document.activeElement;
                window.setTimeout(function () { input.focus(); }, 0);
            } else if (previousFocus && previousFocus.focus) {
                previousFocus.focus();
            }
        }

        function setBubbleText(bubble, text) {
            bubble.replaceChildren(renderMarkdown(text));
        }

        function appendMessage(role, text) {
            const wrap = document.createElement('div');
            wrap.className = 'ai-msg ai-msg-' + role;
            const bubble = document.createElement('div');
            bubble.className = 'ai-bubble';
            setBubbleText(bubble, text);
            wrap.appendChild(bubble);
            if (role === 'assistant') {
                const source = document.createElement('small');
                source.className = 'ai-source-note';
                source.textContent = '数据依据：当前页面上下文与平台授权数据 · 生成来源：AI或明确规则降级';
                wrap.appendChild(source);
            }
            messagesEl.appendChild(wrap);
            messagesEl.scrollTop = messagesEl.scrollHeight;
            return bubble;
        }

        function setBusy(value) {
            busy = value;
            loadingEl.hidden = !value;
            sendBtn.disabled = value;
            regenerateBtn.disabled = value || !lastPrompt;
        }

        async function readJson(response) {
            try { return await response.json(); } catch (error) { return { success: false, error: '服务返回格式异常，请稍后再试。' }; }
        }

        async function fallbackRequest(text, bubble) {
            const response = await fetch(root.dataset.chatUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRFToken': getCookie('csrftoken') },
                body: JSON.stringify({ message: text, history: history.slice(-8), page_context: pageContext })
            });
            const data = await readJson(response);
            const answer = data.success ? data.reply : (data.error || 'AI助手暂时无法回答，请稍后再试。');
            setBubbleText(bubble, answer);
            return answer;
        }

        async function sendMessage(rawText, addUserMessage) {
            const text = String(rawText || '').trim().slice(0, 2000);
            if (!text || busy) return;
            if (addUserMessage !== false) appendMessage('user', text);
            lastPrompt = text;
            history.push({ role: 'user', content: text });
            input.value = '';
            input.style.height = 'auto';
            setBusy(true);
            const bubble = appendMessage('assistant', '正在读取当前页面上下文并生成回答…');
            let answer = '';
            try {
                const response = await fetch(root.dataset.streamUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-CSRFToken': getCookie('csrftoken') },
                    body: JSON.stringify({ message: text, page_context: pageContext })
                });
                if (!response.ok || !response.body || !(response.headers.get('content-type') || '').includes('text/event-stream')) {
                    answer = await fallbackRequest(text, bubble);
                } else {
                    const reader = response.body.getReader();
                    const decoder = new TextDecoder('utf-8');
                    let buffer = '';
                    while (true) {
                        const result = await reader.read();
                        if (result.done) break;
                        buffer += decoder.decode(result.value, { stream: true });
                        const events = buffer.split('\n\n');
                        buffer = events.pop();
                        events.forEach(function (event) {
                            const line = event.split('\n').find(function (item) { return item.startsWith('data:'); });
                            if (!line) return;
                            try {
                                const data = JSON.parse(line.slice(5).trim());
                                if (data.text) answer += data.text;
                                if (data.error) answer += '\n' + data.error;
                            } catch (error) { /* Ignore malformed transport chunks. */ }
                        });
                        setBubbleText(bubble, answer || '正在生成…');
                        messagesEl.scrollTop = messagesEl.scrollHeight;
                    }
                }
            } catch (error) {
                try { answer = await fallbackRequest(text, bubble); }
                catch (fallbackError) { answer = '网络异常，AI助手暂时无法连接，请稍后再试。'; setBubbleText(bubble, answer); }
            }
            lastAnswer = answer;
            history.push({ role: 'assistant', content: answer });
            setBusy(false);
        }

        async function fetchAnalysis() {
            if (busy) return;
            appendMessage('user', '生成我的学习能力分析');
            setBusy(true);
            try {
                const response = await fetch(root.dataset.analysisUrl);
                const data = await readJson(response);
                let text = data.success ? data.analysis : (data.error || '暂时无法生成能力分析。');
                if (data.note) text += '\n\n' + data.note;
                appendMessage('assistant', text);
                lastAnswer = text;
            } catch (error) {
                appendMessage('assistant', '网络异常，无法生成能力分析。');
            }
            setBusy(false);
        }

        openButtons.forEach(function (button) { button.addEventListener('click', function () { setOpen(true); }); });
        closeButtons.forEach(function (button) { button.addEventListener('click', function () { setOpen(false); }); });
        clearBtn.addEventListener('click', function () { history = []; lastPrompt = ''; lastAnswer = ''; messagesEl.replaceChildren(welcome.cloneNode(true)); regenerateBtn.disabled = true; });
        copyBtn.addEventListener('click', async function () { if (lastAnswer && navigator.clipboard) await navigator.clipboard.writeText(lastAnswer); });
        regenerateBtn.addEventListener('click', function () { if (lastPrompt) sendMessage(lastPrompt, false); });
        quickRow.addEventListener('click', function (event) {
            const button = event.target.closest('.ai-quick-btn');
            if (!button) return;
            if (button.dataset.special === 'analysis') fetchAnalysis(); else sendMessage(button.dataset.q, true);
        });
        form.addEventListener('submit', function (event) { event.preventDefault(); sendMessage(input.value, true); });
        input.addEventListener('keydown', function (event) { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); sendMessage(input.value, true); } });
        input.addEventListener('input', function () { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 120) + 'px'; });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && !panel.hidden) { setOpen(false); return; }
            if (event.key !== 'Tab' || panel.hidden) return;
            const focusable = Array.from(panel.querySelectorAll('button:not([disabled]), textarea, a[href], input, select'));
            if (!focusable.length) return;
            const first = focusable[0];
            const last = focusable[focusable.length - 1];
            if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
            if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
        });
        window.addEventListener('resize', function () {
            if (!panel.hidden) {
                backdrop.hidden = window.innerWidth >= 1440;
                document.body.classList.toggle('ai-docked', window.innerWidth >= 1440);
            }
        });
    });
}());
