(function () {
    'use strict';
    document.querySelectorAll('[data-password-toggle]').forEach(function (button) {
        const input = document.getElementById(button.dataset.passwordToggle);
        if (!input) return;
        button.addEventListener('click', function () {
            const show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            button.textContent = show ? '隐藏密码' : '显示密码';
            button.setAttribute('aria-pressed', String(show));
        });
    });
    document.querySelectorAll('[data-demo-username]').forEach(function (button) {
        button.addEventListener('click', function () {
            document.getElementById('username').value = button.dataset.demoUsername;
            document.getElementById('password').value = button.dataset.demoPassword;
            document.getElementById('password').focus();
        });
    });
    const form = document.querySelector('[data-register-form]');
    if (form) {
        const roleInput = form.querySelector('[data-role-input]');
        const roleButtons = Array.from(form.querySelectorAll('[data-role-button]'));
        const fieldGroups = Array.from(form.querySelectorAll('[data-role-fields]'));
        function setRole(role) {
            roleInput.value = role;
            roleButtons.forEach(function (button) {
                const active = button.dataset.roleButton === role;
                button.className = active ? 'btn btn-primary' : 'btn btn-secondary';
                button.setAttribute('aria-pressed', String(active));
            });
            fieldGroups.forEach(function (group) {
                const active = group.dataset.roleFields === role;
                group.hidden = !active;
                group.querySelectorAll('input, select').forEach(function (field) {
                    const alwaysOptional = ['title'].includes(field.name);
                    field.required = active && !alwaysOptional;
                    field.disabled = !active;
                });
            });
        }
        roleButtons.forEach(function (button) { button.addEventListener('click', function () { setRole(button.dataset.roleButton); }); });
        setRole(roleInput.value);
    }
    document.querySelectorAll('form[data-submit-lock]').forEach(function (item) {
        item.addEventListener('submit', function () {
            const submit = item.querySelector('[type="submit"]');
            if (submit) { submit.disabled = true; submit.textContent = submit.dataset.loadingText || '正在提交…'; }
        });
    });
}());
