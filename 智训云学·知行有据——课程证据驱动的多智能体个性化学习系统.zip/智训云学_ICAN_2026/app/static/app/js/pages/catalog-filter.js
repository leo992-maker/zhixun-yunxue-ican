(function () {
    'use strict';
    const controls = document.querySelector('[data-catalog-controls]');
    const list = document.querySelector('[data-catalog-list]');
    if (!controls || !list) return;
    const search = controls.querySelector('[data-catalog-search]');
    const status = controls.querySelector('[data-catalog-status]');
    const difficulty = controls.querySelector('[data-catalog-difficulty]');
    const reset = controls.querySelector('[data-catalog-reset]');
    const empty = document.querySelector('[data-catalog-empty]');
    const items = Array.from(list.querySelectorAll('[data-catalog-item]'));
    function apply() {
        const query = search.value.trim().toLowerCase();
        let visible = 0;
        items.forEach(function (item) {
            const match = (!query || item.dataset.search.toLowerCase().includes(query)) && (!status.value || item.dataset.status === status.value) && (!difficulty.value || item.dataset.difficulty === difficulty.value);
            item.hidden = !match;
            if (match) visible += 1;
        });
        if (empty) empty.hidden = visible > 0;
    }
    [search, status, difficulty].forEach(function (control) { control.addEventListener(control === search ? 'input' : 'change', apply); });
    reset.addEventListener('click', function () { search.value = ''; status.value = ''; difficulty.value = ''; apply(); search.focus(); });
}());
