(function () {
    'use strict';
    const svg = document.getElementById('ability-radar');
    const labelsNode = document.getElementById('radar-labels');
    const scoresNode = document.getElementById('radar-scores');
    if (!svg || !labelsNode || !scoresNode) return;
    let labels = [];
    let scores = [];
    try {
        labels = JSON.parse(labelsNode.textContent || '[]');
        scores = JSON.parse(scoresNode.textContent || '[]');
    } catch (error) { return; }
    if (labels.length < 3 || labels.length !== scores.length) return;

    const ns = 'http://www.w3.org/2000/svg';
    const cx = 180;
    const cy = 168;
    const radius = 112;
    function point(index, scale) {
        const angle = -Math.PI / 2 + (Math.PI * 2 * index / labels.length);
        return [cx + Math.cos(angle) * radius * scale, cy + Math.sin(angle) * radius * scale];
    }
    function element(name, attrs, className) {
        const node = document.createElementNS(ns, name);
        Object.keys(attrs || {}).forEach(function (key) { node.setAttribute(key, attrs[key]); });
        if (className) node.setAttribute('class', className);
        svg.appendChild(node);
        return node;
    }
    [0.2, 0.4, 0.6, 0.8, 1].forEach(function (scale) {
        element('polygon', { points: labels.map(function (_, index) { return point(index, scale).join(','); }).join(' ') }, 'radar-grid');
    });
    labels.forEach(function (label, index) {
        const outer = point(index, 1);
        element('line', { x1: cx, y1: cy, x2: outer[0], y2: outer[1] }, 'radar-axis');
        const textPoint = point(index, 1.25);
        const text = element('text', { x: textPoint[0], y: textPoint[1], 'text-anchor': textPoint[0] < cx - 8 ? 'end' : textPoint[0] > cx + 8 ? 'start' : 'middle' });
        text.textContent = String(label).slice(0, 10);
    });
    const shapePoints = scores.map(function (score, index) { return point(index, Math.max(0, Math.min(100, Number(score) || 0)) / 100); });
    element('polygon', { points: shapePoints.map(function (item) { return item.join(','); }).join(' ') }, 'radar-shape');
    shapePoints.forEach(function (item) { element('circle', { cx: item[0], cy: item[1], r: 4 }, 'radar-point'); });
}());
