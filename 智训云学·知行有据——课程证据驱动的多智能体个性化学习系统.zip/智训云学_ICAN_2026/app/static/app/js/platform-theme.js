(function () {
    'use strict';

    const body = document.body;
    const navToggle = document.querySelector('[data-nav-toggle]');
    const navClose = document.querySelector('[data-nav-close]');
    const appNav = document.getElementById('appNav');
    const userTrigger = document.querySelector('[data-user-menu-trigger]');
    const userMenu = document.querySelector('[data-user-menu]');

    function setNav(open) {
        body.classList.toggle('nav-open', open);
        if (navToggle) {
            navToggle.setAttribute('aria-expanded', String(open));
            navToggle.setAttribute('aria-label', open ? '关闭主导航' : '打开主导航');
        }
        if (open && appNav) {
            const firstLink = appNav.querySelector('a');
            if (firstLink) firstLink.focus();
        }
    }

    function setUserMenu(open) {
        if (!userTrigger || !userMenu) return;
        userTrigger.setAttribute('aria-expanded', String(open));
        userMenu.hidden = !open;
        if (open) {
            const link = userMenu.querySelector('a, button');
            if (link) link.focus();
        }
    }

    if (navToggle) navToggle.addEventListener('click', function () { setNav(!body.classList.contains('nav-open')); });
    if (navClose) navClose.addEventListener('click', function () { setNav(false); });
    if (appNav) appNav.addEventListener('click', function (event) { if (event.target.closest('a') && window.innerWidth <= 900) setNav(false); });
    if (userTrigger) userTrigger.addEventListener('click', function () { setUserMenu(userMenu.hidden); });

    document.addEventListener('click', function (event) {
        if (userMenu && !userMenu.hidden && !event.target.closest('.user-menu')) setUserMenu(false);
    });

    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape') return;
        if (body.classList.contains('nav-open')) {
            setNav(false);
            if (navToggle) navToggle.focus();
        }
        if (userMenu && !userMenu.hidden) {
            setUserMenu(false);
            if (userTrigger) userTrigger.focus();
        }
    });

    window.addEventListener('resize', function () {
        if (window.innerWidth > 900) setNav(false);
    });

    document.querySelectorAll('[data-tabs]').forEach(function (tabs) {
        const buttons = Array.from(tabs.querySelectorAll('[role="tab"]'));
        const panels = Array.from(tabs.querySelectorAll('[role="tabpanel"]'));
        function activate(button, focus) {
            const targetId = button.getAttribute('aria-controls');
            buttons.forEach(function (item) {
                const selected = item === button;
                item.setAttribute('aria-selected', String(selected));
                item.tabIndex = selected ? 0 : -1;
            });
            panels.forEach(function (panel) { panel.hidden = panel.id !== targetId; });
            if (focus) button.focus();
        }
        buttons.forEach(function (button, index) {
            button.addEventListener('click', function () { activate(button, false); });
            button.addEventListener('keydown', function (event) {
                if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
                event.preventDefault();
                let next = index;
                if (event.key === 'ArrowRight') next = (index + 1) % buttons.length;
                if (event.key === 'ArrowLeft') next = (index - 1 + buttons.length) % buttons.length;
                if (event.key === 'Home') next = 0;
                if (event.key === 'End') next = buttons.length - 1;
                activate(buttons[next], true);
            });
        });
    });

    document.querySelectorAll('form[data-submit-lock]').forEach(function (form) {
        form.addEventListener('submit', function () {
            const submit = form.querySelector('[type="submit"]');
            if (!submit || submit.disabled) return;
            submit.disabled = true;
            submit.dataset.originalText = submit.textContent;
            submit.textContent = submit.dataset.loadingText || '正在提交…';
        });
    });

    document.querySelectorAll('form[data-confirm]').forEach(function (form) {
        form.addEventListener('submit', function (event) {
            if (!window.confirm(form.dataset.confirm)) event.preventDefault();
        });
    });

    document.querySelectorAll('[data-char-counter]').forEach(function (field) {
        const counter = document.getElementById(field.dataset.charCounter);
        if (!counter) return;
        function update() { counter.textContent = field.value.length + '/' + (field.maxLength > 0 ? field.maxLength : '不限'); }
        field.addEventListener('input', update);
        update();
    });

    document.querySelectorAll('[data-copy-target]').forEach(function (button) {
        button.addEventListener('click', async function () {
            const target = document.querySelector(button.dataset.copyTarget);
            if (!target || !navigator.clipboard) return;
            await navigator.clipboard.writeText(target.textContent.trim());
            const oldText = button.textContent;
            button.textContent = '已复制';
            window.setTimeout(function () { button.textContent = oldText; }, 1600);
        });
    });
}());
