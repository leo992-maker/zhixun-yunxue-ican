from django.urls import path
from django.views.generic import RedirectView
from . import views

urlpatterns = [
    path('showcase/', views.showcase_view, name='showcase'),
    path('favicon.ico', RedirectView.as_view(url='/static/app/favicon.svg', permanent=True)),
    # 运行状态（供负载均衡、容器编排和压测预检使用）
    path('health/live/', views.health_live, name='health_live'),
    path('health/ready/', views.health_ready, name='health_ready'),

    # 登录
    path('login/', views.login_view, name='login'),
    path('forgot-password/', views.forgot_password_view, name='forgot_password'),
    path('logout/', views.logout_view, name='logout'),
    
    # 学生端
    path('student/dashboard/', views.student_dashboard, name='student_dashboard'),
    path('student/modules/', views.student_modules, name='student_modules'),
    path('student/modules/complete/<int:module_id>/', views.student_complete_learning, name='student_complete_learning'),
    path('student/training/', views.student_training, name='student_training'),
    path('student/training/submit/<int:task_id>/', views.student_submit_training, name='student_submit_training'),
    path('student/training/step/<int:task_id>/', views.student_submit_training, name='student_training_step'),
    path('student/evaluations/', views.student_evaluation_reports, name='student_evaluation_reports'),
    path('student/evaluations/<int:submission_id>/', views.student_evaluation_detail, name='student_evaluation_detail'),
    path('student/recommendations/', views.student_recommendations, name='student_recommendations'),
    path('student/assessment/submit/', views.submit_assessment, name='submit_assessment'),
    path('student/resume/submit/', views.submit_resume, name='submit_resume'),
    path('student/recommendations/report/', views.generate_career_report, name='generate_career_report'),
    path('student/interview/start/', views.start_interview, name='start_interview'),
    path('student/interview/submit/', views.submit_interview, name='submit_interview'),
    path('student/question/submit/', views.submit_question, name='submit_question'),
    
    # 教师端
    path('teacher/dashboard/', views.teacher_dashboard, name='teacher_dashboard'),
    path('teacher/modules/create/', views.teacher_create_module, name='teacher_create_module'),
    path('teacher/training/create/', views.teacher_create_training, name='teacher_create_training'),
    path('teacher/stats/', views.teacher_stats, name='teacher_stats'),
    path('teacher/rubrics/', views.teacher_rubrics, name='teacher_rubrics'),
    path('teacher/reviews/', views.teacher_review_queue, name='teacher_review_queue'),
    path('teacher/reviews/<int:evaluation_id>/', views.teacher_review_detail, name='teacher_review_detail'),
    path('teacher/question/answer/<int:qa_id>/', views.teacher_answer_question, name='teacher_answer_question'),
    path('teacher/warning/handle/<int:warning_id>/', views.handle_warning, name='handle_warning'),
    
    # 管理员端
    path('admin/positions/', views.admin_positions, name='admin_positions'),
    path('reports/', views.report_center, name='report_center'),
    
    # 注册
    path('register/', views.register_view, name='register'),

    # AI 学习助手 / 学生能力分析（大模型接口）
    path('api/ai/chat/', views.ai_chat_api, name='ai_chat_api'),
    path('api/ai/chat/stream/', views.ai_chat_stream_api, name='ai_chat_stream_api'),
    path('api/ai/student-analysis/', views.ai_student_analysis_api, name='ai_student_analysis_api'),
]


