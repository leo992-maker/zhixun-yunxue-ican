"""Reusable parsing and presentation utilities."""
