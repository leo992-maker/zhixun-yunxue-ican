"""Safe static inspection for student deliverables.

Uploaded code is never imported or executed. Archives are inspected in memory,
with traversal, nested archive, file-count and compression-ratio protections.
"""

import hashlib
import mimetypes
import re
import zipfile
from pathlib import Path, PurePosixPath

from django.conf import settings
from django.utils.text import get_valid_filename

ALLOWED_EXTENSIONS = {
    ".zip", ".py", ".java", ".js", ".ts", ".html", ".css", ".sql",
    ".json", ".md", ".txt", ".docx", ".pdf", ".xlsx", ".pptx",
    ".png", ".jpg", ".jpeg",
}
TEXT_EXTENSIONS = {".py", ".java", ".js", ".ts", ".html", ".css", ".sql", ".json", ".md", ".txt"}
OOXML_EXTENSIONS = {".docx", ".xlsx", ".pptx"}
MAX_UPLOAD_BYTES = int(getattr(settings, "MAX_UPLOAD_BYTES", 20 * 1024 * 1024))
MAX_FILES_PER_SUBMISSION = int(getattr(settings, "MAX_FILES_PER_SUBMISSION", 20))
MAX_ARCHIVE_FILES = int(getattr(settings, "MAX_ARCHIVE_FILES", 200))
MAX_ARCHIVE_UNCOMPRESSED = int(getattr(settings, "MAX_ARCHIVE_UNCOMPRESSED", 80 * 1024 * 1024))
MAX_COMPRESSION_RATIO = int(getattr(settings, "MAX_COMPRESSION_RATIO", 100))
MAX_EVIDENCE_CHARS = int(getattr(settings, "MAX_EVIDENCE_CHARS", 18000))


class UnsafeUpload(ValueError):
    """Raised when an upload violates a safety boundary."""


def _safe_relative_name(name):
    normalized = str(name or "").replace("\\", "/")
    pure = PurePosixPath(normalized)
    if pure.is_absolute() or ".." in pure.parts:
        raise UnsafeUpload("文件路径包含非法的目录跳转")
    safe = get_valid_filename(pure.name)
    if not safe or safe in {".", ".."}:
        raise UnsafeUpload("文件名无效")
    return safe


def validate_upload(uploaded):
    safe_name = _safe_relative_name(uploaded.name)
    suffix = Path(safe_name).suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise UnsafeUpload(f"不支持的文件类型：{suffix or '无扩展名'}")
    if uploaded.size <= 0:
        raise UnsafeUpload("空文件不能提交")
    if uploaded.size > MAX_UPLOAD_BYTES:
        raise UnsafeUpload(f"单个文件不能超过 {MAX_UPLOAD_BYTES // 1024 // 1024}MB")
    return safe_name, suffix


def _assert_archive_safe(path):
    try:
        archive = zipfile.ZipFile(path)
    except zipfile.BadZipFile as exc:
        raise UnsafeUpload("ZIP 文件已损坏或格式不正确") from exc
    with archive:
        members = archive.infolist()
        if len(members) > MAX_ARCHIVE_FILES:
            raise UnsafeUpload(f"ZIP 内文件数量不能超过 {MAX_ARCHIVE_FILES}")
        total_size = 0
        for member in members:
            pure = PurePosixPath(member.filename.replace("\\", "/"))
            if pure.is_absolute() or ".." in pure.parts:
                raise UnsafeUpload("ZIP 中存在路径穿越文件")
            if Path(pure.name).suffix.lower() in {".zip", ".rar", ".7z", ".tar", ".gz"}:
                raise UnsafeUpload("ZIP 中不允许嵌套压缩包")
            total_size += member.file_size
            compressed = max(member.compress_size, 1)
            if member.file_size / compressed > MAX_COMPRESSION_RATIO:
                raise UnsafeUpload("ZIP 压缩比异常，可能存在压缩炸弹")
        if total_size > MAX_ARCHIVE_UNCOMPRESSED:
            raise UnsafeUpload("ZIP 解压后总体积超过安全限制")


def validate_archive_path(path):
    """Public archive validation entrypoint for legacy upload flows."""
    _assert_archive_safe(Path(path))


def save_submission_uploads(files, student_id, task_id, version_no):
    uploads = list(files)
    if len(uploads) > MAX_FILES_PER_SUBMISSION:
        raise UnsafeUpload(f"一次最多上传 {MAX_FILES_PER_SUBMISSION} 个文件")
    root = Path(settings.MEDIA_ROOT).resolve()
    relative_dir = Path("training_submissions") / f"student_{student_id}" / f"task_{task_id}" / f"v{version_no}"
    target_dir = (root / relative_dir).resolve()
    if root != target_dir and root not in target_dir.parents:
        raise UnsafeUpload("上传目录校验失败")
    target_dir.mkdir(parents=True, exist_ok=True)
    saved = []
    for index, uploaded in enumerate(uploads, 1):
        safe_name, suffix = validate_upload(uploaded)
        digest = hashlib.sha256()
        stored_name = f"{index:02d}_{safe_name}"
        target = (target_dir / stored_name).resolve()
        if root not in target.parents:
            raise UnsafeUpload("文件保存路径越界")
        with target.open("wb") as destination:
            for chunk in uploaded.chunks():
                digest.update(chunk)
                destination.write(chunk)
        if suffix == ".zip":
            try:
                _assert_archive_safe(target)
            except Exception:
                target.unlink(missing_ok=True)
                raise
        saved.append({
            "original_name": uploaded.name,
            "stored_name": stored_name,
            "relative_path": str(relative_dir / stored_name).replace("\\", "/"),
            "absolute_path": target,
            "extension": suffix,
            "mime_type": uploaded.content_type or mimetypes.guess_type(safe_name)[0] or "application/octet-stream",
            "size": uploaded.size,
            "sha256": digest.hexdigest(),
        })
    return saved


def _decode_text(data):
    for encoding in ("utf-8", "utf-8-sig", "gb18030"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def _extract_xml_text(data):
    text = _decode_text(data)
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _extract_ooxml(path):
    parts = []
    try:
        with zipfile.ZipFile(path) as archive:
            for member in archive.infolist():
                name = member.filename
                if not name.endswith(".xml"):
                    continue
                if not any(token in name for token in ("word/", "ppt/slides/", "xl/sharedStrings", "xl/worksheets")):
                    continue
                parts.append(_extract_xml_text(archive.read(member))[:5000])
                if sum(map(len, parts)) >= MAX_EVIDENCE_CHARS:
                    break
    except (zipfile.BadZipFile, KeyError):
        return "文档结构无法解析"
    return "\n".join(item for item in parts if item)


def _extract_zip_manifest(path):
    with zipfile.ZipFile(path) as archive:
        members = [item for item in archive.infolist() if not item.is_dir()]
        lines = [f"压缩包包含 {len(members)} 个文件："]
        for member in members[:80]:
            lines.append(f"- {member.filename} ({member.file_size} bytes)")
            suffix = Path(member.filename).suffix.lower()
            if suffix in TEXT_EXTENSIONS and member.file_size <= 256 * 1024:
                content = _decode_text(archive.read(member))[:1800]
                lines.append(f"  内容片段：{content}")
        return "\n".join(lines)


def extract_file_evidence(path):
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in TEXT_EXTENSIONS:
        return _decode_text(path.read_bytes()[: MAX_EVIDENCE_CHARS * 2])[:MAX_EVIDENCE_CHARS]
    if suffix in OOXML_EXTENSIONS:
        return _extract_ooxml(path)[:MAX_EVIDENCE_CHARS]
    if suffix == ".zip":
        return _extract_zip_manifest(path)[:MAX_EVIDENCE_CHARS]
    if suffix == ".pdf":
        try:
            from pypdf import PdfReader

            pages = []
            for page in PdfReader(str(path)).pages[:20]:
                pages.append(page.extract_text() or "")
            return "\n".join(pages)[:MAX_EVIDENCE_CHARS] or "PDF 未提取到可读文本"
        except Exception:
            return "PDF 已通过安全校验，但当前环境未能提取文本"
    return f"二进制成果文件：{path.name}，仅记录文件存在性与哈希，不进行内容臆测。"


def build_evidence_bundle(saved_files):
    bundle = []
    remaining = MAX_EVIDENCE_CHARS
    for item in saved_files:
        if remaining <= 0:
            break
        text = extract_file_evidence(item["absolute_path"])[:remaining]
        bundle.append({
            "file_name": item["original_name"],
            "sha256": item["sha256"],
            "size": item["size"],
            "content_excerpt": text,
        })
        remaining -= len(text)
    return bundle
