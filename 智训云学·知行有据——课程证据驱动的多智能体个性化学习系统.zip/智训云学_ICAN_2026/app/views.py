# -*- coding: utf-8 -*-
import json
import random
import hashlib
import logging
import uuid
from datetime import timedelta
from functools import wraps
from pathlib import Path

from django.conf import settings
from django.core.cache import cache
from django.core.paginator import Paginator
from django.db import DatabaseError, IntegrityError, connection, transaction
from django.db.models import Avg, Case, Count, IntegerField, Max, Q, Value, When
from django.db.models.functions import TruncDate
from django.http import HttpResponse, JsonResponse, StreamingHttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.utils.text import get_valid_filename

from . import ai_service
from .prompts.templates import get_prompt
from .services import ai_presenter, evaluation_service, security_service
from .services.identity_service import normalize_teacher_real_name
from .utils.file_parser import (
    ALLOWED_EXTENSIONS,
    MAX_FILES_PER_SUBMISSION,
    MAX_UPLOAD_BYTES,
    UnsafeUpload,
    build_evidence_bundle,
    validate_archive_path,
    validate_upload,
)
from .models import (
    AIEvaluation,
    AIEvaluationDimension,
    AIInvocationLog,
    Ability,
    Assessment,
    AssessmentResult,
    CareerReport,
    ClassInfo,
    Company,
    EvaluationRubric,
    InterviewRecord,
    JobPosition,
    LearningPath,
    LearningRecord,
    Major,
    MicroModule,
    ModuleAbility,
    OperationLog,
    PathModule,
    ProcessScore,
    QaRecord,
    PositionAbility,
    Recommendation,
    ReportSnapshot,
    Resume,
    RoleInfo,
    RubricDimension,
    Student,
    StudentProfile,
    SubmissionFile,
    Teacher,
    TeacherReview,
    TrainingRecord,
    TrainingSubmission,
    TrainingStep,
    TrainingTask,
    UserAccount,
    WarningRecord,
)

RECOMMEND_MODULE = '\u5fae\u6a21\u5757\u63a8\u8350'
RECOMMEND_POSITION = '\u5c97\u4f4d\u63a8\u8350'
RECOMMEND_PATH = '\u5b66\u4e60\u8def\u5f84\u63a8\u8350'
ROLE_STUDENT = '\u5b66\u751f'
ROLE_TEACHER = '\u6559\u5e08'
ROLE_ADMIN = '\u7ba1\u7406\u5458'
STATUS_DONE = '\u5df2\u5b8c\u6210'
STATUS_NOT_START = '\u672a\u5f00\u59cb'
STATUS_NOT_SUBMIT = '\u672a\u63d0\u4ea4'
STATUS_EVALUATED = '\u5df2\u8bc4\u4ef7'
STATUS_NORMAL = '\u6b63\u5e38'
STATUS_UNTREATED = '\u672a\u5904\u7406'
STATUS_HANDLED = '\u5df2\u5904\u7406'
AI_SYSTEM_PROMPT = get_prompt('qa')[0]
ATTACHMENT_MARKER = '\n\n---TRAINING_ATTACHMENTS---\n'
ALLOWED_ATTACHMENT_EXTENSIONS = ALLOWED_EXTENSIONS
logger = logging.getLogger(__name__)
DEMO_ACCOUNTS = (
    {'role': '管理员', 'username': 'admin', 'password': 'Admin@B1Demo'},
    {'role': '教师', 'username': 't001', 'password': 'Teacher@B1'},
    {'role': '学生', 'username': 's001', 'password': 'Student@B1'},
)


def _login_context(**extra):
    context = {
        'show_demo_accounts': bool(getattr(settings, 'SHOW_DEMO_ACCOUNTS', False)),
        'demo_accounts': DEMO_ACCOUNTS,
    }
    context.update(extra)
    return context


def _sha256_file(path, chunk_size=1024 * 1024):
    digest = hashlib.sha256()
    with Path(path).open('rb') as source:
        for chunk in iter(lambda: source.read(chunk_size), b''):
            digest.update(chunk)
    return digest.hexdigest()


def health_live(request):
    """Cheap process liveness probe; intentionally does not touch the database."""
    return JsonResponse({'status': 'ok', 'service': 'zhixun-cloud'})


def showcase_view(request):
    """Read-only public interface tour; it does not expose user data or AI APIs."""
    return render(request, 'showcase/index.html')


def health_ready(request):
    """Readiness probe used by the reverse proxy and pressure-test harness."""
    try:
        with connection.cursor() as cursor:
            cursor.execute('SELECT 1')
            cursor.fetchone()
    except DatabaseError:
        return JsonResponse({'status': 'unavailable', 'database': 'unavailable'}, status=503)
    return JsonResponse({'status': 'ready', 'database': 'ok'})


def _ai_rate_limit_response(request, scope, limit):
    """Fixed-window rate limit backed by the configured shared Django cache."""
    if limit <= 0:
        return None
    user_id = request.session.get('user_id') or 'anonymous'
    bucket = int(timezone.now().timestamp() // 60)
    key = f'ai-rate:{scope}:{user_id}:{bucket}'
    if cache.add(key, 1, timeout=70):
        current = 1
    else:
        try:
            current = cache.incr(key)
        except ValueError:
            cache.set(key, 1, timeout=70)
            current = 1
    if current <= limit:
        return None
    response = JsonResponse({
        'success': False,
        'code': 'RATE_LIMITED',
        'error': 'AI 请求过于频繁，请稍后再试。',
    }, status=429)
    response['Retry-After'] = '60'
    return response


def get_current_user(request):
    user_id = request.session.get('user_id')
    if not user_id:
        return None, None
    try:
        user = UserAccount.objects.select_related('role').get(user_id=user_id)
        return user, user.role
    except (UserAccount.DoesNotExist, DatabaseError):
        return None, None


def login_required(view_func):
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        user, role = get_current_user(request)
        if not user:
            return redirect('/login/')
        return view_func(request, user, role, *args, **kwargs)
    return wrapper


def api_login_required(view_func):
    """与 login_required 类似，但用于 JSON 接口：未登录时返回 401 JSON 而不是跳转页面。"""
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        user, role = get_current_user(request)
        if not user:
            return JsonResponse({'success': False, 'error': '请先登录后再使用该功能'}, status=401)
        return view_func(request, user, role, *args, **kwargs)
    return wrapper


def get_role_home(role):
    if not role:
        return '/login/'
    if role.role_name == ROLE_STUDENT:
        return '/student/dashboard/'
    if role.role_name == ROLE_TEACHER:
        return '/teacher/dashboard/'
    if role.role_name == ROLE_ADMIN:
        return '/admin/dashboard/'
    return '/login/'


def enforce_role(role, expected_role):
    if role.role_name == expected_role:
        return None
    return redirect(get_role_home(role))


def set_flash(request, message, level='success'):
    request.session['flash_message'] = message
    request.session['flash_level'] = level


def pop_flash(request):
    message = request.session.pop('flash_message', None)
    level = request.session.pop('flash_level', 'success')
    return message, level


def split_keywords(text):
    if not text:
        return []
    normalized = str(text)
    for sep in ['\uff0c', '\u3001', ',', '\uff1b', ';', '/', '|', '\n', '\t']:
        normalized = normalized.replace(sep, ' ')
    return [item.strip() for item in normalized.split(' ') if item.strip()]


def split_submission_payload(payload):
    payload = payload or ''
    if ATTACHMENT_MARKER not in payload:
        return payload.strip(), []
    text, raw_attachments = payload.split(ATTACHMENT_MARKER, 1)
    try:
        attachments = json.loads(raw_attachments)
    except json.JSONDecodeError:
        attachments = []
    if not isinstance(attachments, list):
        attachments = []
    cleaned = []
    for item in attachments:
        if isinstance(item, dict) and item.get('url') and item.get('name'):
            cleaned.append({
                'name': item.get('name'),
                'url': item.get('url'),
                'size': item.get('size', ''),
            })
    return text.strip(), cleaned


def build_submission_payload(text, attachments):
    text = (text or '').strip()
    attachments = attachments or []
    if not attachments:
        return text
    return text + ATTACHMENT_MARKER + json.dumps(attachments, ensure_ascii=False)


def format_file_size(size):
    try:
        size = int(size)
    except (TypeError, ValueError):
        return ''
    if size >= 1024 * 1024:
        return f'{round(size / (1024 * 1024), 1)} MB'
    if size >= 1024:
        return f'{round(size / 1024, 1)} KB'
    return f'{size} B'


def save_training_attachments(request, student, task):
    saved = []
    uploads = request.FILES.getlist('attachments')
    if len(uploads) > MAX_FILES_PER_SUBMISSION:
        raise UnsafeUpload(f'一次最多上传 {MAX_FILES_PER_SUBMISSION} 个文件')
    for uploaded in uploads:
        safe_name, suffix = validate_upload(uploaded)
        stamp = timezone.now().strftime('%Y%m%d%H%M%S%f')
        relative_path = Path('training_attachments') / f'student_{student.student_id}' / f'task_{task.task_id}' / f'{stamp}_{safe_name}'
        media_root = Path(settings.MEDIA_ROOT).resolve()
        absolute_path = (media_root / relative_path).resolve()
        if media_root not in absolute_path.parents:
            raise UnsafeUpload('文件保存路径越界')
        absolute_path.parent.mkdir(parents=True, exist_ok=True)
        with absolute_path.open('wb+') as destination:
            for chunk in uploaded.chunks():
                destination.write(chunk)
        if suffix == '.zip':
            try:
                validate_archive_path(absolute_path)
            except Exception:
                absolute_path.unlink(missing_ok=True)
                raise
        saved.append({
            'name': uploaded.name,
            'url': settings.MEDIA_URL + str(relative_path).replace('\\', '/'),
            'size': format_file_size(uploaded.size),
            'bytes': uploaded.size,
        })
    return saved


def _active_rubric(task):
    # Serialize the rare "create first rubric" path so simultaneous student
    # submissions cannot both create task version 1.
    with transaction.atomic():
        TrainingTask.objects.select_for_update().filter(task_id=task.task_id).exists()
        rubric = EvaluationRubric.objects.filter(
            task=task, is_active=True
        ).order_by('-version_no').first()
        if rubric:
            return rubric
        latest_version = EvaluationRubric.objects.filter(task=task).aggregate(
            latest=Max('version_no')
        )['latest'] or 0
        dimensions = evaluation_service.default_dimensions()
        rubric = EvaluationRubric.objects.create(
            task=task,
            created_by=task.teacher,
            rubric_name=f'{task.task_name}标准量规',
            description='平台默认量规，覆盖完成度、正确性、规范、安全、测试与文档。',
            version_no=latest_version + 1,
            total_weight=100,
            source='platform_default',
            prompt_version=get_prompt('training_evaluation')[2],
            status='已发布',
            is_active=True,
        )
        for order, item in enumerate(dimensions, 1):
            RubricDimension.objects.create(
                rubric=rubric,
                dimension_order=order,
                dimension_name=item['name'],
                weight=item['weight'],
                max_score=item['max_score'],
                criteria=item['criteria'],
                excellent_standard=item['excellent_standard'],
                qualified_standard=item['qualified_standard'],
                common_issues=item['common_issues'],
                ai_enabled=item['ai_enabled'],
                teacher_review_required=item['teacher_review_required'],
            )
        return rubric


def _dimension_payload(rubric):
    return [
        {
            'dimension_id': item.dimension_id,
            'name': item.dimension_name,
            'weight': item.weight,
            'max_score': item.max_score,
            'criteria': item.criteria,
            'excellent_standard': item.excellent_standard,
            'qualified_standard': item.qualified_standard,
            'common_issues': item.common_issues,
            'ai_enabled': item.ai_enabled,
            'teacher_review_required': item.teacher_review_required,
        }
        for item in RubricDimension.objects.filter(rubric=rubric).order_by('dimension_order')
    ]


def _reserve_submission(student, task, rubric, text_content, idempotency_key=None):
    """Create one version in a short transaction without holding locks during AI I/O."""
    key = idempotency_key or uuid.uuid4().hex
    for attempt in range(4):
        existing = TrainingSubmission.objects.filter(idempotency_key=key).first()
        if existing:
            return existing, False
        try:
            with transaction.atomic():
                # A row lock on the owning student serializes version allocation
                # for this student's concurrent form submissions.
                Student.objects.select_for_update().filter(
                    student_id=student.student_id
                ).exists()
                latest_version = TrainingSubmission.objects.filter(
                    student=student, task=task
                ).aggregate(latest=Max('version_no'))['latest'] or 0
                submission = TrainingSubmission.objects.create(
                    student=student,
                    task=task,
                    rubric=rubric,
                    version_no=latest_version + 1,
                    text_content=text_content,
                    status='评价处理中',
                    idempotency_key=key,
                )
            return submission, True
        except IntegrityError:
            existing = TrainingSubmission.objects.filter(idempotency_key=key).first()
            if existing:
                return existing, False
            if attempt == 3:
                raise
    raise IntegrityError('无法分配实训提交版本')


def persist_training_evaluation(student, task, text_content, attachments, idempotency_key=None):
    """Persist one submission version, bounded evidence and its evaluation."""
    try:
        rubric = _active_rubric(task)
        submission, created = _reserve_submission(
            student, task, rubric, text_content, idempotency_key
        )
        if not created:
            return AIEvaluation.objects.filter(
                submission=submission
            ).order_by('-evaluation_id').first()
        version_no = submission.version_no

        evidence_files = []
        media_root = Path(settings.MEDIA_ROOT).resolve()
        for item in attachments:
            url = str(item.get('url') or '')
            relative = url[len(settings.MEDIA_URL):] if url.startswith(settings.MEDIA_URL) else ''
            path = (media_root / relative).resolve()
            if not relative or media_root not in path.parents or not path.exists():
                continue
            digest = _sha256_file(path)
            suffix = path.suffix.lower()
            file_size = path.stat().st_size
            SubmissionFile.objects.get_or_create(
                submission=submission,
                sha256=digest,
                defaults={
                    'original_name': str(item.get('name') or path.name)[:255],
                    'stored_path': relative[:500],
                    'extension': suffix[:20],
                    'mime_type': 'application/octet-stream',
                    'file_size': file_size,
                    'parse_status': '已解析',
                    'parse_message': '仅进行静态解析，未执行学生代码',
                },
            )
            evidence_files.append({
                'original_name': str(item.get('name') or path.name),
                'absolute_path': path,
                'sha256': digest,
                'size': file_size,
            })
        evidence = build_evidence_bundle(evidence_files)
        if text_content:
            evidence.insert(0, {
                'file_name': '在线提交说明.txt',
                'sha256': hashlib.sha256(text_content.encode('utf-8')).hexdigest(),
                'size': len(text_content.encode('utf-8')),
                'content_excerpt': text_content[:8000],
            })
        dimensions = _dimension_payload(rubric)
        task_data = {
            'task_id': task.task_id,
            'task_name': task.task_name,
            'scene_type': task.scene_type,
            'difficulty': task.difficulty,
            'requirement': task.requirement,
            'deliverable': task.deliverable,
            'rubric_version': rubric.version_no,
        }
        result = evaluation_service.evaluate_submission(task_data, dimensions, evidence, version_no)
        data = result.data
        evaluation = AIEvaluation.objects.create(
            submission=submission,
            rubric=rubric,
            total_score=data['total_score'],
            summary=data['summary'],
            strengths_json=data['strengths'],
            critical_issues_json=data['critical_issues'],
            general_issues_json=data['general_issues'],
            suggestions_json=data['suggestions'],
            recommended_modules_json=data['recommended_modules'],
            source=data['source'],
            is_ai_generated=data['is_ai_generated'],
            confidence=data['confidence'],
            requires_teacher_review=data['requires_teacher_review'],
            model_name=data['model'],
            prompt_version=data['prompt_version'],
            raw_response_json=data,
            status='待教师复核',
        )
        dimension_map = {
            item.dimension_id: item
            for item in RubricDimension.objects.filter(rubric=rubric)
        }
        for row in data['dimensions']:
            dimension = dimension_map.get(row.get('dimension_id'))
            if not dimension:
                continue
            AIEvaluationDimension.objects.create(
                evaluation=evaluation,
                dimension=dimension,
                score=row['score'],
                max_score=row['max_score'],
                reason=row['reason'],
                evidence=row['evidence'],
                file_name=row['file_name'],
                line_reference=row['line_reference'],
                confidence=row['confidence'],
            )
        submission.status = '待教师复核'
        submission.save(update_fields=['status'])
        return evaluation
    except DatabaseError:
        # Keeps legacy pages usable before the updated MySQL schema is initialized.
        logger.exception('Unable to persist the B1 evaluation workflow')
        return None


def level_to_score(level_text):
    level_text = (level_text or '').strip()
    mapping = {
        '\u4f4e': 1, '\u4e00\u822c': 1, '\u521d\u7ea7': 1, '\u57fa\u7840': 1,
        '\u4e2d': 2, '\u4e2d\u7ea7': 2, '\u826f\u597d': 2, '\u8f83\u5f3a': 2,
        '\u9ad8': 3, '\u9ad8\u7ea7': 3, '\u719f\u7ec3': 3, '\u4f18\u79c0': 3,
    }
    return mapping.get(level_text, 2)


def score_to_level(value):
    if value >= 2.4:
        return '\u9ad8'
    if value >= 1.5:
        return '\u4e2d'
    return '\u4f4e'


def score_to_percent(value):
    return round(min(max(value, 0), 3) / 3 * 100, 1)


def calc_student_ability_map(student):
    """LearningRecord JOIN ModuleAbility \u805a\u5408\u5b66\u751f\u5404\u80fd\u529b\u9879\u5f97\u5206\u3002"""
    ability_scores = {}
    records = LearningRecord.objects.filter(student=student).select_related('module')
    training_values = []
    for record in TrainingRecord.objects.filter(student=student):
        if record.teacher_score is not None:
            training_values.append(record.teacher_score)
        elif record.ai_score is not None:
            training_values.append(record.ai_score)
    training_avg = sum(training_values) / len(training_values) if training_values else 0
    for record in records:
        module_abilities = ModuleAbility.objects.filter(module=record.module).select_related('ability')
        progress_ratio = (record.progress or 0) / 100
        score_ratio = ((record.score or 60) / 100) if record.score is not None else 0.6
        bonus = min(training_avg / 100, 1) * 0.15 if record.module.module_type != '\u4e13\u4e1a\u6a21\u5757' else 0
        for relation in module_abilities:
            raw_value = progress_ratio * score_ratio * float(relation.weight) * 3 + bonus
            current = ability_scores.get(relation.ability_id, 0)
            ability_scores[relation.ability_id] = round(max(current, min(raw_value, 3)), 2)
    return ability_scores


def get_target_position(student, profile):
    latest_resume = Resume.objects.filter(student=student).select_related('target_position').order_by(
        '-update_time', '-resume_id'
    ).first()
    if latest_resume and latest_resume.target_position:
        return latest_resume.target_position, '\u5df2\u7ed3\u5408\u7b80\u5386\u76ee\u6807\u5c97\u4f4d\u8fdb\u884c\u5339\u914d\u3002'
    latest_report = CareerReport.objects.filter(student=student).select_related('target_position').order_by(
        '-create_time', '-report_id'
    ).first()
    if latest_report and latest_report.target_position:
        return latest_report.target_position, '\u5df2\u7ed3\u5408\u6700\u8fd1\u751f\u6da8\u62a5\u544a\u76ee\u6807\u5c97\u4f4d\u3002'
    lookup_terms = split_keywords(profile.career_interest if profile else '')
    lookup_terms.extend(split_keywords(student.major.major_name))
    for term in lookup_terms:
        match = JobPosition.objects.select_related('company').filter(
            Q(position_name__icontains=term) | Q(industry__icontains=term) | Q(description__icontains=term)
        ).first()
        if match:
            return match, f'\u5df2\u6839\u636e\u300c{term}\u300d\u8bc6\u522b\u76ee\u6807\u5c97\u4f4d\u3002'
    fallback = JobPosition.objects.select_related('company').first()
    if fallback:
        return fallback, '\u5df2\u4f7f\u7528\u5e73\u53f0\u9ed8\u8ba4\u5c97\u4f4d\u8fdb\u884c\u63a8\u8350\u3002'
    return None, '\u6682\u65e0\u53ef\u7528\u5c97\u4f4d\u3002'


def analyze_position_gap(student, position):
    """PositionAbility JOIN Ability \u8ba1\u7b97\u5c97\u4f4d\u80fd\u529b\u5dee\u8ddd\u3002"""
    if not position:
        return [], {}
    ability_scores = calc_student_ability_map(student)
    ability_details = []
    ability_gap_map = {}
    relations = PositionAbility.objects.filter(position=position).select_related('ability')
    for relation in relations:
        required_score = level_to_score(relation.required_level)
        current_score = ability_scores.get(relation.ability_id, 0)
        gap_score = round(max(required_score - current_score, 0), 2)
        detail = {
            'ability': relation.ability,
            'required_level': relation.required_level,
            'required_score': required_score,
            'current_score': round(current_score, 2),
            'current_level': score_to_level(current_score),
            'gap_score': gap_score,
            'required_percent': score_to_percent(required_score),
            'current_percent': score_to_percent(current_score),
            'gap_percent': score_to_percent(gap_score),
        }
        ability_details.append(detail)
        ability_gap_map[relation.ability_id] = detail
    ability_details.sort(key=lambda item: item['gap_score'], reverse=True)
    return ability_details, ability_gap_map


def build_gap_summary_text(position, ability_details):
    if not position:
        return '\u6682\u672a\u5339\u914d\u76ee\u6807\u5c97\u4f4d\u3002'
    top_gaps = [item['ability'].ability_name for item in ability_details if item['gap_score'] > 0][:3]
    if not top_gaps:
        return f'\u4e0e\u300c{position.position_name}\u300d\u6838\u5fc3\u80fd\u529b\u57fa\u672c\u5339\u914d\u3002'
    return f'\u300c{position.position_name}\u300d\u6700\u9700\u8865\u9f50\uff1a' + '\u3001'.join(top_gaps)


def build_learning_summary(student):
    total_modules = MicroModule.objects.count()
    records = LearningRecord.objects.filter(student=student)
    completed = records.filter(status=STATUS_DONE).count()
    avg_score = records.aggregate(Avg('score'))['score__avg'] or 0
    training_scores = []
    for record in TrainingRecord.objects.filter(student=student):
        if record.teacher_score is not None:
            training_scores.append(record.teacher_score)
        elif record.ai_score is not None:
            training_scores.append(record.ai_score)
    training_avg = sum(training_scores) / len(training_scores) if training_scores else 0
    assessment_avg = AssessmentResult.objects.filter(student=student).aggregate(Avg('score'))['score__avg'] or 0
    completion_rate = completed / total_modules * 100 if total_modules else 0
    return {
        'total_modules': total_modules,
        'completed': completed,
        'pending': max(total_modules - completed, 0),
        'completion_rate': round(completion_rate, 1),
        'avg_score': round(avg_score, 1),
        'training_avg': round(training_avg, 1),
        'assessment_avg': round(assessment_avg, 1),
    }


def pick_recommended_module(student, profile, summary, ability_details=None):
    completed_ids = LearningRecord.objects.filter(student=student, status=STATUS_DONE).values_list('module_id', flat=True)
    candidates = MicroModule.objects.exclude(module_id__in=completed_ids)
    if not candidates.exists():
        return None, None
    top_gap_ability_ids = [item['ability'].ability_id for item in (ability_details or []) if item['gap_score'] > 0][:3]
    if top_gap_ability_ids:
        best_module = None
        best_score = -1
        for module in candidates:
            mappings = ModuleAbility.objects.filter(module=module, ability_id__in=top_gap_ability_ids).select_related('ability')
            if not mappings:
                continue
            module_score = sum(float(item.weight) for item in mappings)
            if module_score > best_score:
                best_score = module_score
                best_module = (module, mappings)
        if best_module:
            module, mappings = best_module
            names = '\u3001'.join(item.ability.ability_name for item in mappings[:2])
            return module, f'\u9488\u5bf9\u80fd\u529b\u5dee\u8ddd\u8865\u300c{names}\u300d\uff0c\u5efa\u8bae\u5b66\u4e60\u300c{module.module_name}\u300d\u3002'
    match = candidates.order_by('duration', 'module_id').first()
    return match, f'\u5b8c\u6210\u7387{summary["completion_rate"]}%\uff0c\u63a8\u8350\u300c{match.module_name}\u300d\u3002'


def pick_top3_positions(student, profile):
    ranked = []
    direct_position, direct_reason = get_target_position(student, profile)
    for position in JobPosition.objects.select_related('company').all():
        ability_details, _ = analyze_position_gap(student, position)
        total_gap = round(sum(item['gap_score'] for item in ability_details), 2)
        max_gap = (len(ability_details) or 1) * 3
        match_score = round(max(0, min(100, 100 - (total_gap / max_gap) * 100)), 1)
        reason = build_gap_summary_text(position, ability_details)
        if direct_position and position.position_id == direct_position.position_id:
            match_score = min(100, match_score + 5)
            reason = direct_reason + reason
        ranked.append({'position': position, 'match_score': match_score, 'total_gap': total_gap, 'ability_details': ability_details, 'reason': reason})
    ranked.sort(key=lambda item: (-item['match_score'], item['total_gap']))
    return ranked[:3]


def pick_recommended_position(student, profile):
    top3 = pick_top3_positions(student, profile)
    if top3:
        item = top3[0]
        return item['position'], item['reason'], item['ability_details']
    return None, '\u6682\u65e0\u5c97\u4f4d\u63a8\u8350\u3002', []


def pick_top3_modules(student, profile, summary, ability_details=None):
    completed_ids = set(LearningRecord.objects.filter(student=student, status=STATUS_DONE).values_list('module_id', flat=True))
    if ability_details is None:
        _, _, ability_details = pick_recommended_position(student, profile)
    top_gaps = [item for item in (ability_details or []) if item['gap_score'] > 0][:3]
    results = []
    used_module_ids = set()
    for gap_item in top_gaps:
        ability_id = gap_item['ability'].ability_id
        ability_name = gap_item['ability'].ability_name
        mapping = ModuleAbility.objects.filter(ability_id=ability_id).exclude(
            module_id__in=completed_ids
        ).exclude(module_id__in=used_module_ids).select_related('module', 'ability').order_by('-weight').first()
        if mapping:
            used_module_ids.add(mapping.module_id)
            results.append({
                'module': mapping.module,
                'ability_name': ability_name,
                'gap_score': gap_item['gap_score'],
                'reason': f'\u300c{ability_name}\u300d\u5dee\u8ddd{gap_item["gap_score"]}\uff0c\u63a8\u8350\u300c{mapping.module.module_name}\u300d\u3002',
            })
    if len(results) < 3:
        module, reason = pick_recommended_module(student, profile, summary, ability_details)
        if module and module.module_id not in used_module_ids:
            results.append({'module': module, 'ability_name': '\u7efc\u5408\u63d0\u5347', 'gap_score': 0, 'reason': reason})
    return results[:3]


def pick_learning_path(student, position):
    queryset = LearningPath.objects.select_related('major', 'target_position')
    if position:
        target_path = queryset.filter(target_position=position).first()
        if target_path:
            return target_path, '\u5df2\u5339\u914d\u76ee\u6807\u5c97\u4f4d\u5bf9\u5e94\u5b66\u4e60\u8def\u5f84\u3002'
    major_path = queryset.filter(major=student.major).first()
    if major_path:
        return major_path, '\u5df2\u5339\u914d\u6240\u5c5e\u4e13\u4e1a\u5b66\u4e60\u8def\u5f84\u3002'
    fallback = queryset.first()
    if fallback:
        return fallback, '\u5df2\u5339\u914d\u901a\u7528\u5b66\u4e60\u8def\u5f84\u3002'
    return None, None


def get_path_with_modules(student, position):
    """LearningPath JOIN PathModule JOIN MicroModule \u6309\u987a\u5e8f\u8fd4\u56de\u8def\u5f84\u6a21\u5757\u3002"""
    path, path_reason = pick_learning_path(student, position)
    if not path:
        return None, None, []
    rows = PathModule.objects.filter(path=path).select_related('module').order_by('module_order')
    records = {record.module_id: record for record in LearningRecord.objects.filter(student=student)}
    modules = []
    for row in rows:
        record = records.get(row.module_id)
        modules.append({
            'order': row.module_order,
            'module': row.module,
            'status': record.status if record else STATUS_NOT_START,
            'progress': record.progress if record else 0,
        })
    return path, path_reason, modules


def ensure_student_recommendations(student, force=False):
    if not force:
        existing_types = set(
            Recommendation.objects.filter(student=student)
            .values_list('recommend_type', flat=True)
            .distinct()
        )
        # Recommendations are refreshed by the learning/assessment/resume write
        # paths.  Avoid rebuilding the full ability graph on every dashboard GET.
        if {RECOMMEND_MODULE, RECOMMEND_POSITION}.issubset(existing_types):
            return 0
    if force:
        Recommendation.objects.filter(student=student).delete()
    created = 0
    summary = build_learning_summary(student)
    profile = StudentProfile.objects.filter(student=student).first()
    top3_positions = pick_top3_positions(student, profile)
    ability_details = top3_positions[0]['ability_details'] if top3_positions else []
    target_position = top3_positions[0]['position'] if top3_positions else None
    for item in pick_top3_modules(student, profile, summary, ability_details):
        if not Recommendation.objects.filter(student=student, recommend_type=RECOMMEND_MODULE, module=item['module']).exists():
            Recommendation.objects.create(student=student, recommend_type=RECOMMEND_MODULE, module=item['module'], reason=item['reason'], recommend_time=timezone.now())
            created += 1
    for item in top3_positions:
        reason = f'\u5339\u914d\u5ea6{item["match_score"]}%\u3002{item["reason"]}'
        if not Recommendation.objects.filter(student=student, recommend_type=RECOMMEND_POSITION, position=item['position']).exists():
            Recommendation.objects.create(student=student, recommend_type=RECOMMEND_POSITION, position=item['position'], reason=reason, recommend_time=timezone.now())
            created += 1
    path, path_reason, _ = get_path_with_modules(student, target_position)
    if path and not Recommendation.objects.filter(student=student, recommend_type=RECOMMEND_PATH, path=path).exists():
        Recommendation.objects.create(student=student, recommend_type=RECOMMEND_PATH, path=path, reason=path_reason, recommend_time=timezone.now())
        created += 1
    refresh_student_profile(student)
    return created


@transaction.atomic
def batch_generate_all_recommendations():
    total_created = 0
    student_count = 0
    for student in Student.objects.select_related('user', 'major').all():
        total_created += ensure_student_recommendations(student, force=True)
        student_count += 1
    return student_count, total_created


def get_student_recommendation_context(student):
    profile = refresh_student_profile(student)
    summary = build_learning_summary(student)
    top3_positions = pick_top3_positions(student, profile)
    top3_modules = pick_top3_modules(student, profile, summary)
    target_item = top3_positions[0] if top3_positions else None
    position = target_item['position'] if target_item else None
    position_reason = target_item['reason'] if target_item else ''
    ability_details = target_item['ability_details'] if target_item else []
    recommended_path, path_reason, path_modules = get_path_with_modules(student, position)
    radar_labels, radar_scores = build_radar_data(student)
    recommendations = Recommendation.objects.filter(student=student).select_related(
        'module', 'position__company', 'path'
    ).order_by('-recommend_time', '-recommend_id')[:30]
    latest_report = CareerReport.objects.filter(student=student).select_related(
        'target_position'
    ).order_by('-create_time', '-report_id').first()
    latest_resume = Resume.objects.filter(student=student).select_related(
        'target_position'
    ).order_by('-update_time', '-resume_id').first()
    assessment_results = list(
        AssessmentResult.objects.filter(student=student).select_related('assessment')
        .order_by('-test_time', '-result_id')[:5]
    )
    interview_records = list(
        InterviewRecord.objects.filter(student=student).select_related('position__company')
        .order_by('-interview_time', '-interview_id')[:5]
    )
    return {
        'profile': profile, 'summary': summary, 'target_position': position,
        'target_position_reason': position_reason, 'ability_details': ability_details,
        'gap_summary': build_gap_summary_text(position, ability_details),
        'top3_modules': top3_modules, 'top3_positions': top3_positions,
        'recommended_path': recommended_path, 'path_reason': path_reason, 'path_modules': path_modules,
        'radar_labels': radar_labels,
        'radar_scores': radar_scores,
        'radar_data': list(zip(radar_labels, radar_scores)),
        'positions': JobPosition.objects.select_related('company').all().order_by('company__company_name', 'position_name'),
        'interview_records': interview_records,
        'interview_views': [
            {'record': item, 'content': ai_presenter.present_interview(item.feedback, item.ai_score)}
            for item in interview_records
        ],
        'latest_report': latest_report,
        'latest_report_view': ai_presenter.present_career_report(
            latest_report.gap_analysis,
            latest_report.plan_content,
            latest_report.target_position.position_name if latest_report and latest_report.target_position else '',
        ) if latest_report else None,
        'latest_resume': latest_resume,
        'latest_resume_view': ai_presenter.present_resume(
            latest_resume.ai_comment, latest_resume.match_score
        ) if latest_resume else None,
        'assessments': Assessment.objects.all().order_by('assessment_id'),
        'assessment_results': assessment_results,
        'assessment_result_views': [
            {'record': item, 'content': ai_presenter.present_assessment(item.result_text, item.score)}
            for item in assessment_results
        ],
        'recommendations': recommendations,
    }


def build_student_mission_control(student, summary=None, profile=None):
    summary = summary or build_learning_summary(student)
    profile = profile or StudentProfile.objects.filter(student=student).first()
    readiness_score = round(
        summary['completion_rate'] * 0.35
        + summary['avg_score'] * 0.25
        + summary['training_avg'] * 0.2
        + summary['assessment_avg'] * 0.2
    )
    if readiness_score >= 85:
        readiness_level = '冲刺高匹配岗位'
    elif readiness_score >= 70:
        readiness_level = '稳步提升竞争力'
    elif readiness_score >= 55:
        readiness_level = '补齐关键短板'
    else:
        readiness_level = '优先建立基础闭环'

    actions = []
    module_rec = Recommendation.objects.filter(
        student=student,
        recommend_type=RECOMMEND_MODULE,
        module__isnull=False,
    ).select_related('module').order_by('-recommend_time', '-recommend_id').first()
    if module_rec:
        actions.append({
            'type': '微模块行动',
            'title': module_rec.module.module_name,
            'reason': module_rec.reason,
            'url': '/student/modules/',
        })
    elif summary['pending'] > 0:
        actions.append({
            'type': '微模块行动',
            'title': '完成一个未学微模块',
            'reason': f'当前还有{summary["pending"]}个模块待完成，先补齐学习闭环。',
            'url': '/student/modules/',
        })

    evaluated_task_ids = TrainingRecord.objects.filter(student=student, status=STATUS_EVALUATED).values_list('task_id', flat=True)
    next_task = TrainingTask.objects.exclude(task_id__in=evaluated_task_ids).order_by('difficulty', 'task_id').first()
    if next_task:
        actions.append({
            'type': '实场景行动',
            'title': next_task.task_name,
            'reason': f'通过「{next_task.scene_type}」任务把知识点转化为真实交付物。',
            'url': '/student/training/',
        })
    else:
        actions.append({
            'type': '实场景行动',
            'title': '复盘已完成实训',
            'reason': '所有已发布实训均已提交，可回看反馈并完善项目表达。',
            'url': '/student/training/',
        })

    has_assessment = AssessmentResult.objects.filter(student=student).exists()
    latest_resume = Resume.objects.filter(student=student).order_by('-update_time', '-resume_id').first()
    if not has_assessment or summary['assessment_avg'] < 70:
        actions.append({
            'type': '测评行动',
            'title': '完成一次职业能力测评',
            'reason': '测评会更新职业倾向和能力短板，让推荐更贴近当前状态。',
            'url': '/student/recommendations/',
        })
    elif not latest_resume:
        actions.append({
            'type': '就业行动',
            'title': '提交一版简历诊断',
            'reason': '把学习与实训成果转成岗位匹配证据，形成求职材料。',
            'url': '/student/recommendations/',
        })
    else:
        actions.append({
            'type': '就业行动',
            'title': '进行一次岗位模拟面试',
            'reason': f'最近简历匹配度{latest_resume.match_score or 0}%，建议继续训练专业表达。',
            'url': '/student/recommendations/',
        })

    evidence = [
        f'完成率 {summary["completion_rate"]}%',
        f'学习均分 {summary["avg_score"]}',
        f'实训均分 {summary["training_avg"]}',
        f'测评均分 {summary["assessment_avg"]}',
    ]
    if profile and profile.weak_ability:
        evidence.append(f'短板 {profile.weak_ability}')
    return {
        'score': max(0, min(readiness_score, 100)),
        'level': readiness_level,
        'actions': actions[:3],
        'evidence': evidence[:5],
    }


def get_state_owned_recruitment_news():
    return [
        {
            'company': '中国铝业集团有限公司',
            'title': '2026年校园招聘',
            'channel': '中铝集团官网 / 国聘网',
            'summary': '面向2026届毕业生开放校园招聘，岗位覆盖工程技术、材料、机械、电气、自动化、计算机、财务等方向。',
            'url': 'https://zlwebsite.chinalco.com.cn/pub/zljt/rlzy/rlzy_zpxx/',
        },
        {
            'company': '西北铝业有限责任公司',
            'title': '2026届毕业生招聘公告',
            'channel': '中国铝业集团成员企业官网 / 国聘网',
            'summary': '招聘技术员、会计、生产操作等岗位，公告明确通过国聘网投递简历，并提示招聘不收取任何费用。',
            'url': 'https://xbl.chinalco.com.cn/rlzy1/djxw/202510/t20251011_156182.html',
        },
        {
            'company': '国家电网有限公司',
            'title': '高校毕业生招聘',
            'channel': '国家电网人力资源招聘平台',
            'summary': '各单位在招聘平台发布招聘公告、报名条件、需求信息和联系方式，适合电气、计算机、通信、自动化等专业关注。',
            'url': 'https://zhaopin.sgcc.com.cn/',
        },
    ]


def safe_float(value, default=0):
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def refresh_student_profile(student):
    """Refresh StudentProfile with ORM aggregate results from learning/training/position tables."""
    learning_stats = LearningRecord.objects.filter(student=student).aggregate(
        avg_score=Avg('score'),
        avg_time=Avg('study_time'),
        avg_duration=Avg('module__duration'),
    )
    avg_score = safe_float(learning_stats['avg_score'])
    avg_time = safe_float(learning_stats['avg_time'])
    avg_duration = safe_float(learning_stats['avg_duration'], 1)

    if avg_score >= 85:
        foundation_level = '优秀'
    elif avg_score >= 70:
        foundation_level = '良好'
    else:
        foundation_level = '一般'

    if avg_score >= 80 and avg_time <= avg_duration:
        learning_habit = '高效稳定型'
    elif avg_time >= avg_duration * 1.5:
        learning_habit = '投入充分型'
    else:
        learning_habit = '稳步提升型'

    current_profile = StudentProfile.objects.filter(student=student).first()
    top_positions = pick_top3_positions(student, current_profile)
    best_position_item = top_positions[0] if top_positions else None
    weak_names = []
    if best_position_item:
        weak_names = [
            item['ability'].ability_name
            for item in best_position_item['ability_details']
            if item['gap_score'] > 0
        ][:3]

    weak_ability = '、'.join(weak_names) if weak_names else '暂无明显短板'
    career_interest = best_position_item['position'].position_name if best_position_item else '待匹配岗位方向'

    profile, created = StudentProfile.objects.get_or_create(
        student=student,
        defaults={
            'foundation_level': foundation_level,
            'learning_habit': learning_habit,
            'weak_ability': weak_ability,
            'career_interest': career_interest,
            'update_time': timezone.now(),
        },
    )
    if not created:
        profile.foundation_level = foundation_level
        profile.learning_habit = learning_habit
        profile.weak_ability = weak_ability
        profile.career_interest = career_interest
        profile.update_time = timezone.now()
        profile.save(update_fields=[
            'foundation_level', 'learning_habit', 'weak_ability', 'career_interest', 'update_time',
        ])
    return profile


def build_radar_data(student):
    """Ability JOIN ModuleAbility JOIN LearningRecord, with aggregate score per ability."""
    abilities = list(Ability.objects.all().order_by('ability_id')[:5])
    radar_labels = []
    radar_scores = []
    for ability in abilities:
        stats = LearningRecord.objects.filter(
            student=student,
            module__moduleability__ability=ability,
        ).aggregate(
            avg_score=Avg('score'),
            avg_progress=Avg('progress'),
            avg_weight=Avg('module__moduleability__weight'),
        )
        avg_score = safe_float(stats['avg_score'])
        avg_progress = safe_float(stats['avg_progress'])
        avg_weight = safe_float(stats['avg_weight'], 1)
        radar_labels.append(ability.ability_name)
        radar_scores.append(round(min(100, avg_score * 0.75 + avg_progress * 0.25 * avg_weight), 1))
    return radar_labels, radar_scores


def evaluate_module_answer(module, answer):
    answer = (answer or '').strip()
    system_prompt, task_prompt, _ = get_prompt('module_evaluation')
    result = ai_service.call_structured(
        [
            {'role': 'system', 'content': system_prompt},
            {'role': 'system', 'content': task_prompt},
            {'role': 'user', 'content': json.dumps({
                'module': {
                    'name': module.module_name,
                    'type': module.module_type,
                    'knowledge_point': module.knowledge_point,
                    'description': module.description,
                },
                'student_answer': answer,
            }, ensure_ascii=False)},
        ],
        use_case='module_evaluation',
        max_tokens=1000,
    )
    if result.success and isinstance(result.data, dict):
        score = round(evaluation_service.clamp(result.data.get('score')))
        study_time = max(module.duration, min(module.duration + len(answer) // 30, module.duration + 20))
        feedback = str(result.data.get('feedback') or result.data.get('next_action') or '')
        return score, study_time, 'deepseek', feedback
    keywords = []
    for source in [module.module_name, module.knowledge_point, module.description, module.module_type]:
        for item in split_keywords(source):
            if len(item) >= 2 and item not in keywords:
                keywords.append(item)
    keywords = keywords[:8]
    hit_count = sum(1 for keyword in keywords if keyword in answer)
    length_score = min(35, len(answer) // 5)
    keyword_score = round(hit_count / len(keywords) * 35) if keywords else 20
    structure_score = 20 if any(mark in answer for mark in ['1.', '一、', '首先', '其次', '最后', '\n']) else 8
    reflection_score = 10 if any(word in answer for word in ['总结', '反思', '收获', '应用', '问题']) else 4
    score = max(60, min(100, length_score + keyword_score + structure_score + reflection_score))
    study_time = max(module.duration, min(module.duration + len(answer) // 30, module.duration + 20))
    return score, study_time, 'rule_based_fallback', 'DeepSeek 未配置或暂不可用，本次仅完成规则预检。'


def build_step_rows(steps, current_order):
    rows = []
    for step in steps:
        if step.step_order < current_order:
            state = '已完成'
        elif step.step_order == current_order:
            state = '进行中'
        else:
            state = '锁定'
        rows.append({'step': step, 'state': state})
    return rows


def get_training_keywords(task, step=None):
    sources = [task.task_name, task.scene_type, task.deliverable, task.requirement]
    if step:
        sources.extend([step.step_name, step.step_hint])
    keywords = []
    for source in sources:
        for item in split_keywords(source):
            if len(item) >= 2 and item not in keywords:
                keywords.append(item)
    return keywords[:10]


def score_training_by_rule(task, content, completed_steps, total_steps):
    content = (content or '').strip()
    completion_score = completed_steps / total_steps * 100 if total_steps else 100
    keywords = get_training_keywords(task)
    hit_count = sum(1 for keyword in keywords if keyword in content)
    accuracy_score = hit_count / len(keywords) * 100 if keywords else 70
    structure_score = 40
    if len(content) >= 100:
        structure_score += 20
    if '\n' in content:
        structure_score += 20
    if any(mark in content for mark in ['1.', '一、', '首先', '其次', '最后']):
        structure_score += 20
    structure_score = min(structure_score, 100)
    ai_score = round(completion_score * 0.3 + accuracy_score * 0.4 + structure_score * 0.3)
    missing = [keyword for keyword in keywords if keyword not in content][:5]
    feedback = f'完成度{round(completion_score, 1)}分，准确性{round(accuracy_score, 1)}分，规范性{structure_score}分。'
    correction = '建议补充关键内容：' + '、'.join(missing) if missing else '关键内容覆盖较完整，可进一步优化表达结构。'
    return ai_score, feedback, correction


def check_step_content(task, step, content):
    keywords = get_training_keywords(task, step)[:6]
    content = (content or '').strip()
    if len(content) < 30:
        return False, '本步骤提交内容过短，请补充分步骤说明、关键判断和阶段成果。'
    missing = [keyword for keyword in keywords if keyword not in content][:3]
    if missing:
        return True, '可以进入下一步；建议继续补充：' + '、'.join(missing) + '。'
    return True, '本步骤关键内容完整，可以进入下一步。'


def score_assessment_result(assessment, values):
    valid_values = []
    for value in values:
        try:
            parsed = int(value)
        except (TypeError, ValueError):
            parsed = 3
        valid_values.append(max(1, min(parsed, 5)))
    score = round(sum(valid_values) / (len(valid_values) * 5) * 100) if valid_values else 60
    if score >= 85:
        level = '优势明显'
        suggestion = '建议继续对接更高阶的岗位任务，沉淀项目成果与作品集。'
    elif score >= 70:
        level = '基础较好'
        suggestion = '建议结合推荐微模块补齐短板，并在实训任务中强化应用表达。'
    elif score >= 60:
        level = '需要巩固'
        suggestion = '建议优先完成基础模块，围绕岗位能力要求逐项补强。'
    else:
        level = '重点预警'
        suggestion = '建议联系教师进行学习跟进，并重新规划近期学习任务。'
    return score, f'{assessment.assessment_name}结果：{level}。{suggestion}'


def diagnose_resume(student, position, content):
    content = (content or '').strip()
    position_abilities = PositionAbility.objects.filter(position=position).select_related('ability')
    system_prompt, task_prompt, _ = get_prompt('resume_diagnosis')
    result = ai_service.call_structured(
        [
            {'role': 'system', 'content': system_prompt},
            {'role': 'system', 'content': task_prompt},
            {'role': 'user', 'content': json.dumps({
                'position': {
                    'name': position.position_name,
                    'industry': position.industry,
                    'description': position.description,
                    'abilities': [item.ability.ability_name for item in position_abilities],
                },
                'resume': content,
            }, ensure_ascii=False)},
        ],
        use_case='resume_diagnosis',
        max_tokens=1800,
    )
    if result.success and isinstance(result.data, dict):
        match_score = round(evaluation_service.clamp(result.data.get('match_score')))
        return match_score, ai_presenter.format_resume_storage(result.data), 'deepseek'
    keyword_sources = [position.position_name, position.industry, position.description]
    keyword_sources.extend(item.ability.ability_name for item in position_abilities)
    keywords = []
    for source in keyword_sources:
        for item in split_keywords(source):
            if len(item) >= 2 and item not in keywords:
                keywords.append(item)
    keywords = keywords[:10]
    hit_count = sum(1 for keyword in keywords if keyword in content)
    keyword_score = hit_count / len(keywords) * 40 if keywords else 24
    length_score = min(25, len(content) // 12)
    structure_score = 20 if any(mark in content for mark in ['项目', '经历', '技能', '证书', '成果', '1.', '一、', '\n']) else 8
    evidence_score = 15 if any(word in content for word in ['负责', '完成', '提升', '优化', '数据', '系统', '团队', '沟通']) else 6
    match_score = round(max(35, min(100, keyword_score + length_score + structure_score + evidence_score)))
    missing = [keyword for keyword in keywords if keyword not in content][:4]
    if missing:
        advice = '建议补充与岗位相关的关键词和成果证据：' + '、'.join(missing) + '。'
    else:
        advice = '岗位关键词覆盖较完整，建议继续量化项目成果和个人贡献。'
    profile = StudentProfile.objects.filter(student=student).first()
    if profile and profile.weak_ability:
        advice += f' 结合当前能力画像，还可突出对「{profile.weak_ability}」的补强经历。'
    return match_score, f'规则预检（未调用AI）：岗位匹配度{match_score}%。{advice}', 'rule_based_fallback'


def generate_warning_records():
    total_modules = MicroModule.objects.count()
    for student in Student.objects.select_related('user').all():
        completed = LearningRecord.objects.filter(student=student, status=STATUS_DONE).count()
        completion_rate = completed / total_modules * 100 if total_modules else 0
        if completion_rate < 30 and not WarningRecord.objects.filter(student=student, warning_type='微模块完成率过低').exists():
            WarningRecord.objects.create(
                student=student,
                warning_type='微模块完成率过低',
                warning_reason=f'微模块完成率仅为{round(completion_rate, 1)}%，低于30%。',
                warning_level='一般',
                create_time=timezone.now(),
                status=STATUS_UNTREATED,
            )

        process_score = ProcessScore.objects.filter(student=student).first()
        total_score = safe_float(process_score.total_score) if process_score else 0
        if total_score < 60 and not WarningRecord.objects.filter(student=student, warning_type='过程性成绩过低').exists():
            WarningRecord.objects.create(
                student=student,
                warning_type='过程性成绩过低',
                warning_reason=f'过程性成绩为{round(total_score, 1)}分，低于60分。',
                warning_level='严重',
                create_time=timezone.now(),
                status=STATUS_UNTREATED,
            )


INTERVIEW_QUESTION_BANK = {
    '数据': ['请说明你如何进行数据清洗？', '如何理解数据库索引？', '如何分析一个业务指标下降？', '请介绍一次数据建模思路。', '如何保证数据质量？'],
    '开发': ['请说明 MVC 或 MTV 架构。', '如何优化 SQL 查询？', '如何处理接口异常？', '请介绍一次项目开发经历。', '如何保证代码可维护性？'],
    '运营': ['如何设计用户增长方案？', '如何分析活动效果？', '如何提升用户留存？', '请说明一次运营复盘思路。', '如何制定内容策略？'],
    '默认': ['请做一个自我介绍。', '你为什么选择这个岗位？', '请介绍你的项目经历。', '你的优势是什么？', '你如何规划职业发展？'],
}


def get_interview_questions(position):
    abilities = [
        item.ability.ability_name
        for item in PositionAbility.objects.filter(position=position).select_related('ability')
    ] if position else []
    system_prompt, task_prompt, _ = get_prompt('interview_questions')
    result = ai_service.call_structured(
        [
            {'role': 'system', 'content': system_prompt},
            {'role': 'system', 'content': task_prompt},
            {'role': 'user', 'content': json.dumps({
                'position_name': position.position_name if position else '',
                'industry': position.industry if position else '',
                'description': position.description if position else '',
                'ability_requirements': abilities,
            }, ensure_ascii=False)},
        ],
        use_case='interview_questions',
        max_tokens=1400,
    )
    if result.success and isinstance(result.data, dict):
        questions = []
        for item in result.data.get('questions') or []:
            if isinstance(item, dict) and item.get('question'):
                questions.append(str(item['question'])[:500])
            elif isinstance(item, str):
                questions.append(item[:500])
        if questions:
            return questions[:5], 'deepseek'
    position_name = position.position_name if position else ''
    for keyword, questions in INTERVIEW_QUESTION_BANK.items():
        if keyword != '默认' and keyword in position_name:
            selected = list(questions)
            random.shuffle(selected)
            return selected[:5], 'rule_based_fallback'
    selected = list(INTERVIEW_QUESTION_BANK['默认'])
    random.shuffle(selected)
    return selected[:5], 'rule_based_fallback'


def score_interview_answer(answer, question='', position=None):
    answer = (answer or '').strip()
    system_prompt, task_prompt, _ = get_prompt('interview_evaluation')
    result = ai_service.call_structured(
        [
            {'role': 'system', 'content': system_prompt},
            {'role': 'system', 'content': task_prompt},
            {'role': 'user', 'content': json.dumps({
                'position': position.position_name if position else '',
                'question': question,
                'answer': answer,
            }, ensure_ascii=False)},
        ],
        use_case='interview_evaluation',
        max_tokens=1200,
    )
    if result.success and isinstance(result.data, dict):
        score = round(evaluation_service.clamp(result.data.get('total_score')))
        return score, ai_presenter.format_interview_storage(result.data), 'deepseek'
    professional_words = ['数据库', '索引', '事务', '需求', '模型', '接口', '分析', '优化', '算法', '业务']
    positive_words = ['负责', '主动', '协作', '复盘', '提升', '解决', '沟通', '学习', '目标', '结果']
    professional_score = min(100, sum(1 for word in professional_words if word in answer) * 15 + 40)
    logic_score = min(100, len(answer) // 3 + (20 if any(x in answer for x in ['首先', '其次', '最后', '第一']) else 0))
    quality_score = min(100, sum(1 for word in positive_words if word in answer) * 12 + 40)
    total_score = round(professional_score * 0.4 + logic_score * 0.3 + quality_score * 0.3)
    feedback = f'专业知识{professional_score}分，逻辑表达{logic_score}分，职业素养{quality_score}分。建议结合岗位要求补充具体项目案例。'
    return total_score, '规则预检（未调用AI）：' + feedback, 'rule_based_fallback'


AI_QA_RULES = {
    '推荐': '系统会根据学习记录、能力映射和岗位能力要求，自动生成微模块、岗位和学习路径推荐。',
    '实训': '实训评分由完成度、关键词准确性和结构规范性共同决定，建议按步骤提交完整内容。',
    '成绩': '过程性成绩会综合微模块学习、实场景实训和职业测评结果自动更新。',
    '画像': '学生画像根据学习均分、学习时长、能力差距和岗位匹配结果自动更新。',
}
DEFAULT_AI_ANSWER = 'AI助教建议你先明确目标岗位或当前任务，再对照“知识点、能力要求、交付物”三项逐条补齐；如果问题涉及课程安排或个人情况，可以选择指定教师继续跟进。'


def simulate_training_feedback(task, content):
    content = (content or '').strip()
    keywords = set()
    for source in [task.task_name, task.scene_type, task.deliverable, task.requirement]:
        for item in split_keywords(source):
            if len(item) >= 2:
                keywords.add(item)
    hit_count = sum(1 for keyword in list(keywords)[:8] if keyword in content)
    score = min(95, 45 + min(len(content) // 18, 24) + min(hit_count * 6, 24) + (10 if '\n' in content else 0))
    feedback = '\u63d0\u4ea4\u5b8c\u6210\uff0c\u5177\u5907\u57fa\u672c\u8868\u8fbe\u3002'
    correction = '\u5efa\u8bae\u8865\u5145\u5173\u952e\u8bcd\u4e0e\u7ed3\u6784\u5316\u63cf\u8ff0\u3002'
    return score, feedback, correction


ADMIN_CONTEXT_CACHE_KEY = 'admin:dashboard:context:v3'


def build_admin_context(user):
    cached_context = cache.get(ADMIN_CONTEXT_CACHE_KEY)
    if cached_context is not None:
        return {**cached_context, 'user': user}

    companies = list(Company.objects.all().order_by('company_name'))
    positions = list(JobPosition.objects.select_related('company').all().order_by('company__company_name', 'position_name'))
    majors = list(Major.objects.all().order_by('major_name'))
    classes = list(ClassInfo.objects.select_related('major').all().order_by('-grade', 'class_name'))
    students = list(Student.objects.select_related('user', 'major', 'class_field').defer('user__password'))
    teachers = list(Teacher.objects.select_related('user').defer('user__password'))
    student_map = {item.user_id: item for item in students}
    teacher_map = {item.user_id: item for item in teachers}
    user_rows = []
    for account in UserAccount.objects.select_related('role').defer('password').order_by('role_id', 'user_id'):
        profile_text = '-'
        if account.user_id in student_map:
            s = student_map[account.user_id]
            profile_text = f'{s.student_no} / {s.major.major_name} / {s.class_field.class_name}'
        elif account.user_id in teacher_map:
            t = teacher_map[account.user_id]
            profile_text = f'{t.teacher_no} / {t.department}'
        user_rows.append({'account': account, 'profile_text': profile_text})
    total_modules = MicroModule.objects.count()
    learning_rows = LearningRecord.objects.values('student_id').annotate(
        completed=Count(
            'record_id',
            filter=Q(status=STATUS_DONE),
        ),
        avg_score=Avg('score'),
    )
    learning_map = {row['student_id']: row for row in learning_rows}
    low_progress_students = []
    for student in students:
        row = learning_map.get(student.student_id, {})
        completed = row.get('completed') or 0
        avg_score = safe_float(row.get('avg_score'))
        completion_rate = completed / total_modules * 100 if total_modules else 0
        low_progress_students.append({
            'student': student,
            'user': student.user,
            'completion_rate': round(completion_rate, 1),
            'pending': max(total_modules - completed, 0),
            'avg_score': round(avg_score, 1),
        })
    low_progress_students.sort(key=lambda item: (item['completion_rate'], item['avg_score']))
    major_student_rows = list(Major.objects.annotate(student_count=Count('student')).values('major_name', 'student_count').order_by('major_name'))
    major_score_rows = list(ProcessScore.objects.values('student__major__major_name').annotate(avg_score=Avg('total_score')).order_by('student__major__major_name'))
    trend_start = timezone.now() - timedelta(days=6)
    trend_rows = list(
        Recommendation.objects.filter(recommend_time__gte=trend_start)
        .annotate(day=TruncDate('recommend_time'))
        .values('day')
        .annotate(total=Count('recommend_id'))
        .order_by('day')
    )
    task_count = TrainingTask.objects.count()
    warning_count = WarningRecord.objects.filter(status=STATUS_UNTREATED).count()
    warning_total = WarningRecord.objects.count()
    recommendation_count = Recommendation.objects.count()
    assessment_report_count = AssessmentResult.objects.count() + CareerReport.objects.count()
    employment_training_count = Resume.objects.count() + InterviewRecord.objects.count()
    process_evaluation_count = ProcessScore.objects.count() + warning_total
    qa_count = QaRecord.objects.count()
    aggregate_metrics = {
        'avg_progress': round(safe_float(LearningRecord.objects.aggregate(Avg('progress'))['progress__avg']), 1),
        'avg_score': round(safe_float(ProcessScore.objects.aggregate(Avg('total_score'))['total_score__avg']), 1),
        'avg_match': round(safe_float(Resume.objects.aggregate(Avg('match_score'))['match_score__avg']), 1),
    }
    context = {
        'overview': {
            'user_count': len(user_rows),
            'major_count': len(majors),
            'class_count': len(classes),
            'position_count': len(positions),
            'module_count': total_modules,
            'task_count': task_count,
            'warning_count': warning_count,
            'recommendation_count': recommendation_count,
        },
        'companies': companies, 'positions': positions, 'majors': majors, 'classes': classes,
        'user_rows': user_rows, 'students': students, 'low_progress_students': low_progress_students[:6],
        'recent_recommendations': list(Recommendation.objects.select_related('student__user', 'module', 'position__company', 'path').defer('student__user__password').order_by('-recommend_time', '-recommend_id')[:8]),
        'recent_warnings': list(WarningRecord.objects.select_related('student__user').defer('student__user__password').filter(status=STATUS_UNTREATED).order_by('-create_time', '-warning_id')[:6]),
        'coverage_cards': [
            {'title': '微模块课程融合', 'value': total_modules, 'desc': '专业模块、生涯模块与融合模块'},
            {'title': '实场景实训', 'value': task_count, 'desc': '岗位任务、步骤引导与过程反馈'},
            {'title': '个性化推荐', 'value': recommendation_count, 'desc': '微模块、岗位与学习路径推荐'},
            {'title': '测评与生涯报告', 'value': assessment_report_count, 'desc': '职业测评、差距分析与规划报告'},
            {'title': '就业技能训练', 'value': employment_training_count, 'desc': '简历诊断与模拟面试记录'},
            {'title': '过程性评价预警', 'value': process_evaluation_count, 'desc': '过程成绩、风险识别与教师处理'},
            {'title': '师生互动答疑', 'value': qa_count, 'desc': 'AI辅助回答与教师跟进'},
            {'title': '岗位校企资源', 'value': len(positions), 'desc': '岗位库、企业案例与能力映射'},
        ],
        'big_screen': {
            'student_count': len(students),
            'teacher_count': len(teachers),
            'module_count': total_modules,
            'task_count': task_count,
            **aggregate_metrics,
        },
        'major_student_chart': [
            {
                'label': row['major_name'],
                'value': row['student_count'],
                'percent': round(row['student_count'] / max([item['student_count'] for item in major_student_rows] or [1]) * 100),
            }
            for row in major_student_rows
        ],
        'major_score_chart': [
            {
                'label': row['student__major__major_name'] or '未分组',
                'value': round(safe_float(row['avg_score']), 1),
                'percent': round(safe_float(row['avg_score'])),
            }
            for row in major_score_rows
        ],
        'recommendation_trend': [
            {
                'label': row['day'].strftime('%m-%d') if row['day'] else '-',
                'value': row['total'],
                'percent': round(row['total'] / max([item['total'] for item in trend_rows] or [1]) * 100),
            }
            for row in trend_rows
        ],
    }
    cache.set(ADMIN_CONTEXT_CACHE_KEY, context, timeout=30)
    return {**context, 'user': user}


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '')
        if security_service.login_is_limited(request, username):
            return render(request, 'login.html', _login_context(**{
                'error': '连续登录失败次数过多，请15分钟后再试。',
            }), status=429)
        try:
            user = UserAccount.objects.select_related('role').get(username=username)
            if not security_service.verify_and_upgrade_password(user, password):
                remaining = security_service.register_login_failure(request, username)
                return render(request, 'login.html', _login_context(**{
                    'error': f'用户名或密码错误，本时段还可尝试 {remaining} 次。',
                }), status=401)
            if user.status != STATUS_NORMAL:
                return render(request, 'login.html', _login_context(error='账号已停用'), status=403)
            role = user.role
            security_service.clear_login_failures(request, username)
            request.session.cycle_key()
            request.session['user_id'] = user.user_id
            return redirect(get_role_home(role))
        except UserAccount.DoesNotExist:
            remaining = security_service.register_login_failure(request, username)
            return render(request, 'login.html', _login_context(**{
                'error': f'用户名或密码错误，本时段还可尝试 {remaining} 次。',
            }), status=401)
    return render(request, 'login.html', _login_context())


def forgot_password_view(request):
    roles = RoleInfo.objects.all().order_by('role_id')
    if request.method == 'POST':
        role_name = request.POST.get('role_name')
        username = request.POST.get('username', '').strip()
        real_name = request.POST.get('real_name', '').strip()
        contact = request.POST.get('contact', '').strip()
        new_password = request.POST.get('new_password', '')
        confirm_password = request.POST.get('confirm_password', '')
        if new_password != confirm_password:
            return render(request, 'forgot_password.html', {'roles': roles, 'error': '两次输入的新密码不一致。'})
        errors = security_service.password_errors(new_password)
        if errors:
            return render(request, 'forgot_password.html', {'roles': roles, 'error': '；'.join(errors)})
        try:
            account = UserAccount.objects.select_related('role').get(
                username=username,
                real_name=real_name,
                role__role_name=role_name,
            )
        except UserAccount.DoesNotExist:
            return render(request, 'forgot_password.html', {'roles': roles, 'error': '账号、角色或真实姓名不匹配。'})
        if not contact or contact not in [account.phone, account.email]:
            return render(request, 'forgot_password.html', {'roles': roles, 'error': '联系电话或邮箱验证失败，请使用注册时填写的信息。'})
        account.password = security_service.hash_password(new_password)
        account.save(update_fields=['password'])
        try:
            OperationLog.objects.create(
                operator=account,
                action='用户自助重置密码',
                target_type='user_account',
                target_id=str(account.user_id),
                detail_json={'channel': 'verified_contact'},
                ip_address=request.META.get('REMOTE_ADDR') or None,
            )
        except DatabaseError:
            logger.warning('Password reset audit log table is unavailable')
        return render(request, 'forgot_password.html', {'roles': roles, 'success': '密码已重置，请返回登录页使用新密码登录。'})
    return render(request, 'forgot_password.html', {'roles': roles})


def logout_view(request):
    request.session.flush()
    return redirect('/login/')


@login_required
def student_dashboard(request, user, role):
    redirect_response = enforce_role(role, ROLE_STUDENT)
    if redirect_response:
        return redirect_response
    student = Student.objects.get(user=user)
    summary = build_learning_summary(student)
    ensure_student_recommendations(student)
    profile = StudentProfile.objects.filter(student=student).first() or refresh_student_profile(student)
    mission = build_student_mission_control(student, summary, profile)
    recommendations = Recommendation.objects.filter(student=student).order_by('-recommend_time', '-recommend_id')[:4]
    qa_records = QaRecord.objects.filter(student=student).select_related(
        'teacher__user'
    ).order_by('-create_time', '-qa_id')[:8]
    teachers = Teacher.objects.select_related('user').order_by('teacher_id')
    return render(request, 'student/dashboard.html', {'user': user, 'student': student, 'profile': profile, 'mission': mission, 'total_modules': summary['total_modules'], 'completed': summary['completed'], 'avg_score': summary['avg_score'], 'training_count': TrainingRecord.objects.filter(student=student).count(), 'completion_rate': summary['completion_rate'], 'assessment_avg': summary['assessment_avg'], 'recommendations': recommendations, 'qa_records': qa_records, 'teachers': teachers, 'state_owned_jobs': get_state_owned_recruitment_news()})


@login_required
def student_modules(request, user, role):
    redirect_response = enforce_role(role, ROLE_STUDENT)
    if redirect_response:
        return redirect_response
    student = Student.objects.get(user=user)
    records = {r.module_id: r for r in LearningRecord.objects.filter(student=student)}
    module_list = []
    for module in MicroModule.objects.all():
        record = records.get(module.module_id)
        module_list.append({'module': module, 'record': record, 'status': record.status if record else STATUS_NOT_START, 'progress': record.progress if record else 0, 'score': record.score if record else '-'})
    flash_message, flash_level = pop_flash(request)
    return render(request, 'student/modules.html', {'user': user, 'modules': module_list, 'flash_message': flash_message, 'flash_level': flash_level})


@login_required
def student_complete_learning(request, user, role, module_id):
    redirect_response = enforce_role(role, ROLE_STUDENT)
    if redirect_response:
        return redirect_response
    student = Student.objects.get(user=user)
    module = get_object_or_404(MicroModule, module_id=module_id)
    if request.method != 'POST':
        set_flash(request, '请先填写学习回答，再提交完成微模块。', 'warning')
        return redirect('/student/modules/')
    answer = request.POST.get('answer_content', '').strip()
    if len(answer) < 30:
        set_flash(request, '学习回答至少需要30个字，请补充知识点理解、应用场景和学习收获。', 'warning')
        return redirect('/student/modules/')
    score, study_time, source, feedback = evaluate_module_answer(module, answer)
    record, created = LearningRecord.objects.get_or_create(student=student, module=module, defaults={'progress': 100, 'study_time': study_time, 'score': score, 'status': STATUS_DONE, 'last_study_time': timezone.now()})
    if not created:
        record.progress = 100
        record.study_time = study_time
        record.score = score
        record.status = STATUS_DONE
        record.last_study_time = timezone.now()
        record.save()
    ensure_student_recommendations(student, force=True)
    source_label = 'DeepSeek语义评价' if source == 'deepseek' else '规则预检（非AI）'
    set_flash(request, f'微模块《{module.module_name}》已完成，{source_label}为 {score} 分。{feedback}')
    return redirect('/student/modules/')


@login_required
def student_training(request, user, role):
    redirect_response = enforce_role(role, ROLE_STUDENT)
    if redirect_response:
        return redirect_response
    student = Student.objects.get(user=user)
    records = {r.task_id: r for r in TrainingRecord.objects.filter(student=student)}
    task_list = []
    for task in TrainingTask.objects.all():
        record = records.get(task.task_id)
        submit_text, attachments = split_submission_payload(record.submit_content if record else '')
        task_list.append({'task': task, 'record': record, 'status': record.status if record else STATUS_NOT_SUBMIT, 'score': record.teacher_score if record and record.teacher_score is not None else record.ai_score if record and record.ai_score is not None else '-', 'submit_text': submit_text, 'attachments': attachments})
    return render(request, 'student/training.html', {'user': user, 'tasks': task_list})


@login_required
def student_submit_training(request, user, role, task_id):
    redirect_response = enforce_role(role, ROLE_STUDENT)
    if redirect_response:
        return redirect_response
    student = Student.objects.get(user=user)
    task = get_object_or_404(TrainingTask, task_id=task_id)
    steps = list(TrainingStep.objects.filter(task=task).order_by('step_order'))
    total_steps = len(steps)
    session_key = f'training_step_{student.student_id}_{task.task_id}'
    current_step_order = int(request.session.get(session_key, 1))
    current_step_order = max(1, min(current_step_order, total_steps or 1))
    record = TrainingRecord.objects.filter(student=student, task=task).first()
    idempotency_session_key = f'training_submit_token_{student.student_id}_{task.task_id}'
    if idempotency_session_key not in request.session:
        request.session[idempotency_session_key] = uuid.uuid4().hex
    idempotency_key = request.session[idempotency_session_key]
    step_message = None
    step_error = None
    if request.method == 'POST':
        action = request.POST.get('action', 'step_submit')
        content = request.POST.get('content', '').strip()
        previous_text, previous_attachments = split_submission_payload(record.submit_content if record else '')
        try:
            if len(previous_attachments) + len(request.FILES.getlist('attachments')) > MAX_FILES_PER_SUBMISSION:
                raise UnsafeUpload(f'同一版本最多保留 {MAX_FILES_PER_SUBMISSION} 个成果文件')
            new_attachments = save_training_attachments(request, student, task)
        except UnsafeUpload as exc:
            submit_text, attachments = split_submission_payload(record.submit_content if record else '')
            return render(request, 'student/submit_training.html', {
                'user': user, 'task': task, 'steps': steps,
                'step_rows': build_step_rows(steps, current_step_order),
                'current_step': steps[current_step_order - 1] if steps else None,
                'current_step_order': current_step_order, 'total_steps': total_steps,
                'record': record, 'record_submit_text': submit_text,
                'attachments': attachments, 'step_error': str(exc),
                'idempotency_key': idempotency_key,
            }, status=400)
        attachments = previous_attachments + new_attachments
        review_content = content or previous_text
        content_for_ai = review_content
        if attachments and len(content_for_ai.strip()) < 30:
            content_for_ai = (content_for_ai + '\n附件材料：学生已上传实训成果文件，需结合附件进行查看。').strip()
        submit_payload = build_submission_payload(review_content, attachments)
        current_step = steps[current_step_order - 1] if steps else None
        passed, message = check_step_content(task, current_step, content_for_ai)
        if attachments and not review_content:
            passed = True
            message = '已收到附件材料；建议补充一段文字说明，方便教师快速理解处理过程和结论。'
        if action == 'step_submit' and steps:
            if passed:
                completed_order = current_step_order
                status_text = '已提交'
                TrainingRecord.objects.update_or_create(
                    student=student,
                    task=task,
                    defaults={
                        'submit_content': submit_payload,
                        'ai_score': None,
                        'feedback': f'已完成第{completed_order}步：{current_step.step_name}' + (f'，已上传{len(attachments)}个附件。' if attachments else ''),
                        'correction_suggestion': message,
                        'status': status_text,
                        'submit_time': timezone.now(),
                    },
                )
                if current_step_order < total_steps:
                    current_step_order += 1
                    request.session[session_key] = current_step_order
                    step_message = message
                else:
                    action = 'final_submit'
            else:
                step_error = message

        if action == 'final_submit' or not steps:
            completed_steps = total_steps or 1
            evaluation = persist_training_evaluation(
                student,
                task,
                review_content,
                attachments,
                request.POST.get('idempotency_key') or idempotency_key,
            )
            with transaction.atomic():
                if evaluation:
                    ai_score = round(float(evaluation.total_score))
                    source_name = 'DeepSeek结构化评价' if evaluation.is_ai_generated else '规则安全预检'
                    feedback = f'{source_name}：{evaluation.summary}'
                    suggestions = evaluation.suggestions_json or []
                    correction = '；'.join(str(item) for item in suggestions[:4]) or '等待教师复核。'
                else:
                    ai_score, legacy_feedback, correction = score_training_by_rule(
                        task, content_for_ai, completed_steps, total_steps or 1
                    )
                    feedback = '规则安全预检（未调用AI）：' + legacy_feedback
                if attachments:
                    feedback += f' 已收到{len(attachments)}个附件，可作为教师复核材料。'
                TrainingRecord.objects.update_or_create(
                    student=student,
                    task=task,
                    defaults={
                        'submit_content': submit_payload,
                        'ai_score': ai_score,
                        'feedback': feedback + ' 已生成待教师复核报告。',
                        'correction_suggestion': correction,
                        'status': STATUS_EVALUATED,
                        'submit_time': timezone.now(),
                    },
                )
                refresh_student_profile(student)
            request.session.pop(session_key, None)
            request.session.pop(idempotency_session_key, None)
            return redirect('/student/training/')
        record = TrainingRecord.objects.filter(student=student, task=task).first()
    step_rows = build_step_rows(steps, current_step_order)
    current_step = steps[current_step_order - 1] if steps else None
    submit_text, attachments = split_submission_payload(record.submit_content if record else '')
    return render(request, 'student/submit_training.html', {'user': user, 'task': task, 'steps': steps, 'step_rows': step_rows, 'current_step': current_step, 'current_step_order': current_step_order, 'total_steps': total_steps, 'record': record, 'record_submit_text': submit_text, 'attachments': attachments, 'step_message': step_message, 'step_error': step_error, 'idempotency_key': idempotency_key})


@login_required
def student_recommendations(request, user, role):
    redirect_response = enforce_role(role, ROLE_STUDENT)
    if redirect_response:
        return redirect_response
    student = Student.objects.get(user=user)
    ensure_student_recommendations(student)
    context = get_student_recommendation_context(student)
    flash_message, flash_level = pop_flash(request)
    context.update({'user': user, 'flash_message': flash_message, 'flash_level': flash_level})
    return render(request, 'student/recommendations.html', context)


@login_required
def submit_assessment(request, user, role):
    redirect_response = enforce_role(role, ROLE_STUDENT)
    if redirect_response:
        return redirect_response
    if request.method != 'POST':
        return redirect('/student/recommendations/')
    student = Student.objects.get(user=user)
    assessment = get_object_or_404(Assessment, assessment_id=request.POST.get('assessment_id'))
    try:
        values = [
            max(1, min(5, int(request.POST.get('interest_score', 3)))),
            max(1, min(5, int(request.POST.get('ability_score', 3)))),
            max(1, min(5, int(request.POST.get('quality_score', 3)))),
        ]
    except (TypeError, ValueError):
        set_flash(request, '测评选项无效，请重新选择。', 'warning')
        return redirect('student_recommendations')
    duplicate_since = timezone.now() - timedelta(seconds=10)
    if AssessmentResult.objects.filter(
        student=student, assessment=assessment, test_time__gte=duplicate_since
    ).exists():
        set_flash(request, '本次测评已提交，请勿重复操作。', 'warning')
        return redirect('student_recommendations')
    score, result_text = score_assessment_result(assessment, values)
    system_prompt, task_prompt, _ = get_prompt('assessment_interpretation')
    interpretation = ai_service.call_structured(
        [
            {'role': 'system', 'content': system_prompt},
            {'role': 'system', 'content': task_prompt},
            {'role': 'user', 'content': json.dumps({
                'assessment': assessment.assessment_name,
                'assessment_type': assessment.assessment_type,
                'deterministic_score': score,
                'learning_summary': build_learning_summary(student),
            }, ensure_ascii=False)},
        ],
        use_case='assessment_interpretation',
        max_tokens=1400,
    )
    if interpretation.success and isinstance(interpretation.data, dict):
        result_text = ai_presenter.format_assessment_storage(interpretation.data)
    else:
        result_text = ai_presenter.format_assessment_storage(
            {'summary': result_text, 'confidence': '规则结果，需教师确认'},
            source=ai_presenter.SOURCE_RULE,
        )
    AssessmentResult.objects.create(
        student=student,
        assessment=assessment,
        score=score,
        result_text=result_text,
        test_time=timezone.now(),
    )
    refresh_student_profile(student)
    ensure_student_recommendations(student, force=True)
    set_flash(request, f'{assessment.assessment_name}已完成，测评分数为 {score} 分。')
    return redirect('/student/recommendations/')


@login_required
def submit_resume(request, user, role):
    redirect_response = enforce_role(role, ROLE_STUDENT)
    if redirect_response:
        return redirect_response
    if request.method != 'POST':
        return redirect('/student/recommendations/')
    student = Student.objects.get(user=user)
    position = get_object_or_404(JobPosition, position_id=request.POST.get('position_id'))
    content = request.POST.get('resume_content', '').strip()
    if len(content) < 40:
        set_flash(request, '简历内容至少需要 40 个字，请补充教育经历、项目经历、技能和求职方向。', 'warning')
        return redirect('/student/recommendations/')
    match_score, ai_comment, source = diagnose_resume(student, position, content)
    Resume.objects.create(
        student=student,
        target_position=position,
        resume_content=content,
        ai_comment=ai_comment,
        match_score=match_score,
        update_time=timezone.now(),
    )
    refresh_student_profile(student)
    ensure_student_recommendations(student, force=True)
    source_label = 'DeepSeek诊断' if source == 'deepseek' else '规则预检（非AI）'
    set_flash(request, f'{source_label}完成，岗位匹配度为 {match_score}%。')
    return redirect('/student/recommendations/')


@login_required
def generate_career_report(request, user, role):
    redirect_response = enforce_role(role, ROLE_STUDENT)
    if redirect_response:
        return redirect_response
    if request.method != 'POST':
        set_flash(request, '请通过“生成成长报告”按钮提交请求。', 'warning')
        return redirect('student_recommendations')
    student = Student.objects.get(user=user)
    context = get_student_recommendation_context(student)
    target_position = context['target_position']
    top_module_names = [item['module'].module_name for item in context['top3_modules']]
    system_prompt, task_prompt, _ = get_prompt('career_plan')
    result = ai_service.call_structured(
        [
            {'role': 'system', 'content': system_prompt},
            {'role': 'system', 'content': task_prompt},
            {'role': 'user', 'content': json.dumps({
                'major': student.major.major_name,
                'target_position': target_position.position_name if target_position else '待匹配',
                'gap_analysis': context['gap_summary'],
                'recommended_modules': top_module_names,
                'learning_summary': context['summary'],
            }, ensure_ascii=False, default=str)},
        ],
        use_case='career_plan',
        max_tokens=2000,
    )
    if result.success and isinstance(result.data, dict):
        gap_analysis = str(result.data.get('gap_analysis') or context['gap_summary'])
        plan_content = ai_presenter.format_career_storage(result.data)
        source_label = 'DeepSeek生涯规划'
    else:
        gap_analysis = context['gap_summary']
        plan_content = ai_presenter.format_career_storage({
            'gap_analysis': context['gap_summary'],
            'plan_summary': '建议优先完成推荐微模块，并结合岗位能力要求补齐短板。',
            'stages': [{
                'period': '近期',
                'goal': '完成关键能力补学',
                'deliverable': '完成' + ('、'.join(top_module_names) if top_module_names else '平台基础模块'),
            }],
            'evidence_sources': ['平台学习记录', '实训记录', '岗位能力要求'],
            'confidence': '规则结果，需教师确认',
        }, source=ai_presenter.SOURCE_RULE)
        source_label = '规则降级规划'
    CareerReport.objects.create(
        student=student,
        target_position=target_position,
        gap_analysis=gap_analysis,
        plan_content=plan_content,
        create_time=timezone.now(),
    )
    refresh_student_profile(student)
    set_flash(request, f'{source_label}已生成。')
    return redirect('/student/recommendations/')


@login_required
def start_interview(request, user, role):
    redirect_response = enforce_role(role, ROLE_STUDENT)
    if redirect_response:
        return redirect_response
    if request.method != 'POST':
        return redirect('/student/recommendations/')
    student = Student.objects.get(user=user)
    position = get_object_or_404(JobPosition, position_id=request.POST.get('position_id'))
    questions, source = get_interview_questions(position)
    for question in questions:
        InterviewRecord.objects.create(
            student=student,
            position=position,
            question=question,
            answer='',
            ai_score=0,
            feedback='待作答｜题目来源：' + ('DeepSeek' if source == 'deepseek' else '规则题库（非AI）'),
            interview_time=timezone.now(),
        )
    return redirect('/student/recommendations/')


@login_required
def submit_interview(request, user, role):
    redirect_response = enforce_role(role, ROLE_STUDENT)
    if redirect_response:
        return redirect_response
    student = Student.objects.get(user=user)
    for key, answer in request.POST.items():
        if not key.startswith('answer_'):
            continue
        interview_id = key.replace('answer_', '')
        record = InterviewRecord.objects.filter(student=student, interview_id=interview_id).first()
        if record:
            score, feedback, source = score_interview_answer(answer, record.question, record.position)
            record.answer = answer
            record.ai_score = score
            record.feedback = feedback
            record.interview_time = timezone.now()
            record.save(update_fields=['answer', 'ai_score', 'feedback', 'interview_time'])
    return redirect('/student/recommendations/')


@login_required
def submit_question(request, user, role):
    redirect_response = enforce_role(role, ROLE_STUDENT)
    if redirect_response:
        return redirect_response
    if request.method != 'POST':
        return redirect('/student/dashboard/')
    student = Student.objects.get(user=user)
    question = request.POST.get('question_content', '').strip()
    target = request.POST.get('qa_target') or request.POST.get('target', 'AI')
    ai_answer = ''
    teacher = None
    if target == 'AI':
        summary = build_learning_summary(student)
        profile = StudentProfile.objects.filter(student=student).first()
        qa_system, qa_prompt, _ = get_prompt('qa')
        result = ai_service.call_chat(
            [
                {'role': 'system', 'content': qa_system},
                {'role': 'system', 'content': qa_prompt},
                {'role': 'user', 'content': json.dumps({
                    'question': question,
                    'platform_context': {
                        'major': student.major.major_name,
                        'completion_rate': summary['completion_rate'],
                        'learning_avg': summary['avg_score'],
                        'training_avg': summary['training_avg'],
                        'weak_ability': profile.weak_ability if profile else '暂无画像',
                    },
                    'data_sources': ['学习记录', '实训记录', '学生画像'],
                }, ensure_ascii=False)},
            ],
            temperature=0.3,
            max_tokens=1000,
            use_case='student_qa',
        )
        if result.success:
            ai_answer = result.content + '\n\n数据依据：学习记录、实训记录、学生画像。'
        else:
            fallback = next((answer for keyword, answer in AI_QA_RULES.items() if keyword in question), DEFAULT_AI_ANSWER)
            ai_answer = '规则知识库降级（未调用AI）：' + fallback
        status = 'AI已回复'
        answer_time = timezone.now()
    else:
        teacher_id = target.split(':', 1)[1] if target.startswith('teacher:') else request.POST.get('teacher_id')
        teacher = Teacher.objects.filter(teacher_id=teacher_id).first() if teacher_id else None
        status = '待回复'
        answer_time = None
    QaRecord.objects.create(
        student=student,
        teacher=teacher,
        question_content=question,
        ai_answer=ai_answer,
        status=status,
        create_time=timezone.now(),
        answer_time=answer_time,
    )
    return redirect('/student/dashboard/')


@login_required
def teacher_answer_question(request, user, role, qa_id):
    redirect_response = enforce_role(role, ROLE_TEACHER)
    if redirect_response:
        return redirect_response
    if request.method != 'POST':
        return redirect('/teacher/dashboard/')
    teacher = Teacher.objects.get(user=user)
    qa_record = get_object_or_404(QaRecord, qa_id=qa_id)
    qa_record.teacher = teacher
    qa_record.teacher_answer = request.POST.get('teacher_answer', '').strip()
    qa_record.answer_time = timezone.now()
    qa_record.status = '教师已回复'
    qa_record.save(update_fields=['teacher', 'teacher_answer', 'answer_time', 'status'])
    return redirect('/teacher/dashboard/')


@login_required
def handle_warning(request, user, role, warning_id):
    redirect_response = enforce_role(role, ROLE_TEACHER)
    if redirect_response:
        return redirect_response
    if request.method != 'POST':
        return redirect('/teacher/stats/')
    warning = get_object_or_404(WarningRecord, warning_id=warning_id)
    warning.status = STATUS_HANDLED
    warning.save(update_fields=['status'])
    set_flash(request, f'{warning.student.user.real_name}的预警已标记为已处理。')
    return redirect('/teacher/stats/')


@login_required
def teacher_dashboard(request, user, role):
    redirect_response = enforce_role(role, ROLE_TEACHER)
    if redirect_response:
        return redirect_response
    teacher = Teacher.objects.get(user=user)
    total_modules = MicroModule.objects.count()
    unfinished_students = Student.objects.annotate(
        completed_modules=Count(
            'learningrecord',
            filter=Q(learningrecord__status=STATUS_DONE),
            distinct=True,
        )
    ).filter(completed_modules__lt=total_modules).count()
    qa_records = (
        QaRecord.objects.select_related('student__user', 'teacher__user')
        .filter(Q(teacher=teacher) | Q(teacher__isnull=True, status='待回复'))
        .exclude(status='AI已回复')
        .order_by('status', '-create_time')[:12]
    )
    recent_training_records = []
    training_records = (
        TrainingRecord.objects.select_related('student__user', 'task')
        .filter(task__teacher=teacher)
        .exclude(submit_content__isnull=True)
        .order_by('-submit_time', '-training_record_id')[:10]
    )
    for item in training_records:
        submit_text, attachments = split_submission_payload(item.submit_content)
        recent_training_records.append({'record': item, 'submit_text': submit_text, 'attachments': attachments})
    return render(request, 'teacher/dashboard.html', {'user': user, 'teacher': teacher, 'modules': MicroModule.objects.all(), 'tasks': TrainingTask.objects.filter(teacher=teacher), 'module_count': total_modules, 'task_count': TrainingTask.objects.filter(teacher=teacher).count(), 'warning_count': WarningRecord.objects.filter(status=STATUS_UNTREATED).count(), 'unfinished_students': unfinished_students, 'qa_records': qa_records, 'recent_training_records': recent_training_records})


@login_required
def teacher_create_module(request, user, role):
    redirect_response = enforce_role(role, ROLE_TEACHER)
    if redirect_response:
        return redirect_response
    if request.method == 'POST':
        try:
            duration_int = int(request.POST.get('duration'))
        except (TypeError, ValueError):
            return render(request, 'teacher/create_module.html', {'user': user, 'error': '\u65f6\u957f\u5fc5\u987b\u4e3a\u6570\u5b57'})
        if duration_int < 5 or duration_int > 15:
            return render(request, 'teacher/create_module.html', {'user': user, 'error': '\u65f6\u957f\u5fc5\u987b\u57285-15\u5206\u949f\u4e4b\u95f4'})
        MicroModule.objects.create(module_name=request.POST.get('module_name'), duration=duration_int, module_type=request.POST.get('module_type', '\u4e13\u4e1a\u6a21\u5757'), difficulty=request.POST.get('difficulty', '\u4f4e'), knowledge_point=request.POST.get('knowledge_point', ''), description=request.POST.get('description', ''))
        return redirect('/teacher/dashboard/')
    return render(request, 'teacher/create_module.html', {'user': user})


@login_required
def teacher_create_training(request, user, role):
    redirect_response = enforce_role(role, ROLE_TEACHER)
    if redirect_response:
        return redirect_response
    if request.method == 'POST':
        teacher = Teacher.objects.get(user=user)
        TrainingTask.objects.create(teacher=teacher, position_id=request.POST.get('position_id') or None, task_name=request.POST.get('task_name'), scene_type=request.POST.get('scene_type'), difficulty=request.POST.get('difficulty'), requirement=request.POST.get('requirement'), deliverable=request.POST.get('deliverable', ''), publish_time=timezone.now())
        return redirect('/teacher/dashboard/')
    return render(request, 'teacher/create_training.html', {'user': user, 'positions': JobPosition.objects.all()})


@login_required
def teacher_stats(request, user, role):
    redirect_response = enforce_role(role, ROLE_TEACHER)
    if redirect_response:
        return redirect_response
    generate_warning_records()
    unfinished_students = []
    total_modules = MicroModule.objects.count()
    for student in Student.objects.select_related('user').all():
        completed = LearningRecord.objects.filter(student=student, status=STATUS_DONE).count()
        if completed < total_modules:
            unfinished_students.append({'student': student, 'user': student.user, 'completed': completed, 'total': total_modules, 'completion_rate': round(completed / total_modules * 100, 1) if total_modules else 0})
    score_queryset = ProcessScore.objects.select_related('student__user').order_by('-total_score')
    score_list = [{'student': ps.student, 'user': ps.student.user, 'score': ps} for ps in score_queryset]
    untreated_warnings = WarningRecord.objects.select_related('student__user').filter(status=STATUS_UNTREATED).order_by('-create_time', '-warning_id')
    handled_warnings = WarningRecord.objects.select_related('student__user').filter(status=STATUS_HANDLED).order_by('-create_time', '-warning_id')[:6]
    warning_list = [{'warning': w, 'user': w.student.user} for w in untreated_warnings]
    handled_warning_list = [{'warning': w, 'user': w.student.user} for w in handled_warnings]
    distribution = ProcessScore.objects.aggregate(
        excellent=Count(Case(When(total_score__gte=85, then=Value(1)), output_field=IntegerField())),
        good=Count(Case(When(total_score__gte=70, total_score__lt=85, then=Value(1)), output_field=IntegerField())),
        passed=Count(Case(When(total_score__gte=60, total_score__lt=70, then=Value(1)), output_field=IntegerField())),
        failed=Count(Case(When(total_score__lt=60, then=Value(1)), output_field=IntegerField())),
    )
    score_distribution = [
        distribution['excellent'] or 0,
        distribution['good'] or 0,
        distribution['passed'] or 0,
        distribution['failed'] or 0,
    ]
    flash_message, flash_level = pop_flash(request)
    return render(request, 'teacher/stats.html', {'user': user, 'unfinished_students': unfinished_students, 'score_list': score_list, 'warning_list': warning_list, 'handled_warning_list': handled_warning_list, 'score_count': len(score_list), 'score_distribution': score_distribution, 'flash_message': flash_message, 'flash_level': flash_level})


@login_required
def admin_positions(request, user, role):
    redirect_response = enforce_role(role, ROLE_ADMIN)
    if redirect_response:
        return redirect_response
    if request.method == 'POST':
        action = request.POST.get('action')
        try:
            if action == 'add_company':
                Company.objects.create(company_name=request.POST.get('company_name'), industry=request.POST.get('industry'), contact_person=request.POST.get('contact_person', ''), contact_phone=request.POST.get('contact_phone', ''))
                set_flash(request, '\u4f01\u4e1a\u5df2\u6dfb\u52a0')
            elif action == 'add_position':
                JobPosition.objects.create(company_id=request.POST.get('company_id'), position_name=request.POST.get('position_name'), industry=request.POST.get('industry', ''), salary_range=request.POST.get('salary_range', ''), description=request.POST.get('description', ''))
                set_flash(request, '\u5c97\u4f4d\u5df2\u6dfb\u52a0')
            elif action == 'add_major':
                Major.objects.create(major_name=request.POST.get('major_name'), college=request.POST.get('college'), description=request.POST.get('description', ''))
                set_flash(request, '\u4e13\u4e1a\u5df2\u6dfb\u52a0')
            elif action == 'add_class':
                ClassInfo.objects.create(major_id=request.POST.get('major_id'), class_name=request.POST.get('class_name'), grade=request.POST.get('grade'))
                set_flash(request, '\u73ed\u7ea7\u5df2\u6dfb\u52a0')
            elif action == 'delete_position':
                JobPosition.objects.filter(position_id=request.POST.get('position_id')).delete()
                set_flash(request, '\u5c97\u4f4d\u5df2\u5220\u9664', 'warning')
            elif action == 'toggle_user_status':
                target_user = get_object_or_404(UserAccount, user_id=request.POST.get('target_user_id'))
                target_user.status = request.POST.get('new_status', STATUS_NORMAL)
                target_user.save(update_fields=['status'])
                set_flash(request, f'\u72b6\u6001\u5df2\u66f4\u65b0\u4e3a{target_user.status}')
            elif action == 'reset_user_password':
                target_user = get_object_or_404(UserAccount, user_id=request.POST.get('target_user_id'))
                new_password = request.POST.get('new_password', '').strip()
                errors = security_service.password_errors(new_password)
                if errors:
                    set_flash(request, '；'.join(errors), 'warning')
                else:
                    target_user.password = security_service.hash_password(new_password)
                    target_user.save(update_fields=['password'])
                    OperationLog.objects.create(
                        operator=user,
                        action='管理员重置用户密码',
                        target_type='user_account',
                        target_id=str(target_user.user_id),
                        detail_json={'username': target_user.username},
                        ip_address=request.META.get('REMOTE_ADDR') or None,
                    )
                    set_flash(request, f'已为{target_user.display_name}重置登录密码')
            elif action == 'ai_recommend':
                selected_student_id = request.POST.get('student_id')
                if selected_student_id:
                    target_student = get_object_or_404(Student.objects.select_related('user'), student_id=selected_student_id)
                else:
                    target_student = None
                    target_summary = None
                    for candidate in Student.objects.select_related('user').all():
                        candidate_summary = build_learning_summary(candidate)
                        if target_student is None or candidate_summary['completion_rate'] < target_summary['completion_rate']:
                            target_student = candidate
                            target_summary = candidate_summary
                if target_student:
                    created = ensure_student_recommendations(target_student, force=True)
                    set_flash(request, f'\u5df2\u4e3a{target_student.user.real_name}\u751f\u6210{created}\u6761\u63a8\u8350')
                else:
                    set_flash(request, '\u6682\u65e0\u5b66\u751f\u6570\u636e', 'warning')
            elif action == 'batch_ai_recommend':
                student_count, total_created = batch_generate_all_recommendations()
                set_flash(request, f'已为{student_count}名学生批量生成{total_created}条智能推荐')
        except IntegrityError:
            set_flash(request, '\u6570\u636e\u51b2\u7a81\uff0c\u8bf7\u68c0\u67e5\u91cd\u590d\u8bb0\u5f55', 'warning')
        cache.delete(ADMIN_CONTEXT_CACHE_KEY)
        return redirect('/admin/positions/')
    context = build_admin_context(user)
    position_query = JobPosition.objects.select_related('company').all().order_by(
        'company__company_name', 'position_name'
    )
    search = request.GET.get('q', '').strip()[:80]
    industry = request.GET.get('industry', '').strip()[:80]
    company_id = request.GET.get('company', '').strip()
    if search:
        position_query = position_query.filter(
            Q(position_name__icontains=search) | Q(description__icontains=search)
        )
    if industry:
        position_query = position_query.filter(industry=industry)
    if company_id.isdigit():
        position_query = position_query.filter(company_id=int(company_id))
    position_page = Paginator(position_query, 12).get_page(request.GET.get('position_page'))
    context['positions'] = list(position_page.object_list)
    context['position_page_obj'] = position_page
    context['position_filters'] = {'q': search, 'industry': industry, 'company': company_id}
    context['industries'] = JobPosition.objects.exclude(industry='').values_list(
        'industry', flat=True
    ).distinct().order_by('industry')
    user_page = Paginator(context['user_rows'], 15).get_page(request.GET.get('user_page'))
    context['user_rows'] = list(user_page.object_list)
    context['user_page_obj'] = user_page
    flash_message, flash_level = pop_flash(request)
    context.update({'flash_message': flash_message, 'flash_level': flash_level})
    return render(request, 'admin/positions.html', context)


def register_view(request):
    majors = Major.objects.all()
    classes = ClassInfo.objects.all()
    if request.method == 'POST':
        username = request.POST.get('username')
        if UserAccount.objects.filter(username=username).exists():
            return render(request, 'register.html', {'error': '\u7528\u6237\u540d\u5df2\u5b58\u5728', 'majors': majors, 'classes': classes})
        try:
            role = RoleInfo.objects.get(role_name=request.POST.get('role_type'))
        except RoleInfo.DoesNotExist:
            return render(request, 'register.html', {'error': '\u89d2\u8272\u914d\u7f6e\u5f02\u5e38', 'majors': majors, 'classes': classes})
        raw_password = request.POST.get('password', '')
        errors = security_service.password_errors(raw_password)
        if errors:
            return render(request, 'register.html', {'error': '；'.join(errors), 'majors': majors, 'classes': classes})
        role_type = request.POST.get('role_type')
        real_name = request.POST.get('real_name', '').strip()
        if role_type == ROLE_TEACHER:
            real_name = normalize_teacher_real_name(real_name)
        user = UserAccount.objects.create(role=role, username=username, password=security_service.hash_password(raw_password), real_name=real_name, phone=request.POST.get('phone') or None, email=request.POST.get('email') or None, status=STATUS_NORMAL, create_time=timezone.now())
        if role_type == ROLE_STUDENT:
            Student.objects.create(user=user, major_id=request.POST.get('major_id'), class_field_id=request.POST.get('class_id'), student_no=request.POST.get('student_no'), enrollment_year=request.POST.get('enrollment_year'))
        elif role_type == ROLE_TEACHER:
            Teacher.objects.create(user=user, teacher_no=request.POST.get('teacher_no'), title=request.POST.get('title', ''), department=request.POST.get('department'))
        return redirect('/login/')
    return render(request, 'register.html', {'majors': majors, 'classes': classes})


# ==================== AI 学习助手 / 学生能力分析（大模型接口） ====================

@api_login_required
def ai_chat_api(request, user, role):
    """
    AI 学习助手对话接口。
    POST JSON: {"message": "...", "history": [{"role": "user"/"assistant", "content": "..."}]}
    未配置 AI_API_KEY 时返回规范降级提示，不会导致页面崩溃。
    """
    if request.method != 'POST':
        return JsonResponse({'success': False, 'error': '仅支持 POST 请求'}, status=405)
    limited = _ai_rate_limit_response(
        request, 'chat', int(getattr(settings, 'AI_RATE_LIMIT_PER_MINUTE', 12))
    )
    if limited:
        return limited

    try:
        payload = json.loads(request.body or '{}')
    except (json.JSONDecodeError, UnicodeDecodeError):
        return JsonResponse({'success': False, 'error': '请求格式错误，无法解析 JSON'}, status=400)

    message = (payload.get('message') or '').strip()
    if not message:
        return JsonResponse({'success': False, 'error': '请输入问题内容后再发送'}, status=400)
    if len(message) > 2000:
        message = message[:2000]

    if not ai_service.is_ai_configured():
        return JsonResponse({
            'success': False,
            'code': 'AI_NOT_CONFIGURED',
            'error': 'AI学习助手尚未配置。请联系管理员配置 AI_API_KEY 后重启服务。',
        }, status=503)

    history = payload.get('history') or []
    messages = [{'role': 'system', 'content': AI_SYSTEM_PROMPT}]
    if isinstance(history, list):
        for item in history[-6:]:
            if not isinstance(item, dict):
                continue
            role_name = item.get('role')
            content = item.get('content')
            if role_name in ('user', 'assistant') and content:
                messages.append({'role': role_name, 'content': str(content)[:1000]})
    messages.append({'role': 'user', 'content': message})

    success, content = ai_service.call_ai_chat(messages)
    if not success:
        return JsonResponse({'success': False, 'code': 'AI_ERROR', 'error': content})
    return JsonResponse({'success': True, 'reply': content})


@api_login_required
def ai_student_analysis_api(request, user, role):
    """
    学生能力分析接口。
    结合平台已有的学习记录 / 实训 / 测评 / 能力画像数据生成分析。
    未配置 AI_API_KEY 时，基于平台数据用规则拼装一份说明性分析，不会凭空编造真实成绩。
    """
    if not role or role.role_name != ROLE_STUDENT:
        return JsonResponse({'success': False, 'error': '仅学生账号可使用学生能力分析功能'}, status=403)
    limited = _ai_rate_limit_response(
        request, 'student-analysis', int(getattr(settings, 'AI_RATE_LIMIT_PER_MINUTE', 12))
    )
    if limited:
        return limited

    student = Student.objects.select_related('major').get(user=user)
    profile = refresh_student_profile(student)
    summary = build_learning_summary(student)
    top3_positions = pick_top3_positions(student, profile)
    ability_details = top3_positions[0]['ability_details'] if top3_positions else []
    top3_modules = pick_top3_modules(student, profile, summary, ability_details)
    radar_labels, radar_scores = build_radar_data(student)

    strengths = [label for label, score in zip(radar_labels, radar_scores) if score >= 70]
    weaknesses = [label for label, score in zip(radar_labels, radar_scores) if score < 60]
    recommend_courses = [item['module'].module_name for item in top3_modules]
    career_advice = top3_positions[0]['reason'] if top3_positions else '暂无可匹配岗位，建议先完善学习记录与职业能力测评。'

    fallback_text = (
        '【基于当前平台记录生成】\n'
        f'学习完成率 {summary["completion_rate"]}%，学习平均分 {summary["avg_score"]}，'
        f'实训平均分 {summary["training_avg"]}，测评平均分 {summary["assessment_avg"]}。\n\n'
        f'优势：{"、".join(strengths) if strengths else "现有学习记录较少，暂未识别出明显优势能力"}\n'
        f'薄弱点：{"、".join(weaknesses) if weaknesses else "暂未发现明显短板"}\n'
        f'学习建议：优先完成尚未学习的微模块，并针对薄弱能力对应的实训任务加强练习。\n'
        f'推荐课程：{"、".join(recommend_courses) if recommend_courses else "暂无可推荐课程，建议先完成更多微模块学习"}\n'
        f'就业能力建议：{career_advice}'
    )

    if not ai_service.is_ai_configured():
        return JsonResponse({
            'success': True,
            'source': 'rule_based',
            'analysis': fallback_text,
            'note': 'AI_API_KEY 未配置，以上内容基于平台已有数据规则生成；配置 AI 服务后可获得更细致的大模型分析。',
        })

    prompt_data = {
        '专业': student.major.major_name,
        '学习完成率': f'{summary["completion_rate"]}%',
        '学习平均分': summary['avg_score'],
        '实训平均分': summary['training_avg'],
        '测评平均分': summary['assessment_avg'],
        '能力画像': [f'{label}:{score}分' for label, score in zip(radar_labels, radar_scores)],
        '推荐课程候选': recommend_courses,
        '匹配岗位候选': [item['position'].position_name for item in top3_positions],
    }
    user_prompt = (
        '以下是某学生在教学平台上的真实记录数据（JSON格式），请仅基于这些数据生成学生能力分析，'
        '不要编造数据中不存在的内容。请分别输出以下五个部分："优势""薄弱点""学习建议""推荐课程""就业能力建议"，'
        '每部分2-4句话，语言适合大学生阅读。\n数据：' + json.dumps(prompt_data, ensure_ascii=False)
    )
    messages = [
        {'role': 'system', 'content': AI_SYSTEM_PROMPT},
        {'role': 'user', 'content': user_prompt},
    ]
    success, content = ai_service.call_ai_chat(messages, max_tokens=900)
    if not success:
        return JsonResponse({
            'success': True,
            'source': 'rule_based_fallback',
            'analysis': fallback_text,
            'note': f'AI 服务暂时不可用（{content}），已展示基于平台数据规则生成的分析。',
        })
    return JsonResponse({'success': True, 'source': 'ai', 'analysis': content})


# ==================== B1 实训评价闭环 ====================

@login_required
def student_evaluation_reports(request, user, role):
    redirect_response = enforce_role(role, ROLE_STUDENT)
    if redirect_response:
        return redirect_response
    student = Student.objects.get(user=user)
    rows = []
    submissions = TrainingSubmission.objects.filter(student=student).select_related(
        'task', 'rubric'
    ).order_by('-submitted_at', '-submission_id')
    for submission in submissions:
        evaluation = AIEvaluation.objects.filter(submission=submission).order_by('-evaluation_id').first()
        review = TeacherReview.objects.filter(evaluation=evaluation).first() if evaluation else None
        rows.append({'submission': submission, 'evaluation': evaluation, 'review': review})
    return render(request, 'student/evaluation_reports.html', {
        'user': user,
        'student': student,
        'rows': rows,
    })


@login_required
def student_evaluation_detail(request, user, role, submission_id):
    redirect_response = enforce_role(role, ROLE_STUDENT)
    if redirect_response:
        return redirect_response
    student = Student.objects.get(user=user)
    submission = get_object_or_404(
        TrainingSubmission.objects.select_related('task', 'rubric'),
        submission_id=submission_id,
        student=student,
    )
    evaluation = get_object_or_404(
        AIEvaluation.objects.select_related('rubric'), submission=submission
    )
    details = AIEvaluationDimension.objects.filter(evaluation=evaluation).select_related(
        'dimension'
    ).order_by('dimension__dimension_order')
    review = TeacherReview.objects.filter(evaluation=evaluation).select_related('teacher__user').first()
    previous_submission = TrainingSubmission.objects.filter(
        student=student,
        task=submission.task,
        version_no__lt=submission.version_no,
    ).order_by('-version_no').first()
    comparison = None
    if previous_submission:
        previous_evaluation = AIEvaluation.objects.filter(submission=previous_submission).first()
        if previous_evaluation:
            comparison = evaluation_service.compare_versions(
                previous_evaluation.raw_response_json,
                evaluation.raw_response_json,
            )
    return render(request, 'student/evaluation_detail.html', {
        'user': user,
        'submission': submission,
        'evaluation': evaluation,
        'details': details,
        'review': review,
        'comparison': comparison,
        'files': SubmissionFile.objects.filter(submission=submission).order_by('file_id'),
    })


def _save_rubric(task, teacher, payload, source):
    dimensions = evaluation_service.validate_dimensions(payload.get('dimensions') or [])
    with transaction.atomic():
        TrainingTask.objects.select_for_update().filter(task_id=task.task_id).exists()
        latest_version = EvaluationRubric.objects.filter(task=task).aggregate(
            latest=Max('version_no')
        )['latest'] or 0
        EvaluationRubric.objects.filter(task=task, is_active=True).update(is_active=False)
        rubric = EvaluationRubric.objects.create(
            task=task,
            created_by=teacher,
            rubric_name=str(payload.get('name') or f'{task.task_name}评价量规')[:120],
            description=str(payload.get('description') or '')[:5000],
            version_no=latest_version + 1,
            total_weight=100,
            source=source,
            prompt_version=get_prompt('rubric_generation')[2],
            status='已发布',
            is_active=True,
        )
        for order, item in enumerate(dimensions, 1):
            RubricDimension.objects.create(
                rubric=rubric,
                dimension_order=order,
                dimension_name=item['name'],
                weight=item['weight'],
                max_score=item['max_score'],
                criteria=str(item.get('criteria') or ''),
                excellent_standard=str(item.get('excellent_standard') or ''),
                qualified_standard=str(item.get('qualified_standard') or ''),
                common_issues=str(item.get('common_issues') or ''),
                ai_enabled=bool(item.get('ai_enabled', True)),
                teacher_review_required=bool(item.get('teacher_review_required', False)),
            )
    return rubric


@login_required
def teacher_rubrics(request, user, role):
    redirect_response = enforce_role(role, ROLE_TEACHER)
    if redirect_response:
        return redirect_response
    teacher = Teacher.objects.get(user=user)
    if request.method == 'POST':
        task = get_object_or_404(TrainingTask, task_id=request.POST.get('task_id'), teacher=teacher)
        action = request.POST.get('action', 'default')
        try:
            if action == 'ai_generate':
                result = evaluation_service.generate_rubric({
                    'task_name': task.task_name,
                    'scene_type': task.scene_type,
                    'difficulty': task.difficulty,
                    'requirement': task.requirement,
                    'deliverable': task.deliverable,
                })
                source = 'deepseek' if result.success else 'rule_based_fallback'
                rubric = _save_rubric(task, teacher, result.data, source)
                note = 'DeepSeek 已生成量规' if result.success else 'DeepSeek 不可用，已创建待教师确认的默认量规'
            elif action == 'copy':
                source_rubric = get_object_or_404(
                    EvaluationRubric.objects.prefetch_related('dimensions'),
                    rubric_id=request.POST.get('rubric_id'),
                    created_by=teacher,
                )
                payload = {
                    'name': source_rubric.rubric_name + '（副本）',
                    'description': source_rubric.description,
                    'dimensions': [
                        {
                            'name': item.dimension_name,
                            'weight': item.weight,
                            'max_score': item.max_score,
                            'criteria': item.criteria,
                            'excellent_standard': item.excellent_standard,
                            'qualified_standard': item.qualified_standard,
                            'common_issues': item.common_issues,
                            'ai_enabled': item.ai_enabled,
                            'teacher_review_required': item.teacher_review_required,
                        }
                        for item in source_rubric.dimensions.all()
                    ],
                }
                rubric = _save_rubric(task, teacher, payload, 'teacher_copy')
                note = '量规已复制为新版本'
            else:
                payload = {
                    'name': f'{task.task_name}标准量规',
                    'description': '教师从平台标准维度创建，可继续在数据库或后续版本中调整。',
                    'dimensions': evaluation_service.default_dimensions(),
                }
                rubric = _save_rubric(task, teacher, payload, 'teacher')
                note = '标准量规已创建'
            OperationLog.objects.create(
                operator=user,
                action='创建评价量规',
                target_type='evaluation_rubric',
                target_id=str(rubric.rubric_id),
                detail_json={'source': rubric.source, 'version': rubric.version_no},
            )
            set_flash(request, note)
        except evaluation_service.InvalidRubric as exc:
            set_flash(request, str(exc), 'warning')
        return redirect('/teacher/rubrics/')
    flash_message, flash_level = pop_flash(request)
    return render(request, 'teacher/rubrics.html', {
        'user': user,
        'teacher': teacher,
        'tasks': TrainingTask.objects.filter(teacher=teacher).order_by('-publish_time'),
        'rubrics': EvaluationRubric.objects.filter(created_by=teacher).select_related(
            'task'
        ).order_by('-update_time', '-rubric_id'),
        'flash_message': flash_message,
        'flash_level': flash_level,
    })


@login_required
def teacher_review_queue(request, user, role):
    redirect_response = enforce_role(role, ROLE_TEACHER)
    if redirect_response:
        return redirect_response
    teacher = Teacher.objects.get(user=user)
    evaluations = AIEvaluation.objects.filter(
        submission__task__teacher=teacher
    ).select_related(
        'submission__student__user', 'submission__task', 'rubric'
    ).order_by('status', '-evaluated_at')
    return render(request, 'teacher/review_queue.html', {
        'user': user,
        'teacher': teacher,
        'evaluations': evaluations,
        'pending_count': evaluations.filter(status='待教师复核').count(),
    })


@login_required
def teacher_review_detail(request, user, role, evaluation_id):
    redirect_response = enforce_role(role, ROLE_TEACHER)
    if redirect_response:
        return redirect_response
    teacher = Teacher.objects.get(user=user)
    evaluation = get_object_or_404(
        AIEvaluation.objects.select_related(
            'submission__student__user', 'submission__task', 'rubric'
        ),
        evaluation_id=evaluation_id,
        submission__task__teacher=teacher,
    )
    details = list(AIEvaluationDimension.objects.filter(evaluation=evaluation).select_related(
        'dimension'
    ).order_by('dimension__dimension_order'))
    if request.method == 'POST':
        adjusted = {}
        weighted_score = 0
        for detail in details:
            raw_score = request.POST.get(f'dimension_{detail.detail_id}', detail.score)
            score = evaluation_service.clamp(raw_score, 0, float(detail.max_score))
            adjusted[str(detail.dimension_id)] = score
            weighted_score += (
                score / float(detail.max_score or 100) * float(detail.dimension.weight)
            )
        teacher_score = round(weighted_score, 1)
        decision = request.POST.get('decision', '通过')
        if decision not in {'通过', '退回', '要求重交'}:
            decision = '退回'
        review, _ = TeacherReview.objects.update_or_create(
            evaluation=evaluation,
            defaults={
                'teacher': teacher,
                'adjusted_scores_json': adjusted,
                'teacher_comment': request.POST.get('teacher_comment', '').strip(),
                'ai_error_notes': request.POST.get('ai_error_notes', '').strip(),
                'decision': decision,
                'teacher_score': teacher_score,
                'final_score': teacher_score,
            },
        )
        evaluation.status = '已复核' if decision == '通过' else decision
        evaluation.save(update_fields=['status'])
        evaluation.submission.status = evaluation.status
        evaluation.submission.save(update_fields=['status'])
        TrainingRecord.objects.filter(
            student=evaluation.submission.student,
            task=evaluation.submission.task,
        ).update(
            teacher_score=round(float(review.final_score)),
            status=STATUS_EVALUATED,
        )
        OperationLog.objects.create(
            operator=user,
            action='教师复核实训评价',
            target_type='ai_evaluation',
            target_id=str(evaluation.evaluation_id),
            detail_json={
                'decision': decision,
                'ai_score': float(evaluation.total_score),
                'teacher_score': teacher_score,
            },
        )
        set_flash(request, '复核结果已保存，学生端最终成绩已同步。')
        return redirect('/teacher/reviews/')
    return render(request, 'teacher/review_detail.html', {
        'user': user,
        'teacher': teacher,
        'evaluation': evaluation,
        'details': details,
        'review': TeacherReview.objects.filter(evaluation=evaluation).select_related(
            'teacher__user'
        ).first(),
        'files': SubmissionFile.objects.filter(submission=evaluation.submission),
    })


@login_required
def report_center(request, user, role):
    if role.role_name not in {ROLE_TEACHER, ROLE_ADMIN}:
        return redirect(get_role_home(role))
    queryset = AIEvaluation.objects.select_related(
        'submission__student__user', 'submission__student__major',
        'submission__student__class_field', 'submission__task',
        'teacher_review__teacher__user'
    )
    if role.role_name == ROLE_TEACHER:
        teacher = Teacher.objects.get(user=user)
        queryset = queryset.filter(submission__task__teacher=teacher)
    major_id = request.GET.get('major_id')
    class_id = request.GET.get('class_id')
    task_id = request.GET.get('task_id')
    if major_id:
        queryset = queryset.filter(submission__student__major_id=major_id)
    if class_id:
        queryset = queryset.filter(submission__student__class_field_id=class_id)
    if task_id:
        queryset = queryset.filter(submission__task_id=task_id)
    rows = queryset.order_by('-evaluated_at')
    if request.GET.get('format') == 'csv':
        response = HttpResponse(content_type='text/csv; charset=utf-8')
        response['Content-Disposition'] = 'attachment; filename="b1_evaluation_report.csv"'
        response.write('\ufeff')
        import csv

        writer = csv.writer(response)
        writer.writerow(['学生', '专业', '班级', '实训任务', '提交版本', 'AI/预检分', '来源', '复核教师', '教师分', '最终分', '状态', '评价时间'])
        for item in rows:
            review = getattr(item, 'teacher_review', None)
            writer.writerow([
                item.submission.student.user.real_name,
                item.submission.student.major.major_name,
                item.submission.student.class_field.class_name,
                item.submission.task.task_name,
                item.submission.version_no,
                item.total_score,
                'DeepSeek' if item.is_ai_generated else '规则预检',
                review.teacher.user.display_name if review else '',
                review.teacher_score if review else '',
                review.final_score if review else '',
                item.status,
                timezone.localtime(item.evaluated_at).strftime('%Y-%m-%d %H:%M'),
            ])
        return response
    summary = rows.aggregate(avg_ai=Avg('total_score'), total=Count('evaluation_id'))
    reviewed_count = TeacherReview.objects.filter(evaluation__in=rows).count()
    return render(request, 'reports/center.html', {
        'user': user,
        'role': role,
        'rows': rows[:200],
        'summary': summary,
        'reviewed_count': reviewed_count,
        'majors': Major.objects.all().order_by('major_name'),
        'classes': ClassInfo.objects.select_related('major').all().order_by('class_name'),
        'tasks': TrainingTask.objects.all().order_by('-publish_time'),
    })


@api_login_required
def ai_chat_stream_api(request, user, role):
    if request.method != 'POST':
        return JsonResponse({'success': False, 'error': '仅支持 POST'}, status=405)
    limited = _ai_rate_limit_response(
        request,
        'chat-stream',
        int(getattr(settings, 'AI_STREAM_RATE_LIMIT_PER_MINUTE', 6)),
    )
    if limited:
        return limited
    try:
        payload = json.loads(request.body or '{}')
    except (json.JSONDecodeError, UnicodeDecodeError):
        return JsonResponse({'success': False, 'error': 'JSON 格式错误'}, status=400)
    message = str(payload.get('message') or '').strip()[:2000]
    page_context = str(payload.get('page_context') or '')[:200]
    if not message:
        return JsonResponse({'success': False, 'error': '问题不能为空'}, status=400)
    qa_system, qa_prompt, _ = get_prompt('qa')
    messages = [
        {'role': 'system', 'content': qa_system},
        {'role': 'system', 'content': qa_prompt},
        {'role': 'user', 'content': f'当前页面：{page_context or "未知页面"}\n用户问题：{message}'},
    ]

    def event_stream():
        try:
            for chunk in ai_service.stream_chat(messages):
                yield f'data: {json.dumps({"text": chunk}, ensure_ascii=False)}\n\n'
            yield 'data: {"done": true}\n\n'
        except Exception as exc:
            logger.warning('AI streaming request failed: %s', type(exc).__name__)
            yield 'data: {"error": "AI调用失败，未生成AI结果；当前可继续使用规则降级功能。"}\n\n'

    response = StreamingHttpResponse(event_stream(), content_type='text/event-stream; charset=utf-8')
    response['Cache-Control'] = 'no-cache'
    response['X-Accel-Buffering'] = 'no'
    return response
