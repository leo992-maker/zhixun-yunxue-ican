"""智训云学历史B1拓展能力合成成果（V2）。

仅用于展示安全文件上传、静态解析和版本化评价：无网络请求、无密钥、
无个人信息，也不会在平台侧执行。
"""


def summarize_scores(rows):
    """Return a small, deterministic summary for valid numeric scores."""
    values = [float(row["score"]) for row in rows if row.get("score") is not None]
    if not values:
        return {"count": 0, "average": 0.0, "maximum": 0.0}
    return {
        "count": len(values),
        "average": round(sum(values) / len(values), 2),
        "maximum": max(values),
    }


if __name__ == "__main__":
    synthetic_rows = [{"score": 72}, {"score": 88}, {"score": 94}]
    print(summarize_scores(synthetic_rows))
