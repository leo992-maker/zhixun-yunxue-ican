"""智训云学历史B1拓展能力合成成果（V1）：供版本对比使用。"""


def average_score(values):
    if not values:
        return 0
    return sum(values) / len(values)


if __name__ == "__main__":
    print(average_score([72, 88, 94]))
