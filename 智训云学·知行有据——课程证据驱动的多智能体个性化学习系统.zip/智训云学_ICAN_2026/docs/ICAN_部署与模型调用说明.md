# 智训云学 · 评委访问和模型调用

更新：2026-09-29。此文档区分三个地址/成果：

| 入口 | 作用 | 状态 |
|---|---|---|
| 已发布界面预览 | 不登录即可浏览 4 张真实演示界面、学习流程 | 可供评委看外观；**不是**后台智能体运行站 |
| 原 Django `/showcase/` | 与预览页同样的只读界面，在完整系统部署后无需登录访问 | 源码和测试已完成；需部署主机 |
| 原 Django `/login/` | 学生账号操作生成、题目与路径；教师/管理端另有权限 | 需部署 Web、Worker、MySQL，配置模型凭据及隔离演示数据 |

## Windows 本地：最少操作跑出完整交互界面

1. 在 Windows 安装、启动 Docker Desktop（包含 Docker Compose），等待引擎显示运行。解压**整个** `03_可运行项目/`，不要双击 ZIP 内的文件。
2. 双击 `一键启动本地演示.bat`，首次下载镜像并构建网站。它创建私有 `deploy/local-demo.env`、随机数据库密码、随机管理员/教师/学生密码、独立数据库卷；不需要你单独安装 MySQL 或 Python。
3. 启动窗口会给出学生账号 `s001` 和本次密码，并打开 `http://127.0.0.1:8000/login/`。登录后从课程知识点发起**新**资源生成任务，查看 Run/Step、生成资源、答题、路径变化。`http://127.0.0.1:8000/showcase/` 是本机界面导览，`/login/` 才是完整系统。
4. 模型可后配：双击 `配置并验证模型.bat`，在打开的记事本中按下面的表填入密钥，保存并关闭；脚本自动重启 Web/Worker，向已配置提供者发出真实最短请求。失败时给出状态，不把密钥打印到屏幕。未填密钥时项目可运行，但只会规则降级。
5. 诊断用 `查看本地运行状态.bat`；停止用 `停止本地演示.bat`。后者保留独立数据库卷；不要执行 `docker compose down -v`，除非你明确要删掉本机演示数据。若 `init` 报 `MYSQL_PASSWORD` 与旧数据卷不匹配，恢复原来的 `deploy/local-demo.env`；若旧数据不需要，双击 `重置本地演示数据.bat` 并输入 `RESET`，再重新启动。

**已有旧版且已启动成功时更新代码**：先保留当前 `deploy/local-demo.env` 和 Docker 数据卷，将新版 `03_可运行项目` 的源码覆盖到同一项目目录，不要复制私有配置文件或清理卷。重新双击 `一键启动本地演示.bat` 会构建新镜像。已经生成的旧 PPTX 不会自动重排；需在资源中心发起**新的**任务，下载该任务生成的 PPTX。任务页的证据链也只展示该任务实际记录。

**免费模型选择**：讯飞控制台可能展示限时免费或免费的 Spark 版本；优惠、额度和 API 权限以你的控制台实际开通状态为准。不要把网页展示名直接猜成 API 参数，必须进入该模型的“API调用/接入说明”，复制它给出的 Model ID、接口地址和密钥类型。项目支持下面两种星火 OpenAI 兼容接口模式：

**本次交付的稳妥推荐**：使用你已经在控制台开通并验证过的 `Spark-X2.5-1.7B`，配置为 `spark-x2.5-1.7b` + MaaS `/v2` 地址。它与项目默认的 `SparkProvider` 直接对应，后台日志会真实标记为 `spark`；GLM-5.3 保留为可选提供商。模型是否免费以“用量查询”页面为准，不能把“已开通”理解成无限免费。

| 模式 | `SPARK_BASE_URL` | `SPARK_MODEL` | `SPARK_API_PASSWORD` 实际填写内容 |
|---|---|---|---|
| 传统星火 HTTP 接口 | `https://spark-api-open.xf-yun.com/v1` | 例如 `generalv3.5`（以已授权版本为准） | 控制台对应版本的 APIPassword |
| 星辰 MaaS / X2.5 | 控制台 API调用页给出的 `/v2` 地址，例如 `https://maas-api.cn-huabei-1.xf-yun.com/v2` | API调用页给出的 Model ID；官方示例为 `spark-x2.5`，X2.5-4B/1.7B 以你页面显示的实际 ID 为准 | API调用页给出的 API Key（项目仍放在这个字段，代码以 Bearer 方式发送） |

讯飞官方的[产品使用说明](https://www.xfyun.cn/doc/spark/%E4%BA%A7%E5%93%81%E4%BD%BF%E7%94%A8%E8%AF%B4%E6%98%8E.html)给出了 `spark-x2.5` 的 MaaS 示例；旧版[星火 HTTP 文档](https://www.xfyun.cn/doc/spark/HTTP%E8%B0%83%E7%94%A8%E6%96%87%E6%A1%A3.html)仍使用 `generalv3.5` 和 `spark-api-open.xf-yun.com/v1`。两种模式的地址、模型 ID 和凭据不能交叉使用。保存后双击验证脚本，必须看到 `spark: SUCCESS` 才能在视频中宣称在线调用成功。

| 需要的能力 | 你要取得什么 | 填入私有文件的字段 | 是否必需 |
|---|---|---|---|
| 星火在线文本生成（本项目主模型） | 在[讯飞开放平台星火控制台](https://console.xfyun.cn/)开通对应模型，取该模型版本的 **APIPassword** | `SPARK_API_PASSWORD`，`SPARK_MODEL` 对应有授权的模型 | 想证明在线主模型时必需 |
| GLM-5.3（讯飞 MaaS） | 在讯飞模型 API调用页开通 GLM-5.3，复制 API Key、Base URL、Model ID | `A3_MODEL_PROVIDER=glm`、`GLM_API_KEY`、`GLM_BASE_URL`、`GLM_MODEL` | 可选；可作为 A3 主模型 |
| DeepSeek 文本（备用及 B1 扩展） | 在 [DeepSeek API 平台](https://platform.deepseek.com/api_keys)创建 **API Key**；确认服务额度 | `AI_API_KEY`；默认 `AI_MODEL=deepseek-flash` | 可选；主模型失败时需要备用则必需 |
| 讯飞在线语音合成 | 在[讯飞在线语音合成控制台](https://console.xfyun.cn/)开通该服务，取 **AppID、APIKey、APISecret** | `SPARK_TTS_APP_ID`、`SPARK_TTS_API_KEY`、`SPARK_TTS_API_SECRET` | 可选；仅微课音频需要 |

账号和模型服务在你名下开通；我不能从供应商网站代你领取密钥。**不用下载或在电脑部署大模型权重**，本项目通过 HTTPS/WebSocket 调用供应商的在线 API。星火模型版本、对应 APIPassword 与额度必须匹配；拿到一个平台的网页聊天账号不等于拥有 API 权限。请勿把 `local-demo.env` 或密钥截图放入项目、提交页、GitHub 或聊天。

本机地址仅供录屏和自测，评委的电脑不能访问它。交给评委的完整交互站仍需使用以下公网部署流程；已公开的界面导览只提供截图浏览。

## 文件导航

```text
智训云学_ICAN_2026/
├── README.md                       项目运行总入口
├── 参赛交付导航.md                  从这里开始
├── 一键启动本地演示.bat             Windows 本机完整系统启动
├── 配置并验证模型.bat               私有配置和 API 真连通检查
├── 查看本地运行状态.bat / 停止本地演示.bat
├── deploy/
│   ├── Dockerfile                  Web/Worker 同一镜像
│   ├── compose.local.yaml          本机 MySQL、初始化、Web、Worker
│   ├── compose.yaml                公网 MySQL、初始化、Web、Worker、HTTPS
│   ├── Caddyfile                   域名与 HTTPS 反向代理
│   └── public-demo.env.example     复制并在主机私有填写
├── app/                             登录、B1 教学业务、评委预览页
├── agent_learning/                  A3 画像、检索、资源、路径、辅导与多智能体
├── myproject/                       Django 配置与路由
├── demo_assets/                     演示数据需要的两份样例代码
├── scripts/                         四个 Windows 入口的实现
├── docs/
│   ├── ICAN_2026_改造与交付清单.md    差距、PDF 页序、评估设计
│   ├── ICAN_复赛应用方案.pdf          18 页应用方案
│   ├── ICAN_五分钟演示脚本.md        视频操作顺序
│   └── ICAN_部署与模型调用说明.md    本文
├── tools/                           去敏打包、部署初始化与检查
└── employment_ai_platform_optimized.sql 首次空库初始化
```

`employment_ai_platform_optimized.sql` 是首次建库必需的**结构与演示基础数据**文件，交付包会保留它；真实 `.env`、`deploy/public-demo.env`、`deploy/local-demo.env`、上传文件、媒体文件、数据库文件和虚拟环境不在交付包里。

## 公网部署步骤（有域名和 Linux 主机后）

1. 域名 A 记录指向主机公网 IP；放通 80/443；主机安装 Docker Compose。单独准备演示用主机及数据库，不能连接真实学生数据。
2. 复制 `deploy/public-demo.env.example` 为 `deploy/public-demo.env`，填写真实域名、随机数据库密码、至少 50 字符的 Django 密钥，以及彼此不同且至少 16 字符的管理员/教师/学生演示密码。模型字段可先留空，但此时只会显示规则降级；将供应商密钥仅放在这个主机私有文件中。
3. 在项目根目录执行 `docker compose --env-file deploy/public-demo.env -f deploy/compose.yaml up -d --build`。第一次启动仅在**空数据库**上运行旧 SQL 初始化；遇到非空的异项目数据库会停止。之后执行迁移、生成演示数据并立即轮换所有种子账号的密码。
4. 执行 `docker compose --env-file deploy/public-demo.env -f deploy/compose.yaml ps`，确认 `init` 成功结束，`db/web/worker/https` 运行。访问 `https://你的域名/showcase/`、`/health/live/`、`/health/ready/` 与 `/login/`。
5. 从手机流量/校外设备登录学生演示账号，完成一次选择知识点→发起任务→查看真实 Run→作答→路径调整。将**地址与学生账号**填入提交说明，教师/管理员密码仅由团队保管。
   若要实测模型，在配置有效凭据后执行 `docker compose --env-file deploy/public-demo.env -f deploy/compose.yaml exec web python manage.py verify_ai_services --include-tts`；输出只含结果、模型与耗时，不打印密钥或回答内容。
6. 持续运行到评审结束，关注 Worker 状态、磁盘、模型额度和匿名演示数据；定期备份 MySQL 与媒体卷。修改代码后需重新构建；不要对已有非空库执行 `init_db.py`。

本仓库内没有域名、主机或模型密钥，所以不能宣称上面的公网环境已经完成。HTTPS 预览链接只保证评委看界面；完整交互站需按上述步骤在团队主机另行上线。

## 模型调用边界

| 功能 | 实际入口 | 主模型与备用 | 校验、记录与降级 |
|---|---|---|---|
| 画像访谈字段抽取 | `apply_profile_message` | 不调用模型；固定规则抽取 | 对话与来源标注“规则抽取”，不宣称在线 AI |
| 画像分析、资源策划、审核建议、路径规划 | `structured_agent_call` | `A3_MODEL_PROVIDER=spark` 或 `glm` 时先对应主模型；失败再 DeepSeek | JSON 契约校验、一次修复；调用尝试由 Agent 保存，最终可规则降级 |
| 七类资源生成 | `generate_resource` → `_model_content` | 星火或 GLM 主模型，失败再 DeepSeek | 每类 Schema、修复尝试、知识片段引用、来源标签；失败用规则构建，不冒充在线生成 |
| 课程导师问答 | `answer_tutor` | 星火优先，失败再 DeepSeek | 知识点限定检索；无证据拒答；输出安全检查；消息标记主/备用/规则来源 |
| 微课语音与视频 | `SparkTTSProvider.synthesize`、`export_microcourse_video` | 讯飞 TTS 可选；本地 Pillow + FFmpeg 编码 | Worker 保存六幕 H.264 MP4；有语音时合成 AAC 音轨，无语音时标明静音分镜。是幻灯式微课，不是文生动画视频，亦不能代替官方五分钟操作录屏 |
| 原 B1 评价、简历、问答等拓展能力 | `app/services/ai_service.py` | `AI_API_KEY` 配置的 OpenAI 兼容服务 | 限流、超时/有限重试、结构验证和 AIInvocationLog；不属于 A3 主演示链 |

密钥：`SPARK_API_PASSWORD`、`AI_API_KEY`、`SPARK_TTS_APP_ID`、`SPARK_TTS_API_KEY`、`SPARK_TTS_API_SECRET`。`deploy/public-demo.env.example` 还明确列出主/备模型、地址和 TTS 音色；DeepSeek 默认模型设为其官方文档推荐的 `deepseek-flash`。模型名称和接口权限以团队供应商控制台当前实际可用项为准。公开仓库只包含变量名，不包含值。

## 上线验收（必须形成真实记录）

| 检查 | 通过条件 |
|---|---|
| 未配置密钥 | 资源标“规则降级”，音频状态准确，任务仍能完成；不得声称在线模型成功 |
| 星火最小连接 | 管理员模型状态页真实调用成功，记录时间、模型、耗时与错误码 |
| 备用模型 | 主模型故障时保留失败尝试，再记备用结果；学生端来源显示备用 |
| 结构化生成 | 返回实际 Schema 可解析结果；不合格时修复或降级，不保存畸形 JSON 当作完成 |
| 导师与引用 | 问题有对应有效片段；无证据拒答；虚假外链被拦截 |
| 端到端 | Web 与 Worker 均运行；至少一个新任务产生 Run/Step、资源、题库作答和路径变化 |
| 公网权限 | 无登录可看 `/showcase/`；学生不能访问教师/管理员页；默认种子密码不能登录 |

这张表是验收条件，**不是实测结论**。项目历史文档的线上成功记录属于当时的本机环境；新部署必须重新验证并保存截图/日志。静态预览页不能作为上述调用成功的证据。
