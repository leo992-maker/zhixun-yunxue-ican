# 多智能体架构

## 角色

| 角色 | 真实职责 | 工具/服务 | 持久化证据 |
|---|---|---|---|
| 编排智能体 | 拆解目标、组织顺序、并发、失败与降级 | `LearningOrchestrator`、线程池 | Workflow、Run、Job |
| 画像智能体 | 读取10维画像、证据与确认状态 | Profile Store | Profile相关表、Step |
| 知识检索智能体 | 过滤启用文档/版本并执行中文BM25 | BM25 Course Retrieval | Step citations、ResourceCitation |
| 资源策划智能体 | 选资源形式、难度、长度和目标 | Resource Strategy | Step输入输出 |
| 文档智能体 | 分层讲解与DOCX | python-docx | Resource、Artifact、文件 |
| PPT智能体 | 9页完整课件 | python-pptx | Resource、PPTX文件 |
| 导图智能体 | 树形JSON、Mermaid、SVG | SVG Renderer | Resource、SVG文件 |
| 题库智能体 | 六题型、解析和评分 | Quiz Builder | QuestionBank/Question |
| 阅读智能体 | 基于课程文档组织阅读 | Knowledge Reading Builder | Resource引用 |
| 实操智能体 | 起始代码、提示、测试和参考实现 | Static Code Case Builder | Resource；不执行学生代码 |
| 多模态智能体 | 脚本、分镜、TTS | Spark TTS（按配置） | Resource、音频状态/文件 |
| 安全智能体 | 注入、敏感、越界、外链、页码、HTML、引用 | Content Safety Rules | SafetyRecord |
| 质量审核智能体 | 完整性、画像适配、依据和文件检查 | Quality Gate | AgentReview |
| 路径规划智能体 | 路径、推荐、版本和调整原因 | Dynamic Path Planner | Plan/Node/Recommendation |
| 辅导智能体 | 课程内RAG答疑 | Course RAG Tutor | TutorConversation/Message |
| 评估智能体 | 评分、掌握度、六维效果 | Learning Effect Assessor | Attempt/Mastery/Report |

## 工作流

```text
1 画像分析
2 知识检索
3 资源策划
4..N 专业资源智能体真实并行
N+1 内容安全检查
N+2 质量审核
N+3 学习路径与推荐更新
```

每个步骤记录参与Agent、输入摘要、输出摘要、状态、顺序、开始/结束、耗时、工具、引用、重试和降级。专业资源不是一个大模型响应切成多个卡片：每个Future分别调用对应生成函数、可选模型Provider、文件导出器和数据库事务。

## 重试和返工

- 数据库并发死锁1205/1213：单个专业资源最多重试两次，仍失败则整个Job标失败。
- 模型失败：当前资源使用知识库规则降级，来源明确；不把降级内容标为AI。
- 安全失败：阻断资源并进入教师处理。
- 质量失败：`AgentReview.triggered_rework=true`并给出建议；当前规则资源在正常证据下通过。后续在线模型资源可基于建议重新生成新版本。
- 用户重试：创建新Job和新幂等键，保留旧失败Run。

