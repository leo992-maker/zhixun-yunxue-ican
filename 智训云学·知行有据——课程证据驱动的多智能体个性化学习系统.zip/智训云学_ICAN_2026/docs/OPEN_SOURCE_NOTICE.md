# 开源软件与AI服务说明

## Python/Django依赖

| 软件 | 用途 | 上游许可 |
|---|---|---|
| Django | Web框架、模板、迁移、测试 | BSD-3-Clause |
| PyMySQL | MySQL驱动 | MIT |
| requests | HTTP模型调用 | Apache-2.0 |
| python-dotenv | 环境变量配置 | BSD-3-Clause |
| pypdf | PDF静态文本提取 | BSD-3-Clause |
| python-docx | DOCX生成 | MIT |
| python-pptx | 真实PPTX生成 | MIT |
| openpyxl | Excel相关兼容能力 | MIT |
| websocket-client | 讯飞TTS WebSocket客户端 | Apache-2.0 |
| Waitress | Windows WSGI服务 | ZPL-2.1 |
| WhiteNoise | 静态资源服务 | MIT |
| redis-py | 可选Redis客户端 | MIT |
| Pillow | 微课分镜图片绘制 | HPND |
| FFmpeg | 分镜/语音编码为 H.264 MP4（Docker 中安装） | LGPL/GPL，取决于发行构建选项 |
| Noto Sans SC | 微课画面及参赛 PDF 的可嵌入中文字体 | OFL-1.1；许可原文见 `assets/fonts/OFL.txt` |

发布前应以锁定版本的上游包元数据再次核对完整许可文本，并按许可保留版权声明。本文件是项目使用说明，不替代上游LICENSE。

## AI和第三方服务

- 科大讯飞星火：正式比赛主模型Provider；使用者自行申请额度、确认服务协议和内容合规。
- 科大讯飞在线语音合成：用于多模态微课音频；无授权时不调用。
- DeepSeek/OpenAI-compatible：保留为可选备用Provider，不是比赛主模型。

## 课程内容

演示《Python程序设计》知识库为项目课程组自建内容。教师另行上传的资料必须拥有合法使用权，并填写真实来源。
