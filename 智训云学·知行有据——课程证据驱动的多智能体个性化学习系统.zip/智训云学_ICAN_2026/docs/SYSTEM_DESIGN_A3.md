# 智训云学 A3 系统设计

## 架构

```text
浏览器（Django Template + 原生JS + SSE/轮询）
           │
Waitress Web ── 身份/权限/CSRF/上传安全 ── MySQL
           │                                  │
           └─ GenerationJob队列 ← Agent Worker
                                      │
                Profile / RAG / Resource / Safety / Review / Path / Assessment
                                      │
                     SparkProvider（主） / OpenAICompatible（备用）
                     SparkTTSProvider（按密钥启用）
```

Web请求只创建任务并返回，不等待长时间生成。Worker使用数据库行锁领取任务，资源Agent并行执行；MySQL死锁1205/1213最多有限重试两次，最终失败保留原因并允许创建新重试任务。

## 数据边界

- 旧`app`模型继续`managed=False`，B1表和数据不删除、不改所有权。
- 新`agent_learning`应用只管理`a3_*`表；指向旧学生/教师的外键使用`db_constraint=False`，避免迁移改写旧表约束。
- 演示 MySQL 数据保存在独立 Docker 卷；升级已有数据库前由部署者先创建备份，初始化脚本仅在空库执行。
- 幂等键用于生成任务和资源，重复请求不会重复创建同一版本。

## 角色和权限

- 学生：只访问自己的画像、任务、资源、题库、路径、导师与报告。
- 教师：维护知识库和课程结构，查看学习情况，审核资源；不能访问管理员模型配置。
- 管理员：监控AgentRun、任务、模型、AI日志、安全、知识库和健康状态。
- B1权限仍由原装饰器与视图守卫保护。

## 失败和降级

| 场景 | 行为 |
|---|---|
| 星火Key缺失 | Provider返回`NOT_CONFIGURED`，资源标“规则降级生成” |
| 知识证据不足 | 返回固定提示，不生成确定性结论 |
| 模型网络/限流/审核错误 | 保存错误码、耗时和失败原因，允许重试 |
| TTS未配置 | 保留脚本与分镜，音频状态明确为待配置 |
| 文件解析失败 | 保存解析失败状态和原因，文档不进入检索 |
| 内容审核失败 | 阻断资源，教师端显示安全驳回 |

## 可观测性

`AgentRun → AgentStep → AgentMessage/AgentToolCall/AgentReview → AgentRunArtifact`保存真实协作；`GenerationJobStep`面向学生显示进度；旧`AIInvocationLog`继续记录提供者、模型、Token/用量、耗时、状态和错误码，不存密钥。
