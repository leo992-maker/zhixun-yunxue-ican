-- =========================================================
-- AI驱动的就业赋能在线教学平台：优化版完整 SQL 脚本
-- 适用环境：MySQL 8.0+ / MySQL Workbench
-- 使用建议：可以整份执行；做报告截图时建议按“第1步~第9步”分段执行。
-- 数据库名称：employment_ai_platform
-- =========================================================

/* =========================================================
第1步：创建并使用独立数据库
说明：不要放在平时练习库里，避免和其他表冲突。
========================================================= */
CREATE DATABASE IF NOT EXISTS employment_ai_platform
DEFAULT CHARACTER SET utf8mb4
DEFAULT COLLATE utf8mb4_general_ci;

USE employment_ai_platform;

/* =========================================================
第2步：清理旧对象，保证脚本可重复执行
说明：如果第一次运行，没有旧对象也不会报错。
========================================================= */
DROP VIEW IF EXISTS v_platform_dashboard_summary;
DROP VIEW IF EXISTS v_position_ability_gap;
DROP VIEW IF EXISTS v_teacher_dashboard;
DROP VIEW IF EXISTS v_student_learning_progress;

DROP PROCEDURE IF EXISTS sp_refresh_process_score;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS notification;
DROP TABLE IF EXISTS operation_log;
DROP TABLE IF EXISTS ai_invocation_log;
DROP TABLE IF EXISTS report_snapshot;
DROP TABLE IF EXISTS teacher_review;
DROP TABLE IF EXISTS ai_evaluation_dimension;
DROP TABLE IF EXISTS ai_evaluation;
DROP TABLE IF EXISTS submission_file;
DROP TABLE IF EXISTS training_submission;
DROP TABLE IF EXISTS rubric_dimension;
DROP TABLE IF EXISTS evaluation_rubric;
DROP TABLE IF EXISTS score_weight_config;
DROP TABLE IF EXISTS qa_record;
DROP TABLE IF EXISTS warning_record;
DROP TABLE IF EXISTS process_score;
DROP TABLE IF EXISTS recommendation;
DROP TABLE IF EXISTS interview_record;
DROP TABLE IF EXISTS resume;
DROP TABLE IF EXISTS career_report;
DROP TABLE IF EXISTS assessment_result;
DROP TABLE IF EXISTS assessment;
DROP TABLE IF EXISTS student_profile;
DROP TABLE IF EXISTS training_record;
DROP TABLE IF EXISTS training_step;
DROP TABLE IF EXISTS training_task;
DROP TABLE IF EXISTS learning_record;
DROP TABLE IF EXISTS student_path;
DROP TABLE IF EXISTS path_module;
DROP TABLE IF EXISTS learning_path;
DROP TABLE IF EXISTS position_ability;
DROP TABLE IF EXISTS job_position;
DROP TABLE IF EXISTS company;
DROP TABLE IF EXISTS module_ability;
DROP TABLE IF EXISTS ability;
DROP TABLE IF EXISTS course_module;
DROP TABLE IF EXISTS micro_module;
DROP TABLE IF EXISTS course;
DROP TABLE IF EXISTS teacher;
DROP TABLE IF EXISTS student;
DROP TABLE IF EXISTS class_info;
DROP TABLE IF EXISTS major;
DROP TABLE IF EXISTS user_account;
DROP TABLE IF EXISTS role_info;
SET FOREIGN_KEY_CHECKS = 1;

/* =========================================================
第3步：创建基础用户、专业、班级、师生表
对应题目：用户权限管理、教师管理、学生管理、专业班级管理。
========================================================= */
CREATE TABLE role_info (
    role_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '角色唯一ID',
    role_name VARCHAR(20) NOT NULL UNIQUE COMMENT '角色名称：管理员/教师/学生',
    description VARCHAR(200) NULL COMMENT '角色说明'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色表';

CREATE TABLE user_account (
    user_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '用户唯一ID',
    role_id INT NOT NULL COMMENT '角色ID',
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '登录账号',
    password VARCHAR(128) NOT NULL COMMENT 'Django PBKDF2/Argon2 等安全哈希，兼容旧账号首次登录升级',
    real_name VARCHAR(30) NOT NULL COMMENT '真实姓名',
    phone VARCHAR(20) UNIQUE COMMENT '联系电话',
    email VARCHAR(80) UNIQUE COMMENT '邮箱',
    status VARCHAR(20) NOT NULL DEFAULT '正常' COMMENT '账号状态',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    CONSTRAINT fk_user_role FOREIGN KEY (role_id) REFERENCES role_info(role_id),
    CONSTRAINT ck_user_status CHECK (status IN ('正常','禁用'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户账号表';

CREATE TABLE major (
    major_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '专业唯一ID',
    major_name VARCHAR(60) NOT NULL UNIQUE COMMENT '专业名称',
    college VARCHAR(60) NOT NULL COMMENT '所属学院',
    description VARCHAR(255) NULL COMMENT '专业说明'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='专业表';

CREATE TABLE class_info (
    class_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '班级唯一ID',
    major_id INT NOT NULL COMMENT '专业ID',
    class_name VARCHAR(50) NOT NULL COMMENT '班级名称',
    grade VARCHAR(10) NOT NULL COMMENT '年级',
    CONSTRAINT fk_class_major FOREIGN KEY (major_id) REFERENCES major(major_id),
    CONSTRAINT uk_major_class UNIQUE (major_id, class_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='班级表';

CREATE TABLE student (
    student_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '学生唯一ID',
    user_id INT NOT NULL UNIQUE COMMENT '用户ID，体现用户与学生的一对一关系',
    major_id INT NOT NULL COMMENT '专业ID',
    class_id INT NOT NULL COMMENT '班级ID',
    student_no VARCHAR(30) NOT NULL UNIQUE COMMENT '学号',
    enrollment_year YEAR NOT NULL COMMENT '入学年份',
    CONSTRAINT fk_student_user FOREIGN KEY (user_id) REFERENCES user_account(user_id),
    CONSTRAINT fk_student_major FOREIGN KEY (major_id) REFERENCES major(major_id),
    CONSTRAINT fk_student_class FOREIGN KEY (class_id) REFERENCES class_info(class_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学生表';

CREATE TABLE teacher (
    teacher_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '教师唯一ID',
    user_id INT NOT NULL UNIQUE COMMENT '用户ID，体现用户与教师的一对一关系',
    teacher_no VARCHAR(30) NOT NULL UNIQUE COMMENT '教师工号',
    title VARCHAR(30) NULL COMMENT '职称',
    department VARCHAR(60) NOT NULL COMMENT '所属院系',
    CONSTRAINT fk_teacher_user FOREIGN KEY (user_id) REFERENCES user_account(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='教师表';

/* =========================================================
第4步：创建课程、微模块、能力、岗位相关表
对应题目：微模块化课程融合中心、岗位资源与校企实场景对接。
========================================================= */
CREATE TABLE course (
    course_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '课程唯一ID',
    major_id INT NOT NULL COMMENT '所属专业ID',
    teacher_id INT NOT NULL COMMENT '授课教师ID',
    course_name VARCHAR(80) NOT NULL COMMENT '课程名称',
    course_type VARCHAR(20) NOT NULL COMMENT '课程类型',
    description TEXT NULL COMMENT '课程说明',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    CONSTRAINT fk_course_major FOREIGN KEY (major_id) REFERENCES major(major_id),
    CONSTRAINT fk_course_teacher FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id),
    CONSTRAINT ck_course_type CHECK (course_type IN ('专业课程','生涯课程','融合课程'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='课程表';

CREATE TABLE micro_module (
    module_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '微模块唯一ID',
    module_name VARCHAR(80) NOT NULL COMMENT '模块名称',
    module_type VARCHAR(20) NOT NULL COMMENT '模块类型：专业模块/生涯模块/融合模块',
    duration INT NOT NULL COMMENT '时长，分钟，题目要求5至15分钟',
    knowledge_point VARCHAR(120) NULL COMMENT '知识点',
    difficulty VARCHAR(10) NOT NULL COMMENT '难度',
    description TEXT NULL COMMENT '模块说明',
    CONSTRAINT ck_module_type CHECK (module_type IN ('专业模块','生涯模块','融合模块')),
    CONSTRAINT ck_module_duration CHECK (duration BETWEEN 5 AND 15),
    CONSTRAINT ck_module_difficulty CHECK (difficulty IN ('低','中','高'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='微模块表';

CREATE TABLE course_module (
    course_id INT NOT NULL COMMENT '课程ID',
    module_id INT NOT NULL COMMENT '微模块ID',
    module_order INT NOT NULL COMMENT '模块顺序',
    PRIMARY KEY (course_id, module_id),
    CONSTRAINT fk_cm_course FOREIGN KEY (course_id) REFERENCES course(course_id) ON DELETE CASCADE,
    CONSTRAINT fk_cm_module FOREIGN KEY (module_id) REFERENCES micro_module(module_id) ON DELETE CASCADE,
    CONSTRAINT ck_cm_order CHECK (module_order > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='课程-微模块关系表，m:n联系转关系表';

CREATE TABLE ability (
    ability_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '能力项唯一ID',
    ability_name VARCHAR(60) NOT NULL UNIQUE COMMENT '能力名称',
    ability_type VARCHAR(20) NOT NULL COMMENT '能力类型',
    description VARCHAR(255) NULL COMMENT '能力说明',
    CONSTRAINT ck_ability_type CHECK (ability_type IN ('专业能力','职业素养','就业能力'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='能力项表';

CREATE TABLE module_ability (
    module_id INT NOT NULL COMMENT '微模块ID',
    ability_id INT NOT NULL COMMENT '能力项ID',
    weight DECIMAL(4,2) NOT NULL DEFAULT 1.00 COMMENT '能力权重，0至1',
    PRIMARY KEY (module_id, ability_id),
    CONSTRAINT fk_ma_module FOREIGN KEY (module_id) REFERENCES micro_module(module_id) ON DELETE CASCADE,
    CONSTRAINT fk_ma_ability FOREIGN KEY (ability_id) REFERENCES ability(ability_id) ON DELETE CASCADE,
    CONSTRAINT ck_ma_weight CHECK (weight > 0 AND weight <= 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='微模块-能力关系表，m:n联系转关系表';

CREATE TABLE company (
    company_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '企业唯一ID',
    company_name VARCHAR(80) NOT NULL UNIQUE COMMENT '企业名称',
    industry VARCHAR(60) NOT NULL COMMENT '行业',
    contact_person VARCHAR(30) NULL COMMENT '联系人',
    contact_phone VARCHAR(20) NULL COMMENT '联系电话'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='企业表';

CREATE TABLE job_position (
    position_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '岗位唯一ID',
    company_id INT NOT NULL COMMENT '企业ID',
    position_name VARCHAR(80) NOT NULL COMMENT '岗位名称',
    industry VARCHAR(60) NULL COMMENT '岗位行业方向',
    salary_range VARCHAR(50) NULL COMMENT '薪资范围',
    description TEXT NULL COMMENT '岗位描述',
    CONSTRAINT fk_position_company FOREIGN KEY (company_id) REFERENCES company(company_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='岗位表';

CREATE TABLE position_ability (
    position_id INT NOT NULL COMMENT '岗位ID',
    ability_id INT NOT NULL COMMENT '能力项ID',
    required_level VARCHAR(20) NOT NULL COMMENT '要求等级',
    PRIMARY KEY (position_id, ability_id),
    CONSTRAINT fk_pa_position FOREIGN KEY (position_id) REFERENCES job_position(position_id) ON DELETE CASCADE,
    CONSTRAINT fk_pa_ability FOREIGN KEY (ability_id) REFERENCES ability(ability_id) ON DELETE CASCADE,
    CONSTRAINT ck_pa_level CHECK (required_level IN ('基础','熟练','精通'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='岗位-能力要求表，m:n联系转关系表';

/* =========================================================
第5步：创建学习路径、学习记录、实训、测评、推荐、预警相关表
对应题目：学习路径、实场景实训、学生画像、测评、生涯规划、AI推荐、过程性评价。
========================================================= */
CREATE TABLE learning_path (
    path_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '学习路径唯一ID',
    path_name VARCHAR(80) NOT NULL COMMENT '路径名称',
    major_id INT NULL COMMENT '适用专业ID',
    target_position_id INT NULL COMMENT '目标岗位ID',
    description TEXT NULL COMMENT '路径说明',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    CONSTRAINT fk_lp_major FOREIGN KEY (major_id) REFERENCES major(major_id),
    CONSTRAINT fk_lp_position FOREIGN KEY (target_position_id) REFERENCES job_position(position_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学习路径表';

CREATE TABLE path_module (
    path_id INT NOT NULL COMMENT '学习路径ID',
    module_id INT NOT NULL COMMENT '微模块ID',
    module_order INT NOT NULL COMMENT '路径中的模块顺序',
    PRIMARY KEY (path_id, module_id),
    CONSTRAINT fk_pm_path FOREIGN KEY (path_id) REFERENCES learning_path(path_id) ON DELETE CASCADE,
    CONSTRAINT fk_pm_module FOREIGN KEY (module_id) REFERENCES micro_module(module_id) ON DELETE CASCADE,
    CONSTRAINT ck_pm_order CHECK (module_order > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学习路径-微模块表，m:n联系转关系表';

CREATE TABLE student_path (
    student_id INT NOT NULL COMMENT '学生ID',
    path_id INT NOT NULL COMMENT '学习路径ID',
    assign_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '分配时间',
    status VARCHAR(20) NOT NULL DEFAULT '学习中' COMMENT '路径状态',
    PRIMARY KEY (student_id, path_id),
    CONSTRAINT fk_sp_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_sp_path FOREIGN KEY (path_id) REFERENCES learning_path(path_id) ON DELETE CASCADE,
    CONSTRAINT ck_sp_status CHECK (status IN ('学习中','已完成','已停止'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学生学习路径表';

CREATE TABLE learning_record (
    record_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '学习记录唯一ID',
    student_id INT NOT NULL COMMENT '学生ID',
    module_id INT NOT NULL COMMENT '微模块ID',
    progress INT NOT NULL DEFAULT 0 COMMENT '学习进度，0至100',
    study_time INT NOT NULL DEFAULT 0 COMMENT '学习时长，分钟',
    score INT DEFAULT 0 COMMENT '学习得分，0至100',
    status VARCHAR(20) NOT NULL DEFAULT '未开始' COMMENT '学习状态',
    last_study_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '最后学习时间',
    CONSTRAINT fk_lr_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_lr_module FOREIGN KEY (module_id) REFERENCES micro_module(module_id),
    CONSTRAINT uk_lr_student_module UNIQUE (student_id, module_id),
    CONSTRAINT ck_lr_progress CHECK (progress BETWEEN 0 AND 100),
    CONSTRAINT ck_lr_study_time CHECK (study_time >= 0),
    CONSTRAINT ck_lr_score CHECK (score BETWEEN 0 AND 100),
    CONSTRAINT ck_lr_status CHECK (status IN ('未开始','学习中','已完成'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学习记录表';

CREATE TABLE training_task (
    task_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '实训任务唯一ID',
    teacher_id INT NOT NULL COMMENT '发布教师ID',
    position_id INT NULL COMMENT '关联岗位ID',
    task_name VARCHAR(80) NOT NULL COMMENT '任务名称',
    scene_type VARCHAR(30) NOT NULL COMMENT '职场场景类型',
    difficulty VARCHAR(10) NOT NULL COMMENT '任务难度',
    requirement TEXT NOT NULL COMMENT '任务要求',
    deliverable VARCHAR(120) NULL COMMENT '提交成果形式',
    publish_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
    CONSTRAINT fk_task_teacher FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id),
    CONSTRAINT fk_task_position FOREIGN KEY (position_id) REFERENCES job_position(position_id),
    CONSTRAINT ck_task_scene CHECK (scene_type IN ('数据处理场景','需求分析场景','项目实施场景','职场沟通场景','软件开发场景','测试验证场景','接口设计场景','数据可视化场景','项目汇报场景')),
    CONSTRAINT ck_task_difficulty CHECK (difficulty IN ('低','中','高'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='实训任务表';

CREATE TABLE training_step (
    step_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '实训步骤唯一ID',
    task_id INT NOT NULL COMMENT '实训任务ID',
    step_order INT NOT NULL COMMENT '步骤顺序',
    step_name VARCHAR(80) NOT NULL COMMENT '步骤名称',
    step_hint TEXT NULL COMMENT 'AI步骤提示或引导内容',
    CONSTRAINT fk_step_task FOREIGN KEY (task_id) REFERENCES training_task(task_id) ON DELETE CASCADE,
    CONSTRAINT uk_task_step UNIQUE (task_id, step_order),
    CONSTRAINT ck_step_order CHECK (step_order > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='实训步骤表，用于体现AI引导与闯关训练';

CREATE TABLE training_record (
    training_record_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '实训记录唯一ID',
    student_id INT NOT NULL COMMENT '学生ID',
    task_id INT NOT NULL COMMENT '实训任务ID',
    submit_content TEXT NULL COMMENT '提交内容',
    ai_score INT DEFAULT 0 COMMENT 'AI评分，0至100',
    teacher_score INT DEFAULT 0 COMMENT '教师评分，0至100',
    feedback TEXT NULL COMMENT '评价反馈',
    correction_suggestion TEXT NULL COMMENT 'AI过程纠错或优化建议',
    status VARCHAR(20) NOT NULL DEFAULT '未提交' COMMENT '状态',
    submit_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '提交时间',
    CONSTRAINT fk_tr_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_tr_task FOREIGN KEY (task_id) REFERENCES training_task(task_id) ON DELETE CASCADE,
    CONSTRAINT uk_tr_student_task UNIQUE (student_id, task_id),
    CONSTRAINT ck_tr_ai_score CHECK (ai_score BETWEEN 0 AND 100),
    CONSTRAINT ck_tr_teacher_score CHECK (teacher_score BETWEEN 0 AND 100),
    CONSTRAINT ck_tr_status CHECK (status IN ('未提交','已提交','已评价'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='实训记录表';

CREATE TABLE student_profile (
    profile_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '画像唯一ID',
    student_id INT NOT NULL UNIQUE COMMENT '学生ID',
    foundation_level VARCHAR(20) NULL COMMENT '专业基础水平',
    learning_habit VARCHAR(100) NULL COMMENT '学习习惯',
    weak_ability VARCHAR(100) NULL COMMENT '能力短板',
    career_interest VARCHAR(100) NULL COMMENT '职业倾向',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
    CONSTRAINT fk_profile_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学生画像表';

CREATE TABLE assessment (
    assessment_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '测评唯一ID',
    assessment_name VARCHAR(80) NOT NULL COMMENT '测评名称',
    assessment_type VARCHAR(30) NOT NULL COMMENT '测评类型',
    description TEXT NULL COMMENT '测评说明',
    CONSTRAINT ck_assessment_type CHECK (assessment_type IN ('职业兴趣','性格','能力','职业素养'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='测评表';

CREATE TABLE assessment_result (
    result_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '测评结果唯一ID',
    student_id INT NOT NULL COMMENT '学生ID',
    assessment_id INT NOT NULL COMMENT '测评ID',
    score INT DEFAULT 0 COMMENT '测评分数，0至100',
    result_text TEXT NULL COMMENT '测评结果说明',
    test_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '测评时间',
    CONSTRAINT fk_ar_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_ar_assessment FOREIGN KEY (assessment_id) REFERENCES assessment(assessment_id) ON DELETE CASCADE,
    CONSTRAINT ck_ar_score CHECK (score BETWEEN 0 AND 100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='测评结果表';

CREATE TABLE career_report (
    report_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '报告唯一ID',
    student_id INT NOT NULL COMMENT '学生ID',
    target_position_id INT NULL COMMENT '目标岗位ID',
    gap_analysis TEXT NULL COMMENT '能力差距分析',
    plan_content TEXT NULL COMMENT '发展规划内容',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '生成时间',
    CONSTRAINT fk_cr_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_cr_position FOREIGN KEY (target_position_id) REFERENCES job_position(position_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='生涯报告表';

CREATE TABLE resume (
    resume_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '简历唯一ID',
    student_id INT NOT NULL COMMENT '学生ID',
    target_position_id INT NULL COMMENT '目标岗位ID',
    resume_content TEXT NOT NULL COMMENT '简历内容',
    ai_comment TEXT NULL COMMENT 'AI优化建议',
    match_score INT DEFAULT 0 COMMENT '岗位匹配度，0至100',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
    CONSTRAINT fk_resume_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_resume_position FOREIGN KEY (target_position_id) REFERENCES job_position(position_id),
    CONSTRAINT ck_resume_match CHECK (match_score BETWEEN 0 AND 100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='简历表';

CREATE TABLE interview_record (
    interview_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '面试记录唯一ID',
    student_id INT NOT NULL COMMENT '学生ID',
    position_id INT NULL COMMENT '目标岗位ID',
    question TEXT NOT NULL COMMENT '面试问题',
    answer TEXT NULL COMMENT '学生回答',
    ai_score INT DEFAULT 0 COMMENT 'AI面试评分，0至100',
    feedback TEXT NULL COMMENT '面试反馈',
    interview_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '面试时间',
    CONSTRAINT fk_ir_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_ir_position FOREIGN KEY (position_id) REFERENCES job_position(position_id),
    CONSTRAINT ck_ir_score CHECK (ai_score BETWEEN 0 AND 100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='模拟面试记录表';

CREATE TABLE recommendation (
    recommend_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '推荐记录唯一ID',
    student_id INT NOT NULL COMMENT '学生ID',
    recommend_type VARCHAR(20) NOT NULL COMMENT '推荐类型',
    module_id INT NULL COMMENT '被推荐微模块ID',
    position_id INT NULL COMMENT '被推荐岗位ID',
    path_id INT NULL COMMENT '被推荐学习路径ID',
    reason TEXT NOT NULL COMMENT '推荐理由',
    recommend_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '推荐时间',
    CONSTRAINT fk_rec_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_rec_module FOREIGN KEY (module_id) REFERENCES micro_module(module_id),
    CONSTRAINT fk_rec_position FOREIGN KEY (position_id) REFERENCES job_position(position_id),
    CONSTRAINT fk_rec_path FOREIGN KEY (path_id) REFERENCES learning_path(path_id),
    CONSTRAINT ck_rec_type CHECK (recommend_type IN ('微模块推荐','岗位推荐','学习路径推荐')),
    CONSTRAINT ck_rec_target CHECK (
        (recommend_type = '微模块推荐' AND module_id IS NOT NULL AND position_id IS NULL AND path_id IS NULL)
        OR (recommend_type = '岗位推荐' AND module_id IS NULL AND position_id IS NOT NULL AND path_id IS NULL)
        OR (recommend_type = '学习路径推荐' AND module_id IS NULL AND position_id IS NULL AND path_id IS NOT NULL)
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='推荐记录表';

CREATE TABLE process_score (
    score_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '成绩记录唯一ID',
    student_id INT NOT NULL UNIQUE COMMENT '学生ID',
    module_completion_rate DECIMAL(5,2) DEFAULT 0 COMMENT '模块平均完成度',
    learning_avg_score DECIMAL(5,2) DEFAULT 0 COMMENT '学习平均分',
    training_avg_score DECIMAL(5,2) DEFAULT 0 COMMENT '实训平均分',
    assessment_avg_score DECIMAL(5,2) DEFAULT 0 COMMENT '测评平均分',
    total_score DECIMAL(5,2) DEFAULT 0 COMMENT '过程性总成绩',
    update_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '更新时间',
    CONSTRAINT fk_ps_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    CONSTRAINT ck_ps_total CHECK (total_score BETWEEN 0 AND 100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='过程性成绩表';

CREATE TABLE warning_record (
    warning_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '预警记录唯一ID',
    student_id INT NOT NULL COMMENT '学生ID',
    warning_type VARCHAR(30) NOT NULL COMMENT '预警类型',
    warning_reason TEXT NOT NULL COMMENT '预警原因',
    warning_level VARCHAR(20) NOT NULL COMMENT '预警等级',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '生成时间',
    status VARCHAR(20) NOT NULL DEFAULT '未处理' COMMENT '处理状态',
    CONSTRAINT fk_wr_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    CONSTRAINT ck_wr_level CHECK (warning_level IN ('一般','重要','严重')),
    CONSTRAINT ck_wr_status CHECK (status IN ('未处理','已处理'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='预警记录表';

CREATE TABLE qa_record (
    qa_id INT PRIMARY KEY AUTO_INCREMENT COMMENT '答疑记录唯一ID',
    student_id INT NOT NULL COMMENT '提问学生ID',
    teacher_id INT NULL COMMENT '答疑教师ID',
    question_content TEXT NOT NULL COMMENT '问题内容',
    ai_answer TEXT NULL COMMENT 'AI辅助回答',
    teacher_answer TEXT NULL COMMENT '教师回答',
    status VARCHAR(20) NOT NULL DEFAULT '待回复' COMMENT '答疑状态',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '提问时间',
    answer_time DATETIME NULL COMMENT '回复时间',
    CONSTRAINT fk_qa_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_qa_teacher FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id),
    CONSTRAINT ck_qa_status CHECK (status IN ('待回复','AI已回复','教师已回复'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='师生互动与AI答疑记录表';

/* =========================================================
第5.1步：B1 软件实训成果智能检查评价闭环
说明：量规、提交版本、证据文件、AI评价、教师复核、审计与报表快照。
========================================================= */
CREATE TABLE score_weight_config (
    config_id INT PRIMARY KEY AUTO_INCREMENT,
    config_name VARCHAR(80) NOT NULL UNIQUE,
    module_weight DECIMAL(5,2) NOT NULL DEFAULT 30,
    training_weight DECIMAL(5,2) NOT NULL DEFAULT 40,
    assessment_weight DECIMAL(5,2) NOT NULL DEFAULT 20,
    career_quality_weight DECIMAL(5,2) NOT NULL DEFAULT 10,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT ck_score_weight_total CHECK (
        module_weight + training_weight + assessment_weight + career_quality_weight = 100
    )
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='过程性成绩权重配置';

CREATE TABLE evaluation_rubric (
    rubric_id INT PRIMARY KEY AUTO_INCREMENT,
    task_id INT NOT NULL,
    created_by_id INT NOT NULL,
    rubric_name VARCHAR(120) NOT NULL,
    description TEXT NULL,
    version_no INT UNSIGNED NOT NULL DEFAULT 1,
    total_weight DECIMAL(5,2) NOT NULL DEFAULT 100,
    source VARCHAR(30) NOT NULL DEFAULT 'teacher',
    prompt_version VARCHAR(40) NOT NULL DEFAULT '',
    status VARCHAR(20) NOT NULL DEFAULT '草稿',
    is_active TINYINT(1) NOT NULL DEFAULT 0,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_rubric_task FOREIGN KEY (task_id) REFERENCES training_task(task_id),
    CONSTRAINT fk_rubric_teacher FOREIGN KEY (created_by_id) REFERENCES teacher(teacher_id),
    CONSTRAINT uk_rubric_task_version UNIQUE (task_id, version_no),
    CONSTRAINT ck_rubric_weight CHECK (total_weight = 100),
    INDEX idx_rubric_task_active (task_id, is_active, version_no)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='实训评价量规';

CREATE TABLE rubric_dimension (
    dimension_id INT PRIMARY KEY AUTO_INCREMENT,
    rubric_id INT NOT NULL,
    dimension_order INT UNSIGNED NOT NULL DEFAULT 1,
    dimension_name VARCHAR(80) NOT NULL,
    weight DECIMAL(5,2) NOT NULL,
    max_score DECIMAL(6,2) NOT NULL DEFAULT 100,
    criteria TEXT NOT NULL,
    excellent_standard TEXT NOT NULL,
    qualified_standard TEXT NOT NULL,
    common_issues TEXT NOT NULL,
    ai_enabled TINYINT(1) NOT NULL DEFAULT 1,
    teacher_review_required TINYINT(1) NOT NULL DEFAULT 0,
    CONSTRAINT fk_dimension_rubric FOREIGN KEY (rubric_id) REFERENCES evaluation_rubric(rubric_id) ON DELETE CASCADE,
    CONSTRAINT uk_dimension_order UNIQUE (rubric_id, dimension_order),
    CONSTRAINT uk_dimension_name UNIQUE (rubric_id, dimension_name),
    CONSTRAINT ck_dimension_weight CHECK (weight > 0 AND weight <= 100),
    CONSTRAINT ck_dimension_score CHECK (max_score > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='量规评价维度';

CREATE TABLE training_submission (
    submission_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    task_id INT NOT NULL,
    rubric_id INT NULL,
    version_no INT UNSIGNED NOT NULL DEFAULT 1,
    text_content LONGTEXT NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT '已提交',
    idempotency_key VARCHAR(64) NOT NULL UNIQUE,
    submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_submission_student FOREIGN KEY (student_id) REFERENCES student(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_submission_task FOREIGN KEY (task_id) REFERENCES training_task(task_id),
    CONSTRAINT fk_submission_rubric FOREIGN KEY (rubric_id) REFERENCES evaluation_rubric(rubric_id),
    CONSTRAINT uk_submission_version UNIQUE (student_id, task_id, version_no),
    INDEX idx_submission_task_status_time (task_id, status, submitted_at),
    INDEX idx_submission_student_time (student_id, submitted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学生实训提交版本';

CREATE TABLE submission_file (
    file_id INT PRIMARY KEY AUTO_INCREMENT,
    submission_id INT NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    stored_path VARCHAR(500) NOT NULL,
    extension VARCHAR(20) NOT NULL,
    mime_type VARCHAR(120) NOT NULL,
    file_size BIGINT NOT NULL,
    sha256 CHAR(64) NOT NULL,
    parse_status VARCHAR(30) NOT NULL DEFAULT '已保存',
    parse_message VARCHAR(255) NOT NULL DEFAULT '',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_file_submission FOREIGN KEY (submission_id) REFERENCES training_submission(submission_id) ON DELETE CASCADE,
    CONSTRAINT uk_submission_sha UNIQUE (submission_id, sha256),
    CONSTRAINT ck_file_size CHECK (file_size > 0),
    INDEX idx_file_sha256 (sha256)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='提交成果文件证据';

CREATE TABLE ai_evaluation (
    evaluation_id INT PRIMARY KEY AUTO_INCREMENT,
    submission_id INT NOT NULL,
    rubric_id INT NOT NULL,
    total_score DECIMAL(6,2) NOT NULL,
    summary LONGTEXT NOT NULL,
    strengths_json JSON NOT NULL,
    critical_issues_json JSON NOT NULL,
    general_issues_json JSON NOT NULL,
    suggestions_json JSON NOT NULL,
    recommended_modules_json JSON NOT NULL,
    source VARCHAR(30) NOT NULL DEFAULT 'deepseek',
    is_ai_generated TINYINT(1) NOT NULL DEFAULT 1,
    confidence DECIMAL(4,3) NOT NULL DEFAULT 0,
    requires_teacher_review TINYINT(1) NOT NULL DEFAULT 1,
    model_name VARCHAR(80) NOT NULL DEFAULT '',
    prompt_version VARCHAR(40) NOT NULL,
    raw_response_json JSON NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT '待教师复核',
    evaluated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_evaluation_submission FOREIGN KEY (submission_id) REFERENCES training_submission(submission_id) ON DELETE CASCADE,
    CONSTRAINT fk_evaluation_rubric FOREIGN KEY (rubric_id) REFERENCES evaluation_rubric(rubric_id),
    CONSTRAINT ck_evaluation_score CHECK (total_score BETWEEN 0 AND 100),
    CONSTRAINT ck_evaluation_confidence CHECK (confidence BETWEEN 0 AND 1),
    INDEX idx_evaluation_status_time (status, evaluated_at),
    INDEX idx_evaluation_submission_time (submission_id, evaluated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='AI结构化评价记录';

CREATE TABLE ai_evaluation_dimension (
    detail_id INT PRIMARY KEY AUTO_INCREMENT,
    evaluation_id INT NOT NULL,
    dimension_id INT NOT NULL,
    score DECIMAL(6,2) NOT NULL,
    max_score DECIMAL(6,2) NOT NULL,
    reason TEXT NOT NULL,
    evidence TEXT NOT NULL,
    file_name VARCHAR(255) NOT NULL DEFAULT '',
    line_reference VARCHAR(200) NOT NULL DEFAULT '',
    confidence DECIMAL(4,3) NOT NULL DEFAULT 0,
    CONSTRAINT fk_detail_evaluation FOREIGN KEY (evaluation_id) REFERENCES ai_evaluation(evaluation_id) ON DELETE CASCADE,
    CONSTRAINT fk_detail_dimension FOREIGN KEY (dimension_id) REFERENCES rubric_dimension(dimension_id),
    CONSTRAINT uk_evaluation_dimension UNIQUE (evaluation_id, dimension_id),
    CONSTRAINT ck_detail_score CHECK (score >= 0 AND score <= max_score),
    CONSTRAINT ck_detail_confidence CHECK (confidence BETWEEN 0 AND 1)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='AI评价维度证据明细';

CREATE TABLE teacher_review (
    review_id INT PRIMARY KEY AUTO_INCREMENT,
    evaluation_id INT NOT NULL UNIQUE,
    teacher_id INT NOT NULL,
    adjusted_scores_json JSON NOT NULL,
    teacher_comment TEXT NOT NULL,
    ai_error_notes TEXT NOT NULL,
    decision VARCHAR(20) NOT NULL,
    teacher_score DECIMAL(6,2) NOT NULL,
    final_score DECIMAL(6,2) NOT NULL,
    review_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_review_evaluation FOREIGN KEY (evaluation_id) REFERENCES ai_evaluation(evaluation_id) ON DELETE CASCADE,
    CONSTRAINT fk_review_teacher FOREIGN KEY (teacher_id) REFERENCES teacher(teacher_id),
    CONSTRAINT ck_review_decision CHECK (decision IN ('通过','退回','要求重交')),
    CONSTRAINT ck_review_scores CHECK (teacher_score BETWEEN 0 AND 100 AND final_score BETWEEN 0 AND 100),
    INDEX idx_review_teacher_time (teacher_id, review_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='教师复核记录';

CREATE TABLE report_snapshot (
    snapshot_id INT PRIMARY KEY AUTO_INCREMENT,
    report_type VARCHAR(60) NOT NULL,
    scope_type VARCHAR(30) NOT NULL,
    scope_id INT UNSIGNED NULL,
    filters_json JSON NOT NULL,
    data_json JSON NOT NULL,
    generated_by_id INT NULL,
    generated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_snapshot_user FOREIGN KEY (generated_by_id) REFERENCES user_account(user_id),
    INDEX idx_snapshot_scope_time (report_type, scope_type, scope_id, generated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='教学报表快照';

CREATE TABLE ai_invocation_log (
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    use_case VARCHAR(60) NOT NULL,
    provider VARCHAR(30) NOT NULL,
    model VARCHAR(80) NOT NULL,
    prompt_version VARCHAR(40) NOT NULL,
    status VARCHAR(20) NOT NULL,
    latency_ms INT UNSIGNED NOT NULL DEFAULT 0,
    input_tokens INT UNSIGNED NOT NULL DEFAULT 0,
    output_tokens INT UNSIGNED NOT NULL DEFAULT 0,
    error_code VARCHAR(40) NOT NULL DEFAULT '',
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ai_log_case_time (use_case, create_time),
    INDEX idx_ai_log_status_time (status, create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='AI调用审计与耗时日志';

CREATE TABLE operation_log (
    operation_id INT PRIMARY KEY AUTO_INCREMENT,
    operator_id INT NULL,
    action VARCHAR(80) NOT NULL,
    target_type VARCHAR(60) NOT NULL,
    target_id VARCHAR(60) NOT NULL DEFAULT '',
    detail_json JSON NOT NULL,
    ip_address VARCHAR(45) NULL,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_operation_user FOREIGN KEY (operator_id) REFERENCES user_account(user_id),
    INDEX idx_operation_target_time (target_type, target_id, create_time),
    INDEX idx_operation_user_time (operator_id, create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='关键操作审计日志';

CREATE TABLE notification (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(120) NOT NULL,
    content TEXT NOT NULL,
    notification_type VARCHAR(30) NOT NULL DEFAULT '系统',
    link VARCHAR(255) NOT NULL DEFAULT '',
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    create_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_notification_user FOREIGN KEY (user_id) REFERENCES user_account(user_id) ON DELETE CASCADE,
    INDEX idx_notification_user_read_time (user_id, is_read, create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='站内通知消息';

CREATE INDEX idx_learning_student_status ON learning_record(student_id, status, last_study_time);
CREATE INDEX idx_training_student_status ON training_record(student_id, status, submit_time);
CREATE INDEX idx_training_task_status ON training_record(task_id, status, submit_time);
CREATE INDEX idx_assessment_student_time ON assessment_result(student_id, test_time);
CREATE INDEX idx_warning_status_time ON warning_record(status, warning_level, create_time);
CREATE INDEX idx_qa_teacher_status_time ON qa_record(teacher_id, status, create_time);

/* =========================================================
第6步：创建存储过程和触发器
说明：触发器用于体现“过程性评价自动生成”和“薄弱点自动预警”。
========================================================= */
DELIMITER $$

CREATE PROCEDURE sp_refresh_process_score(IN p_student_id INT)
BEGIN
    DECLARE v_module_completion DECIMAL(5,2) DEFAULT 0;
    DECLARE v_learning_avg DECIMAL(5,2) DEFAULT 0;
    DECLARE v_training_avg DECIMAL(5,2) DEFAULT 0;
    DECLARE v_assessment_avg DECIMAL(5,2) DEFAULT 0;
    DECLARE v_total DECIMAL(5,2) DEFAULT 0;

    SELECT COALESCE(AVG(progress), 0), COALESCE(AVG(score), 0)
    INTO v_module_completion, v_learning_avg
    FROM learning_record
    WHERE student_id = p_student_id;

    SELECT COALESCE(AVG((ai_score + teacher_score) / 2), 0)
    INTO v_training_avg
    FROM training_record
    WHERE student_id = p_student_id AND status = '已评价';

    SELECT COALESCE(AVG(score), 0)
    INTO v_assessment_avg
    FROM assessment_result
    WHERE student_id = p_student_id;

    SET v_total = v_learning_avg * 0.40 + v_training_avg * 0.40 + v_assessment_avg * 0.20;

    INSERT INTO process_score(
        student_id, module_completion_rate, learning_avg_score,
        training_avg_score, assessment_avg_score, total_score, update_time
    )
    VALUES (
        p_student_id, v_module_completion, v_learning_avg,
        v_training_avg, v_assessment_avg, v_total, NOW()
    )
    ON DUPLICATE KEY UPDATE
        module_completion_rate = v_module_completion,
        learning_avg_score = v_learning_avg,
        training_avg_score = v_training_avg,
        assessment_avg_score = v_assessment_avg,
        total_score = v_total,
        update_time = NOW();
END$$

CREATE TRIGGER trg_learning_record_after_insert
AFTER INSERT ON learning_record
FOR EACH ROW
BEGIN
    CALL sp_refresh_process_score(NEW.student_id);

    IF NEW.progress < 30 AND NOT EXISTS (
        SELECT 1 FROM warning_record
        WHERE student_id = NEW.student_id
          AND warning_type = '学习进度预警'
          AND status = '未处理'
    ) THEN
        INSERT INTO warning_record(student_id, warning_type, warning_reason, warning_level, create_time, status)
        VALUES (NEW.student_id, '学习进度预警', '微模块学习进度低于30%', '一般', NOW(), '未处理');
    END IF;
END$$

CREATE TRIGGER trg_learning_record_after_update
AFTER UPDATE ON learning_record
FOR EACH ROW
BEGIN
    CALL sp_refresh_process_score(NEW.student_id);

    IF NEW.progress < 30 AND NOT EXISTS (
        SELECT 1 FROM warning_record
        WHERE student_id = NEW.student_id
          AND warning_type = '学习进度预警'
          AND status = '未处理'
    ) THEN
        INSERT INTO warning_record(student_id, warning_type, warning_reason, warning_level, create_time, status)
        VALUES (NEW.student_id, '学习进度预警', '微模块学习进度低于30%', '一般', NOW(), '未处理');
    END IF;
END$$

CREATE TRIGGER trg_training_record_after_insert
AFTER INSERT ON training_record
FOR EACH ROW
BEGIN
    CALL sp_refresh_process_score(NEW.student_id);

    IF NEW.status = '已评价'
       AND ((NEW.ai_score + NEW.teacher_score) / 2) < 60
       AND NOT EXISTS (
            SELECT 1 FROM warning_record
            WHERE student_id = NEW.student_id
              AND warning_type = '实训成绩预警'
              AND status = '未处理'
       ) THEN
        INSERT INTO warning_record(student_id, warning_type, warning_reason, warning_level, create_time, status)
        VALUES (NEW.student_id, '实训成绩预警', '实场景实训平均得分低于60分', '重要', NOW(), '未处理');
    END IF;
END$$

CREATE TRIGGER trg_training_record_after_update
AFTER UPDATE ON training_record
FOR EACH ROW
BEGIN
    CALL sp_refresh_process_score(NEW.student_id);

    IF NEW.status = '已评价'
       AND ((NEW.ai_score + NEW.teacher_score) / 2) < 60
       AND NOT EXISTS (
            SELECT 1 FROM warning_record
            WHERE student_id = NEW.student_id
              AND warning_type = '实训成绩预警'
              AND status = '未处理'
       ) THEN
        INSERT INTO warning_record(student_id, warning_type, warning_reason, warning_level, create_time, status)
        VALUES (NEW.student_id, '实训成绩预警', '实场景实训平均得分低于60分', '重要', NOW(), '未处理');
    END IF;
END$$

CREATE TRIGGER trg_assessment_result_after_insert
AFTER INSERT ON assessment_result
FOR EACH ROW
BEGIN
    CALL sp_refresh_process_score(NEW.student_id);

    IF NEW.score < 60 AND NOT EXISTS (
        SELECT 1 FROM warning_record
        WHERE student_id = NEW.student_id
          AND warning_type = '测评能力预警'
          AND status = '未处理'
    ) THEN
        INSERT INTO warning_record(student_id, warning_type, warning_reason, warning_level, create_time, status)
        VALUES (NEW.student_id, '测评能力预警', '职业能力测评分数低于60分', '重要', NOW(), '未处理');
    END IF;
END$$

CREATE TRIGGER trg_assessment_result_after_update
AFTER UPDATE ON assessment_result
FOR EACH ROW
BEGIN
    CALL sp_refresh_process_score(NEW.student_id);

    IF NEW.score < 60 AND NOT EXISTS (
        SELECT 1 FROM warning_record
        WHERE student_id = NEW.student_id
          AND warning_type = '测评能力预警'
          AND status = '未处理'
    ) THEN
        INSERT INTO warning_record(student_id, warning_type, warning_reason, warning_level, create_time, status)
        VALUES (NEW.student_id, '测评能力预警', '职业能力测评分数低于60分', '重要', NOW(), '未处理');
    END IF;
END$$

DELIMITER ;

/* =========================================================
第7步：插入基础测试数据
说明：用于后续查询、视图、触发器截图。
========================================================= */
INSERT INTO role_info(role_name, description) VALUES
('管理员','维护用户、专业、岗位与系统数据'),
('教师','发布课程微模块与实训任务'),
('学生','学习微模块、完成实训、查看推荐');

INSERT INTO user_account(role_id, username, password, real_name, phone, email) VALUES
(1,'admin','pbkdf2_sha256$1200000$xvovPTDyQYYNmlidqgjAwk$4EYpAgyFjn1VUkJrVcboe2VmbLbQ7U2DLDJVEz22V0U=','系统管理员','13800000001','admin@example.com'),
(2,'t001','pbkdf2_sha256$1200000$xXYyX17n7GeXF8yf8iax3c$S+FgsiXXAowf2f7c3ZHpuZZB2CdoUMisFtXJNf7S8ZQ=','张小华','13800000002','t001@example.com'),
(2,'t002','pbkdf2_sha256$1200000$wy20xNRpKw0FP6GdJ0bHIg$g05gh+MU8nC2N3gJc3YtSkbbBgxHWUV9R0brApARMMQ=','李文静','13800000003','t002@example.com'),
(3,'s001','pbkdf2_sha256$1200000$HP2r0b3c7JA1gjaMls9GlH$h6mp2ls7jwtiWPQIO6B/kJ2EUDSdA7IsNlQ93jjbDw0=','王小明','13800000011','s001@example.com'),
(3,'s002','pbkdf2_sha256$1200000$OsO0gUu19eQrQZS2qjbqqC$iP8vVGeYMJp4rzDLCXwucCXkrpf21f1wpwdl0iN3k9w=','刘小雨','13800000012','s002@example.com'),
(3,'s003','pbkdf2_sha256$1200000$PehqHBMUrT4CJafgM0VuZU$bDUK5AqJ6d52wG1P4cgSH5ryImacvN8A56EsszIifSI=','陈晨','13800000013','s003@example.com'),
(3,'s004','pbkdf2_sha256$1200000$m4W8zPGExP0KCwNSzIXkHw$VPRj3GE/n5HhMht0ZtkmCEM/KzGKZym2eXUfWQ0Vem4=','赵一凡','13800000014','s004@example.com'),
(3,'s005','pbkdf2_sha256$1200000$zv5gXzNOr96SUwUvC34wxZ$gPw+mUKsIi5gfPgphIYrGEy/0k2yBt03RiwGwUbOU7w=','孙可','13800000015','s005@example.com');

INSERT INTO score_weight_config(
    config_name, module_weight, training_weight, assessment_weight, career_quality_weight, is_active
) VALUES ('默认形成性评价权重',30,40,20,10,1);

INSERT INTO major(major_name, college, description) VALUES
('软件工程','信息工程学院','面向软件开发与项目实施岗位'),
('数据科学与大数据技术','信息工程学院','面向数据处理与数据分析岗位');

INSERT INTO class_info(major_id, class_name, grade) VALUES
(1,'软件工程2301','2023'),
(2,'大数据2301','2023');

INSERT INTO teacher(user_id, teacher_no, title, department) VALUES
(2,'T2023001','讲师','信息工程学院'),
(3,'T2023002','副教授','创新创业学院');

INSERT INTO student(user_id, major_id, class_id, student_no, enrollment_year) VALUES
(4,1,1,'S2023001',2023),
(5,1,1,'S2023002',2023),
(6,2,2,'S2023003',2023),
(7,2,2,'S2023004',2023),
(8,2,2,'S2023005',2023);

INSERT INTO course(major_id, teacher_id, course_name, course_type, description) VALUES
(1,1,'数据库系统概论','专业课程','数据库基本原理与SQL实践'),
(2,1,'Python数据处理','专业课程','数据清洗、统计与可视化'),
(1,2,'大学生职业发展与就业指导','生涯课程','职业规划、简历与面试训练');

INSERT INTO micro_module(module_name, module_type, duration, knowledge_point, difficulty, description) VALUES
('SQL基础查询','专业模块',10,'SELECT语句','低','掌握基本查询'),
('连接查询实践','专业模块',12,'JOIN连接','中','掌握多表连接'),
('嵌套查询实践','专业模块',12,'子查询','中','掌握嵌套查询'),
('数据库完整性约束','专业模块',10,'主键外键约束','中','理解完整性设计'),
('数据清洗入门','专业模块',10,'缺失值处理','低','掌握基础清洗方法'),
('岗位能力分析','生涯模块',8,'岗位能力匹配','低','理解岗位能力要求'),
('简历结构优化','生涯模块',8,'简历诊断','低','优化简历结构'),
('模拟面试表达','生涯模块',10,'面试表达','中','提升面试表达能力'),
('项目需求分析','融合模块',15,'需求分析','高','结合岗位场景完成需求分析'),
('职场沟通协作','融合模块',10,'沟通协作','中','提升职场沟通能力');

INSERT INTO course_module(course_id, module_id, module_order) VALUES
(1,1,1),(1,2,2),(1,3,3),(1,4,4),
(2,5,1),(3,6,1),(3,7,2),(3,8,3),(3,10,4);

INSERT INTO ability(ability_name, ability_type, description) VALUES
('SQL数据查询','专业能力','能完成数据库查询与统计'),
('数据处理能力','专业能力','能清洗和处理业务数据'),
('需求分析能力','就业能力','能理解并拆解业务需求'),
('简历表达能力','就业能力','能准确呈现个人能力'),
('职场沟通能力','职业素养','能进行团队协作与汇报沟通');

INSERT INTO module_ability(module_id, ability_id, weight) VALUES
(1,1,1.00),(2,1,1.00),(3,1,0.80),(4,1,0.70),
(5,2,1.00),(9,3,1.00),(7,4,1.00),(8,5,0.80),(10,5,1.00);

INSERT INTO company(company_name, industry, contact_person, contact_phone) VALUES
('中国铝业集团有限公司','中央企业 / 有色金属与先进制造','中铝招聘平台','以官网公告为准'),
('国家电网有限公司','中央企业 / 能源电力','国家电网招聘平台','以官网公告为准'),
('中国电子科技集团有限公司','中央企业 / 电子信息与数字基础设施','中国电科招聘平台','以官网公告为准');

INSERT INTO job_position(company_id, position_name, industry, salary_range, description) VALUES
(1,'工程技术岗','先进制造','以官方公告为准','参考中铝集团校园招聘方向，面向材料、机械、电气、自动化、计算机等相关专业'),
(2,'电网数字化技术岗','能源电力数字化','以官方公告为准','参考国家电网招聘平台公告，关注电气、计算机、通信、自动化等专业能力'),
(3,'软件与系统开发岗','电子信息','以官方公告为准','参考中国电科校园招聘方向，参与软件开发、系统集成、数据处理与数字化项目交付');

INSERT INTO position_ability(position_id, ability_id, required_level) VALUES
(1,1,'熟练'),(1,3,'基础'),
(2,1,'基础'),(2,2,'熟练'),
(3,3,'熟练'),(3,5,'熟练');

INSERT INTO learning_path(path_name, major_id, target_position_id, description) VALUES
('电网数字化技术岗提升路径',2,2,'面向国企数字化与数据分析岗位的微模块学习路径'),
('工程技术岗提升路径',1,1,'面向央企工程技术与系统开发岗位的微模块学习路径');

INSERT INTO path_module(path_id, module_id, module_order) VALUES
(1,1,1),(1,5,2),(1,6,3),(1,9,4),
(2,1,1),(2,2,2),(2,4,3),(2,9,4);

INSERT INTO student_path(student_id, path_id, status) VALUES
(1,2,'学习中'),(3,1,'学习中');

INSERT INTO training_task(teacher_id, position_id, task_name, scene_type, difficulty, requirement, deliverable) VALUES
(1,2,'销售数据清洗与分析','数据处理场景','中','清洗销售数据并输出分析结论','数据分析报告'),
(1,3,'就业平台需求分析','需求分析场景','高','根据用户需求完成需求说明','需求说明书'),
(2,3,'职场沟通情景模拟','职场沟通场景','中','根据职场情境完成沟通方案','沟通方案');

INSERT INTO training_step(task_id, step_order, step_name, step_hint) VALUES
(1,1,'数据导入','检查字段、缺失值和重复数据'),
(1,2,'数据清洗','根据业务规则处理异常值'),
(1,3,'分析汇总','输出核心指标与结论'),
(2,1,'需求识别','明确用户角色和功能边界'),
(2,2,'需求整理','形成需求说明书结构');

INSERT INTO assessment(assessment_name, assessment_type, description) VALUES
('职业兴趣测评','职业兴趣','分析学生职业倾向'),
('就业能力测评','能力','评估就业核心能力'),
('职场素养测评','职业素养','评估沟通协作与职业态度');

-- 插入学习记录后，触发器会自动生成/更新 process_score，并对低进度学生生成 warning_record
INSERT INTO learning_record(student_id, module_id, progress, study_time, score, status) VALUES
(1,1,100,35,88,'已完成'),
(1,2,80,25,76,'学习中'),
(2,1,25,10,40,'学习中'),
(3,5,100,30,90,'已完成'),
(4,6,60,15,70,'学习中');

-- 插入实训记录后，触发器会自动更新 process_score
INSERT INTO training_record(student_id, task_id, submit_content, ai_score, teacher_score, feedback, correction_suggestion, status) VALUES
(1,1,'已提交销售数据分析报告',82,85,'分析较完整，图表表达可继续优化','建议增加可视化图表标题','已评价'),
(2,1,'提交初版报告',55,58,'数据清洗过程不够完整','建议补充缺失值处理步骤','已评价'),
(3,1,'提交完整报告',88,90,'分析逻辑清晰','可进一步补充业务解释','已评价'),
(4,2,'提交需求说明书',76,78,'需求边界还需细化','建议补充非功能需求','已评价'),
(5,3,'提交沟通方案',70,72,'表达较清楚','建议增强沟通结构','已评价');

-- 插入测评结果后，触发器会自动更新 process_score，并对低分学生生成 warning_record
INSERT INTO assessment_result(student_id, assessment_id, score, result_text) VALUES
(1,1,80,'倾向软件开发和项目实施'),
(2,2,55,'就业能力基础较弱，需要补充基础模块'),
(3,1,85,'倾向数据分析岗位');

INSERT INTO student_profile(student_id, foundation_level, learning_habit, weak_ability, career_interest) VALUES
(1,'中','学习稳定','需求分析能力','软件开发'),
(2,'低','学习进度偏慢','SQL数据查询','软件开发'),
(3,'中','完成度较高','职场沟通能力','数据分析');

INSERT INTO career_report(student_id, target_position_id, gap_analysis, plan_content) VALUES
(1,1,'需要提升项目需求分析能力','继续学习项目需求分析和数据库完整性约束模块'),
(3,2,'需要加强职场沟通表达','学习职场沟通协作模块');

INSERT INTO resume(student_id, target_position_id, resume_content, ai_comment, match_score) VALUES
(1,1,'软件工程学生，掌握SQL和Python基础','建议补充项目经历和量化成果',78),
(3,2,'大数据专业学生，完成数据分析课程','建议突出数据清洗和报告能力',85);

INSERT INTO interview_record(student_id, position_id, question, answer, ai_score, feedback) VALUES
(1,1,'请介绍一次你完成数据库项目的经历。','完成过就业平台数据库设计。',78,'回答有项目背景，但细节还可增强'),
(3,2,'如何处理数据中的缺失值？','先分析缺失原因，再选择填充或删除。',84,'回答较完整');

INSERT INTO recommendation(student_id, recommend_type, module_id, position_id, path_id, reason) VALUES
(2,'微模块推荐',1,NULL,NULL,'该生SQL基础得分偏低，推荐补学SQL基础查询'),
(3,'岗位推荐',NULL,2,NULL,'学习记录与数据分析助理岗位能力匹配度较高'),
(1,'学习路径推荐',NULL,NULL,2,'目标岗位为软件开发助理，推荐对应学习路径');

INSERT INTO qa_record(student_id, teacher_id, question_content, ai_answer, teacher_answer, status, answer_time) VALUES
(2,1,'连接查询和嵌套查询有什么区别？','连接查询强调多表横向关联，嵌套查询强调条件中包含子查询。','可以结合具体业务题目理解两者差异。','教师已回复',NOW());

/* =========================================================
第8步：ALTER TABLE 表结构修改示例
说明：满足题目中“修改表结构：增加列、删除列、增加约束”的要求。
========================================================= */
ALTER TABLE micro_module ADD COLUMN resource_url VARCHAR(255) NULL COMMENT '学习资源链接';
ALTER TABLE micro_module DROP COLUMN resource_url;
ALTER TABLE qa_record ADD COLUMN is_helpful TINYINT DEFAULT 0 COMMENT '答疑是否有帮助，0否1是';
ALTER TABLE qa_record ADD CONSTRAINT ck_qa_helpful CHECK (is_helpful IN (0,1));

/* =========================================================
第9步：数据操纵与查询示例
说明：截图时可以分别执行 INSERT、UPDATE、DELETE、SELECT、JOIN、GROUP BY、子查询。
========================================================= */
-- INSERT 示例：新增一条临时推荐记录
INSERT INTO recommendation(student_id, recommend_type, module_id, position_id, path_id, reason)
VALUES (4,'微模块推荐',10,NULL,NULL,'临时测试推荐记录，用于演示INSERT和DELETE');

-- UPDATE 示例：更新学习进度，触发器会同步刷新过程性成绩
UPDATE learning_record
SET progress = 100, score = 86, status = '已完成', last_study_time = NOW()
WHERE student_id = 1 AND module_id = 2;

-- DELETE 示例：删除临时测试推荐记录，不影响核心演示数据
DELETE FROM recommendation
WHERE student_id = 4 AND recommend_type = '微模块推荐' AND module_id = 10;

-- 普通查询：查询微模块列表
SELECT module_id, module_name, module_type, duration, difficulty
FROM micro_module;

-- 连接查询：查询学生微模块学习进度
SELECT 
    s.student_no,
    u.real_name,
    m.module_name,
    lr.progress,
    lr.score,
    lr.status
FROM learning_record lr
JOIN student s ON lr.student_id = s.student_id
JOIN user_account u ON s.user_id = u.user_id
JOIN micro_module m ON lr.module_id = m.module_id;

-- 分组统计查询：统计每个专业学生过程性平均成绩
SELECT 
    ma.major_name,
    ROUND(AVG(ps.total_score),2) AS avg_score
FROM process_score ps
JOIN student s ON ps.student_id = s.student_id
JOIN major ma ON s.major_id = ma.major_id
GROUP BY ma.major_name;

-- 嵌套查询：查询过程性成绩低于全体平均分的学生
SELECT s.student_id, s.student_no, u.real_name
FROM student s
JOIN user_account u ON s.user_id = u.user_id
WHERE s.student_id IN (
    SELECT student_id
    FROM process_score
    WHERE total_score < (
        SELECT AVG(total_score)
        FROM process_score
    )
);

/* =========================================================
第10步：创建视图
说明：满足题目中“创建视图”的要求，也方便展示学生端、教师端、数据大屏。
========================================================= */
CREATE OR REPLACE VIEW v_student_learning_progress AS
SELECT 
    s.student_id,
    s.student_no,
    u.real_name,
    ma.major_name,
    m.module_name,
    lr.progress,
    lr.score,
    lr.status
FROM learning_record lr
JOIN student s ON lr.student_id = s.student_id
JOIN user_account u ON s.user_id = u.user_id
JOIN major ma ON s.major_id = ma.major_id
JOIN micro_module m ON lr.module_id = m.module_id;

CREATE OR REPLACE VIEW v_teacher_dashboard AS
SELECT 
    c.course_name,
    mm.module_name,
    COUNT(lr.record_id) AS learner_count,
    ROUND(COALESCE(AVG(lr.progress),0),2) AS avg_progress,
    ROUND(COALESCE(AVG(lr.score),0),2) AS avg_score
FROM course c
JOIN course_module cm ON c.course_id = cm.course_id
JOIN micro_module mm ON cm.module_id = mm.module_id
LEFT JOIN learning_record lr ON mm.module_id = lr.module_id
GROUP BY c.course_name, mm.module_name;

CREATE OR REPLACE VIEW v_position_ability_gap AS
SELECT
    jp.position_name,
    a.ability_name,
    a.ability_type,
    pa.required_level
FROM job_position jp
JOIN position_ability pa ON jp.position_id = pa.position_id
JOIN ability a ON pa.ability_id = a.ability_id;

CREATE OR REPLACE VIEW v_platform_dashboard_summary AS
SELECT
    (SELECT COUNT(*) FROM student) AS student_count,
    (SELECT COUNT(*) FROM teacher) AS teacher_count,
    (SELECT COUNT(*) FROM micro_module) AS module_count,
    (SELECT COUNT(*) FROM training_task) AS training_task_count,
    (SELECT COUNT(*) FROM recommendation) AS recommendation_count,
    (SELECT COUNT(*) FROM warning_record WHERE status = '未处理') AS untreated_warning_count,
    (SELECT ROUND(AVG(total_score),2) FROM process_score) AS avg_process_score;

-- 查看视图结果：截图时可执行
SELECT * FROM v_student_learning_progress;
SELECT * FROM v_teacher_dashboard;
SELECT * FROM v_position_ability_gap;
SELECT * FROM v_platform_dashboard_summary;

/* =========================================================
第11步：触发器验证
说明：证明不是只创建触发器，而是触发器确实能自动生成预警、更新过程性成绩。
========================================================= */
-- 新增一条低进度学习记录，触发学习进度预警并刷新过程性成绩
INSERT INTO learning_record(student_id, module_id, progress, study_time, score, status)
VALUES (5, 1, 20, 5, 30, '学习中');

-- 查看触发器自动生成的预警记录
SELECT * FROM warning_record WHERE student_id = 5;

-- 查看触发器自动生成/更新的过程性成绩
SELECT * FROM process_score WHERE student_id = 5;

/* =========================================================
第12步：查看所有表
说明：用于最终检查数据库表是否创建完整。
========================================================= */
SHOW TABLES;
