import os
from pathlib import Path

import pymysql
from dotenv import load_dotenv


BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

SQL_FILE = BASE_DIR / "employment_ai_platform_optimized.sql"

DB_CONFIG = {
    "host": os.getenv("MYSQL_HOST", "127.0.0.1"),
    "user": os.getenv("MYSQL_USER", "root"),
    "password": os.getenv("MYSQL_PASSWORD", ""),
    "port": int(os.getenv("MYSQL_PORT", "3306")),
    "charset": "utf8mb4",
    "autocommit": False,
}


def strip_line_comments(sql: str) -> str:
    lines = []
    for line in sql.splitlines():
        stripped = line.strip()
        if stripped.startswith("--") or stripped.startswith("#"):
            continue
        lines.append(line)
    return "\n".join(lines)


def split_sql_statements(sql: str, delimiter: str = ";") -> list[str]:
    statements = []
    current = []
    in_single = False
    in_double = False
    in_backtick = False
    in_block_comment = False
    i = 0

    while i < len(sql):
        ch = sql[i]
        nxt = sql[i : i + 2]

        if in_block_comment:
            current.append(ch)
            if nxt == "*/":
                current.append("/")
                in_block_comment = False
                i += 2
                continue
            i += 1
            continue

        if not in_single and not in_double and not in_backtick and nxt == "/*":
            in_block_comment = True
            current.append(nxt)
            i += 2
            continue

        if ch == "'" and not in_double and not in_backtick:
            prev = sql[i - 1] if i > 0 else ""
            if prev != "\\":
                in_single = not in_single
        elif ch == '"' and not in_single and not in_backtick:
            prev = sql[i - 1] if i > 0 else ""
            if prev != "\\":
                in_double = not in_double
        elif ch == "`" and not in_single and not in_double:
            in_backtick = not in_backtick

        if (
            not in_single
            and not in_double
            and not in_backtick
            and not in_block_comment
            and sql.startswith(delimiter, i)
        ):
            statement = "".join(current).strip()
            if statement:
                statements.append(statement)
            current = []
            i += len(delimiter)
            continue

        current.append(ch)
        i += 1

    tail = "".join(current).strip()
    if tail:
        statements.append(tail)
    return statements


def iter_mysql_script(sql: str) -> list[str]:
    statements = []
    delimiter = ";"
    buffer = []

    for line in sql.splitlines():
        stripped = line.strip()
        if stripped.upper().startswith("DELIMITER "):
            if buffer:
                statements.extend(split_sql_statements("\n".join(buffer), delimiter))
                buffer = []
            delimiter = stripped.split(maxsplit=1)[1]
            continue
        buffer.append(line)

    if buffer:
        statements.extend(split_sql_statements("\n".join(buffer), delimiter))
    return statements


def execute_script() -> None:
    if not SQL_FILE.exists():
        raise FileNotFoundError(f"SQL file not found: {SQL_FILE}")

    sql = SQL_FILE.read_text(encoding="utf-8")
    sql = strip_line_comments(sql)
    statements = iter_mysql_script(sql)

    print(f"SQL file: {SQL_FILE}")
    print(f"Statements found: {len(statements)}")

    conn = pymysql.connect(**DB_CONFIG)
    try:
        with conn.cursor() as cursor:
            for index, statement in enumerate(statements, start=1):
                try:
                    cursor.execute(statement)
                    print(f"[{index:03d}/{len(statements)}] OK")
                except Exception as exc:
                    conn.rollback()
                    preview = " ".join(statement.split())[:500]
                    print(f"[{index:03d}/{len(statements)}] FAILED")
                    print(preview)
                    raise RuntimeError(f"SQL execution failed at statement {index}: {exc}") from exc
        conn.commit()
    finally:
        conn.close()

    print("Database initialization completed.")


if __name__ == "__main__":
    execute_script()
