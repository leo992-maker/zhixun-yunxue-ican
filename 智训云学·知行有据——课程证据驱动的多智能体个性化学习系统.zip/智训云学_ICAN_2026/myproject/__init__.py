import pymysql

# Django 5.x checks the MySQLdb driver version before opening a connection.
# PyMySQL works as a MySQLdb replacement here, but some environments expose a
# legacy compatibility version such as 1.4.6. Patch the advertised version so
# Django accepts the PyMySQL adapter.
pymysql.version_info = (2, 2, 1, "final", 0)
pymysql.__version__ = "2.2.1"
pymysql.install_as_MySQLdb()
