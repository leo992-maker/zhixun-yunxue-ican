from django.conf import settings
from django.conf.urls.static import static
from django.shortcuts import redirect
from django.urls import path, include

urlpatterns = [
    path('', lambda request: redirect('/showcase/')),
    # A3 routes are deliberately registered before legacy B1 routes so the
    # established role landing paths can be upgraded without deleting B1 views.
    path('', include('agent_learning.urls')),
    path('', include('app.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

