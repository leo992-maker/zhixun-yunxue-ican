﻿$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$compose = Join-Path $root 'deploy\compose.local.yaml'
$envFile = Join-Path $root 'deploy\local-demo.env'
Set-Location -LiteralPath $root

if (-not (Test-Path -LiteralPath $envFile)) {
    Write-Host '请先双击“一键启动本地演示.bat”生成私有配置。' -ForegroundColor Red
    exit 1
}

Write-Host '记事本将打开私有配置。只填写你已开通服务的密钥，保留其他行；保存并关闭后会重启模型调用进程。'
Start-Process -FilePath notepad.exe -ArgumentList ('"' + $envFile + '"') -Wait
& docker compose --env-file $envFile -f $compose up -d --no-deps --force-recreate web worker
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host '正在向已配置的供应商发出最短连接请求；这是真实 API 调用，可能消耗少量额度。'
& docker compose --env-file $envFile -f $compose exec -T web python manage.py verify_ai_services --include-tts --strict
if ($LASTEXITCODE -ne 0) {
    Write-Host '模型验证未通过。检查服务授权、额度、模型名称、密钥和网络；具体状态见上方。' -ForegroundColor Yellow
    exit $LASTEXITCODE
}
Write-Host '模型连接通过。现在可在学生账号中发起新任务；预置的历史资源不能证明本次在线生成。' -ForegroundColor Green
