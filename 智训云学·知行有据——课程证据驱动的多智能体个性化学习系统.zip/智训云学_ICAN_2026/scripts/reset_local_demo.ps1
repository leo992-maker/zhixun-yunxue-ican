﻿$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$envFile = Join-Path $root 'deploy\local-demo.env'
Set-Location -LiteralPath $root

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { throw '找不到 Docker，请先启动 Docker Desktop。' }
& docker info --format '{{.ServerVersion}}' *> $null
if ($LASTEXITCODE -ne 0) { throw 'Docker Desktop 尚未启动，请等待引擎显示 Running。' }

Write-Host '此操作只删除本项目的本地演示容器和数据卷，不影响其他 Docker 项目。' -ForegroundColor Yellow
Write-Host '它会清除本地演示账号、任务和上传文件；需要保留数据时请先取消。' -ForegroundColor Yellow
$answer = Read-Host '确认清除请输入 RESET'
if ($answer -cne 'RESET') {
    Write-Host '已取消，没有删除任何数据。'
    exit 1
}

$compose = Join-Path $root 'deploy\compose.local.yaml'
if (Test-Path -LiteralPath $envFile) {
    & docker compose --env-file $envFile -f $compose down --remove-orphans
    if ($LASTEXITCODE -ne 0) { throw '停止旧演示容器失败，请检查 Docker Desktop 状态。' }
} else {
    $containers = @(& docker ps -aq --filter 'label=com.docker.compose.project=zhixun-ican-local' | Where-Object { $_ })
    if ($LASTEXITCODE -ne 0) { throw '读取本项目旧容器失败，没有清理数据卷。' }
    if ($containers.Count -gt 0) {
        & docker rm -f $containers | Out-Null
        if ($LASTEXITCODE -ne 0) { throw '删除旧演示容器失败，数据卷尚未清理。' }
    }
}

foreach ($volume in @('zhixun-ican-local_local_mysql_data', 'zhixun-ican-local_local_media_data')) {
    # Docker's name filter can match a substring; compare exact names before deletion.
    $found = @(& docker volume ls -q --filter ('name=' + $volume) | Where-Object { $_ -eq $volume })
    if ($LASTEXITCODE -ne 0) { throw "读取本项目数据卷 $volume 失败。" }
    if ($found.Count -gt 0) {
        & docker volume rm $found | Out-Null
        if ($LASTEXITCODE -ne 0) { throw "删除本项目数据卷 $volume 失败，请检查是否还有容器占用。" }
    }
}

Write-Host '本地演示数据已清除。现在可以重新双击“一键启动本地演示.bat”。' -ForegroundColor Green
