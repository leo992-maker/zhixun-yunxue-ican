﻿param([switch]$NoBrowser)

$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$compose = Join-Path $root 'deploy\compose.local.yaml'
$envFile = Join-Path $root 'deploy\local-demo.env'
Set-Location -LiteralPath $root

function New-RandomValue([int]$count) {
    $bytes = [byte[]]::new($count)
    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
    return [Convert]::ToBase64String($bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_')
}

function Get-PrivateValue([string]$name) {
    $line = Get-Content -LiteralPath $envFile -Encoding UTF8 |
        Where-Object { $_ -match ('^' + [regex]::Escape($name) + '=') } |
        Select-Object -Last 1
    if (-not $line) { throw "Missing $name in private demo configuration." }
    return (($line -split '=', 2)[1]).Trim()
}

function Get-ExistingLocalState() {
    $containers = @(& docker ps -aq --filter 'label=com.docker.compose.project=zhixun-ican-local' | Where-Object { $_ })
    $volumes = @(& docker volume ls -q --filter 'name=zhixun-ican-local_local_mysql_data' | Where-Object { $_ })
    return @{ Containers = $containers; Volumes = $volumes }
}

function Test-PortBusy([int]$port) {
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $result = $client.BeginConnect('127.0.0.1', $port, $null, $null)
        if (-not $result.AsyncWaitHandle.WaitOne(150)) { return $false }
        try { $client.EndConnect($result); return $true } catch { return $false }
    } finally { $client.Close() }
}

try {
    if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
        throw '请先安装并启动 Docker Desktop（Windows），然后重新双击此文件。'
    }
    & docker info --format '{{.ServerVersion}}' *> $null
    if ($LASTEXITCODE -ne 0) { throw 'Docker Desktop 尚未启动；打开它并等待引擎显示 Running。' }
    & docker compose version *> $null
    if ($LASTEXITCODE -ne 0) { throw '缺少 Docker Compose；请安装最新 Docker Desktop。' }

    $requiredSecrets = @('MYSQL_PASSWORD', 'DJANGO_SECRET_KEY', 'DEMO_ADMIN_PASSWORD', 'DEMO_TEACHER_PASSWORD', 'DEMO_STUDENT_PASSWORD')
    if (-not (Test-Path -LiteralPath $envFile)) {
        # A fresh password cannot unlock an old MySQL volume. Stop before Compose
        # starts containers so the user gets a repair instruction instead of a
        # misleading 60-second connection timeout.
        $oldState = Get-ExistingLocalState
        if ($oldState.Containers.Count -gt 0 -or $oldState.Volumes.Count -gt 0) {
            throw '检测到旧的本地演示数据卷，但 deploy/local-demo.env 已不存在。请恢复原配置文件；如果不需要旧数据，请运行“重置本地演示数据.bat”后再启动。'
        }
        $port = 8000
        while ((Test-PortBusy $port) -and $port -le 8010) { $port++ }
        if ($port -gt 8010) { throw '8000–8010 端口均已占用；请先关闭占用它们的程序。' }
        $databasePassword = New-RandomValue 32
        $djangoSecret = New-RandomValue 64
        $adminPassword = New-RandomValue 24
        $teacherPassword = New-RandomValue 24
        $studentPassword = New-RandomValue 24
        $rows = @(
            '# Generated locally. NEVER upload this file or paste its contents into chat.',
            'DEMO_MODE=local',
            "DEMO_PORT=$port",
            "MYSQL_PASSWORD=$databasePassword",
            "DJANGO_SECRET_KEY=$djangoSecret",
            "DEMO_ADMIN_PASSWORD=$adminPassword",
            "DEMO_TEACHER_PASSWORD=$teacherPassword",
            "DEMO_STUDENT_PASSWORD=$studentPassword",
            'A3_MODEL_PROVIDER=spark',
            '# Spark legacy: spark-api-open.xf-yun.com/v1 + model ID + APIPassword; X2.5/MaaS: copy BASE_URL/MODEL/API Key from API调用 page.',
            '# Recommended delivery model: Spark-X2.5-1.7B MaaS; copy its newly rotated API Key.',
            'SPARK_BASE_URL=https://maas-api.cn-huabei-1.xf-yun.com/v2',
            'SPARK_MODEL=spark-x2.5-1.7b',
            'SPARK_API_PASSWORD=',
            '# GLM MaaS: set A3_MODEL_PROVIDER=glm and copy the API调用 page values below.',
            'GLM_BASE_URL=https://maas-api.cn-huabei-1.xf-yun.com/v2',
            'GLM_MODEL=xopglm5.3',
            'GLM_API_KEY=',
            'AI_BASE_URL=https://api.deepseek.com',
            'AI_MODEL=deepseek-flash',
            'AI_API_KEY=',
            'SPARK_TTS_VOICE=xiaoyan',
            'SPARK_TTS_APP_ID=',
            'SPARK_TTS_API_KEY=',
            'SPARK_TTS_API_SECRET='
        )
        [System.IO.File]::WriteAllLines($envFile, [string[]]$rows, [System.Text.UTF8Encoding]::new($false))
        Write-Host '已自动生成私有数据库密码、Django 密钥和演示账号密码。' -ForegroundColor Green
    }

    # The first Windows package could leave all credentials blank before Docker
    # created any containers. Repair those generated blanks in place, retaining
    # nonempty values and optional model credentials. Never rotate a live volume.
    $blankSecrets = @($requiredSecrets | Where-Object { -not (Get-PrivateValue $_) })
    if ($blankSecrets.Count -gt 0) {
        $existingContainers = @(& docker ps -aq --filter 'label=com.docker.compose.project=zhixun-ican-local' | Where-Object { $_ })
        $existingVolumes = @(& docker volume ls -q --filter 'name=zhixun-ican-local_local_mysql_data' | Where-Object { $_ })
        if ($existingContainers.Count -gt 0 -or $existingVolumes.Count -gt 0) {
            throw '私有配置缺少必要密码，但已有项目容器或数据卷。为保护数据，未自动更改密码；请保留该文件并联系维护者。'
        }
        $lines = [System.IO.File]::ReadAllLines($envFile, [System.Text.Encoding]::UTF8)
        if ($lines.Count -eq 0 -or $lines[0] -ne '# Generated locally. NEVER upload this file or paste its contents into chat.') {
            throw '私有配置缺少必要密码，且不是本项目自动生成的文件；请检查配置。'
        }
        $fresh = @{
            MYSQL_PASSWORD = (New-RandomValue 32)
            DJANGO_SECRET_KEY = (New-RandomValue 64)
            DEMO_ADMIN_PASSWORD = (New-RandomValue 24)
            DEMO_TEACHER_PASSWORD = (New-RandomValue 24)
            DEMO_STUDENT_PASSWORD = (New-RandomValue 24)
        }
        for ($index = 0; $index -lt $lines.Count; $index++) {
            if ($lines[$index] -match '^([A-Z_]+)=$' -and $blankSecrets -contains $Matches[1]) {
                $name = $Matches[1]
                $lines[$index] = "$name=$($fresh[$name])"
            }
        }
        [System.IO.File]::WriteAllLines($envFile, [string[]]$lines, [System.Text.UTF8Encoding]::new($false))
        Write-Host '已修复上次未完成的私有配置；已有非空项保持不变。' -ForegroundColor Yellow
    }
    foreach ($key in $requiredSecrets) {
        if (-not (Get-PrivateValue $key)) { throw "$key 不能为空，请查看 deploy/local-demo.env。" }
    }
    $port = Get-PrivateValue 'DEMO_PORT'
    $url = "http://127.0.0.1:$port/login/"

    Write-Host '正在启动 MySQL、网站和智能体 Worker；第一次需要下载镜像并安装依赖，可能较久...'
    & docker compose --env-file $envFile -f $compose up -d --build
    if ($LASTEXITCODE -ne 0) {
        Write-Host 'Docker 镜像构建或容器启动失败；请先看上方的 Failed to fetch、502 或 ERROR。' -ForegroundColor Yellow
        Write-Host '如果是下载源临时故障，保持原有数据，稍后重试一键启动即可。' -ForegroundColor Yellow
        Write-Host '若容器已启动，其最近日志如下：' -ForegroundColor Yellow
        & docker compose --env-file $envFile -f $compose logs --tail=80 db
        & docker compose --env-file $envFile -f $compose logs --tail=60 init
        throw 'Docker 构建或启动失败；请以最先出现的错误信息为准。'
    }

    $ready = $false
    for ($attempt = 0; $attempt -lt 90; $attempt++) {
        try {
            $reply = Invoke-WebRequest -Uri "http://127.0.0.1:$port/health/ready/" -UseBasicParsing -TimeoutSec 2
            if ($reply.StatusCode -eq 200) { $ready = $true; break }
        } catch { }
        Start-Sleep -Seconds 2
    }
    if (-not $ready) { throw '网站未在 3 分钟内就绪。请双击“查看本地运行状态.bat”查看日志。' }

    $running = @(& docker compose --env-file $envFile -f $compose ps -q db web worker | Where-Object { $_ })
    if ($running.Count -ne 3) { throw '网站已响应，但数据库、网站或 Worker 未全部运行。请检查运行状态。' }

    Write-Host ''
    Write-Host "完整交互网站：$url" -ForegroundColor Green
    Write-Host '学生演示账号：s001'
    Write-Host ('学生演示密码：' + (Get-PrivateValue 'DEMO_STUDENT_PASSWORD'))
    Write-Host '在学生端选择课程与知识点后提交生成任务，Worker 会继续处理。'
    Write-Host '本地访问仅限这台电脑；模型密钥可之后双击“配置并验证模型.bat”填写。'
    if (-not $NoBrowser) { Start-Process $url }
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
