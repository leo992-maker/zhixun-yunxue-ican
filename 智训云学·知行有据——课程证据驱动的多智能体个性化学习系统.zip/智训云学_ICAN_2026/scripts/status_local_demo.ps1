﻿$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$compose = Join-Path $root 'deploy\compose.local.yaml'
$envFile = Join-Path $root 'deploy\local-demo.env'
if (-not (Test-Path -LiteralPath $envFile)) { Write-Host '请先双击“一键启动本地演示.bat”。'; exit 1 }
& docker compose --env-file $envFile -f $compose ps
Write-Host '最近的网站与 Worker 日志：'
& docker compose --env-file $envFile -f $compose logs --tail=35 web worker init
