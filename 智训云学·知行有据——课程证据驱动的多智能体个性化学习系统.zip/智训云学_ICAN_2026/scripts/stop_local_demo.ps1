﻿$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$compose = Join-Path $root 'deploy\compose.local.yaml'
$envFile = Join-Path $root 'deploy\local-demo.env'
if (-not (Test-Path -LiteralPath $envFile)) { Write-Host '本地演示尚未创建。'; exit 0 }
& docker compose --env-file $envFile -f $compose down
exit $LASTEXITCODE
