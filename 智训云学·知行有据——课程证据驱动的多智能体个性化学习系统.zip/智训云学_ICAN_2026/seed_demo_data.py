"""Idempotently expand the database to a competition-ready synthetic dataset."""

import os
import shutil
from decimal import Decimal
from pathlib import Path

import django
from dotenv import load_dotenv


BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "myproject.settings")
django.setup()

from django.db import transaction
from django.test import override_settings
from django.utils import timezone

from app.models import (
    AIEvaluation,
    AIEvaluationDimension,
    Ability,
    Assessment,
    AssessmentResult,
    ClassInfo,
    Company,
    Course,
    CourseModule,
    EvaluationRubric,
    InterviewRecord,
    JobPosition,
    LearningPath,
    LearningRecord,
    Major,
    MicroModule,
    ModuleAbility,
    PathModule,
    PositionAbility,
    Recommendation,
    Resume,
    RoleInfo,
    RubricDimension,
    Student,
    StudentPath,
    StudentProfile,
    Teacher,
    TeacherReview,
    TrainingRecord,
    TrainingStep,
    TrainingTask,
    UserAccount,
)
from app.services.identity_service import DEMO_TEACHER_NAMES, normalize_teacher_real_name
from app.services.security_service import hash_password
from app.views import persist_training_evaluation


MAJORS = [
    "软件工程", "计算机科学与技术", "数据科学与大数据技术", "人工智能", "网络工程",
    "网络空间安全", "物联网工程", "数字媒体技术", "信息管理与信息系统", "电子商务",
    "智能科学与技术", "电子信息工程", "自动化", "工业设计", "工商管理",
]
ABILITIES = [
    ("Python工程开发", "专业能力"), ("Java Web开发", "专业能力"), ("前端工程化", "专业能力"),
    ("数据库设计", "专业能力"), ("软件测试", "专业能力"), ("需求分析", "就业能力"),
    ("接口设计", "专业能力"), ("数据可视化", "专业能力"), ("项目文档", "就业能力"),
    ("沟通表达", "职业素养"), ("团队协作", "职业素养"), ("职业规划", "就业能力"),
]
MODULE_TOPICS = [
    "Python数据清洗", "Pandas聚合分析", "Django模型设计", "Django权限控制", "REST接口规范",
    "Java分层架构", "Spring事务基础", "前端响应式布局", "JavaScript异步交互", "TypeScript类型设计",
    "MySQL表结构设计", "SQL索引与执行计划", "数据库事务与锁", "接口自动化测试", "单元测试设计",
    "安全文件上传", "异常处理策略", "需求用例建模", "非功能需求分析", "数据可视化叙事",
    "ECharts图表实践", "项目README写作", "技术方案汇报", "Git协作流程", "代码评审实践",
    "岗位能力拆解", "STAR项目表达", "技术简历优化", "模拟面试表达", "职场沟通反馈",
    "团队冲突处理", "软件工程职业伦理", "学习路径规划", "实习目标管理", "创新方案评估",
    "交付质量检查",
]
TASK_NAMES = [
    "Python销售数据分析项目", "Django教学管理系统开发", "Java Web课程服务开发", "响应式作品集页面开发",
    "教务数据库设计与SQL实训", "软件测试计划与缺陷分析", "校园服务需求分析", "课程平台接口设计",
    "学习行为数据可视化", "项目文档与答辩汇报", "安全文件上传模块开发", "学生预警规则实现",
    "课程推荐服务设计", "岗位能力画像建模", "AI评价结果校验", "实训报告导出实现",
    "并发登录与会话测试", "MySQL慢查询优化", "前端无障碍改造", "教师复核工作流开发",
    "提交版本对比功能", "数据质量巡检任务", "消息通知中心开发", "教学驾驶舱指标设计",
]
COMPANIES = [
    "启航数字科技", "云岭软件服务", "星河数据智能", "远景网络安全", "蓝桥物联网",
    "知行教育科技", "新域电子商务", "光点数字媒体", "融智信息系统", "拓维人工智能",
    "经纬自动化", "创研电子信息", "匠心工业设计", "博远管理咨询", "未来工程实验室",
]
POSITION_NAMES = [
    "Python开发工程师", "数据分析工程师", "Django后端工程师", "Java开发工程师", "前端开发工程师",
    "数据库工程师", "软件测试工程师", "需求分析师", "接口设计工程师", "数据可视化工程师",
    "网络安全工程师", "物联网开发工程师", "AI应用工程师", "产品助理", "实施工程师",
    "运维开发工程师", "数据治理专员", "技术文档工程师", "项目管理助理", "电子商务运营",
    "数字媒体开发", "信息系统顾问", "自动化软件工程师", "嵌入式软件工程师", "解决方案工程师",
    "用户研究助理", "质量保障工程师", "云平台工程师", "教学技术支持", "软件交付工程师",
]


def get_or_create_account(role, username, real_name, password, index, synchronize_real_name=False):
    """Create a demo account, or safely correct only an explicitly-owned demo identity.

    Passwords and all non-demo profiles remain untouched on repeat runs.
    """
    account = UserAccount.objects.filter(username=username).first()
    if account:
        if synchronize_real_name and username in DEMO_TEACHER_NAMES and role.role_name == "教师":
            expected_name = DEMO_TEACHER_NAMES[username]
            if account.real_name != expected_name:
                account.real_name = expected_name
                account.save(update_fields=["real_name"])
        return account
    if role.role_name == "教师":
        real_name = normalize_teacher_real_name(real_name)
    return UserAccount.objects.create(
        role=role,
        username=username,
        password=hash_password(password),
        real_name=real_name,
        phone=f"139{index:08d}",
        email=f"{username}@demo.zhixun.local",
        status="正常",
        create_time=timezone.now(),
    )


def persist_demo_evaluation(student, task, text_content, attachments, idempotency_key):
    """Create stable synthetic evidence without consuming or impersonating a live AI call."""
    with override_settings(AI_API_KEY=""):
        return persist_training_evaluation(
            student, task, text_content, attachments, idempotency_key
        )


def ensure_second_rubric_version(task, teacher):
    """Publish a deterministic V2 rubric for the dedicated recording task."""
    first = EvaluationRubric.objects.filter(task=task).order_by("version_no").first()
    if not first:
        return None
    second, created = EvaluationRubric.objects.get_or_create(
        task=task,
        version_no=2,
        defaults={
            "created_by": teacher,
            "rubric_name": f"{task.task_name}标准量规 V2",
            "description": "录屏合成演示量规：在V1基础上强化异常处理、测试证据与文档可追溯性。",
            "total_weight": Decimal("100"),
            "source": "teacher",
            "prompt_version": first.prompt_version,
            "status": "已发布",
            "is_active": True,
        },
    )
    if created:
        for dimension in RubricDimension.objects.filter(rubric=first).order_by("dimension_order"):
            RubricDimension.objects.create(
                rubric=second,
                dimension_order=dimension.dimension_order,
                dimension_name=dimension.dimension_name,
                weight=dimension.weight,
                max_score=dimension.max_score,
                criteria=dimension.criteria,
                excellent_standard=dimension.excellent_standard,
                qualified_standard=dimension.qualified_standard,
                common_issues=dimension.common_issues,
                ai_enabled=dimension.ai_enabled,
                teacher_review_required=True,
            )
    EvaluationRubric.objects.filter(task=task).exclude(rubric_id=second.rubric_id).update(is_active=False)
    if not second.is_active or second.status != "已发布":
        second.is_active = True
        second.status = "已发布"
        second.save(update_fields=["is_active", "status"])
    return second


def ensure_recording_showcase(student, teacher, position, modules, paths):
    """Prepare one complete, repeatable V1/V2 recording workflow using synthetic data."""
    task, _ = TrainingTask.objects.get_or_create(
        task_name="录屏演示·学生成果安全评价",
        defaults={
            "teacher": teacher,
            "position": position,
            "scene_type": "项目实施场景",
            "difficulty": "中",
            "requirement": "提交可静态解析的Python成果，说明输入校验、异常处理、测试证据与版本改进。",
            "deliverable": "Python源码与版本改进说明（合成演示数据）",
            "publish_time": timezone.now(),
        },
    )
    for order, step_name in enumerate(("理解任务与证据", "上传V1并查看评价", "改进后提交V2"), 1):
        TrainingStep.objects.get_or_create(
            task=task,
            step_order=order,
            defaults={"step_name": step_name, "step_hint": "仅上传安全的合成演示文件，平台只做静态解析。"},
        )

    media_dir = BASE_DIR / "media" / "demo_assets"
    media_dir.mkdir(parents=True, exist_ok=True)
    attachments = {}
    for version, file_name in ((1, "student_training_demo_v1.py"), (2, "student_training_demo.py")):
        source = BASE_DIR / "demo_assets" / file_name
        destination = media_dir / file_name
        shutil.copy2(source, destination)
        attachments[version] = [{
            "name": file_name,
            "url": f"/media/demo_assets/{file_name}",
            "bytes": destination.stat().st_size,
        }]

    v1 = persist_demo_evaluation(
        student,
        task,
        "合成演示V1：已完成基础统计函数，但输入校验、精度处理和测试说明仍需补充。",
        attachments[1],
        "recording-showcase-s001-v1",
    )
    if not v1:
        return task
    ensure_second_rubric_version(task, teacher)
    v2 = persist_demo_evaluation(
        student,
        task,
        "合成演示V2：补充空数据处理、浮点转换、精度控制、文档说明与可重复样例。",
        attachments[2],
        "recording-showcase-s001-v2",
    )

    for evaluation, score, final_score, comment in (
        (v1, Decimal("72"), Decimal("76"), "V1已完成核心逻辑，需补充输入边界与测试证据。"),
        (v2, Decimal("88"), Decimal("91"), "V2补齐异常处理、精度控制与可追溯证据，进步明确。"),
    ):
        if not evaluation:
            continue
        evaluation.total_score = score
        evaluation.summary = "合成演示规则预检：平台未调用AI；各维度建议分仅供教师复核。"
        evaluation.source = "rule_based_fallback"
        evaluation.is_ai_generated = False
        evaluation.model_name = "未调用"
        evaluation.confidence = Decimal("0.680")
        evaluation.status = "已复核"
        evaluation.save(update_fields=[
            "total_score", "summary", "source", "is_ai_generated", "model_name", "confidence", "status"
        ])
        evaluation.submission.status = "已复核"
        evaluation.submission.save(update_fields=["status"])
        dimension_scores = [score - Decimal("5"), score, score + Decimal("3"), score + Decimal("1"), score + Decimal("4"), score - Decimal("2")]
        adjusted = {}
        comparison_dimensions = []
        for index, detail in enumerate(
            AIEvaluationDimension.objects.filter(evaluation=evaluation).select_related("dimension").order_by("dimension__dimension_order")
        ):
            dimension_score = max(Decimal("0"), min(Decimal("100"), dimension_scores[index % len(dimension_scores)]))
            detail.score = dimension_score
            detail.reason = "基于静态文件内容、提交说明与量规标准生成的合成演示规则建议。"
            detail.evidence = "证据来自上传源码与在线提交说明；平台未执行学生代码。"
            detail.file_name = evaluation.submission.files.first().original_name if evaluation.submission.files.exists() else "在线提交说明.txt"
            detail.line_reference = "静态解析片段"
            detail.confidence = Decimal("0.680")
            detail.save(update_fields=["score", "reason", "evidence", "file_name", "line_reference", "confidence"])
            adjusted[str(detail.dimension_id)] = float(dimension_score)
            comparison_dimensions.append({
                "dimension_id": detail.dimension_id,
                "name": detail.dimension.dimension_name,
                "score": float(dimension_score),
                "max_score": float(detail.max_score),
            })
        raw_response = dict(evaluation.raw_response_json or {})
        raw_response.update({
            "total_score": float(score),
            "dimensions": comparison_dimensions,
            "source": "rule_based_fallback",
            "is_ai_generated": False,
            "model": "未调用",
            "confidence": 0.68,
        })
        evaluation.raw_response_json = raw_response
        evaluation.save(update_fields=["raw_response_json"])
        TeacherReview.objects.update_or_create(
            evaluation=evaluation,
            defaults={
                "teacher": teacher,
                "adjusted_scores_json": adjusted,
                "teacher_comment": f"合成演示教师复核：{comment}",
                "ai_error_notes": "本条为录屏稳定数据，明确采用规则降级，未伪装为AI生成。",
                "decision": "通过",
                "teacher_score": final_score,
                "final_score": final_score,
            },
        )

    TrainingRecord.objects.update_or_create(
        student=student,
        task=task,
        defaults={
            "submit_content": "录屏合成演示V2成果，已保留V1/V2证据链。",
            "ai_score": 88,
            "teacher_score": 91,
            "feedback": "规则预检建议分88，教师终审91；AI未调用状态已明确展示。",
            "correction_suggestion": "继续增加单元测试并在README说明边界条件。",
            "status": "已评价",
            "submit_time": timezone.now(),
        },
    )
    Recommendation.objects.update_or_create(
        student=student,
        recommend_type="微模块推荐",
        module=modules[16],
        defaults={"reason": "根据V1/V2差异，推荐补强异常处理与测试证据（合成演示）。", "recommend_time": timezone.now()},
    )
    StudentPath.objects.get_or_create(
        student=student,
        path=paths[0],
        defaults={"assign_time": timezone.now(), "status": "学习中"},
    )
    return task


def seed():
    teacher_role = RoleInfo.objects.get(role_name="教师")
    student_role = RoleInfo.objects.get(role_name="学生")

    majors = []
    classes = []
    for major_index, name in enumerate(MAJORS, 1):
        major, _ = Major.objects.update_or_create(
            major_name=name,
            defaults={"college": "数字技术学院", "description": "中国软件杯竞赛合成演示专业数据"},
        )
        majors.append(major)
        for class_seq in (1, 2):
            class_info, _ = ClassInfo.objects.get_or_create(
                major=major,
                class_name=f"{name[:6]}23{class_seq:02d}",
                defaults={"grade": "2023"},
            )
            classes.append(class_info)

    teachers = []
    for index, (username, natural_name) in enumerate(DEMO_TEACHER_NAMES.items(), 1):
        account = get_or_create_account(
            teacher_role,
            username,
            natural_name,
            f"Teacher@B{index}",
            1000 + index,
            synchronize_real_name=True,
        )
        teacher, _ = Teacher.objects.get_or_create(
            user=account,
            defaults={
                "teacher_no": f"T2026{index:03d}",
                "title": "讲师" if index % 3 else "副教授",
                "department": "数字技术学院",
            },
        )
        teachers.append(teacher)
    teachers = list(Teacher.objects.select_related("user").order_by("teacher_id")[:10])

    students = list(Student.objects.select_related("user", "major", "class_field").order_by("student_id"))
    for index in range(len(students) + 1, 61):
        username = f"s{index:03d}"
        account = get_or_create_account(
            student_role, username, f"演示学生{index:03d}", f"Student@B{index:03d}", 2000 + index
        )
        class_info = classes[(index - 1) % len(classes)]
        student, _ = Student.objects.get_or_create(
            user=account,
            defaults={
                "major": class_info.major,
                "class_field": class_info,
                "student_no": f"S2026{index:04d}",
                "enrollment_year": "2023",
            },
        )
        students.append(student)
    students = list(Student.objects.select_related("user", "major", "class_field").order_by("student_id")[:60])

    courses = []
    for index, major in enumerate(majors[:12]):
        course, _ = Course.objects.get_or_create(
            major=major,
            course_name=f"{major.major_name}软件实训",
            defaults={
                "teacher": teachers[index % len(teachers)],
                "course_type": "融合课程",
                "description": "专业能力、实训评价与就业能力融合课程（竞赛合成演示数据）",
                "create_time": timezone.now(),
            },
        )
        courses.append(course)

    abilities = []
    for name, ability_type in ABILITIES:
        ability, _ = Ability.objects.update_or_create(
            ability_name=name,
            defaults={"ability_type": ability_type, "description": "竞赛演示能力维度"},
        )
        abilities.append(ability)

    modules = []
    for index, topic in enumerate(MODULE_TOPICS, 1):
        module, _ = MicroModule.objects.get_or_create(
            module_name=topic,
            defaults={
                "module_type": "专业模块" if index <= 24 else "融合模块" if index <= 30 else "生涯模块",
                "duration": 5 + index % 11,
                "knowledge_point": topic,
                "difficulty": ("低", "中", "高")[index % 3],
                "description": "5-15分钟微模块，关联实训证据与岗位能力（竞赛合成演示数据）",
            },
        )
        modules.append(module)
        course = courses[(index - 1) % len(courses)]
        CourseModule.objects.get_or_create(
            course=course, module=module, defaults={"module_order": 1 + (index - 1) // len(courses)}
        )
        for offset in (0, 1):
            ability = abilities[(index - 1 + offset) % len(abilities)]
            ModuleAbility.objects.get_or_create(
                module=module,
                ability=ability,
                defaults={"weight": Decimal("0.70") if offset == 0 else Decimal("0.30")},
            )

    companies = []
    for name in COMPANIES:
        company, _ = Company.objects.update_or_create(
            company_name=f"演示·{name}",
            defaults={
                "industry": "软件与数字化服务",
                "contact_person": "竞赛合成演示数据",
                "contact_phone": "非实时招聘信息",
            },
        )
        companies.append(company)

    positions = []
    for index, name in enumerate(POSITION_NAMES, 1):
        position, _ = JobPosition.objects.get_or_create(
            company=companies[(index - 1) % len(companies)],
            position_name=name,
            defaults={
                "industry": "数字技术",
                "salary_range": "竞赛演示，不代表实时招聘",
                "description": "合成岗位能力模型，仅用于教学评价与推荐演示。",
            },
        )
        positions.append(position)
        for offset, level in ((0, "熟练"), (1, "基础"), (2, "基础")):
            PositionAbility.objects.get_or_create(
                position=position,
                ability=abilities[(index - 1 + offset) % len(abilities)],
                defaults={"required_level": level},
            )

    paths = []
    for index in range(10):
        path, _ = LearningPath.objects.get_or_create(
            path_name=f"{positions[index].position_name}能力提升路径",
            defaults={
                "major": majors[index],
                "target_position": positions[index],
                "description": "从实训问题反向推荐微模块的竞赛合成路径",
                "create_time": timezone.now(),
            },
        )
        paths.append(path)
        for order in range(1, 5):
            PathModule.objects.get_or_create(
                path=path, module=modules[index * 3 + order - 1], defaults={"module_order": order}
            )

    tasks = []
    scenes = ("数据处理场景", "需求分析场景", "项目实施场景", "职场沟通场景")
    for index, name in enumerate(TASK_NAMES, 1):
        task, _ = TrainingTask.objects.get_or_create(
            task_name=name,
            defaults={
                "teacher": teachers[(index - 1) % len(teachers)],
                "position": positions[(index - 1) % len(positions)],
                "scene_type": scenes[(index - 1) % len(scenes)],
                "difficulty": ("低", "中", "高")[index % 3],
                "requirement": f"按真实软件工程流程完成{name}，提交源码、测试证据和说明文档。",
                "deliverable": "源码/SQL/文档/截图/ZIP成果包",
                "publish_time": timezone.now(),
            },
        )
        tasks.append(task)
        for order, step_name in enumerate(("理解任务与证据", "实现与静态检查", "测试与结果说明"), 1):
            TrainingStep.objects.get_or_create(
                task=task,
                step_order=order,
                defaults={"step_name": step_name, "step_hint": "结合任务要求保留可定位的成果证据。"},
            )

    assessments = list(Assessment.objects.order_by("assessment_id"))
    for index, student in enumerate(students, 1):
        progress = 25 if index % 13 == 0 else 55 if index % 7 == 0 else 100
        score = 52 if index % 13 == 0 else 68 + index % 25
        for offset in range(6):
            module = modules[(index + offset) % len(modules)]
            LearningRecord.objects.update_or_create(
                student=student,
                module=module,
                defaults={
                    "progress": progress if offset == 0 else min(100, progress + offset * 8),
                    "study_time": 12 + offset * 4,
                    "score": min(96, score + offset),
                    "status": "已完成" if progress >= 90 or offset >= 2 else "学习中",
                    "last_study_time": timezone.now(),
                },
            )
        for offset in range(2):
            task = tasks[(index + offset) % len(tasks)]
            TrainingRecord.objects.update_or_create(
                student=student,
                task=task,
                defaults={
                    "submit_content": "竞赛合成演示成果：包含需求、实现、测试与结果说明。",
                    "ai_score": min(95, score + offset),
                    "teacher_score": min(96, score + offset + (8 if index % 10 == 0 else 2)),
                    "feedback": "结构化演示评价记录，最终成绩已保留教师复核入口。",
                    "correction_suggestion": "根据证据补充测试覆盖与异常处理说明。",
                    "status": "已评价",
                    "submit_time": timezone.now(),
                },
            )
        if assessments:
            AssessmentResult.objects.update_or_create(
                student=student,
                assessment=assessments[index % len(assessments)],
                defaults={
                    "score": score,
                    "result_text": "确定性量表演示分；语义解释需由DeepSeek按配置生成。",
                    "test_time": timezone.now(),
                },
            )
        StudentProfile.objects.update_or_create(
            student=student,
            defaults={
                "foundation_level": "低" if score < 60 else "中" if score < 85 else "高",
                "learning_habit": "阶段性学习" if index % 7 == 0 else "学习节奏稳定",
                "weak_ability": abilities[index % len(abilities)].ability_name,
                "career_interest": positions[index % len(positions)].position_name,
                "update_time": timezone.now(),
            },
        )
        StudentPath.objects.get_or_create(
            student=student,
            path=paths[index % len(paths)],
            defaults={"assign_time": timezone.now(), "status": "学习中"},
        )
        Recommendation.objects.get_or_create(
            student=student,
            recommend_type="微模块推荐",
            module=modules[index % len(modules)],
            defaults={"reason": "基于能力短板与目标岗位的竞赛演示推荐", "recommend_time": timezone.now()},
        )

    # Produce enough versioned B1 reports to make queues and charts non-empty.
    for index, student in enumerate(students[:30], 1):
        task = tasks[index % len(tasks)]
        evaluation = persist_demo_evaluation(
            student,
            task,
            "竞赛合成演示提交：已完成需求说明、核心实现、测试用例与交付文档。",
            [],
            f"seed-b1-{student.student_id}-{task.task_id}",
        )
        if not evaluation:
            continue
        score = Decimal(str(60 + index % 31))
        evaluation.total_score = score
        evaluation.status = "已复核" if index % 4 else "待教师复核"
        evaluation.save(update_fields=["total_score", "status"])
        if index % 4:
            TeacherReview.objects.update_or_create(
                evaluation=evaluation,
                defaults={
                    "teacher": task.teacher,
                    "adjusted_scores_json": {},
                    "teacher_comment": "竞赛合成演示复核：证据链完整，建议继续补强测试说明。",
                    "ai_error_notes": "",
                    "decision": "通过",
                    "teacher_score": min(Decimal("100"), score + Decimal(index % 5 - 2)),
                    "final_score": min(Decimal("100"), score + Decimal(index % 5 - 2)),
                },
            )

    # The dedicated recording task keeps the complete V1/V2 evidence loop
    # available before recording day and remains idempotent on repeat runs.
    ensure_recording_showcase(students[0], teachers[0], positions[0], modules, paths)

    return {
        "majors": Major.objects.count(),
        "classes": ClassInfo.objects.count(),
        "teachers": Teacher.objects.count(),
        "students": Student.objects.count(),
        "modules": MicroModule.objects.count(),
        "tasks": TrainingTask.objects.count(),
        "companies": Company.objects.count(),
        "positions": JobPosition.objects.count(),
        "paths": LearningPath.objects.count(),
        "abilities": Ability.objects.count(),
        "evaluations": AIEvaluation.objects.count(),
    }


if __name__ == "__main__":
    import sys
    skip_worker_demo = "--skip-worker-demo" in sys.argv[1:]
    with transaction.atomic():
        summary = seed()
    print("竞赛合成演示数据已就绪：")
    print(" / ".join(f"{key}={value}" for key, value in summary.items()))
    from agent_learning.seed import seed_a3_demo_data
    a3_summary = seed_a3_demo_data(process_demo_job=not skip_worker_demo)
    print("A3个性化学习闭环已就绪：")
    print(" / ".join(f"{key}={value}" for key, value in a3_summary.items()))
