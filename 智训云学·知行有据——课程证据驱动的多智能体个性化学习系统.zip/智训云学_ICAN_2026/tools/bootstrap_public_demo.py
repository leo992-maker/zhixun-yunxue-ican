"""Initialize only an empty competition demo database; never reset a live one."""

from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path

import pymysql


DEMO_NAMES = ("admin", "t001", "t002", "t003", "s001", "s002", "s003", "s004", "s005")


def require_public_config() -> None:
    local_mode = os.getenv("DEMO_MODE", "").strip().lower() == "local"
    domain = os.getenv("DEMO_DOMAIN", "").strip()
    if not local_mode and (not domain or domain.endswith("example.com") or "/" in domain or ":" in domain):
        raise RuntimeError("Set a real DEMO_DOMAIN in deploy/public-demo.env")
    for name in ("MYSQL_PASSWORD", "DJANGO_SECRET_KEY", "DEMO_ADMIN_PASSWORD", "DEMO_TEACHER_PASSWORD", "DEMO_STUDENT_PASSWORD"):
        value = os.getenv(name, "")
        minimum = 50 if name == "DJANGO_SECRET_KEY" else 16
        if len(value) < minimum:
            raise RuntimeError(f"{name} needs at least {minimum} characters")
    if len({os.environ[name] for name in ("DEMO_ADMIN_PASSWORD", "DEMO_TEACHER_PASSWORD", "DEMO_STUDENT_PASSWORD")}) != 3:
        raise RuntimeError("Use different passwords for the three demo roles")


def connect():
    options = dict(host=os.getenv("MYSQL_HOST", "db"), port=int(os.getenv("MYSQL_PORT", "3306")),
                   user=os.getenv("MYSQL_USER", "root"), password=os.environ["MYSQL_PASSWORD"],
                   database=os.getenv("MYSQL_DATABASE", "employment_ai_platform"), charset="utf8mb4")
    last_error = None
    for _ in range(45):
        try:
            return pymysql.connect(**options)
        except pymysql.MySQLError as exc:
            last_error = exc
            time.sleep(2)
    code = getattr(last_error, "args", [""])[0] if last_error else "unknown"
    detail = str(last_error) if last_error else "no error detail"
    if str(code) == "1045" or "Access denied" in detail:
        raise RuntimeError(
            "MySQL refused MYSQL_PASSWORD (1045). The local-demo.env password does not "
            "match the existing Docker volume; restore that file or run the documented "
            "local-demo reset before starting again."
        ) from last_error
    if str(code) == "1049" or "Unknown database" in detail:
        raise RuntimeError(
            f"MySQL database {options['database']!r} was not created. "
            "Check MYSQL_DATABASE and the db service initialization."
        ) from last_error
    raise RuntimeError(f"MySQL unavailable after 90 seconds ({code}): {detail}") from last_error


def run(*args):
    subprocess.run([sys.executable, *args], check=True)


def rotate_demo_accounts():
    from django.contrib.auth.hashers import make_password
    mapping = {"admin": os.environ["DEMO_ADMIN_PASSWORD"]}
    mapping.update({name: os.environ["DEMO_TEACHER_PASSWORD"] for name in DEMO_NAMES if name.startswith("t")})
    mapping.update({name: os.environ["DEMO_STUDENT_PASSWORD"] for name in DEMO_NAMES if name.startswith("s")})
    conn = connect()
    try:
        with conn.cursor() as cursor:
            for name, password in mapping.items():
                cursor.execute("UPDATE user_account SET password=%s WHERE username=%s", (make_password(password), name))
        conn.commit()
    finally:
        conn.close()


def main():
    require_public_config()
    conn = connect()
    try:
        with conn.cursor() as cursor:
            cursor.execute("SHOW TABLES")
            tables = {row[0] for row in cursor.fetchall()}
    finally:
        conn.close()
    if tables and "user_account" not in tables:
        raise RuntimeError("Database is not empty and does not belong to this project; refusing initialization")
    if not tables:
        run("init_db.py")  # This script is destructive; invoke only after the empty-table check.
        run("upgrade_db.py", "--reset-demo-passwords")
    else:
        run("upgrade_db.py")
    run("manage.py", "migrate", "--noinput")
    if not tables:
        run("seed_demo_data.py", "--skip-worker-demo")
    else:
        run("manage.py", "seed_a3_demo", "--skip-worker-demo")
    # Executing this file as /app/tools/bootstrap_public_demo.py puts /app/tools,
    # not /app, on sys.path. Django settings live in /app/myproject.
    project_root = str(Path(__file__).resolve().parents[1])
    if project_root not in sys.path:
        sys.path.insert(0, project_root)
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "myproject.settings")
    import django
    django.setup()
    rotate_demo_accounts()
    print("Demo database ready; role passwords refreshed without displaying them.")


if __name__ == "__main__":
    main()
