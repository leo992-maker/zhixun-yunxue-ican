"""Create a clearly grouped, source-complete competition handoff ZIP."""

from __future__ import annotations

import sys
import zipfile
from pathlib import Path

from create_ican_release import ROOT, collect, validate


INTRO = """# 智训云学 · 评委交付包导航

请按这个顺序查看：

1. **看界面**：公开预览 https://zhixun-yunxue-ican-preview.tiffany-ball1992.chatgpt.site ，或看 `02_界面截图/`。这些是真实演示界面的历史截图；预览页不运行模型。
2. **看参赛说明**：`01_参赛材料/` 中已有 18 页应用方案 PDF、改造和验收清单、五分钟演示脚本，以及部署与模型调用清单。要求的视频须用实际运行任务录制；不能以截图拼接替代。
3. **本机运行完整程序**：安装并启动 Docker Desktop，进入 `03_可运行项目/`。如果旧项目目录已经删除、旧演示数据也不需要，先双击 `重置本地演示数据.bat` 并输入大写 `RESET`，只清除本项目的旧容器和数据卷。然后双击 `一键启动本地演示.bat`，脚本自动生成新的数据库与密码，并打开登录页（以窗口显示的端口为准）；用窗口显示的学生密码登录。本机链接不能提供给评委远程操作。
   **三端在同一个登录页**：学生 `s001` → `/student/dashboard/`；教师 `t001` → `/teacher/dashboard/`；管理员 `admin` → `/admin/dashboard/`。点击右上角账号菜单“安全退出”后切换角色。教师和管理员的随机密码仅在本机私有 `deploy/local-demo.env` 中，分别对应 `DEMO_TEACHER_PASSWORD` 和 `DEMO_ADMIN_PASSWORD`；具体演示动作见 `01_参赛材料/三端演示路线.md`。`02_界面截图/` 是部分历史画面，含教师工作台；完整管理员监控请在可运行项目中登录查看。
4. **核验模型**：双击 `配置并验证模型.bat`，将个人服务密钥填入只保存在本机的配置文件；脚本会进行真实连接测试。没有密钥时程序明确降级，不代表在线模型成功。
5. **公网交互**：团队有域名和 Linux 主机后按 `03_可运行项目/docs/ICAN_部署与模型调用说明.md` 启动网站、MySQL、Worker，并从外网测试后提交真实地址。

安全：此包不含真实 `.env`、数据库密码、模型密钥、用户上传文件及虚拟环境。原始上传 ZIP 含非空凭据，不能公开；先轮换其中凭据。
"""

MATERIALS = {
    "01_参赛材料/ICAN_复赛应用方案.pdf": "docs/ICAN_复赛应用方案.pdf",
    "01_参赛材料/改造与交付清单.md": "docs/ICAN_2026_改造与交付清单.md",
    "01_参赛材料/本轮修复与最终验收.md": "docs/ICAN_本轮修复与最终验收.md",
    "01_参赛材料/五分钟演示脚本.md": "docs/ICAN_五分钟演示脚本.md",
    "01_参赛材料/部署与模型调用说明.md": "docs/ICAN_部署与模型调用说明.md",
    "01_参赛材料/三端演示路线.md": "docs/ICAN_三端演示路线.md",
}
IMAGES = {
    "02_界面截图/01_学生学习首页.png": "app/static/showcase/screenshots/student-home.png",
    "02_界面截图/02_个性化学习路径.png": "app/static/showcase/screenshots/learning-path.png",
    "02_界面截图/03_知识点思维导图.png": "app/static/showcase/screenshots/mindmap.png",
    "02_界面截图/04_教师工作台.png": "app/static/showcase/screenshots/teacher-home.png",
}


def build(output: Path) -> int:
    files = collect(ROOT, output)
    validate(ROOT, files)
    names = {str(relative) for _, relative in files}
    for relative in (*MATERIALS.values(), *IMAGES.values()):
        if relative not in names:
            raise ValueError(f"交付文件缺失：{relative}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("智训云学_ICAN_评委交付/00_先看我.md", INTRO)
        for target, relative in {**MATERIALS, **IMAGES}.items():
            archive.write(ROOT / relative, "智训云学_ICAN_评委交付/" + target)
        for path, relative in files:
            archive.write(path, "智训云学_ICAN_评委交付/03_可运行项目/" + relative.as_posix())
    return len(files)


if __name__ == "__main__":
    destination = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT.parent / "智训云学_ICAN_评委交付包.zip"
    count = build(destination)
    print(f"交付包已生成：源码 {count} 文件，四个清楚的顶层入口。")
