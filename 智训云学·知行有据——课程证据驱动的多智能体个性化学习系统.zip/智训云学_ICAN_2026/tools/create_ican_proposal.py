"""Compatibility entry point for the maintained 18-page, font-embedded PDF."""

from create_ican_proposal_v2 import build


if __name__ == "__main__":
    print(build())
