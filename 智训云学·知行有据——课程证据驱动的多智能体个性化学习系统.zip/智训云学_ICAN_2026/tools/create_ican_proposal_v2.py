from pathlib import Path
import atexit
import os
import tempfile

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from fontTools.ttLib import TTFont as FontToolsFont
from fontTools.varLib.instancer import instantiateVariableFont


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs" / "ICAN_复赛应用方案.pdf"
W, H = landscape(A4)

FONT = "NotoSansSC"
FONT_BOLD = "NotoSansSC-Bold"
_font_override = os.environ.get("ICAN_CJK_FONT_PATH", "")
if _font_override:
    FONT_PATH = Path(_font_override)
else:
    FONT_PATH = ROOT / "assets" / "fonts" / "NotoSansSC-VF.ttf"
if not FONT_PATH.is_file():
    raise RuntimeError(f"中文字体不存在：{FONT_PATH}")
_fd, _fixed_font = tempfile.mkstemp(suffix=".ttf", prefix="ican-chinese-v2-")
os.close(_fd)
atexit.register(lambda: Path(_fixed_font).unlink(missing_ok=True))
_font = FontToolsFont(str(FONT_PATH))
if any(axis.axisTag == "wght" for axis in _font["fvar"].axes) if "fvar" in _font else False:
    instantiateVariableFont(_font, {"wght": 500}, inplace=True)
_font.save(_fixed_font)
_font.close()
pdfmetrics.registerFont(TTFont(FONT, _fixed_font))
pdfmetrics.registerFont(TTFont(FONT_BOLD, _fixed_font))


NAVY = colors.HexColor("#11243B")
NAVY_2 = colors.HexColor("#173A63")
BLUE = colors.HexColor("#176BC0")
CYAN = colors.HexColor("#08A6C9")
ORANGE = colors.HexColor("#F19A36")
GREEN = colors.HexColor("#2BA58F")
RED = colors.HexColor("#E2665A")
INK = colors.HexColor("#1E3046")
MUTED = colors.HexColor("#5B6D80")
LIGHT = colors.HexColor("#F4F7FB")
PALE_BLUE = colors.HexColor("#EAF3FB")
PALE_CYAN = colors.HexColor("#E8F7F8")
PALE_ORANGE = colors.HexColor("#FFF2DF")
PALE_RED = colors.HexColor("#FCECEA")
LINE = colors.HexColor("#D7E2ED")
WHITE = colors.white


def set_font(c, size, bold=False, color=INK):
    c.setFont(FONT_BOLD if bold else FONT, size)
    c.setFillColor(color)


def wrap_text(text, width, size=10.2, bold=False):
    if not text:
        return []
    font = FONT_BOLD if bold else FONT
    out = []
    for para in str(text).split("\n"):
        if para == "":
            out.append("")
            continue
        current = ""
        for ch in para:
            candidate = current + ch
            if pdfmetrics.stringWidth(candidate, font, size) <= width or not current:
                current = candidate
            else:
                out.append(current)
                current = ch
        if current:
            out.append(current)
    return out


def draw_text(c, x, y, text, width, size=10.2, leading=None, color=INK, bold=False, max_lines=None):
    leading = leading or size * 1.45
    lines = wrap_text(text, width, size=size, bold=bold)
    if max_lines and len(lines) > max_lines:
        lines = lines[:max_lines]
        if lines:
            tail = lines[-1]
            while pdfmetrics.stringWidth(tail + "...", FONT_BOLD if bold else FONT, size) > width and tail:
                tail = tail[:-1]
            lines[-1] = tail + "..."
    set_font(c, size, bold=bold, color=color)
    for i, line in enumerate(lines):
        c.drawString(x, y - i * leading, line)
    return y - len(lines) * leading


def draw_center(c, cx, y, text, size=10, color=INK, bold=False):
    set_font(c, size, bold=bold, color=color)
    c.drawCentredString(cx, y, text)


def rr(c, x, y, w, h, fill=WHITE, stroke=None, radius=12, sw=0.8):
    c.setFillColor(fill)
    c.setStrokeColor(stroke or fill)
    c.setLineWidth(sw)
    c.roundRect(x, y, w, h, radius, fill=1, stroke=1 if stroke else 0)


def line(c, x1, y1, x2, y2, color=LINE, sw=1):
    c.setStrokeColor(color)
    c.setLineWidth(sw)
    c.line(x1, y1, x2, y2)


def pill(c, x, y, text, fill=PALE_BLUE, color=BLUE, size=8.6, pad_x=9, h=18, bold=True):
    font = FONT_BOLD if bold else FONT
    width = pdfmetrics.stringWidth(text, font, size) + pad_x * 2
    rr(c, x, y, width, h, fill=fill, stroke=None, radius=h / 2)
    draw_center(c, x + width / 2, y + 5.3, text, size=size, color=color, bold=bold)
    return width


def section_label(c, x, y, text, accent=ORANGE):
    c.setFillColor(accent)
    c.circle(x + 4, y + 4, 4, fill=1, stroke=0)
    set_font(c, 9.2, bold=True, color=MUTED)
    c.drawString(x + 14, y, text.upper())


def page_base(c, num, title, kicker, dark=False):
    if dark:
        c.setFillColor(NAVY)
        c.rect(0, 0, W, H, fill=1, stroke=0)
        c.setFillColor(NAVY_2)
        c.rect(565, 0, W - 565, H, fill=1, stroke=0)
        line(c, 565, 0, 565, H, color=colors.HexColor("#31547B"), sw=0.8)
        set_font(c, 8.4, bold=True, color=colors.HexColor("#BBD4EE"))
        c.drawString(46, H - 38, "ICAN 2026  /  应用型智能体赛道")
        set_font(c, 8.6, color=colors.HexColor("#BBD4EE"))
        c.drawRightString(W - 44, H - 38, "智训云学  ·  应用方案")
        return
    c.setFillColor(WHITE)
    c.rect(0, 0, W, H, fill=1, stroke=0)
    c.setFillColor(NAVY)
    c.rect(0, H - 13, W, 13, fill=1, stroke=0)
    c.setFillColor(ORANGE)
    c.rect(0, H - 13, 116, 13, fill=1, stroke=0)
    section_label(c, 48, H - 44, kicker, accent=ORANGE)
    set_font(c, 23, bold=True, color=NAVY)
    c.drawString(48, H - 83, title)
    line(c, 48, H - 101, W - 48, H - 101, color=LINE, sw=0.8)
    # Keep a fixed gap between the progress rule and the page counter.
    rail_x, rail_y, rail_w = W - 220, 26, 126
    line(c, rail_x, rail_y + 3, rail_x + rail_w, rail_y + 3, color=LINE, sw=2.5)
    line(c, rail_x, rail_y + 3, rail_x + rail_w * num / 18.0, rail_y + 3, color=BLUE, sw=2.5)
    set_font(c, 8.2, bold=True, color=MUTED)
    c.drawRightString(W - 48, 23, f"{num:02d} / 18")
    set_font(c, 8.2, color=MUTED)
    c.drawString(48, 23, "智训云学  |  有依据的个性化学习资源生成与多智能体协作")


def panel(c, x, y, w, h, title, body="", accent=BLUE, fill=LIGHT, title_size=12.2, body_size=9.5, tag=None):
    rr(c, x, y, w, h, fill=fill, stroke=LINE, radius=12, sw=0.7)
    c.setFillColor(accent)
    c.roundRect(x, y + h - 6, w, 6, 3, fill=1, stroke=0)
    if h < 50:
        set_font(c, min(title_size, 10), bold=True, color=NAVY)
        c.drawString(x + 15, y + h / 2 - 3, title)
        if body:
            label_width = min(127, pdfmetrics.stringWidth(title, FONT_BOLD, min(title_size, 10)) + 25)
            draw_text(c, x + 15 + label_width, y + h / 2 - 3, body,
                      w - 30 - label_width, size=min(body_size, 8.6),
                      leading=11, color=INK, max_lines=1)
        return
    set_font(c, title_size, bold=True, color=NAVY)
    c.drawString(x + 15, y + h - 25 if h < 70 else y + h - 28, title)
    top = y + h - 42 if h < 70 else y + h - 48
    if tag:
        tw = pill(c, x + 15, y + h - 51, tag, fill=colors.white, color=accent, size=7.6, h=16, pad_x=7)
        top = y + h - 72
    if body:
        draw_text(c, x + 15, top, body, w - 30, size=body_size,
                  leading=body_size * 1.35 if h < 70 else body_size * 1.42,
                  color=INK, max_lines=2 if h < 70 else None)


def bullet(c, x, y, text, width, color=INK, accent=BLUE, size=9.4, gap=17):
    c.setFillColor(accent)
    c.circle(x + 3.5, y - 3, 3.2, fill=1, stroke=0)
    return draw_text(c, x + 13, y, text, width - 13, size=size, leading=size * 1.42, color=color) - gap


def metric(c, x, y, w, value, label, accent=BLUE, fill=PALE_BLUE):
    rr(c, x, y, w, 63, fill=fill, stroke=None, radius=12)
    set_font(c, 22, bold=True, color=accent)
    c.drawString(x + 14, y + 28, value)
    draw_text(c, x + 14, y + 16, label, w - 28, size=8.4, leading=10.5, color=MUTED, max_lines=2)


def step_node(c, x, y, w, h, no, title, body, accent=BLUE, output=None):
    rr(c, x, y, w, h, fill=WHITE, stroke=LINE, radius=12, sw=0.8)
    c.setFillColor(accent)
    c.circle(x + 25, y + h - 25, 15, fill=1, stroke=0)
    draw_center(c, x + 25, y + h - 29, str(no), size=11, color=WHITE, bold=True)
    set_font(c, 11, bold=True, color=NAVY)
    c.drawString(x + 49, y + h - 29, title)
    draw_text(c, x + 16, y + h - 56, body, w - 32, size=8.8, leading=12, color=MUTED)
    if output:
        line(c, x + 16, y + 35, x + w - 16, y + 35, color=LINE, sw=0.7)
        draw_text(c, x + 16, y + 21, output, w - 32, size=8.1, leading=10, color=accent, bold=True, max_lines=1)


def arrow(c, x1, y, x2, color=BLUE):
    line(c, x1, y, x2 - 8, y, color=color, sw=2)
    c.setFillColor(color)
    c.setStrokeColor(color)
    c.setLineWidth(2)
    c.line(x2 - 8, y, x2 - 15, y + 5)
    c.line(x2 - 8, y, x2 - 15, y - 5)


def screenshot_path(name):
    return ROOT / "app" / "static" / "showcase" / "screenshots" / name


def draw_screenshot(c, path, x, y, w, h):
    c.setFillColor(WHITE)
    c.setStrokeColor(LINE)
    c.setLineWidth(0.7)
    c.roundRect(x - 4, y - 4, w + 8, h + 8, 10, fill=1, stroke=1)
    c.drawImage(ImageReader(str(path)), x, y, width=w, height=h, preserveAspectRatio=True, anchor="c", mask="auto")


def callout(c, x, y, no, title, body, w=178, accent=ORANGE):
    c.setFillColor(accent)
    c.circle(x + 12, y + 36, 11, fill=1, stroke=0)
    draw_center(c, x + 12, y + 32.5, str(no), size=8.6, color=WHITE, bold=True)
    set_font(c, 10.2, bold=True, color=NAVY)
    c.drawString(x + 31, y + 39, title)
    draw_text(c, x + 31, y + 24, body, w - 31, size=8.5, leading=11, color=MUTED, max_lines=3)


def page_cover(c):
    page_base(c, 1, "", "", dark=True)
    set_font(c, 12, bold=True, color=ORANGE)
    c.drawString(48, H - 95, "ICAN 2026  ·  复赛应用方案")
    set_font(c, 42, bold=True, color=WHITE)
    c.drawString(48, H - 150, "智训云学")
    set_font(c, 20, color=colors.HexColor("#D6E7F8"))
    c.drawString(48, H - 183, "有依据的个性化学习资源生成与多智能体协作")
    draw_text(c, 50, H - 229,
              "把一次模糊的学习目标，变成可解释、可引用、可继续迭代的学习任务包。",
              500, size=12.5, leading=18, color=colors.HexColor("#EAF4FF"))
    line(c, 48, 308, 152, 308, color=ORANGE, sw=2.4)

    # Four points around an open book: the learning loop, drawn as vector art.
    cx, cy = 703, 340
    c.setFillColor(colors.HexColor("#1B4C78"))
    c.circle(cx, cy, 151, fill=1, stroke=0)
    c.setStrokeColor(colors.HexColor("#4585AF"))
    c.setLineWidth(0.9)
    c.circle(cx, cy, 121, fill=0, stroke=1)
    c.setStrokeColor(colors.HexColor("#376B93"))
    c.circle(cx, cy, 96, fill=0, stroke=1)
    for x, y, color in [
        (cx, cy + 121, ORANGE), (cx + 121, cy, CYAN),
        (cx, cy - 121, GREEN), (cx - 121, cy, colors.HexColor("#C3DDF0")),
    ]:
        c.setFillColor(color)
        c.circle(x, y, 5.5, fill=1, stroke=0)
        c.setStrokeColor(colors.HexColor("#9FC9E5"))
        c.setLineWidth(0.8)
        c.circle(x, y, 10, fill=0, stroke=1)
    c.setStrokeColor(WHITE)
    c.setLineWidth(2.1)
    left_page = c.beginPath()
    left_page.moveTo(cx, cy - 30)
    left_page.curveTo(cx - 21, cy - 20, cx - 41, cy - 24, cx - 57, cy - 16)
    left_page.lineTo(cx - 57, cy + 38)
    left_page.curveTo(cx - 35, cy + 30, cx - 17, cy + 32, cx, cy + 21)
    c.drawPath(left_page, stroke=1, fill=0)
    right_page = c.beginPath()
    right_page.moveTo(cx, cy - 30)
    right_page.curveTo(cx + 21, cy - 20, cx + 41, cy - 24, cx + 57, cy - 16)
    right_page.lineTo(cx + 57, cy + 38)
    right_page.curveTo(cx + 35, cy + 30, cx + 17, cy + 32, cx, cy + 21)
    c.drawPath(right_page, stroke=1, fill=0)
    line(c, cx, cy - 30, cx, cy + 21, color=colors.HexColor("#74D0DF"), sw=2.2)
    draw_center(c, cx, 139, "目标  /  证据  /  生成  /  反馈",
                size=10.3, color=colors.HexColor("#CDE6F5"), bold=True)

    # Editorial columns replace filled summary cards.
    values = [
        ("01", "目标驱动", "先理解学习目标，再规划资源与任务"),
        ("02", "证据可追溯", "每个关键结论都有来源与引用位置"),
        ("03", "反馈可闭环", "根据学习结果更新路径，而不是一次性推荐"),
    ]
    line(c, 48, 206, 542, 206, color=colors.HexColor("#45617F"), sw=0.8)
    for i, (no, title, body) in enumerate(values):
        x = 48 + i * 168
        if i:
            line(c, x - 13, 122, x - 13, 189, color=colors.HexColor("#45617F"), sw=0.8)
        set_font(c, 9, bold=True, color=ORANGE)
        c.drawString(x, 183, no)
        set_font(c, 13, bold=True, color=WHITE)
        c.drawString(x, 157, title)
        draw_text(c, x, 135, body, 149, size=8.4, leading=11.5,
                  color=colors.HexColor("#CDE0F3"), max_lines=2)

    set_font(c, 9.2, color=colors.HexColor("#CDE0F3"))
    c.drawString(48, 46, "教育场景  /  课程知识库  /  个性化学习")


def page_problem(c):
    page_base(c, 2, "为什么需要智训云学", "01  问题与机会")
    draw_text(c, 48, H - 132,
              "学习效率的瓶颈不是“没有内容”，而是目标、证据、任务和反馈之间没有形成闭环。",
              740, size=14, leading=20, color=NAVY, bold=True)
    # Broken chain.
    set_font(c, 10, bold=True, color=RED)
    c.drawString(48, 395, "传统学习链路：四次断裂")
    blocks = [
        ("01", "目标模糊", "只说“想学好”，没有可执行的知识边界"),
        ("02", "资源泛化", "链接很多，但与当前水平和时间不匹配"),
        ("03", "过程失焦", "做题、阅读、复习之间缺少节奏和优先级"),
        ("04", "反馈滞后", "错因、薄弱点和下一步行动没有及时回流"),
    ]
    bx, by, bw, bh = 48, 222, 163, 139
    for i, (no, title, body) in enumerate(blocks):
        x = bx + i * 180
        rr(c, x, by, bw, bh, fill=PALE_RED, stroke=colors.HexColor("#F2D2CF"), radius=12)
        set_font(c, 9, bold=True, color=RED)
        c.drawString(x + 15, by + bh - 26, no)
        set_font(c, 12, bold=True, color=NAVY)
        c.drawString(x + 15, by + bh - 52, title)
        draw_text(c, x + 15, by + bh - 77, body, bw - 30, size=8.8, leading=12, color=MUTED)
        if i < 3:
            arrow(c, x + bw + 8, by + bh / 2, x + bw + 26, color=RED)

    # Answer panel.
    panel(c, 48, 90, 746, 103, "智训云学的设计回答", "把“学习目标”作为唯一入口，沿着 目标理解 -> 证据检索 -> 资源编排 -> 互动练习 -> 结果反馈 的链路，让每次生成都留下可检查的中间产物。", accent=BLUE, fill=PALE_BLUE, title_size=13, body_size=10.6)


def page_users(c):
    page_base(c, 3, "谁在使用，解决什么任务", "02  用户与任务")
    draw_text(c, 48, H - 132, "同一套底层能力，对学生、教师和管理者呈现不同的决策界面。", 740, size=13.2, leading=19, color=NAVY, bold=True)
    personas = [
        ("学生", "把目标变成下一步", "输入：考试/课程/兴趣目标\n得到：学习路径、资源包、练习与复盘", BLUE, PALE_BLUE),
        ("教师", "看见班级共性问题", "输入：班级与章节\n得到：学情分布、薄弱点、干预建议", GREEN, PALE_CYAN),
        ("管理者", "看见运行与使用", "输入：任务与过程数据\n得到：资源使用、完成度、迭代依据", ORANGE, PALE_ORANGE),
    ]
    for i, (who, title, body, accent, fill) in enumerate(personas):
        x = 48 + i * 249
        rr(c, x, 310, 229, 128, fill=fill, stroke=LINE, radius=14)
        pill(c, x + 15, 409, who, fill=WHITE, color=accent, size=8.5, h=20)
        set_font(c, 12.2, bold=True, color=NAVY)
        c.drawString(x + 15, 376, title)
        draw_text(c, x + 15, 358, body, 198, size=9, leading=13, color=MUTED)

    set_font(c, 10, bold=True, color=MUTED)
    c.drawString(48, 274, "典型学生任务：从一句话目标到一份可执行任务包")
    journey = [
        ("一句话目标", "“两周后参加 Python 基础测验”"),
        ("系统追问", "识别时间、基础、重点章节与限制"),
        ("生成任务包", "路径 + 资源 + 练习 + 复盘节点"),
        ("行为反馈", "完成度、错因、薄弱点回流到下一轮"),
    ]
    jy = 190
    for i, (title, body) in enumerate(journey):
        x = 48 + i * 180
        c.setFillColor(BLUE if i < 3 else ORANGE)
        c.circle(x + 12, jy + 37, 12, fill=1, stroke=0)
        draw_center(c, x + 12, jy + 33, str(i + 1), size=8.5, color=WHITE, bold=True)
        set_font(c, 10.2, bold=True, color=NAVY)
        c.drawString(x + 34, jy + 42, title)
        draw_text(c, x + 34, jy + 26, body, 133, size=8.3, leading=11, color=MUTED)
        if i < 3:
            arrow(c, x + 151, jy + 37, x + 174, color=LINE)
    panel(c, 48, 72, 746, 55, "关键判断", "项目的核心不是“生成一段文字”，而是把目标、依据、任务和反馈组织成一个可以继续运行的学习系统。", accent=ORANGE, fill=PALE_ORANGE, title_size=10.5, body_size=9.1)


def page_requirements(c):
    page_base(c, 4, "需求如何被产品逐条接住", "03  需求与功能")
    draw_text(c, 48, H - 132, "每一项功能都对应一个用户痛点和一份可被评委检查的界面/数据证据。", 740, size=13.2, leading=19, color=NAVY, bold=True)
    x0, y0 = 48, 102
    widths = [134, 266, 244]
    headers = ["用户需求", "产品响应", "可观察证据"]
    for i, htxt in enumerate(headers):
        x = x0 + sum(widths[:i])
        rr(c, x, 395, widths[i], 38, fill=NAVY, stroke=WHITE, radius=0)
        draw_center(c, x + widths[i] / 2, 409, htxt, size=10, color=WHITE, bold=True)
    rows = [
        ("目标不清", "目标画像与追问卡片", "学生首页的目标输入、时间与基础字段"),
        ("资源太散", "检索 + 引用 + 资源编排", "资源卡片、来源标签、章节映射"),
        ("不知道先学什么", "路径规划与阶段任务", "学习路径时间线、知识点依赖"),
        ("学完不会复盘", "错因分析与反馈回流", "完成状态、薄弱点、下一轮建议"),
        ("教师看不到班级", "班级学情洞察", "教师首页的分布、风险点与干预建议"),
    ]
    row_h = 52
    for r, row in enumerate(rows):
        y = 395 - (r + 1) * row_h
        for i, value in enumerate(row):
            x = x0 + sum(widths[:i])
            fill = WHITE if r % 2 == 0 else LIGHT
            rr(c, x, y, widths[i], row_h, fill=fill, stroke=LINE, radius=0, sw=0.5)
            draw_text(c, x + 12, y + row_h - 20, value, widths[i] - 24, size=8.8, leading=11.5, color=NAVY if i == 0 else MUTED, bold=(i == 0))
    panel(c, 48, 65, 746, 42, "设计边界", "不把大模型当作“万能答案机”；模型只负责理解、编排与生成，来源、权限、状态和异常由应用层约束。", accent=RED, fill=PALE_RED, title_size=10.2, body_size=8.8)


def page_workflow(c):
    page_base(c, 5, "从目标到任务包：一条可追踪的工作流", "04  产品流程")
    draw_text(c, 48, H - 132, "评委可以沿着这条链路，看到一次请求如何被理解、拆分、生成、审核并返回。", 740, size=13.2, leading=19, color=NAVY, bold=True)
    stages = [
        ("目标理解", "提取期限、基础、章节、偏好", "交付：目标画像", BLUE),
        ("证据检索", "检索知识库，保留来源与片段", "交付：引用清单", CYAN),
        ("任务编排", "把目标拆成阶段、资源、练习", "交付：阶段计划", GREEN),
        ("内容生成", "生成讲解、题目、导图与微课分镜", "交付：资源包", ORANGE),
        ("质量反馈", "检查引用、难度、完成度与下一步", "交付：审核反馈", RED),
    ]
    x0, y0, sw, gap = 48, 265, 132, 19
    for i, (title, body, output, accent) in enumerate(stages):
        x = x0 + i * (sw + gap)
        step_node(c, x, y0, sw, 142, i + 1, title, body, accent=accent, output=output)
        if i < len(stages) - 1:
            arrow(c, x + sw + 4, y0 + 71, x + sw + gap - 5, color=LINE)
    panel(c, 48, 100, 360, 111, "输出 1  /  给学生", "学习路径、目标拆分、资源卡片、阶段练习、复盘提示。每一步都能回到原始目标和引用来源。", accent=BLUE, fill=PALE_BLUE, title_size=11.5, body_size=9.2)
    panel(c, 434, 100, 360, 111, "输出 2  /  给教师", "班级薄弱点、风险学生、资源使用与干预建议。把“生成结果”变成“下一步行动”。", accent=GREEN, fill=PALE_CYAN, title_size=11.5, body_size=9.2)
    pill(c, 48, 67, "闭环 A  ·  学习反馈回流", fill=PALE_ORANGE, color=ORANGE, size=8.5)
    pill(c, 224, 67, "闭环 B  ·  证据与引用审计", fill=PALE_BLUE, color=BLUE, size=8.5)
    draw_text(c, 48, 50, "两条闭环分别解决“越学越准”和“越生成越可信”，也是项目区别于普通聊天机器人的关键。", 746, size=8.8, leading=12, color=MUTED)


def page_architecture(c):
    page_base(c, 6, "技术方案：应用层约束模型，模型层提供能力", "05  技术架构")
    draw_text(c, 48, H - 132, "系统采用 Django Web + 任务编排 + 可替换模型适配器，既能本地 Docker 演示，也保留后续部署空间。", 740, size=13, leading=19, color=NAVY, bold=True)
    # Architecture layers.
    layers = [
        (372, 70, "交互层", "学生端 / 教师端 / 管理端", BLUE, PALE_BLUE),
        (289, 70, "应用层", "目标画像、路径、资源、学情、权限与状态机", CYAN, PALE_CYAN),
        (206, 70, "智能体编排层", "理解、检索、规划、生成、审核、评估角色协作", GREEN, colors.HexColor("#E7F5EE")),
        (123, 70, "数据与模型层", "MySQL / Spark / DeepSeek / TTS / FFmpeg", ORANGE, PALE_ORANGE),
    ]
    for y, h, title, body, accent, fill in layers:
        rr(c, 48, y, 492, h, fill=fill, stroke=LINE, radius=10)
        c.setFillColor(accent)
        c.rect(48, y, 8, h, fill=1, stroke=0)
        set_font(c, 11, bold=True, color=NAVY)
        c.drawString(72, y + h - 27, title)
        draw_text(c, 72, y + h - 47, body, 440, size=9.4, leading=12, color=MUTED)
    # Provider box / deployment path.
    rr(c, 568, 123, 226, 319, fill=NAVY, stroke=None, radius=16)
    set_font(c, 10, bold=True, color=ORANGE)
    c.drawString(590, 410, "DEPLOYMENT PATH")
    set_font(c, 18, bold=True, color=WHITE)
    c.drawString(590, 382, "一套代码")
    c.drawString(590, 358, "三种运行形态")
    deploys = [
        ("本地开发", "Docker Compose\n127.0.0.1:8000", BLUE),
        ("评委演示", "Web 界面 + 录屏\n按脚本复现", CYAN),
        ("后续上线", "公网 HTTPS\n替换环境变量", ORANGE),
    ]
    yy = 310
    for title, body, accent in deploys:
        c.setFillColor(accent)
        c.circle(600, yy + 10, 6, fill=1, stroke=0)
        set_font(c, 10.2, bold=True, color=WHITE)
        c.drawString(618, yy + 7, title)
        draw_text(c, 618, yy - 10, body, 135, size=8.3, leading=11, color=colors.HexColor("#C8D8E8"))
        yy -= 74
    panel(c, 48, 63, 746, 39, "工程原则", "把密钥放在 .env，把模型差异收敛到适配器，把业务证据留在数据库和页面里。", accent=ORANGE, fill=PALE_ORANGE, title_size=9.8, body_size=8.7)


def page_agents(c):
    page_base(c, 7, "多智能体不是堆名词，而是分工与交接", "06  智能体协作")
    draw_text(c, 48, H - 132, "一次学生请求由编排器分发给不同角色；每个角色交付结构化中间产物，降低“只返回一段话”的不可控性。", 740, size=12.7, leading=18, color=NAVY, bold=True)
    # A two-tier handoff map keeps the six roles readable and the connectors
    # behind, not across, their labels.
    top_y, bottom_y, card_w, card_h = 338, 105, 222, 91
    xs = [48, 310, 572]
    for cx in [x + card_w / 2 for x in xs]:
        line(c, cx, top_y, 421, 312, color=LINE, sw=1.3)
        line(c, 421, 228, cx, bottom_y + card_h, color=LINE, sw=1.3)
    rr(c, 303, 228, 236, 84, fill=NAVY, stroke=None, radius=16)
    set_font(c, 9, bold=True, color=ORANGE)
    c.drawCentredString(421, 288, "ORCHESTRATOR")
    set_font(c, 17, bold=True, color=WHITE)
    c.drawCentredString(421, 263, "学习任务编排器")
    draw_center(c, 421, 242, "接收目标 / 分配角色 / 合并结果 / 留下日志", size=8.4, color=colors.HexColor("#C9D9E9"))
    agent_items = [
        (xs[0], top_y, "画像分析", "识别基础、时间与约束\n交付：目标画像", BLUE),
        (xs[1], top_y, "证据检索", "召回章节、来源与片段\n交付：引用清单", CYAN),
        (xs[2], top_y, "路径规划", "拆阶段、排优先级\n交付：路径草案", GREEN),
        (xs[0], bottom_y, "资源生成", "讲解、题目、导图与微课\n交付：资源草案", ORANGE),
        (xs[1], bottom_y, "质量审核", "引用、难度与安全边界\n交付：审核记录", RED),
        (xs[2], bottom_y, "结果评估", "完成度、错因与下一步\n交付：反馈建议", NAVY_2),
    ]
    for x, y, title, body, accent in agent_items:
        rr(c, x, y, card_w, card_h, fill=WHITE, stroke=LINE, radius=12)
        c.setFillColor(accent)
        c.circle(x + 22, y + 65, 7, fill=1, stroke=0)
        set_font(c, 10.8, bold=True, color=NAVY)
        c.drawString(x + 39, y + 61, title)
        draw_text(c, x + 16, y + 42, body, card_w - 32, size=8.8, leading=13, color=MUTED)
    panel(c, 48, 47, 746, 40, "评委观察点", "看角色交接：目标、引用、任务、审核和反馈都有可读的中间状态。", accent=BLUE, fill=PALE_BLUE, title_size=10, body_size=8.8)


def page_evidence(c):
    page_base(c, 8, "知识库与引用：让答案有来处", "07  证据链")
    draw_text(c, 48, H - 132, "项目把知识库当作“可检索的学习材料”，把引用当作“生成结果的审计轨迹”。", 740, size=13, leading=19, color=NAVY, bold=True)
    # Evidence flow.
    flow = [
        ("学习材料", "章节、要点、资源\n与适用条件", BLUE, PALE_BLUE),
        ("检索召回", "按目标、章节、难度\n与关键词取片段", CYAN, PALE_CYAN),
        ("引用绑定", "保留来源、位置\n与证据摘要", GREEN, colors.HexColor("#E7F5EE")),
        ("结果审计", "页面展示来源\n审核提示与边界", ORANGE, PALE_ORANGE),
    ]
    for i, (title, body, accent, fill) in enumerate(flow):
        x = 48 + i * 187
        rr(c, x, 325, 160, 106, fill=fill, stroke=LINE, radius=12)
        c.setFillColor(accent)
        c.circle(x + 22, 402, 11, fill=1, stroke=0)
        draw_center(c, x + 22, 398, str(i + 1), size=8.5, color=WHITE, bold=True)
        set_font(c, 11, bold=True, color=NAVY)
        c.drawString(x + 43, 397, title)
        draw_text(c, x + 16, 373, body, 128, size=8.6, leading=12, color=MUTED)
        if i < 3:
            arrow(c, x + 165, 378, x + 181, color=LINE)
    set_font(c, 10, bold=True, color=MUTED)
    c.drawString(48, 282, "当前数据底座（代码种子 + 可扩展资源表）")
    rows = [
        ("知识结构", "9 个章节 / 27 个知识点", "用于路径拆分与阶段排序"),
        ("资源索引", "27 份文档 / 54 个片段", "用于召回、引用和资源卡片"),
        ("审计字段", "来源、位置、摘要、命中理由", "用于页面解释和结果复核"),
    ]
    for i, row in enumerate(rows):
        y = 232 - i * 47
        rr(c, 48, y, 365, 36, fill=LIGHT if i % 2 == 0 else WHITE, stroke=LINE, radius=7, sw=0.5)
        set_font(c, 9.2, bold=True, color=NAVY)
        c.drawString(61, y + 20, row[0])
        set_font(c, 9.2, bold=True, color=BLUE)
        c.drawString(143, y + 20, row[1])
        set_font(c, 8.3, color=MUTED)
        c.drawString(143, y + 8, row[2])
    panel(c, 442, 92, 352, 150, "为什么这是智能体优势", "普通问答只需“答对”；学习系统还要说明：为什么推荐这份材料、它服务哪个目标、完成后如何判断下一步。引用链把这些判断变成可检查的数据结构。", accent=GREEN, fill=PALE_CYAN, title_size=11.5, body_size=9.2)
    x = 457
    for label in ("目标对应", "来源可查", "反馈可用"):
        x += pill(c, x, 110, label, fill=WHITE, color=GREEN, size=7.8, h=17, pad_x=7) + 7


def page_models(c):
    page_base(c, 9, "模型策略：可替换、可降级、可核验", "08  模型与调用")
    draw_text(c, 48, H - 132, "模型负责能力，应用负责可靠性。当前本机探针已通过；端到端新任务仍需在提交前现场复测。", 740, size=12.8, leading=18, color=NAVY, bold=True)
    cards = [
        ("主模型", "Spark MaaS", "spark-x2.5-1.7b", "SUCCESS  ·  802 ms", "用于目标理解、路径规划与内容生成", BLUE, PALE_BLUE),
        ("备用模型", "DeepSeek", "deepseek-flash", "SUCCESS  ·  696 ms", "主模型超时/异常时接管文本生成", GREEN, PALE_CYAN),
        ("语音能力", "Spark TTS", "xiaoyan", "SUCCESS  ·  已连通", "把学习讲解扩展成可听的复习材料", ORANGE, PALE_ORANGE),
    ]
    for i, (role, provider, model, status, body, accent, fill) in enumerate(cards):
        x = 48 + i * 249
        rr(c, x, 289, 229, 151, fill=fill, stroke=LINE, radius=14)
        pill(c, x + 15, 407, role, fill=WHITE, color=accent, size=8.3, h=19)
        set_font(c, 12.3, bold=True, color=NAVY)
        c.drawString(x + 15, 376, provider)
        set_font(c, 9.5, color=MUTED)
        c.drawString(x + 15, 358, model)
        set_font(c, 9.2, bold=True, color=accent)
        c.drawString(x + 15, 334, status)
        draw_text(c, x + 15, 315, body, 198, size=8.7, leading=11, color=MUTED)
    # Decision path.
    set_font(c, 10, bold=True, color=MUTED)
    c.drawString(48, 254, "运行时决策路径")
    # Main success and fallback are branches, not sequential steps.
    for x, y, w, label, accent in [
        (48, 207, 145, "请求", BLUE),
        (280, 207, 178, "Spark 尝试", BLUE),
        (566, 207, 228, "成功：直接返回", GREEN),
        (280, 161, 178, "超时/异常", ORANGE),
        (491, 161, 149, "DeepSeek 尝试", GREEN),
        (673, 161, 121, "成功返回 / 失败提示", RED),
    ]:
        rr(c, x, y, w, 34, fill=WHITE, stroke=LINE, radius=9)
        draw_center(c, x + w / 2, y + 12, label, size=8.8, color=accent, bold=True)
    arrow(c, 196, 224, 275, color=LINE)
    arrow(c, 461, 224, 560, color=LINE)
    line(c, 369, 206, 369, 196, color=ORANGE, sw=1.5)
    c.setFillColor(ORANGE)
    c.circle(369, 196, 2.5, fill=1, stroke=0)
    arrow(c, 461, 178, 486, color=LINE)
    arrow(c, 643, 178, 668, color=LINE)
    panel(c, 48, 74, 746, 78, "证据边界", "2026-09-29 本机探针结果：Spark SUCCESS、DeepSeek SUCCESS、Spark TTS SUCCESS。探针只证明密钥、网络和模型端点可用；最终交付仍要用学生账号新建任务，确认生成资源、引用和页面状态完整。", accent=RED, fill=PALE_RED, title_size=10.5, body_size=8.9)


def screenshot_page(c, num, title, kicker, image_name, subtitle, callouts, accent=BLUE):
    page_base(c, num, title, kicker)
    draw_text(c, 48, H - 132, subtitle, 730, size=12.7, leading=18, color=NAVY, bold=True)
    img = screenshot_path(image_name)
    draw_screenshot(c, img, 48, 83, 500, 353)
    # Accent frame.
    c.setStrokeColor(accent)
    c.setLineWidth(2)
    c.roundRect(48, 83, 500, 353, 10, fill=0, stroke=1)
    yy = 361
    for no, ct, body in callouts:
        callout(c, 584, yy, no, ct, body, w=197, accent=accent)
        yy -= 88
    rr(c, 584, 83, 197, 58, fill=PALE_BLUE if accent == BLUE else PALE_CYAN, stroke=None, radius=10)
    set_font(c, 8.7, bold=True, color=accent)
    c.drawString(598, 122, "SCREEN EVIDENCE")
    draw_text(c, 598, 105, "真实界面截图；演示视频应按同一流程操作。", 169, size=8.2, leading=10.5, color=MUTED)


def page_local(c):
    page_base(c, 14, "本地可运行：四步完成评委演示", "13  运行与演示")
    draw_text(c, 48, H - 132, "Docker 解决环境一致性，演示脚本解决操作一致性；评委不需要理解内部实现才能看到价值。", 740, size=12.8, leading=18, color=NAVY, bold=True)
    steps = [
        ("启动", "双击 一键启动本地演示.bat", "容器健康后打开 127.0.0.1:8000", BLUE),
        ("配置", "运行 配置并验证模型.bat", "查看 Spark / DeepSeek / TTS 探针", CYAN),
        ("体验", "登录学生账号 s001", "输入学习目标，创建一次新任务", GREEN),
        ("展示", "切换教师账号 t001", "查看学情、路径、资源与引用", ORANGE),
    ]
    for i, (title, cmd, body, accent) in enumerate(steps):
        x = 48 + i * 180
        c.setFillColor(accent)
        c.circle(x + 18, 371, 15, fill=1, stroke=0)
        draw_center(c, x + 18, 366, str(i + 1), size=10, color=WHITE, bold=True)
        set_font(c, 11, bold=True, color=NAVY)
        c.drawString(x + 43, 374, title)
        rr(c, x, 284, 160, 58, fill=LIGHT, stroke=LINE, radius=8)
        draw_text(c, x + 10, 326, cmd, 140, size=8.3, leading=11, color=BLUE, bold=True)
        draw_text(c, x + 10, 302, body, 140, size=8.2, leading=11, color=MUTED)
        if i < 3:
            arrow(c, x + 165, 367, x + 177, color=LINE)
    panel(c, 48, 160, 746, 83, "建议录屏顺序", "学生登录 -> 输入“我想在两周内掌握 Python 基础” -> 展示目标追问 -> 打开学习路径 -> 查看资源来源 -> 如生成了微课，播放六幕分镜 MP4（含语音或明确静音） -> 展示反馈。", accent=BLUE, fill=PALE_BLUE, title_size=11, body_size=9.4)
    panel(c, 48, 77, 360, 57, "必查地址", "http://127.0.0.1:8000/login/  |  学生 s001  |  教师 t001", accent=GREEN, fill=PALE_CYAN, title_size=9.8, body_size=8.5)
    panel(c, 434, 77, 360, 57, "故障时展示", "即使模型临时不可用，也要展示规则化降级提示、已有资源和引用边界。", accent=ORANGE, fill=PALE_ORANGE, title_size=9.8, body_size=8.5)


def page_security(c):
    page_base(c, 15, "安全与异常：把不可控因素关在边界外", "14  安全与边界")
    draw_text(c, 48, H - 132, "项目不把密钥、权限和模型状态暴露给用户；异常时优先保证可解释和可恢复。", 740, size=13, leading=19, color=NAVY, bold=True)
    # Trust boundary.
    rr(c, 48, 235, 265, 164, fill=PALE_BLUE, stroke=LINE, radius=14)
    set_font(c, 10, bold=True, color=BLUE)
    c.drawString(66, 375, "用户可见区")
    panel(c, 66, 277, 229, 74, "浏览器", "页面只显示数据与状态，绝不接收 API Key。", accent=BLUE, fill=WHITE, title_size=10.5, body_size=8.5)
    rr(c, 337, 235, 214, 164, fill=PALE_CYAN, stroke=LINE, radius=14)
    set_font(c, 10, bold=True, color=GREEN)
    c.drawString(355, 375, "应用控制区")
    panel(c, 355, 277, 178, 74, "Django + 任务层", "鉴权、状态机、提示词、日志、降级与数据权限。", accent=GREEN, fill=WHITE, title_size=10.5, body_size=8.5)
    rr(c, 575, 235, 219, 164, fill=PALE_ORANGE, stroke=LINE, radius=14)
    set_font(c, 10, bold=True, color=ORANGE)
    c.drawString(593, 375, "私密服务区")
    panel(c, 593, 277, 183, 74, "模型与密钥", "密钥仅由环境变量注入；日志记录模型、耗时和状态。", accent=ORANGE, fill=WHITE, title_size=10.5, body_size=8.5)
    arrow(c, 316, 317, 332, color=LINE)
    arrow(c, 555, 317, 570, color=LINE)
    set_font(c, 10, bold=True, color=MUTED)
    c.drawString(48, 198, "角色权限矩阵")
    roles = [("学生", "自己的目标、路径、资源与复盘", BLUE), ("教师", "班级聚合数据与干预建议", GREEN), ("管理者", "配置、资源与运行状态", ORANGE)]
    for i, (role, desc, accent) in enumerate(roles):
        x = 48 + i * 249
        rr(c, x, 90, 229, 82, fill=WHITE, stroke=LINE, radius=10)
        pill(c, x + 13, 145, role, fill=PALE_BLUE if accent == BLUE else (PALE_CYAN if accent == GREEN else PALE_ORANGE), color=accent, size=8.4, h=18)
        draw_text(c, x + 13, 123, desc, 198, size=8.6, leading=11.5, color=MUTED)


def page_evaluation(c):
    page_base(c, 16, "如何证明它真的可用", "15  评估与证据")
    draw_text(c, 48, H - 132, "把评委关心的“好不好”拆成三道证据闸门：可信、可靠、可持续。", 740, size=13.2, leading=19, color=NAVY, bold=True)
    gates = [
        ("01", "来源可信", "有知识结构、资源片段、引用位置和边界提示。", "已完成代码级与页面级证据", BLUE, PALE_BLUE),
        ("02", "任务可靠", "有状态机、模型降级、异常提示和本机探针。", "本机探针已通过；新 Run 待复测", GREEN, PALE_CYAN),
        ("03", "应用可持续", "有教师反馈、路径更新和后续试点指标。", "待授权试点，不虚构效果数据", ORANGE, PALE_ORANGE),
    ]
    for i, (no, title, body, status, accent, fill) in enumerate(gates):
        x = 48 + i * 249
        rr(c, x, 264, 229, 165, fill=fill, stroke=LINE, radius=14)
        set_font(c, 20, bold=True, color=accent)
        c.drawString(x + 15, 388, no)
        set_font(c, 13, bold=True, color=NAVY)
        c.drawString(x + 15, 355, title)
        draw_text(c, x + 15, 330, body, 198, size=9, leading=12, color=MUTED)
        pill(c, x + 15, 284, status, fill=WHITE, color=accent, size=7.6, h=18, pad_x=7)
    set_font(c, 10, bold=True, color=MUTED)
    c.drawString(48, 226, "提交前的最小复测矩阵")
    matrix = [
        ("学生新建任务", "能否生成路径、资源与引用", "待现场复测"),
        ("模型断开", "能否给出清晰降级提示", "代码已覆盖"),
        ("教师切换", "能否看到班级洞察与风险点", "界面已具备"),
        ("视频复现", "评委是否能按脚本完成操作", "待录制"),
    ]
    for i, row in enumerate(matrix):
        y = 192 - i * 31
        fill = LIGHT if i % 2 == 0 else WHITE
        rr(c, 48, y, 746, 24, fill=fill, stroke=LINE, radius=4, sw=0.4)
        set_font(c, 8.8, bold=True, color=NAVY)
        c.drawString(61, y + 8, row[0])
        set_font(c, 8.5, color=MUTED)
        c.drawString(176, y + 8, row[1])
        set_font(c, 8.5, bold=True, color=ORANGE if row[2] in ("待现场复测", "待录制") else GREEN)
        c.drawRightString(778, y + 8, row[2])
    panel(c, 48, 47, 746, 38, "原则", "能复现的写“已验证”，需要真实用户或公网部署的写“待试点”；透明本身就是可信度。", accent=RED, fill=PALE_RED, title_size=9.8, body_size=8.6)


def page_roadmap(c):
    page_base(c, 17, "从可演示到可规模化：下一步怎么长大", "16   prospects  ·  展望")
    draw_text(c, 48, H - 132, "现在交付的是一套可运行的应用骨架；下一阶段用真实学习过程验证推荐质量，再扩展到课程与机构。", 740, size=12.8, leading=18, color=NAVY, bold=True)
    roadmap = [
        ("0  /  可演示", "Docker 本地运行\n学生/教师双端\n模型探针与降级", BLUE, PALE_BLUE),
        ("1  /  可试点", "小规模课程试用\n新 Run 数据闭环\n教师反馈标注", GREEN, PALE_CYAN),
        ("2  /  可扩展", "课程模板市场\n多学科知识库\n公网部署与组织权限", ORANGE, PALE_ORANGE),
    ]
    for i, (stage, body, accent, fill) in enumerate(roadmap):
        x = 48 + i * 249
        rr(c, x, 274, 229, 153, fill=fill, stroke=LINE, radius=14)
        set_font(c, 10, bold=True, color=accent)
        c.drawString(x + 15, 398, stage)
        draw_text(c, x + 15, 367, body, 198, size=10, leading=15, color=NAVY, bold=True)
        if i < 2:
            arrow(c, x + 235, 349, x + 248, color=LINE)
    panel(c, 48, 150, 360, 82, "应用前景", "面向考试备考、职业技能和企业培训，把“内容生成”升级成“过程陪练 + 反馈干预”。", accent=BLUE, fill=PALE_BLUE, title_size=10.8, body_size=9)
    panel(c, 434, 150, 360, 82, "可行商业模型", "基础版按课程/席位提供；机构版增加知识库导入、教师驾驶舱和私有化部署。具体价格需以试点成本与效果数据为依据。", accent=GREEN, fill=PALE_CYAN, title_size=10.8, body_size=9)
    panel(c, 48, 68, 746, 52, "当前最重要的验证", "不是继续堆功能，而是完成一次真实学生新任务：记录目标、引用、生成耗时、学习行为和下一轮路径变化。", accent=ORANGE, fill=PALE_ORANGE, title_size=10.2, body_size=8.8)


def page_delivery(c):
    page_base(c, 18, "交付清单：让评委打开就能看、按步骤就能跑", "17  交付与提交")
    draw_text(c, 48, H - 132, "按官方提交字段拆开准备，避免“项目做完了，但评委看不到”的最后一公里。", 740, size=13.2, leading=19, color=NAVY, bold=True)
    items = [
        ("应用方案 PDF", "18 / 20 页以内；单文件 <= 200 MB", "本版已完成，直接上传 ICAN_复赛应用方案.pdf", GREEN),
        ("演示视频 MP4", "<= 5 分钟；完整展示请求 -> 分析 -> 协作 -> 结果", "需要本地录制一次真实新 Run", ORANGE),
        ("可运行程序", "提供公网 HTTPS 链接或可获取的源码", "Docker 本地已就绪；公网链接/仓库地址待填写", BLUE),
        ("硬件材料", "仅硬件项目填写设计说明与实物照片 ZIP", "本软件智能体项目不适用，保持空白", MUTED),
    ]
    for i, (title, rule, status, accent) in enumerate(items):
        y = 348 - i * 59
        rr(c, 48, y, 746, 45, fill=WHITE if i % 2 == 0 else LIGHT, stroke=LINE, radius=8, sw=0.6)
        c.setFillColor(accent)
        c.circle(68, y + 23, 9, fill=1, stroke=0)
        draw_center(c, 68, y + 20, str(i + 1), size=7.5, color=WHITE, bold=True)
        set_font(c, 10.2, bold=True, color=NAVY)
        c.drawString(88, y + 27, title)
        set_font(c, 8.5, color=MUTED)
        c.drawString(88, y + 11, rule)
        set_font(c, 8.5, bold=True, color=accent)
        c.drawRightString(778, y + 20, status)
    panel(c, 48, 80, 360, 75, "本地材料", "智训云学_ICAN_评委交付包.zip\n智训云学_ICAN_2026_去敏源码.zip\nREADME + 部署说明 + 演示脚本", accent=BLUE, fill=PALE_BLUE, title_size=10.5, body_size=8.7)
    panel(c, 434, 80, 360, 75, "安全检查", "上传前确认：.env 不进仓库、API Key 不进 PDF/视频、日志不打印密钥、链接不是 localhost。", accent=RED, fill=PALE_RED, title_size=10.5, body_size=8.7)
    set_font(c, 8.5, bold=True, color=ORANGE)
    c.drawString(48, 59, "最后动作：录制 5 分钟演示视频 -> 填写公网源码/运行链接 -> 上传本 PDF -> 保存提交回执。")


def page_screens(c):
    screenshot_page(
        c, 10, "学生端：先把目标说清楚", "09  界面证据  /  学生端",
        "student-home.png",
        "首页不是聊天框，而是一个把目标、时间、基础和学习偏好结构化的任务入口。",
        [
            (1, "目标入口", "输入一句话目标后，系统可继续追问时间、基础和重点范围。"),
            (2, "任务状态", "资源、路径和练习不是孤立卡片，而是围绕一个任务组织。"),
            (3, "可继续迭代", "完成与反馈会回到下一轮路径，而不是一次性答案。"),
        ],
        accent=BLUE,
    )


def page_path(c):
    screenshot_page(
        c, 11, "学习路径：把结果变成下一步行动", "10  界面证据  /  路径",
        "learning-path.png",
        "路径页把复杂目标拆成阶段、知识点和资源，评委可直接观察推荐逻辑是否落到页面。",
        [
            (1, "阶段排序", "先基础、后综合；每个阶段有明确的完成条件。"),
            (2, "资源绑定", "每个节点都能看到材料类型、预计用时和来源。"),
            (3, "复盘节点", "学习结果进入薄弱点与下一轮建议，形成动态路径。"),
        ],
        accent=GREEN,
    )


def page_mindmap(c):
    screenshot_page(
        c, 12, "思维导图：让知识结构可见", "11  界面证据  /  知识结构",
        "mindmap.png",
        "思维导图是知识库与生成结果之间的可视化桥梁，帮助学生理解“为什么先学这个”。",
        [
            (1, "中心目标", "从当前学习目标出发，而不是从随机关键词出发。"),
            (2, "依赖关系", "知识点之间的先后与关联被显式呈现。"),
            (3, "可点击回溯", "节点可以关联资源、练习和引用，降低认知跳跃。"),
        ],
        accent=CYAN,
    )


def page_teacher(c):
    screenshot_page(
        c, 13, "教师端：从数据看见干预机会", "12  界面证据  /  教师端",
        "teacher-home.png",
        "教师端不替教师做决定，而是把班级共性问题、风险点和下一步干预集中呈现。",
        [
            (1, "班级分布", "看完成度、薄弱章节与资源使用，不只看单个分数。"),
            (2, "风险提示", "把需要关注的学生与原因放在同一视图。"),
            (3, "干预建议", "建议可回到资源与任务，形成教师可执行动作。"),
        ],
        accent=ORANGE,
    )


def build(destination=OUT):
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    c = canvas.Canvas(str(destination), pagesize=(W, H))
    c.setTitle("智训云学 - ICAN 2026 复赛应用方案")
    c.setAuthor("智训云学项目组")
    page_cover(c); c.showPage()
    page_problem(c); c.showPage()
    page_users(c); c.showPage()
    page_requirements(c); c.showPage()
    page_workflow(c); c.showPage()
    page_architecture(c); c.showPage()
    page_agents(c); c.showPage()
    page_evidence(c); c.showPage()
    page_models(c); c.showPage()
    page_screens(c); c.showPage()
    page_path(c); c.showPage()
    page_mindmap(c); c.showPage()
    page_teacher(c); c.showPage()
    page_local(c); c.showPage()
    page_security(c); c.showPage()
    page_evaluation(c); c.showPage()
    page_roadmap(c); c.showPage()
    page_delivery(c); c.showPage()
    c.save()
    return destination


if __name__ == "__main__":
    print(build())
