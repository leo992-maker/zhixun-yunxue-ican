"""Build a source-only review ZIP. Never package local credentials or user uploads.

Run from any directory: python tools/create_ican_release.py [output.zip]
"""

from __future__ import annotations

import re
import sys
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_DIRS = {
    ".git", ".idea", ".venv", ".venv-ready", ".venv-local", "__pycache__",
    ".pytest_cache", "node_modules", "staticfiles", "media", "backups",
    "release", "work", "outputs", "tmp", ".agents", ".codex", "browser_sessions",
}
EXCLUDED_NAMES = {".env", "public-demo.env", "local-demo.env", ".server-state.json", "db.sqlite3"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".log", ".zip", ".sql"}
PUBLIC_SCHEMA = "employment_ai_platform_optimized.sql"
REQUIRED_DELIVERY = {
    "manage.py", "requirements.txt", PUBLIC_SCHEMA,
    "init_db.py", "upgrade_db.py", "seed_demo_data.py",
    "demo_assets/student_training_demo.py", "demo_assets/student_training_demo_v1.py",
    "一键启动本地演示.bat", "scripts/start_local_demo.ps1",
    "deploy/Dockerfile", "deploy/compose.local.yaml", "deploy/public-demo.env.example",
}
TEXT_SUFFIXES = {".py", ".md", ".html", ".js", ".css", ".json", ".txt", ".ps1", ".bat", ".example", ".svg", ".sql"}
SECRET_NAME = re.compile(r"(?:PASSWORD|SECRET|API_KEY|TOKEN|APP_ID)", re.I)
KEY_ASSIGNMENT = re.compile(r"(?im)^[ \t]*([A-Z_]*(?:PASSWORD|SECRET|API_KEY|TOKEN|APP_ID)[A-Z_]*)[ \t]*=[ \t]*([^\r\n]*)$")


def private_values(source: Path) -> set[str]:
    values = set()
    for env in (source / ".env", source / "deploy" / "public-demo.env", source / "deploy" / "local-demo.env"):
        if env.exists():
            for line in env.read_text(encoding="utf-8-sig").splitlines():
                if "=" not in line or line.lstrip().startswith("#"):
                    continue
                name, raw = line.split("=", 1)
                value = raw.strip().strip('"\'')
                if SECRET_NAME.search(name) and len(value) >= 8:
                    values.add(value)
    return values


def collect(source: Path, output: Path) -> list[tuple[Path, Path]]:
    files = []
    for path in source.rglob("*"):
        if not path.is_file() or path == output:
            continue
        relative = path.relative_to(source)
        if any(part in EXCLUDED_DIRS or part.startswith("release_staging_") for part in relative.parts[:-1]):
            continue
        if relative.name in EXCLUDED_NAMES or (relative.suffix.lower() in EXCLUDED_SUFFIXES and relative.name != PUBLIC_SCHEMA):
            continue
        if relative.name.startswith(".env") or relative.name.endswith(".env"):
            continue
        if relative.parts[:2] == ("docs", "screenshots"):
            continue
        files.append((path, relative))
    return sorted(files, key=lambda item: str(item[1]))


def validate(source: Path, files: list[tuple[Path, Path]]) -> None:
    names = {str(relative) for _, relative in files}
    if "manage.py" not in names:
        raise ValueError("缺少 manage.py，停止打包")
    if source == ROOT:
        missing = REQUIRED_DELIVERY - names
        if missing:
            raise ValueError("缺少启动或首次安装文件，停止打包：" + ", ".join(sorted(missing)))
    secrets = private_values(source)
    for path, relative in files:
        if path.suffix.lower() not in TEXT_SUFFIXES or path.stat().st_size > 2_000_000:
            continue
        content = path.read_text(encoding="utf-8-sig")
        if any(value in content for value in secrets):
            raise ValueError(f"检测到与私有配置相同的凭据：{relative}（值不输出）")
        if relative.name == "public-demo.env.example":
            for name, raw in KEY_ASSIGNMENT.findall(content):
                value = raw.strip().strip('"\'')
                if value and not re.fullmatch(r"(?:AUTO_GENERATE_ON_FIRST_RUN|change[-_ ]?me|your[-_ ].*|example|placeholder)", value, re.I):
                    raise ValueError(f"public-demo.env.example 含非空凭据字段：{name}（值不输出）")


def build(source: Path, output: Path) -> int:
    files = collect(source, output)
    validate(source, files)
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path, relative in files:
            archive.write(path, f"智训云学_ICAN_2026/{relative.as_posix()}")
    with zipfile.ZipFile(output) as archive:
        bad = [name for name in archive.namelist() if any(
            part in EXCLUDED_DIRS or part in EXCLUDED_NAMES
            for part in Path(name).parts
        )]
        if bad:
            output.unlink(missing_ok=True)
            raise ValueError("ZIP 复核发现禁止文件，已删除输出")
    return len(files)


if __name__ == "__main__":
    destination = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT.parent / "智训云学_ICAN_2026_去敏源码.zip"
    count = build(ROOT, destination)
    print(f"已打包 {count} 个源码/文档文件：{destination}")
    print("发布前还须人工核查个人资料、Git 历史和演示账号，并轮换原始 ZIP 中的凭据。")
