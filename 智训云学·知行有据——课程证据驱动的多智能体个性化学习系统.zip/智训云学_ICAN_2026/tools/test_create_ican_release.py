import tempfile
import unittest
import zipfile
from pathlib import Path

from create_ican_release import build


class ReleaseTests(unittest.TestCase):
    def test_excludes_secret_and_private_content(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "manage.py").write_text("print('ok')", encoding="utf-8")
            (root / ".env").write_text("API_KEY=private-example-secret\n", encoding="utf-8")
            (root / "media").mkdir()
            (root / "media" / "student.txt").write_text("private", encoding="utf-8")
            (root / "deploy").mkdir()
            (root / "deploy" / "public-demo.env").write_text("MYSQL_PASSWORD=private-example-secret", encoding="utf-8")
            (root / "deploy" / "local-demo.env").write_text("SPARK_API_PASSWORD=private-example-secret", encoding="utf-8")
            out = root / "release.zip"
            build(root, out)
            with zipfile.ZipFile(out) as archive:
                names = archive.namelist()
                self.assertTrue(any(name.endswith("manage.py") for name in names))
                self.assertFalse(any("student.txt" in name or name.endswith("/.env") or name.endswith("public-demo.env") or name.endswith("local-demo.env") for name in names))

    def test_rejects_leaked_private_value(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "manage.py").write_text("private-example-secret", encoding="utf-8")
            (root / ".env").write_text("API_KEY=private-example-secret\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                build(root, root / "release.zip")

    def test_rejects_leaked_local_model_key(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "manage.py").write_text("# leaked-local-demo-key", encoding="utf-8")
            (root / "deploy").mkdir()
            (root / "deploy" / "local-demo.env").write_text(
                "SPARK_API_PASSWORD=leaked-local-demo-key\n", encoding="utf-8"
            )
            with self.assertRaises(ValueError):
                build(root, root / "release.zip")


if __name__ == "__main__":
    unittest.main()
