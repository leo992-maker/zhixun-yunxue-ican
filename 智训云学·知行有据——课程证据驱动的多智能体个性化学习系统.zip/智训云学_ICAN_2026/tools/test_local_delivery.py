import os
import unittest
from unittest.mock import patch

from bootstrap_public_demo import require_public_config


class DemoConfigTests(unittest.TestCase):
    def setUp(self):
        self.valid = {
            "MYSQL_PASSWORD": "m" * 30,
            "DJANGO_SECRET_KEY": "k" * 64,
            "DEMO_ADMIN_PASSWORD": "a" * 24,
            "DEMO_TEACHER_PASSWORD": "t" * 24,
            "DEMO_STUDENT_PASSWORD": "s" * 24,
        }

    def test_local_launch_needs_no_domain_but_validates_randomized_passwords(self):
        with patch.dict(os.environ, {**self.valid, "DEMO_MODE": "local", "DEMO_DOMAIN": ""}, clear=True):
            require_public_config()
        with patch.dict(os.environ, {**self.valid, "DEMO_MODE": "local", "DEMO_STUDENT_PASSWORD": "a" * 24}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "different passwords"):
                require_public_config()

    def test_public_launch_still_requires_a_real_domain(self):
        with patch.dict(os.environ, {**self.valid, "DEMO_MODE": "", "DEMO_DOMAIN": "demo.example.com"}, clear=True):
            with self.assertRaisesRegex(RuntimeError, "real DEMO_DOMAIN"):
                require_public_config()

if __name__ == "__main__":
    unittest.main()
