"""Regression checks for editable PPT content and verifiable references."""

import unittest
from types import SimpleNamespace

from agent_learning.services.ppt_export import build_teaching_deck


def sample_resource():
    titles = ["异常捕获顺序", "本节学习目标", "知识结构", "核心概念", "示例代码",
              "易错点对比", "即时练习", "总结与下一步", "内容依据"]
    slides = [
        {"title": title, "core_content": ["异常应按具体类型优先处理", "先预测结果，再验证原因"],
         "code": "", "visual_note": ""}
        for title in titles
    ]
    slides[2]["core_content"] = ["前置：异常类型", "当前：处理顺序", "示例：预测输出", "练习：改写代码"]
    slides[4]["code"] = "try:\n    int('x')\nexcept ValueError:\n    print('value')"
    slides[8]["core_content"] = ["不存在的教材第999页"]
    return SimpleNamespace(
        content={"slides": slides}, knowledge_base=SimpleNamespace(name="Python程序设计"),
        knowledge_point=SimpleNamespace(title="异常捕获顺序"),
        learning_objective="20分钟理解具体异常与通用异常的顺序",
        adaptation_reason="先观察错误，再对照具体类型",
        generation_source_label="规则降级生成，在线模型未返回有效结果",
        version_no=1,
        citations=[{"document": "课程组讲义", "chapter": "异常处理", "chunk_no": 3, "document_version": 2}],
    )


class PPTExportTests(unittest.TestCase):
    def test_native_flow_and_real_citations(self):
        deck = build_teaching_deck(sample_resource())
        self.assertEqual(len(deck.slides), 9)
        self.assertAlmostEqual(deck.slide_width / deck.slide_height, 16 / 9, places=2)
        flow = " ".join(shape.text for shape in deck.slides[2].shapes if shape.has_text_frame)
        refs = " ".join(shape.text for shape in deck.slides[8].shapes if shape.has_text_frame)
        self.assertIn("练习：改写代码", flow)
        self.assertIn("课程组讲义", refs)
        self.assertIn("片段3", refs)
        self.assertNotIn("不存在的教材", refs)

    def test_missing_sources_are_disclosed(self):
        resource = sample_resource()
        resource.citations = []
        deck = build_teaching_deck(resource)
        refs = " ".join(shape.text for shape in deck.slides[8].shapes if shape.has_text_frame)
        self.assertIn("未关联可核验", refs)


if __name__ == "__main__":
    unittest.main()
