"""Protect cmd.exe and Windows PowerShell 5.1 launch compatibility."""

import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class WindowsEntrypointTests(unittest.TestCase):
    def test_batch_crlf_and_powershell_utf8_bom(self):
        pairs = {
            "一键启动本地演示.bat": "start_local_demo.ps1",
            "配置并验证模型.bat": "configure_local_models.ps1",
            "查看本地运行状态.bat": "status_local_demo.ps1",
            "停止本地演示.bat": "stop_local_demo.ps1",
            "重置本地演示数据.bat": "reset_local_demo.ps1",
        }
        for batch, script in pairs.items():
            with self.subTest(batch=batch):
                batch_bytes = (ROOT / batch).read_bytes()
                self.assertTrue(batch_bytes.isascii())
                self.assertEqual(batch_bytes.count(b"\n"), batch_bytes.count(b"\r\n"))
                self.assertIn(script.encode("ascii"), batch_bytes)
                self.assertTrue((ROOT / "scripts" / script).read_bytes().startswith(b"\xef\xbb\xbf"))

    def test_local_passwords_are_written_as_complete_lines(self):
        source = (ROOT / "scripts" / "start_local_demo.ps1").read_text(encoding="utf-8-sig")
        for name, variable in {
            "MYSQL_PASSWORD": "databasePassword",
            "DJANGO_SECRET_KEY": "djangoSecret",
            "DEMO_ADMIN_PASSWORD": "adminPassword",
            "DEMO_TEACHER_PASSWORD": "teacherPassword",
            "DEMO_STUDENT_PASSWORD": "studentPassword",
        }.items():
            with self.subTest(name=name):
                self.assertIn(f'"{name}=${variable}"', source)
                self.assertNotIn(f"'{name}=' +", source)
        self.assertIn("$existingVolumes.Count -gt 0", source)

    def test_local_build_avoids_remote_dockerfile_frontend(self):
        # A syntax directive triggers an extra Docker Hub authentication request.
        # The local demo must use Docker Desktop's bundled BuildKit frontend.
        dockerfile = (ROOT / "deploy" / "Dockerfile").read_text()
        self.assertTrue(dockerfile.startswith("FROM python:3.12-slim\n"))
        self.assertNotIn("# syntax=", dockerfile)
        self.assertIn("Acquire::Retries=8", dockerfile)
        self.assertIn("--mount=type=cache", dockerfile)


if __name__ == "__main__":
    unittest.main()
