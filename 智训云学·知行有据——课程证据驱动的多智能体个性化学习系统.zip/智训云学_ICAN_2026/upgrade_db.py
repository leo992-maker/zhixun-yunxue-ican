"""Non-destructive upgrade for the B1 evaluation workflow.

Unlike ``init_db.py`` this command never drops a table.  It creates missing B1
tables and indexes, widens the password hash column, and can rotate only the
documented competition demo accounts.
"""

import argparse
import os
import re
from pathlib import Path

import django
import pymysql
from dotenv import load_dotenv

from app.services.identity_service import DEMO_TEACHER_NAMES
from init_db import iter_mysql_script


BASE_DIR = Path(__file__).resolve().parent
SQL_FILE = BASE_DIR / "employment_ai_platform_optimized.sql"
START_MARKER = "CREATE TABLE score_weight_config"
END_MARKER = "第6步：创建存储过程和触发器"
DEMO_PASSWORDS = {
    "admin": "Admin@B1Demo",
    "t001": "Teacher@B1",
    "t002": "Teacher@B2",
    "t003": "Teacher@B3",
    "s001": "Student@B1",
    "s002": "Student@B2",
    "s003": "Student@B3",
    "s004": "Student@B4",
    "s005": "Student@B5",
}


def runtime_sql():
    source = SQL_FILE.read_text(encoding="utf-8")
    start = source.index(START_MARKER)
    marker = source.index(END_MARKER, start)
    end = source.rfind("/* =========================================================", start, marker)
    fragment = source[start:end]
    return iter_mysql_script(fragment)


def index_exists(cursor, table, index):
    cursor.execute(
        "SELECT 1 FROM information_schema.statistics "
        "WHERE table_schema=%s AND table_name=%s AND index_name=%s LIMIT 1",
        (os.getenv("MYSQL_DATABASE", "employment_ai_platform"), table, index),
    )
    return cursor.fetchone() is not None


def repair_demo_teacher_names(cursor):
    """Correct only owned demo-teacher profiles; never touch passwords or ordinary users."""
    updated = 0
    for username, natural_name in DEMO_TEACHER_NAMES.items():
        cursor.execute(
            "UPDATE user_account AS u "
            "JOIN role_info AS r ON r.role_id=u.role_id "
            "SET u.real_name=%s "
            "WHERE u.username=%s AND r.role_name=%s AND u.real_name<>%s",
            (natural_name, username, "教师", natural_name),
        )
        updated += cursor.rowcount
    return updated


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--reset-demo-passwords",
        action="store_true",
        help="rotate only admin/t001/t002/s001-s005 to the documented strong demo passwords",
    )
    args = parser.parse_args()

    load_dotenv(BASE_DIR / ".env")
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "myproject.settings")
    django.setup()
    from django.contrib.auth.hashers import make_password

    connection = pymysql.connect(
        host=os.getenv("MYSQL_HOST", "127.0.0.1"),
        user=os.getenv("MYSQL_USER", "root"),
        password=os.getenv("MYSQL_PASSWORD", ""),
        port=int(os.getenv("MYSQL_PORT", "3306")),
        database=os.getenv("MYSQL_DATABASE", "employment_ai_platform"),
        charset="utf8mb4",
        autocommit=False,
    )
    created_or_checked = 0
    repaired_teacher_names = 0
    try:
        with connection.cursor() as cursor:
            cursor.execute("ALTER TABLE user_account MODIFY password VARCHAR(128) NOT NULL")
            for statement in runtime_sql():
                normalized = statement.strip()
                if normalized.upper().startswith("CREATE TABLE "):
                    normalized = re.sub(
                        r"^CREATE TABLE\s+", "CREATE TABLE IF NOT EXISTS ", normalized, count=1, flags=re.I
                    )
                index_match = re.match(
                    r"CREATE INDEX\s+(`?\w+`?)\s+ON\s+(`?\w+`?)", normalized, flags=re.I
                )
                if index_match:
                    index_name = index_match.group(1).strip("`")
                    table_name = index_match.group(2).strip("`")
                    if index_exists(cursor, table_name, index_name):
                        continue
                cursor.execute(normalized)
                created_or_checked += 1

            cursor.execute("SELECT user_id, password FROM user_account")
            for user_id, stored in cursor.fetchall():
                if not str(stored).startswith(("pbkdf2_", "argon2$", "bcrypt")):
                    cursor.execute(
                        "UPDATE user_account SET password=%s WHERE user_id=%s",
                        (make_password(stored), user_id),
                    )

            repaired_teacher_names = repair_demo_teacher_names(cursor)

            if args.reset_demo_passwords:
                for username, raw_password in DEMO_PASSWORDS.items():
                    cursor.execute(
                        "UPDATE user_account SET password=%s WHERE username=%s",
                        (make_password(raw_password), username),
                    )
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()

    print(f"B1 schema upgrade complete; {created_or_checked} DDL statements applied or checked.")
    print(f"Demo teacher profile corrections applied: {repaired_teacher_names}.")
    if args.reset_demo_passwords:
        print("Competition demo passwords rotated; no password value was printed.")


if __name__ == "__main__":
    main()
