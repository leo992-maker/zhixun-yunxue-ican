@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\configure_local_models.ps1"
set "demo_exit=%errorlevel%"
if not "%demo_exit%"=="0" echo Operation failed. See the message above.
echo.
pause
exit /b %demo_exit%
