@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\reset_local_demo.ps1"
set "demo_exit=%errorlevel%"
echo.
pause
exit /b %demo_exit%
